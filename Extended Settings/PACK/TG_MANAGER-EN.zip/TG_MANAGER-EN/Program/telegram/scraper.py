"""
Module pour le scraping des membres d'un groupe ou canal Telegram.

Ce module contient les fonctions nécessaires pour récupérer
la liste des membres d'un groupe ou canal source et suivre les membres
du groupe ou canal cible.
"""
import csv
import asyncio
import logging
from typing import List, Dict, Optional, Union, Tuple
import sys
from datetime import datetime, timedelta

from telethon._updates import Entity
from telethon.tl.types import User, Channel, Chat, TypeChat, TypeUser
from telethon.errors import ChannelPrivateError, UserPrivacyRestrictedError
from telethon.tl.functions.channels import GetFullChannelRequest, GetParticipantsRequest
from telethon.tl.types import ChannelParticipantsSearch, InputPeerChannel

from database.db_manager import db_manager
from config.settings import Config
from utils.logger import logger

# Configuration du logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Config.LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)

class EntityScraper:
    """Classe de base pour le scraping de l'entité Telegram."""
    
    def __init__(self, client):
        """Initialise le scraper avec un client Telethon."""
        self.client = client
        self.processed_members = set()
        self.last_update = datetime.now()
        
    async def _get_entity(self, entity_identifier: str) -> Optional[Union[Channel, Chat]]:
        """Récupère l'entité d'un groupe ou canal à partir de son identifiant."""
        try:
            return await self.client.get_entity(entity_identifier)
        except Exception as e:
            logger.error(f"Error getting entity {entity_identifier}: {e}")
            return None

class SourceEntityScraper(EntityScraper):
    """
    Gère le scraping des membres d'un groupe ou canal source et la mise à jour
    des membres existants dans le groupe ou canal cible.
    """
    
    def __init__(self, client, target_entity_link: str = None):
        """
        Initialise le scraper du groupe ou canal source avec une référence au groupe ou canal cible.
        
        Args:
            client: Client Telethon authentifié
            target_entity_link: Lien ou identifiant du groupe ou canal cible (optionnel)
        """
        super().__init__(client)
        self.target_entity_link = target_entity_link
        self.target_entity = None
        self.last_target_sync = None

    async def get_members(self, entity_link: str, limit: int = None) -> Tuple[List[Dict], int]:
        """
        Récupère les membres d'un groupe ou canal source avec gestion des délais et des erreurs.
        
        Args:
            entity_link: Lien ou identifiant du groupe ou canal source
            limit: Nombre maximum de membres à récupérer (optionnel) """
                
        members = []
        existing_count = 0
        processed_count = 0
        start_time = datetime.now()
        
        try:
            # Récupération de l'entité du groupe ou canal source
            entity = await self._get_entity(entity_link)
            if not entity:
                return [], 0
                
            # Vérification des autorisations
            if not await self._check_permissions(entity):
                return [], 0
            
            # Configuration optimisée pour plus de rapidité
            request_delay = 3  # Réduit à 3 secondes entre les requêtes (au lieu de 15)
            last_request = datetime.now() - timedelta(seconds=request_delay)
            
            # Essayer de récupérer le nombre total de membres pour afficher la progression
            total_members = 0
            try:
                if isinstance(entity, Channel):
                    full_chat = await self.client(GetFullChannelRequest(channel=entity))
                    if hasattr(full_chat.full_chat, 'participants_count'):
                        total_members = full_chat.full_chat.participants_count
                elif isinstance(entity, Chat):
                    full_chat = await self.client(GetFullChatRequest(chat_id=entity.id))
                    if hasattr(full_chat.full_chat, 'participants_count'):
                        total_members = full_chat.full_chat.participants_count

                logger.info(f"Starting entity scraping: {getattr(entity, 'title', 'Unknown')} ({total_members} members)")
            except Exception as e:
                logger.warning(f"Unable to retrieve total member count: {e}")
                logger.info(f"Starting entity scraping: {getattr(entity, 'title', 'Unknown')}")
            # Augmenter la taille des lots pour réduire le nombre de requêtes
            batch_size = 200  # Augmenté à 200 membres par lot (au lieu de 100)
            offset = 0
            
            while True:
                try:
                    # Gestion du délai entre les requêtes (version plus légère)
                    now = datetime.now()
                    time_since_last = (now - last_request).total_seconds()
                    if time_since_last < request_delay:
                        wait_time = request_delay - time_since_last
                        # Reduce the frequency of wait time logs for faster processing
                        if wait_time > 1 and offset % 500 == 0:  # Only log every 500 entries
                            logger.info(f"Waiting for {wait_time:.1f}s...")
                        await asyncio.sleep(wait_time)
                    
                    # Retrieve a batch of members
                    logger.info(f"Retrieving members {offset+1} to {offset+batch_size}...")
                    participants = await self.client(GetParticipantsRequest(
                        channel=entity,
                        filter=ChannelParticipantsSearch(''),
                        offset=offset,
                        limit=batch_size,
                        hash=0
                    ))
                    last_request = datetime.now()
                    
                    if not participants.users:
                        break  # Plus de membres à récupérer
                        
                    for user in participants.users:
                        processed_count += 1
                        
                        # Display progress with percentage in real-time
                        if processed_count % 20 == 0 or processed_count == 1:  # Display more frequently
                            progress = f"[Processing: {processed_count}"
                            if total_members > 0:
                                percent = (processed_count / total_members) * 100
                                progress += f" / {total_members} ({min(100.0, percent):.1f}%)"
                            progress += "]"
                            
                            # Use a newline to update in place
                            if hasattr(sys.stdout, 'isatty') and sys.stdout.isatty():
                                # In interactive console mode, use backspace to overwrite the line
                                sys.stdout.write("\r" + " " * 100 + "\r")  # Clear the line
                                sys.stdout.write(f"{progress} Unique members: {len(members)}")
                                sys.stdout.flush()
                            else:
                                # Otherwise, do a simple log
                                logger.info(f"{progress} Unique members: {len(members)}")
                        
                        if not isinstance(user, User) or user.bot or user.deleted:
                            continue
                        members.append(self._format_member(user))
                        
                        # Arrêter si la limite est atteinte
                        if limit and len(members) >= limit:
                            break
                    
                    offset += batch_size
                    
                    # Arrêter si la limite est atteinte
                    if limit and len(members) >= limit:
                        break
                        
                except Exception as e:
                    logger.error(f"Error retrieving members: {e}")
                    # In case of error, wait longer before retrying
                    retry_delay = 60  # Wait 60 seconds before retrying
                    logger.info(f"New attempt in {retry_delay} seconds...")
                    await asyncio.sleep(retry_delay)
                    
            # Affichage du résumé
            duration = (datetime.now() - start_time).total_seconds()
            # Aller à la ligne après la barre de progression
            if hasattr(sys.stdout, 'isatty') and sys.stdout.isatty():
                print()  # Nouvelle ligne après la barre de progression
                
            logger.info(f"Retrieval completed in {duration:.1f} seconds. {len(members)} unique members found on {processed_count} processed.")
            
            # Afficher un résumé des membres exclus
            if processed_count > len(members):
                logger.info(f"Members excluded (bots, deleted accounts, etc.): {processed_count - len(members)}")
            logger.info("="*50)
            logger.info(f"Members processed:  {processed_count}")
            logger.info(f"Unique members:  {len(members)}")
            logger.info(f"Already members:     {existing_count}")
            logger.info(f"Time elapsed:    {duration:.1f} seconds")
            logger.info("="*50 + "\n")
            
            # Save members to a CSV file
            if members:
                from config.settings import Config
                # ✅ Nom du fichier CSV personnalisé avec numéro de compte et nom du groupe
                try:
                    # Obtenir les informations du compte connecté
                    me = await self.client.get_me()
                    account_phone = getattr(me, 'phone', None)
                    
                    # Obtenir le lien du groupe source pour le nom du fichier
                    # Nettoyer le lien du groupe pour l'utiliser dans un nom de fichier
                    import re
                    # Extraire le nom du lien (ex: https://t.me/groupname -> groupname)
                    if 't.me/' in entity_link:
                        clean_entity_link = entity_link.split('t.me/')[-1]
                    else:
                        clean_entity_link = entity_link
                    
                    # Nettoyer le lien pour le nom de fichier
                    clean_entity_link = re.sub(r'[^\w\s-]', '', clean_entity_link)
                    clean_entity_link = re.sub(r'[-\s]+', '_', clean_entity_link)
                    clean_entity_link = clean_entity_link[:50]  # Limiter la longueur
                    
                    if account_phone and account_phone != 'unknown_account':
                        # Nettoyer le numéro de téléphone pour l'utiliser comme nom de fichier
                        # Remplacer uniquement les caractères non valides pour les noms de fichiers, mais garder le +
                        clean_phone = account_phone.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
                        # Format préféré : members_+phone_grouplink.csv
                        csv_file = f"csv_data/members_+{clean_phone}_{clean_entity_link}.csv"
                        print(f"✅ Custom CSV file name: {csv_file}")
                    else:
                        # Fallback si le numéro n'est pas disponible - utiliser un timestamp pour éviter les conflits
                        import time
                        timestamp = int(time.time())
                        csv_file = f"csv_data/members_unknown_{clean_entity_link}_{timestamp}.csv"
                        print(f"⚠️  Account number not detected, using : {csv_file}")
                except Exception as e:
                    # En cas d'erreur pour obtenir les infos du compte
                    import time
                    timestamp = int(time.time())
                    csv_file = f"csv_data/members_error_{timestamp}.csv"
                    print(f"⚠️  Error while detecting the account number, using : {csv_file}")
                    logger.warning(f"Failed to obtain account information: {e}")
                
                if await self._save_to_csv(members, csv_file):
                    logger.info(f"✅ {len(members)} members saved to {csv_file}")
                else:
                    logger.error(f"❌ Failed to save CSV file: {csv_file}")
            
            return members, existing_count
            
        except Exception as e:
            logger.error(f"Error during members retrieval: {e}")
            return [], 0
            
    def _format_member(self, user) -> dict:
        """
        Formate les informations d'un membre pour le stockage.
        
        Args:
            user: Objet utilisateur Telethon
            
        Returns:
            dict: Dictionnaire contenant les informations formatées du membre
        """
        return {
            'id': user.id,
            'username': user.username or '',
            'first_name': user.first_name or '',
            'last_name': user.last_name or '',
            'phone': user.phone or ''
        }
        
    async def _check_permissions(self, entity) -> bool:
        """
        Vérifie les permissions nécessaires pour le scraping.
        
        Pour les groupes publics, on peut récupérer les membres même sans être admin.
        Pour les groupes privés, il faut être admin avec les droits appropriés.
        """
        try:
            # Essayer de récupérer les participants (fonctionne pour les groupes publics)
            # On limite à 1 pour vérifier rapidement les permissions
            try:
                await self.client.get_participants(entity, limit=1)
                return True
            except (ChannelPrivateError, ValueError) as e:
                # Si c'est un groupe privé, on essaie une autre approche
                if hasattr(entity, 'broadcast') and entity.broadcast:
                    logger.error("Unable to scrape a broadcast channel.")
                    return False
                
                # Pour les groupes privés, vérifier si on est admin
                if hasattr(entity, 'admin_rights'):
                    if entity.admin_rights and entity.admin_rights.add_admins:
                        return True
                
                # Vérifier les droits via les informations du chat
                try:
                    full_chat = await self.client(GetFullChannelRequest(channel=entity))
                    if hasattr(full_chat, 'participants_count'):
                        # Si on peut voir le nombre de participants, on peut probablement les lister
                        return True
                except Exception:
                    pass
                
                logger.error(
                    "Access denied to the group or channel. For private groups or channels, you must be an administrator "
                    "with the right to view participants."
                )
                return False
                
        except Exception as e:
            logger.error(f"Error checking permissions: {e}")
            return False
            
    async def _fetch_members(self, entity, limit: int = 0) -> List[Dict]:
        """
        Récupère les membres d'une entité (groupe ou canal).
        
        Args:
            entity: Entité Telethon (groupe/canal)
            limit: Nombre maximum de membres à récupérer (0 pour tous)
            
        Returns:
            Liste des membres avec leurs informations
        """
        members = []
        try:
            logger.info(f"Starting member retrieval for {getattr(entity, 'title', 'unknown entity')}")
            
            # Determine the type of entity
            is_channel = hasattr(entity, 'broadcast') or (hasattr(entity, 'megagroup') and entity.megagroup)
            
            # Retrieve participants
            async for user in self.client.iter_participants(
                entity,
                limit=limit if limit > 0 else None,
                aggressive=not is_channel  # Mode agressif pour les groupes ou canaux normaux
            ):
                if user.bot or user.deleted or user.is_self:
                    continue
                    
                member_info = {
                    'id': user.id,
                    'username': user.username or '',
                    'first_name': user.first_name or '',
                    'last_name': user.last_name or '',
                    'phone': user.phone or '',
                    'access_hash': user.access_hash if hasattr(user, 'access_hash') else 0,
                    'scraped_at': datetime.now().isoformat()
                }
                members.append(member_info)
                
                # Display progress
                if len(members) % 100 == 0:
                    logger.info(f"{len(members)} members retrieved...")
            
            logger.info(f"Members retrieval completed. {len(members)} members found.")
            return members
            
        except Exception as e:
            logger.error(f"Error retrieving members: {e}")
            # If we have members already, return them anyway
            if members:
                logger.warning(f"Returning {len(members)} members despite the error")
                return members
            return []
        
    async def _save_to_csv(self, members: List[Dict], filename: str) -> bool:
        """
        Sauvegarde les membres dans un fichier CSV.
        
        Args:
            members: Liste des membres à sauvegarder
            filename: Nom du fichier de sortie
            
        Returns:
            bool: True si la sauvegarde a réussi, False sinon
        """
        if not members:
            logger.warning("No members to save to CSV file")
            return False
            
        try:
            # ✅ Mélanger aléatoirement les membres avant de sauvegarder
            import random
            shuffled_members = members.copy()
            random.shuffle(shuffled_members)
            logger.info(f"🔀 Members randomly shuffled (original order preserved in memory)")
            
            # ✅ Créer le dossier csv_data s'il n'existe pas
            import os
            csv_dir = os.path.dirname(filename)
            if csv_dir and not os.path.exists(csv_dir):
                os.makedirs(csv_dir, exist_ok=True)
                logger.info(f"📁 Created CSV directory: {csv_dir}")
            
            # Define the column headers
            fieldnames = ['id', 'username', 'first_name', 'last_name', 'phone', 'access_hash', 'scraped_at']
            
            # Écrire dans le fichier CSV
            with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                
                # Écrire chaque membre dans le fichier (ordre mélangé)
                for member in shuffled_members:
                    # S'assurer que tous les champs requis sont présents
                    row = {field: member.get(field, '') for field in fieldnames}
                    writer.writerow(row)
            
            logger.info(f"{len(members)} members saved to {filename}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving to CSV file: {e}")
            return False