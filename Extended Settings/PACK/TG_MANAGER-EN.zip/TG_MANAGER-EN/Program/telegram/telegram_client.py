"""
Module client pour l'API Telegram.

Ce module gère la connexion à l'API Telegram et fournit
une interface simplifiée pour les opérations courantes.
"""
import asyncio
import os
from typing import Optional

import logging
from telethon import TelegramClient, events
from telethon.errors import SessionPasswordNeededError
from telethon.tl.types import Updates, UpdateShortMessage, UpdateNewChannelMessage
from typing import Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from telethon import TelegramClient
    from .telegram_client import TelegramClientManager

from config.settings import Config
from utils.logger import logger
from .telegram_session_manager import SessionManager

# Dictionnaire pour suivre les clients actifs par numéro de téléphone
active_clients: Dict[str, 'TelegramClientManager'] = {}

# Configurer le logger pour Telethon
telethon_logger = logging.getLogger('telethon')
# Réduire le niveau de détail pour les logs de connexion
telethon_logger.setLevel(logging.WARNING)

# Désactiver les logs verbeux inutiles
logging.getLogger('telethon.network.mtprotosender').setLevel(logging.ERROR)
logging.getLogger('telethon.network.connection').setLevel(logging.ERROR)
logging.getLogger('telethon.crypto').setLevel(logging.ERROR)
logging.getLogger('telethon.extensions').setLevel(logging.ERROR)

class TelegramClientManager:
    """
    Gère la connexion à l'API Telegram.
    """
    
    def __init__(self, phone_number: str):
        """
        Initialise le gestionnaire de client.
        
        Args:
            phone_number: Numéro de téléphone associé au compte
        """
        self.phone_number = phone_number
        self.client = None
        # ✅ Supprimer l'ancien système de session fichier
        # self.session_file = os.path.join(Config.SESSION_DIR, f'session_{phone_number}')
        
    async def connect(self) -> bool:
        """
        Établit une connexion avec l'API Telegram.
        
        Returns:
            bool: True si la connexion a réussi
        """
        from . import active_clients
        
        try:
            # Enregistrer ce client comme actif
            active_clients[self.phone_number] = self
            
            # ✅ Utiliser le SessionManager pour éviter les conflits multi-comptes
            self.client = await SessionManager.create_client(
                phone=self.phone_number,
                api_id=Config.get_api_id(),
                api_hash=Config.get_api_hash()
            )
            
            # Configurer les paramètres du client
            self.client.device_model = "Telegram Members Manager(TMM)"
            self.client.app_version = "HE.0.5"
            self.client.system_version = "Windows 10 & 11"
            self.client.flood_sleep_threshold = 0
            
            # Se connecter
            try:
                await self.client.connect()
            except Exception as e:
                if "A wait of" in str(e) and "seconds is required" in str(e):
                    # Extraire le temps d'attente en secondes
                    import re
                    wait_seconds = int(re.search(r'A wait of (\d+)', str(e)).group(1))
                    wait_minutes = wait_seconds // 60
                    
                    print("\n⚠️  TOO MANY CONNECTION ATTEMPTS")
                    print("="*50)
                    print(f"\n❌ You must wait {wait_seconds} seconds ({wait_minutes} minutes)")
                    print("   before trying to connect again.")
                    print("\n🔒 This limit is imposed by Telegram for security reasons.")
                    print("   Please wait and try again later.")
                    
                    # Afficher un compte à rebours pour tous les temps d'attente
                    from utils.progress import countdown, format_time
                    wait_minutes = wait_seconds // 60
                    wait_hours = wait_minutes // 60
                    
                    if wait_seconds > 3600:  # Plus d'une heure
                        print(f"\n⏳ Estimated wait time: {wait_hours}h {wait_minutes % 60}min")
                        print("   The program will now automatically wait...\n")
                    
                    # Afficher une barre de progression pendant l'attente
                    print(f"⏳ Waiting for {format_time(wait_seconds)} before trying again...\n")
                    
                    # Afficher une barre de progression pendant l'attente
                    countdown(wait_seconds, "Time remaining before trying again")
                    
                    print("\n✅ Wait time is over. New connection attempt...")
                    
                    # Réessayer après l'attente
                    try:
                        await self.client.disconnect()
                        await self.client.connect()
                    except Exception as e:
                        logger.error(f"Error reconnecting: {e}")
                        print(f"\n❌ Error reconnecting: {str(e)[:200]}")
                        return False
                else:
                    # Autre type d'erreur
                    logger.error(f"Connection error: {e}")
                    print(f"\n❌ Connection error: {str(e)[:200]}")
                    return False
            
            # Vérifier si l'utilisateur est déjà autorisé
            if not await self.client.is_user_authorized():
                try:
                    # Envoyer la demande de code
                    await self.client.send_code_request(self.phone_number)
                    print("\n📱 A verification code has been sent to your Telegram account.")
                    print()  # Saut de ligne explicite
                    from utils.progress import countdown
                    countdown(5, "Preparation of code reception")
                except Exception as e:
                    if "A wait of" in str(e) and "seconds is required" in str(e):
                        # Extraire le temps d'attente en secondes
                        import re
                        wait_seconds = int(re.search(r'A wait of (\d+)', str(e)).group(1))
                        wait_minutes = wait_seconds // 60
                        
                        print("\n⚠️  TOO MANY CODE SEND ATTEMPTS")
                        print("="*50)
                        print(f"\n❌ You must wait {wait_seconds} seconds ({wait_minutes} minutes)")
                        print("   before trying to request a new verification code.")
                        print("\n🔒 This limit is imposed by Telegram for security reasons.")
                        print("   Please wait and try again later.")
                        
                        # Afficher un compte à rebours pour tous les temps d'attente
                        from utils.progress import countdown, format_time
                        wait_minutes = wait_seconds // 60
                        wait_hours = wait_minutes // 60
                        
                        if wait_seconds > 3600:  # Plus d'une heure
                            print(f"\n⏳ Estimated wait time: {wait_hours}h {wait_minutes % 60}min")
                            print("   The program will now automatically wait...\n")
                        
                        # Afficher une barre de progression pendant l'attente
                        print(f"⏳ Waiting for {format_time(wait_seconds)} before trying again...\n")
                        countdown(wait_seconds, "Time remaining before trying again")
                        
                        print("\n✅ Wait time is over. New code send attempt...")
                        
                        # Réessayer après l'attente
                        try:
                            await self.client.send_code_request(self.phone_number)
                            print("\n📱 A verification code has been sent to your Telegram account.")
                            print()  # Saut de ligne explicite
                            countdown(5, "Preparation of code reception")
                        except Exception as e:
                            logger.error(f"Error sending code after wait: {e}")
                            print(f"\n❌ Failed to send code after wait: {str(e)[:200]}")
                            return False
                    else:
                        # Autre type d'erreur
                        logger.error(f"Code sending error: {e}")
                        print(f"\n❌ Code sending error: {str(e)[:200]}")
                        return False
                
                max_attempts = 3
                attempts = 0
                
                while attempts < max_attempts:
                    try:
                        # Demander le code à l'utilisateur
                        if attempts == 0:
                            code = input("\n🔢 Please enter the 5-digit verification code: ")
                        else:
                            code = input("🔢 Incorrect code. Please try again: ")
                        
                        # Nettoyer le code (supprimer les espaces et tirets)
                        code = ''.join(filter(str.isdigit, code))
                        
                        # Vérifier que le code a la bonne longueur
                        if len(code) != 5:
                            raise ValueError("The code must contain exactly 5 digits")
                        
                        # Essayer de se connecter avec le code
                        print("\n🔐 Verifying the code...")
                        await self.client.sign_in(phone=self.phone_number, code=code)
                        print("✅ Code verified successfully!")
                        break  # Si la connexion réussit, on sort de la boucle
                        
                    except ValueError as ve:
                        attempts += 1
                        remaining_attempts = max_attempts - attempts
                        if remaining_attempts > 0:
                            print(f"❌ {str(ve)}. \n❌ You have {remaining_attempts} attempt(s) remaining.")
                        else:
                            print("❌ Maximum number of attempts reached. Please try again later.")
                            return False
                            
                    except SessionPasswordNeededError:
                        # Gestion du mot de passe à deux facteurs
                        print("\n🔒 This account is protected by two-factor authentication (2FA).")
                        remaining_attempts = 3
                        
                        while remaining_attempts > 0:
                            try:
                                password = input(f"\n🔑 Please enter your 2FA password ({remaining_attempts} attempts remaining) : ")
                                if not password:
                                    print("❌ Password cannot be empty.")
                                    remaining_attempts -= 1
                                    continue
                                    
                                print("\n🔐 Verifying the password...")
                                await self.client.sign_in(password=password)
                                print("✅ 2FA authentication successful!")
                                return True  # Connection successful with 2FA
                                
                            except Exception as e2:
                                remaining_attempts -= 1
                                if remaining_attempts > 0:
                                    print(f"❌ {str(e2)}. \n❌ Incorrect password. You have {remaining_attempts} attempt(s) remaining.")
                                else:
                                    print("❌ Maximum number of 2FA attempts reached. Please try again later.")
                                    return False
                    
                    except Exception as e:
                        attempts += 1
                        remaining_attempts = max_attempts - attempts
                        
                        # Gestion des erreurs de flood (trop de tentatives)
                        if "FLOOD_WAIT" in str(e) or "flood" in str(e).lower():
                            wait_time = 300  # 5 minutes par défaut
                            
                            # Essayer d'extraire le temps d'attente de l'erreur
                            import re
                            match = re.search(r'(\d+)', str(e))
                            if match:
                                wait_time = int(match.group(1))
                                
                            print(f"\n⚠️ Too many connection attempts. Please wait...")
                            countdown(wait_time, f"Waiting before new attempt")
                            
                            # Retry after waiting
                            if remaining_attempts > 0:
                                print(f"\n🔄 New connection attempt ({remaining_attempts} attempt(s) remaining)...")
                                continue
                            
                        logger.error(f"Connection error: {e}")
                        
                        if remaining_attempts > 0:
                            print(f"\n❌ Error: {str(e)[:100]}...")
                            print(f"   You have {remaining_attempts} attempt(s) remaining.")
                        else:
                            print("\n❌ Maximum number of attempts reached. Please try again later.")
                            return False
            
            # Récupérer les informations du compte pour afficher le nom
            me = await self.client.get_me()
            display_name = me.first_name or me.username or self.phone_number
            if me.username:
                display_name = f"@{me.username} ({me.first_name or 'Sans nom'})"
            else:
                display_name = me.first_name or f"Compte {self.phone_number}"
                
            logger.info(f"Connected successfully as {display_name} (ID: {me.id})")
            print(f"✅ Connected as {display_name}")
            return True
            
        except Exception as e:
            logger.error(f"Error connecting to {self.phone_number}: {e}")
            return False
            
    async def disconnect(self) -> None:
        """Ferme la connexion avec l'API Telegram."""
        from . import active_clients
        
        if self.client and self.client.is_connected():
            await self.client.disconnect()
            logger.info(f"Disconnected from account {self.phone_number}")
            
        # ✅ Fermer la session via le SessionManager
        await SessionManager.close_session(self.phone_number)
            
        # Remove this client from active clients
        if self.phone_number in active_clients:
            del active_clients[self.phone_number]
            
    async def get_me(self) -> Optional[dict]:
        """
        Récupère les informations du compte connecté.
        
        Returns:
            dict: Informations du compte ou None en cas d'erreur
        """
        if not self.client or not self.client.is_connected():
            if not await self.connect():
                return None
                
        try:
            me = await self.client.get_me()
            return {
                'id': me.id,
                'first_name': me.first_name,
                'last_name': me.last_name,
                'username': me.username,
                'phone': me.phone,
                'is_bot': me.bot
            }
        except Exception as e:
            logger.error(f"Error retrieving account information: {e}")
            return None

async def cleanup_all_sessions():
    """Ferme toutes les sessions Telegram actives."""
    await SessionManager.close_all_sessions()
    active_clients.clear()
    logger.info("All Telegram sessions have been closed")

async def get_active_sessions_count() -> int:
    """Retourne le nombre de sessions actives."""
    return SessionManager.get_session_count()

def list_active_sessions() -> list:
    """Liste les sessions actives."""
    return SessionManager.list_active_sessions()