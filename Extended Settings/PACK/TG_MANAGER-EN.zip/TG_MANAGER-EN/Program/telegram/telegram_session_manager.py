"""
Gestionnaire de sessions Telegram pour éviter les conflits multi-comptes.
"""
import os
import asyncio
from pathlib import Path
from typing import Dict, Optional
from telethon import TelegramClient
from telethon.sessions import SQLiteSession
import logging

logger = logging.getLogger(__name__)

class SessionManager:
    """Gestionnaire de sessions Telegram pour multi-comptes."""
    
    _sessions: Dict[str, SQLiteSession] = {}
    _lock = asyncio.Lock()
    
    @classmethod
    async def get_session(cls, phone: str, api_id: int, api_hash: str) -> SQLiteSession:
        """
        Obtient ou crée une session SQLite pour un compte spécifique.
        
        Args:
            phone: Numéro de téléphone du compte
            api_id: API ID Telegram
            api_hash: API Hash Telegram
            
        Returns:
            SQLiteSession: Session unique pour ce compte
        """
        async with cls._lock:
            if phone in cls._sessions:
                return cls._sessions[phone]
            
            # Créer un nom de fichier de session unique par compte
            session_name = f"session_{phone.replace('+', '').replace(' ', '').replace('-', '')}"
            
            # Déterminer le sous-dossier selon le type de session
            if phone.startswith('bot_'):
                # Session pour bot
                subfolder = "bot_sessions"
                clean_phone = phone.replace('bot_', '').replace('+', '').replace(' ', '').replace('-', '')
                session_name = f"session_bot_{clean_phone}"
                # Créer un sous-dossier pour ce numéro de bot
                bot_folder = f"bot_{clean_phone}"
                session_path = Path(__file__).parent.parent / "sessions" / "telegram_sessions" / subfolder / bot_folder / f"{session_name}.session"
            else:
                # Session pour compte utilisateur
                subfolder = "account_sessions"
                clean_phone = phone.replace('+', '').replace(' ', '').replace('-', '')
                session_name = f"session_{clean_phone}"
                # Créer un sous-dossier pour ce numéro de compte
                account_folder = f"account_{clean_phone}"
                session_path = Path(__file__).parent.parent / "sessions" / "telegram_sessions" / subfolder / account_folder / f"{session_name}.session"
            
            # S'assurer que les dossiers existent
            session_path.parent.mkdir(parents=True, exist_ok=True)
            
            # ✅ Créer une session avec configuration WAL directement
            class WALSQLiteSession(SQLiteSession):
                """Session SQLite avec configuration WAL pour éviter les verrous."""
                
                def __init__(self, session_id: str):
                    super().__init__(session_id)
                    self._configured = False
                
                def _execute(self, stmt, *args):
                    """Override pour configurer WAL avant la première exécution."""
                    if not self._configured and self._conn:
                        try:
                            # Configurer WAL et autres optimisations
                            self._conn.execute("PRAGMA journal_mode=WAL")
                            self._conn.execute("PRAGMA synchronous=NORMAL")
                            self._conn.execute("PRAGMA cache_size=-2000")
                            self._conn.execute("PRAGMA temp_store=memory")
                            self._conn.execute("PRAGMA busy_timeout=60000")  # 60 secondes
                            self._conn.execute("PRAGMA foreign_keys=ON")
                            self._configured = True
                        except Exception as e:
                            # Si la configuration échoue, continuer sans WAL
                            logger.info(f"For the moment could not configure WAL PRAGMA for session: {e}")
                            self._configured = True  # Marquer comme configuré pour éviter les retries
                    
                    return super()._execute(stmt, *args)
            
            # Créer la session WAL personnalisée
            session = WALSQLiteSession(str(session_path))
            
            cls._sessions[phone] = session
            logger.info(f"Created new WAL session for account {phone}: {session_path}")
            
            return cls._sessions[phone]
    
    @classmethod
    async def create_client(cls, phone: str, api_id: int, api_hash: str) -> TelegramClient:
        """
        Crée un client Telegram avec une session unique.
        
        Args:
            phone: Numéro de téléphone du compte
            api_id: API ID Telegram
            api_hash: API Hash Telegram
            
        Returns:
            TelegramClient: Client configuré avec session unique
        """
        session = await cls.get_session(phone, api_id, api_hash)
        
        # Create the client with session and disable auto-reconnect
        client = TelegramClient(
            session, 
            api_id, 
            api_hash,
            auto_reconnect=False,          # Disable auto-reconnect
            connection_retries=1,          # Reduce connection attempts
            request_retries=1,             # Reduce request attempts
            retry_delay=1                  # Minimal delay between attempts
        )
        
        # Configurer le client pour éviter les verrous
        try:
            # Configurer les timeouts
            client._timeout = 60
            
            # Configurer la gestion des erreurs de connexion
            if hasattr(client, '_entity_cache'):
                client._entity_cache.clear()
                
        except Exception as e:
            logger.warning(f"Could not configure client optimizations for {phone}: {e}")
        
        return client
    
    @classmethod
    async def close_session(cls, phone: str):
        """
        Ferme une session spécifique.
        
        Args:
            phone: Numéro de téléphone du compte
        """
        async with cls._lock:
            if phone in cls._sessions:
                try:
                    session = cls._sessions.pop(phone)
                    # ✅ Vérifier si la session a une méthode close
                    if hasattr(session, 'close') and callable(getattr(session, 'close')):
                        if asyncio.iscoroutinefunction(session.close):
                            await session.close()
                        else:
                            session.close()
                    logger.info(f"Closed session for account {phone}")
                except Exception as e:
                    logger.error(f"Error closing session for {phone}: {e}")
            else:
                logger.debug(f"No session found for account {phone} to close")
    
    @classmethod
    async def close_all_sessions(cls):
        """Ferme toutes les sessions."""
        async with cls._lock:
            for phone in list(cls._sessions.keys()):
                await cls.close_session(phone)
    
    @classmethod
    def get_session_count(cls) -> int:
        """Retourne le nombre de sessions actives."""
        return len(cls._sessions)
    
    @classmethod
    def list_active_sessions(cls) -> list:
        """Liste les sessions actives."""
        return list(cls._sessions.keys())
