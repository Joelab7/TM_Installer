"""
Module pour l'envoi d'invitations via un bot Telegram.
"""
import asyncio
import logging
import os
from telethon import TelegramClient
from telethon.errors import RPCError
from config.settings import Config
from .telegram_session_manager import SessionManager

# Configuration du logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Vérification du token du bot
bot_token = os.getenv('BOT_TOKEN')
logger.info(f"BOT_TOKEN: {'Defined' if bot_token else 'Not defined'}")

if not bot_token:
    logger.error("❌ BOT_TOKEN manquant dans le fichier .env")
    logger.error("Veuillez ajouter BOT_TOKEN dans le fichier .env")

class BotInviter:
    """
    Gère l'envoi d'invitations via un bot Telegram.
    """
    
    def __init__(self, bot_token: str = None, account_phone: str = None):
        """
        Initialise le bot inviter.
        
        Args:
            bot_token: Token du bot Telegram (optionnel, peut être chargé depuis .env)
            account_phone: Numéro de téléphone du compte pour session unique
        """
        self.bot_token = bot_token or os.getenv('BOT_TOKEN')
        self.account_phone = account_phone or "default_bot"  # Session unique par compte
        if not self.bot_token:
            raise ValueError("ℹ No bot token provided and BOT_TOKEN not found in .env")
        self.client = None
        logger.info(f"🤖 BotInviter initialized for account {self.account_phone}")
        
    async def start(self):
        """Démarre le client bot avec session unique par compte."""
        if not self.client:
            try:
                # ✅ Utiliser SessionManager pour session unique par compte
                self.client = await SessionManager.create_client(
                    phone=f"bot_{self.account_phone}",  # Session unique par compte
                    api_id=Config.get_api_id(),
                    api_hash=Config.get_api_hash()
                )
                
                self.client.parse_mode = 'html'
                self.client.flood_sleep_threshold = 0
                
                # Démarre le client avec le token du bot
                await self.client.start(bot_token=self.bot_token)
                logger.info(f"✅ Bot inviter started successfully for {self.account_phone}")
                return True
            except Exception as e:
                logger.error(f"❌ Error while starting the bot for {self.account_phone}: {str(e)}")
                raise
        return False
    
    async def is_user_accessible(self, user_id: int) -> bool:
        """
        Vérifie si un utilisateur est accessible pour recevoir des messages du bot.
        
        Args:
            user_id: ID de l'utilisateur à vérifier
            
        Returns:
            bool: True si l'utilisateur est accessible, False sinon
        """
        try:
            if not self.client:
                await self.start()
            
            logger.debug(f"🤖 Checking accessibility of user {user_id}...")
                
            # ✅ Essayer send_message direct sans get_entity pour économiser le quota API
            try:
                await self.client.send_message(
                    entity=user_id,
                    message="​",  # Caractère invisible
                    silent=True
                )
                logger.debug(f"🤖 User {user_id} is accessible")
                return True
                
            except ValueError as e:
                if "❎ Could not find the input entity for PeerUser" in str(e):
                    # ❌ Suppression de get_entity() pour économiser le quota API
                    # Si l'entité n'est pas trouvée directement, on considère l'utilisateur comme inaccessible
                    logger.error(f"🤖 ValueError with user {user_id}: {e}")                    
                    return False
                else:
                    logger.debug(f"🤖 User {user_id} not accessible (entity not found)")
                    return False
            except RPCError as e:
                error_msg = str(e).lower()
                if "user is deactivated" in error_msg:
                    logger.warning(f"🤖 User {user_id} has deactivated their account")
                elif "user not found" in error_msg:
                    logger.warning(f"🤖 User {user_id} does not exist or is not accessible")
                elif "user is blocked" in error_msg:
                    logger.warning(f"🤖 Bot is blocked by user {user_id}")
                else:
                    logger.warning(f"🤖 User {user_id} is not accessible: {e}")
                return False
            except Exception as e:
                error_msg = str(e).lower()
                # ✅ Gérer les erreurs de base de données Telethon
                if any(db_error in error_msg for db_error in [
                    'database is locked',
                    'locked', 
                    'busy',
                    'timeout',
                    'operational error'
                ]):
                    logger.warning(f"🤖 Database error for user {user_id}: {e}")
                    # En cas d'erreur de base de données, considérer comme accessible et essayer quand même
                    return True  # Laisser l'invitation se faire quand même
                else:
                    logger.warning(f"🤖 Unexpected error with user {user_id}: {e}")
                    # Pour les autres erreurs, essayer quand même l'invitation
                    return True
                    
        except Exception as e:
            logger.error(f"🤖 Unexpected error when checking accessibility of user {user_id}: {e}", exc_info=True)
            return False
    
    async def _handle_send_message_error(self, error: Exception, user_id: int) -> None:
        """Gère les erreurs d'envoi de message de manière centralisée."""
        error_msg = str(error).lower()
        
        error_handlers = [
            (lambda e: "user is deactivated" in e, 
             lambda u: f"🤖 User {u} has deactivated their account"),
            
            (lambda e: any(term in e for term in ["user not found", "could not find the input entity"]),
             lambda u: f"🤖 User {u} does not exist or is not accessible (the bot may never have interacted with this user)"),
            
            (lambda e: "user is blocked" in e,
             lambda u: f"🤖 Bot is blocked by user {u}"),
            
            (lambda e: "flood" in e,
             lambda u: f"🤖 Flood error when sending to {u}"),
            
            (lambda e: any(term in e for term in ["a chat id must be an integer", "invalid peer"]),
             lambda u: f"🤖 Unable to start a conversation with user {u} - the bot must first be added as a contact")
        ]
        
        # Chercher le premier gestionnaire qui correspond à l'erreur
        for condition, message_func in error_handlers:
            if condition(error_msg):
                logger.warning(message_func(user_id))
                return
        
        # If no condition matches, log the generic error
        logger.warning(f"🤖 Unexpected error with user {user_id}: {error}")
    
    async def _try_send_message(self, user_id: int, message: str, is_accessible: bool) -> bool:
        """Tente d'envoyer un message avec différentes méthodes."""
        try:
            # Try first with the user ID directly
            await self.client.send_message(
                entity=user_id,
                message=message,
                link_preview=False,
                silent=not is_accessible
            )
            logger.info(f"🤖 Invitation sent successfully to user {user_id} via bot (direct ID)")
            return True
            
        except (ValueError, RPCError) as e:
            error_msg = str(e).lower()
            
            # If the error is related to the entity not found, try with InputPeerUser
            if any(term in error_msg for term in ["could not find the input entity", "user not found"]):
                logger.warning(f"🤖 Alternative send attempt for user {user_id}...")
                try:
                    from telethon.tl.types import InputPeerUser
                    input_user = InputPeerUser(user_id=user_id, access_hash=0)
                    await self.client.send_message(
                        entity=input_user,
                        message=message,
                        link_preview=False,
                        silent=not is_accessible
                    )
                    logger.info(f"🤖 Invitation sent successfully to user {user_id} via bot (with InputPeerUser)")
                    return True
                except Exception as inner_e:
                    await self._handle_send_message_error(inner_e, user_id)
                    return False
            
            # For other errors, let the calling method handle
            raise
    
    async def send_invitation(self, user_id: int, entity_link: str, entity_title: str) -> bool:
        """
        Envoie une invitation à un utilisateur via le bot avec retries pour les erreurs de base de données.
        """
        max_retries = 2  # Réduit de 3 à 2 pour optimiser le temps
        retry_delay = 1
        
        for attempt in range(max_retries):
            try:
                if not self.client:
                    await self.start()
                
                is_accessible = await self.is_user_accessible(user_id)
                if not is_accessible:
                    logger.warning(f"🤖 User {user_id} not accessible, trying anyway...")
                
                message = (
                    f"👋 Hello! You've been invited to join {entity_title}.\n"
                    f"Click here to join: {entity_link}\n\n"
                    "Best regards,\nThe Administration Team"
                )
                
                try:
                    return await self._try_send_message(user_id, message, is_accessible)
                except Exception as e:
                    error_msg = str(e).lower()
                    if any(db_error in error_msg for db_error in [
                        'database is locked', 'locked', 'busy', 'timeout', 'operational error'
                    ]):
                        if attempt < max_retries - 1:
                            wait_time = retry_delay * (1.5 ** attempt)
                            logger.warning(f"🤖 DB error retry {attempt + 1}/{max_retries} for user {user_id}")
                            await asyncio.sleep(wait_time)
                            continue
                    await self._handle_send_message_error(e, user_id)
                    return False
                    
            except Exception as e:
                if attempt < max_retries - 1:
                    wait_time = retry_delay * (1.5 ** attempt)
                    logger.warning(f"🤖 General error retry {attempt + 1}/{max_retries}: {e}")
                    await asyncio.sleep(wait_time)
                    continue
                await self._handle_send_message_error(e, user_id)
                return False
        
        return False
    
    async def close(self):
        """Ferme la connexion du client du bot et libère la session."""
        if self.client:
            await self.client.disconnect()
            # ✅ Fermer la session via SessionManager
            await SessionManager.close_session(f"bot_{self.account_phone}")
            self.client = None
            logger.info(f"🤖 Bot inviter closed for {self.account_phone}")
