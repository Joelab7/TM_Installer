import asyncio
import logging
import random
from datetime import datetime
from typing import List, Dict, Tuple, Optional, Any, AsyncGenerator, Union
import csv

from telethon import TelegramClient
from telethon.tl.functions.channels import InviteToChannelRequest, GetFullChannelRequest
from telethon.tl.functions.messages import AddChatUserRequest, ImportChatInviteRequest, GetFullChatRequest, ExportChatInviteRequest
from telethon.tl.types import InputPeerChannel, InputPeerChat, InputPeerUser, User, Chat, Channel
from telethon.tl.functions.channels import InviteToChannelRequest
from telethon.tl.functions.messages import AddChatUserRequest
from telethon.errors import (
    UserPrivacyRestrictedError,
    UserNotMutualContactError,
    UserChannelsTooMuchError,
    UsersTooMuchError,
    UserNotParticipantError,
    UserBlockedError,
    UserKickedError,
    UserBotError,
    ChatAdminRequiredError,
    ChatWriteForbiddenError,
    ChannelPrivateError,
    ChannelInvalidError,
    ChatInvalidError,
    InputUserDeactivatedError,
    UserBannedInChannelError,
    UserIdInvalidError,
    BotGroupsBlockedError,
    BotsTooMuchError
)
from typing import Optional

class TelegramError(Exception):
    """Classe de base pour les erreurs liées à l'API Telegram"""
    def __init__(self, message: str, retryable: bool = True, wait_time: int = 0):
        self.message = message
        self.retryable = retryable
        self.wait_time = wait_time
        super().__init__(self.message)

class AddMemberError(TelegramError):
    """Exception pour les erreurs d'ajout de membres."""
    pass

class TooManyRequestsError(TelegramError):
    """Erreur lorsque l'API impose un délai d'attente."""
    def __init__(self, seconds: int, message: str = "too many requests"):
        super().__init__(f"{message} (wait {seconds}s)", retryable=True, wait_time=seconds)
        self.seconds = seconds

class UserPrivacyRestrictedError(TelegramError):
    """Erreur lorsque les paramètres de confidentialité de l'utilisateur empêchent l'action."""
    def __init__(self, message: str = "the user's privacy settings do not allow you to do this"):
        super().__init__(message, retryable=False)
        
class UserBannedInChannelError(TelegramError):
    """Erreur lorsque l'utilisateur est banni du canal."""
    def __init__(self, message: str = "user is banned in this channel"):
        super().__init__(message, retryable=False)

class UserNotMutualContactError(TelegramError):
    """Erreur lorsque l'utilisateur n'est pas un contact mutuel."""
    def __init__(self, message: str = "the provided user is not a mutual contact"):
        super().__init__(message, retryable=False)

class UserChannelsTooMuchError(TelegramError):
    """Erreur lorsque l'utilisateur a rejoint trop de groupes/canaux."""
    def __init__(self, message: str = "the user has joined too many channels"):
        super().__init__(message, retryable=False)

class UsersTooMuchError(TelegramError):
    """Erreur lorsque trop d'utilisateurs sont ajoutés en une seule fois."""
    def __init__(self, message: str = "too many users", seconds: int = 300):
        super().__init__(message, retryable=True, wait_time=seconds)
        self.seconds = seconds  # Stocker les secondes pour l'affichage

class UserNotParticipantError(TelegramError):
    """Erreur lorsque l'utilisateur n'est pas un participant du groupe ou canal source."""
    def __init__(self, message: str = "the user is not a participant of the group or channel"):
        super().__init__(message, retryable=False)

class BotsTooMuchError(TelegramError):
    """Erreur lorsqu'il y a trop de bots dans le chat/canal."""
    def __init__(self, message: str = "There are too many bots in this chat/channel"):
        super().__init__(message, retryable=False)

class BotGroupsBlockedError(TelegramError):
    """Erreur lorsque le bot ne peut pas être ajouté à des groupes ou canaux."""
    def __init__(self, message: str = "This bot can't be added to groups or channels"):
        super().__init__(message, retryable=False)

class ChannelInvalidError(TelegramError):
    """Erreur lorsque le canal est invalide."""
    def __init__(self, message: str = "Invalid channel object"):
        super().__init__(message, retryable=True)

class ChannelPrivateError(TelegramError):
    """Erreur lorsque le canal est privé ou que l'accès est refusé."""
    def __init__(self, message: str = "The channel is private or access is denied"):
        super().__init__(message, retryable=False)

class ChatInvalidError(TelegramError):
    """Erreur lorsque le chat est invalide pour cette requête."""
    def __init__(self, message: str = "The chat is invalid for this request"):
        super().__init__(message, retryable=True)

class InputUserDeactivatedError(TelegramError):
    """Erreur lorsque l'utilisateur spécifié a été supprimé."""
    def __init__(self, message: str = "The specified user was deleted"):
        super().__init__(message, retryable=False)

class UserBlockedError(TelegramError):
    """Erreur lorsque l'utilisateur est bloqué."""
    def __init__(self, message: str = "User blocked"):
        super().__init__(message, retryable=False)

class UserBotError(TelegramError):
    """Erreur liée aux droits d'administration des bots."""
    def __init__(self, message: str = "Bots can only be admins in channels"):
        super().__init__(message, retryable=False)

class UserIdInvalidError(TelegramError):
    """Erreur lorsque l'ID utilisateur est invalide."""
    def __init__(self, message: str = "Invalid user ID"):
        super().__init__(message, retryable=True)

class UserKickedError(TelegramError):
    """Erreur lorsque l'utilisateur a été expulsé du supergroupe/canal."""
    def __init__(self, message: str = "This user was kicked from this supergroup/channel"):
        super().__init__(message, retryable=False)

class TelegramConnectionError(TelegramError):
    """Erreur lorsque le client est déconnecté de Telegram."""
    def __init__(self, message: str = "Client disconnected from Telegram"):
        super().__init__(message, retryable=True, wait_time=30)  # Attendre 30s avant de réessayer

class ChatMemberAddFailedError(TelegramError):
    """Erreur lorsque l'ajout d'un membre à un chat échoue."""
    def __init__(self, message: str = "Failed to add member to chat"):
        super().__init__(message, retryable=True)

# Création manuelle des classes spéciales qui nécessitent une logique personnalisée
class AddMemberError(TelegramError):
    """Exception pour les erreurs d'ajout de membres."""
    pass


def handle_telegram_error(error: Exception) -> TelegramError:
    """Convertit une exception Telegram en une exception personnalisée."""
    error_msg = str(error).lower()
    
    # Gestion des erreurs de type FloodWait et limitations de taux
    if any(term in error_msg for term in ['too many requests', 'wait a while', 'please wait', 'flood wait']):
        # Essayer d'extraire le temps d'attente du message d'erreur
        import re
        wait_time = 300  # Valeur par défaut: 5 minutes
        
        # Essayer de trouver un motif comme 'A wait of X seconds is required' ou 'TooManyRequestsError: A wait of X seconds is required'
        match = re.search(r'(?:wait of |wait )?(\d+)(?: second| sec|s)', error_msg) or \
                re.search(r'too[_ ]?many[_ ]?requests', error_msg) or \
                re.search(r'flood[_ ]?wait[_ ]?(\d+)', error_msg) 
                
        if match:
            wait_time = int(match.group(1)) if match.groups() else 300  # 5 minutes par défaut
            # S'assurer que le temps d'attente n'est pas trop court (minimum 5 secondes)
            wait_time = max(wait_time, 5)
            
        return TooManyRequestsError(seconds=wait_time)
    
    # Erreurs de confidentialité
    if any(term in error_msg for term in ['the user\'s privacy settings do not allow you to do this', 'privacy', 'user privacy restricted', 'privacy settings', 'privacy error', 'restricted by privacy']):
        return UserPrivacyRestrictedError()
    
    # Erreurs de contact mutuel
    if any(term in error_msg for term in ['the provided user is not a mutual contact', 'not a mutual contact', 'user not mutual contact', 'mutual contact required', 'need to be mutual contacts', 'not in your contacts']):
        return UserNotMutualContactError()
    
    # Erreurs de bannissement
    if any(term in error_msg for term in ['user banned', 'banned in channel', 'user is banned', 'banned from channel', 'banned in this channel']):
        return UserBannedInChannelError()
    
    # Erreurs de limites de groupes/canaux
    if any(term in error_msg for term in ['too many channels', 'channels too much', 'user channels too much']):
        return UserChannelsTooMuchError()
    
    # Erreurs de trop d'utilisateurs
    if any(term in error_msg for term in ['too many users', 'users too much', 'too many participants', 'The maximum number of users has been exceeded']):
        wait_time = 300
        return UsersTooMuchError(seconds=wait_time)
    
    # Erreurs de droits d'administrateur
    if any(term in error_msg for term in ['admin rights are required', 'not admin', 'admin required', 'not enough rights', 'need admin rights']):
        return ChatAdminRequiredError()
    
    # Erreurs d'écriture dans le chat
    if any(term in error_msg for term in ['write to chat forbidden', 'can\'t write in this chat', 'chat write forbidden']):
        return ChatWriteForbiddenError()
    
    # Erreurs d'utilisateur non participant
    if any(term in error_msg for term in ['user not participant', 'not a member', 'not in the chat']):
        return UserNotParticipantError()
    
    # Erreurs de trop de bots
    if any(term in error_msg for term in ['too many bots', 'bots too much']):
        return BotsTooMuchError()
    
    # Erreurs de blocage de bot dans les groupes
    if any(term in error_msg for term in ['bot groups blocked', 'bot can\'t be added to groups']):
        return BotGroupsBlockedError()
    
    # Erreurs de canal invalide
    if any(term in error_msg for term in ['channel invalid', 'invalid channel', 'channel not found']):
        return ChannelInvalidError()
    
    # Gestion des erreurs d'ajout de membre
    if any(term in error_msg for term in ['chat_member_add_failed', 'failed to add member']):
        return ChatMemberAddFailedError()
        
    # Gestion des erreurs liées aux canaux privés ou accès refusé
    if any(term in error_msg for term in ['channel private', 'channel is private', 'channel is not accessible', 'no access']):
        return ChannelPrivateError()
    
    # Erreurs de chat invalide
    if any(term in error_msg for term in ['chat invalid', 'invalid chat', 'chat not found']):
        return ChatInvalidError()
    
    # Erreurs d'utilisateur désactivé
    if any(term in error_msg for term in ['user deactivated', 'user deleted', 'account deleted']):
        return InputUserDeactivatedError()
    
    # Erreurs d'utilisateur bloqué
    if any(term in error_msg for term in ['user blocked', 'blocked by user', 'user is blocking you']):
        return UserBlockedError()
    
    # Erreurs de bot
    if any(term in error_msg for term in ['bot admin rights', 'bots as admin', 'bot admin required']):
        return UserBotError()
    
    # Erreurs d'ID utilisateur invalide
    if any(term in error_msg for term in ['user id invalid', 'invalid user id', 'user not found', 'invalid object id for a user', 'make sure to pass the right types', 'designed for users']):
        return UserIdInvalidError()
    
    # Erreurs de connexion
    if any(term in error_msg for term in ['cannot send requests while disconnected', 'connection error', 'not connected', 'disconnected']):
        return TelegramConnectionError("Client disconnected from Telegram")
    
    # Erreurs d'utilisateur expulsé
    if any(term in error_msg for term in ['user kicked', 'kicked from chat', 'banned from chat']):
        return UserKickedError()
    
    # Pour toute autre erreur non gérée
    #error_msg = str(error)
    return TelegramError(f"Unexpected error: {error}", retryable=True)


class DailyLimitReachedError(Exception):
    """Exception levée lorsque la limite quotidienne d'ajouts est atteinte pour un compte."""
    
    def __init__(self, account_phone: str, todays_adds: int, max_daily: int):
        """
        Initialise une nouvelle exception de limite quotidienne atteinte.
        
        Args:
            account_phone: Numéro de téléphone du compte concerné
            todays_adds: Nombre d'ajouts effectués aujourd'hui
            max_daily: Limite quotidienne d'ajouts
        """
        self.account_phone = account_phone
        self.todays_adds = todays_adds
        self.max_daily = max_daily
        message = (
            f"The daily additions limit has been reached for the account {account_phone}.\n"
            f"ℹ️ Adds made today: {todays_adds}/{max_daily}\n"
            "ℹ️ Please restart the program with another account to continue."
        )
        super().__init__(message)


from database.db_manager import db_manager, AddedUser
from config.settings import Config
from .bot_inviter import BotInviter

logger = logging.getLogger(__name__)

# Constantes pour les statuts des utilisateurs
USER_STATUS_ADDED = '✅ added'
USER_STATUS_INVITED = '✅ invited'
USER_STATUS_FAILED = '❌ failed'
USER_STATUS_ALREADY_IN_GROUP_OR_CHANNEL = '❎ failed'
USER_STATUS_ERROR = '⚠️ error'  

class MemberAdder:
    """
    Gère l'ajout de membres à un groupe Telegram.
    """
    
    def __init__(
        self, 
        client: TelegramClient,
        account_phone: str,
        config: Optional[Config] = None,
        bot_token: Optional[str] = None,
        db_manager_instance=None
    ):
        """
        Initialise le gestionnaire d'ajout de membres.
        
        Args:
            client: Client Telegram
            account_phone: Numéro de téléphone du compte
            config: Configuration (optionnel)
            bot_token: Token du bot pour les invitations (optionnel)
            db_manager_instance: Instance du gestionnaire de base de données (optionnel)
        """
        self.client = client
        self.account_phone = account_phone
        self.config = config or Config()
        self.success_count = 0
        self.failed_count = 0
        self.invited_count = 0  # Nouveau compteur pour les invitations
        self.db = db_manager_instance or db_manager  # Utilisation d'une instance ou du singleton
        
        # Initialiser le bot d'invitation si un token est fourni
        self.bot_inviter = None
        if bot_token:
            try:
                # ✅ Passer le numéro de téléphone pour session unique
                self.bot_inviter = BotInviter(bot_token=bot_token, account_phone=self.account_phone)
                self._log_operation('info', f"🤖 Bot inviter initialized successfully for {self.account_phone}")
            except Exception as e:
                self._log_operation('error', f"❎ Error initializing bot inviter: {e}")

    async def __aenter__(self):
        if self.bot_inviter:
            await self.bot_inviter.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.bot_inviter:
            await self.bot_inviter.close()

    def _log_operation(self, level: str, message: str, user_id: int = None, send_notification: bool = False, **kwargs) -> None:
        """
        Méthode utilitaire pour des logs cohérents.
        
        Args:
            level: Niveau de log ('debug', 'info', 'warning', 'error')
            message: Message à logger
            user_id: ID de l'utilisateur concerné (optionnel)
            send_notification: Si True, envoie aussi via le bot notifier
            **kwargs: Autres informations contextuelles
        """
        log_context = {
            'user_id': user_id,
            'account_phone': self.account_phone,
            **kwargs
        }
        log_message = f"{message} | {log_context}"
        
        if level == 'info':
            logger.info(log_message)
        elif level == 'warning':
            logger.warning(log_message)
        elif level == 'error':
            logger.error(log_message)
        else:
            logger.debug(log_message)
        
        # Envoyer via le bot notifier si demandé et si disponible
        if send_notification and hasattr(self, 'bot_notifier') and self.bot_notifier:
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    asyncio.create_task(self.bot_notifier.send_notification(message, False))
                else:
                    loop.run_until_complete(self.bot_notifier.send_notification(message, False))
            except Exception as e:
                logger.error(f"❎ Failed to send notification: {e}")
    
    async def add_members(
        self,
        members: List[Dict],
        target_entity: str,
        delay: int = 60,  # Délai par défaut augmenté à 60 secondes
        max_daily_adds: Optional[int] = None,  # Récupérer le nombre d'ajouts par défaut sur le fichier .env configuré
        total_members: int = None  # Nombre total de membres dans le fichier source (si applicable)
    ) -> Tuple[int, int]:
        if max_daily_adds is None:
            max_daily_adds = self.config.MAX_DAILY_ADDS
        """
        Ajoute une liste de membres à un groupe cible avec gestion des erreurs et des limites.
        
        Args:
            members: Liste des membres à ajouter (dictionnaires avec 'id' et 'username')
            target_entity: Nom d'utilisateur ou ID du groupe ou canal cible
            delay: Délai entre chaque ajout en secondes (par défaut: 60)
            max_daily_adds: Nombre maximum d'ajouts par jour (par défaut: 20)
            
        Returns:
            Tuple[int, int]: (nombre d'ajouts réussis, nombre d'échecs)
            
        Raises:
            DailyLimitReachedError: Si la limite quotidienne d'ajouts est atteinte pour ce compte
        """
        if not members:
            self._log_operation('warning', '❎ No members to add')
            return 0, 0
            
        try:
            # Vérifier la limite quotidienne
            todays_adds = await self.db.get_todays_adds_count(self.account_phone)
            
            if todays_adds >= max_daily_adds:
                # Lancer une exception pour signaler que la limite est atteinte
                raise DailyLimitReachedError(
                    account_phone=self.account_phone,
                    todays_adds=todays_adds,
                    max_daily=max_daily_adds
                )
                
            # Limiter le nombre d'ajouts au nombre restant possible
            remaining_daily = max(0, max_daily_adds - todays_adds)
            
            # Récupérer le nombre total d'utilisateurs traités
            total_processed = await self.db.get_total_users_count()
            
            self._log_operation('info', 
                f"📅 {total_processed} members processed - {remaining_daily} adds remaining today (Already {todays_adds}/{max_daily_adds})",
                send_notification=True
            )
            
        except DailyLimitReachedError:
            # Relancer l'exception pour qu'elle soit gérée plus haut
            raise
        except Exception as e:
            self._log_operation('error', f"❎ Error checking limits: {e}")
            return 0, 0
        
        # Récupérer l'entité du groupe ou canal cible
        try:
            target_entity = await self.client.get_entity(target_entity)
            if not target_entity:
                raise AddMemberError(
                    f"❎ Target group or channel not found: {target_entity}",
                    retryable=False
                )
                
            self._log_operation('info', f"✅ Target group or channel : {getattr(target_entity, 'title', target_entity)}")
            
        except Exception as e:
            error_msg = f"❎ Error getting target group or channel: {e}"
            self._log_operation('error', error_msg)
            raise AddMemberError(error_msg, retryable=False) from e
        
        # Ajouter les membres un par un avec gestion des erreurs
        success_count = 0
        failure_count = 0
        invited_count = 0  # Nouveau compteur pour les invitations
        # Le paramètre total_members représente le nombre total de membres dans le fichier CSV
        # Si non fourni, on utilise la longueur de la liste des membres
        if total_members is None:
            total_members = len(members)
        
        # Initialiser la barre de progression
        from tqdm import tqdm

        # Vérifier si la limite quotidienne est déjà atteinte
        if todays_adds >= max_daily_adds:
            self._log_operation('info', f'ℹ️ Daily limit reached for the account {self.account_phone}')
            return 0, 0

        # Calculer le nombre d'ajouts directs restants pour aujourd'hui
        remaining_daily = max(0, max_daily_adds - todays_adds)
        self._log_operation('info', f'ℹ️ Remaining adds today: {remaining_daily}')

        # Initialiser les compteurs
        success_count = 0
        failure_count = 0
        invited_count = 0  # Nouveau compteur pour les invitations
        total_processed = await self.db.get_total_users_count()

        # Initialiser la barre de progression
        progress_bar = tqdm(
            total=max_daily_adds,
            initial=todays_adds,
            desc=f"📅 Today: {todays_adds}/{max_daily_adds}",
            unit=" add",
            dynamic_ncols=True,
            bar_format='{l_bar}{bar}| [{elapsed}<{remaining}, {rate_fmt}{postfix}]',
            position=0,
            leave=True,
            colour='green'
        )

        progress_bar.set_postfix({
            '✅': '0',
            '❌': '0',
            '📨': '0',
            '📊': f'{total_processed}/{total_members or len(members)} processed',
            '⏳': f'{remaining_daily} remaining',
            '⏰': 'Ready'
        })
        
        try:
            # Parcourir tous les membres jusqu'à atteindre la limite quotidienne
            for member in members:
                # Vérifier si on a atteint la limite quotidienne
                if remaining_daily <= 0:
                    print()
                    self._log_operation('info', f'⚠ Daily limit reached for the account {self.account_phone}')
                    break

                user_id = member.get('id')
                username = member.get('username', f'user_{user_id}')
                
                if not user_id:
                    self._log_operation('warning', '❎ Member without valid ID ignored', **member)
                    failure_count += 1
                    progress_bar.update(0)  # Ne pas incrémenter la barre de progression
                    continue

                # Vérifier si l'utilisateur a déjà été traité (ajouté ou échec) par n'importe quel compte
                users_in_db = await self.db.get_users_by_telegram_id(user_id)  # Récupère tous les utilisateurs avec cet ID
                if users_in_db:
                    # Check if the user has already been processed (added or invited) by any account
                    statuses = [user.status for user in users_in_db]
                    if any(status in [
                        USER_STATUS_ADDED, 
                        USER_STATUS_INVITED,
                        USER_STATUS_FAILED,
                        USER_STATUS_ALREADY_IN_GROUP_OR_CHANNEL
                    ] for status in statuses):
                        status_message = f'⏭️ User already processed: {username} (ID: {user_id}) - Ignored'
                        self._log_operation('info', status_message)
                        progress_bar.update(0)
                        continue    

                try:
                    # Verification si l'utilisateur est deja dans le groupe ou canal avant d'ajouter
                    _is_user_in_group_or_channel = await self._is_user_in_group_or_channel(user_id, target_entity)
                    if _is_user_in_group_or_channel == USER_STATUS_ALREADY_IN_GROUP_OR_CHANNEL:
                        failure_count += 1
                        await self._mark_user(user_id, username, USER_STATUS_ALREADY_IN_GROUP_OR_CHANNEL, message)
                        self._log_operation('info', f"{message}", user_id)                                                
                        progress_bar.set_postfix_str("⏭️ Skipped: Already in group or channel")
                        progress_bar.update(1)
                        continue

                    # Appel direct à _add_single_member pour ajouter l'utilisateur déjà vérifié via _is_user_in_group_or_channel(ci-dessus)
                    operation_status, message, apply_delay = await self._add_single_member(
                        user_id=user_id,
                        username=username,
                        target_entity=target_entity,
                        delay=delay,
                        attempt=1,
                        max_attempts=1,
                    )                       
                    if operation_status == USER_STATUS_ADDED:
                        success_count += 1
                        await self._mark_user(user_id, username, USER_STATUS_ADDED, message)
                        self._log_operation('info', f"{message}", user_id)
                        progress_bar.set_postfix_str(f"Added: {username or user_id}")
                    elif operation_status == USER_STATUS_INVITED:
                        invited_count += 1
                        await self._mark_user(user_id, username, USER_STATUS_INVITED, message)
                        self._log_operation('info', f"{message}", user_id)
                        progress_bar.set_postfix_str(f"Invited: {username or user_id}")
                    elif operation_status == USER_STATUS_FAILED:
                        failure_count += 1
                        await self._mark_user(user_id, username, USER_STATUS_FAILED, message)
                        self._log_operation('warning', f"{message}", user_id)
                        progress_bar.set_postfix_str(f"Failed: {message[:30]}...")
                    
                    # Mettre à jour les compteurs
                    todays_adds = await self.db.get_todays_adds_count(self.account_phone)
                    remaining_daily = max(0, max_daily_adds - todays_adds)  # Ajouts restants aujourd'hui
                    total_processed = await self.db.get_total_users_count()  
                    
                    # Mettre à jour la barre de progression (uniquement les succès)
                    progress_bar.n = todays_adds
                    
                    # Mettre à jour l'affichage
                    progress_bar.desc = f"📅 Today: {todays_adds}/{max_daily_adds}"
                    progress_bar.set_postfix({
                        '✅': f'{success_count}',
                        '❌': f'{failure_count}',
                        '📨': f'{invited_count}',
                        '📊': f'{total_processed}/{total_members} processed',
                        '⏳': f'{remaining_daily} remaining'
                    })
                    
                    # Log du progrès tous les 5 ajouts ou si c'est le dernier
                    # Remplacer la ligne 402
                    if total_processed % 5 == 0 or success_count + failure_count + invited_count >= len(members):
                        self._log_operation('info',
                            f"Session: {success_count} adds, {failure_count} failures, {invited_count} invites - "
                            f"📅 Today: {todays_adds}/{max_daily_adds} - "
                            f"📊 {total_processed}/{total_members} processed - "
                            f"⏳ Remaining: {remaining_daily} remaining",
                            send_notification=True
                        )
                    
                    # Gérer le délai entre les ajouts si nécessaire
                    if delay > 0 and remaining_daily > 0 and apply_delay:  # Ne pas attendre après le dernier ajout possible
                        self._log_operation('info', 
                            f"⌚ Waiting for {delay} seconds before next add... "
                            f"(Remaining {remaining_daily} adds on {max_daily_adds} members to add)",
                            user_id
                        )
                        
                        # Afficher le temps d'attente initial
                        for remaining_seconds in range(delay, 0, -1):
                            progress_bar.set_postfix({
                                '✅': f'{success_count}',
                                '❌': f'{failure_count}',
                                '📨': f'{invited_count}',
                                '📊': f'{total_processed}/{total_members} processed',
                                '🕒': f'{remaining_seconds}s'
                            }, refresh=True)
                            await asyncio.sleep(1)
                        
                        # Réinitialiser l'affichage après l'attente
                        progress_bar.set_postfix({
                            '✅': f'{success_count}',
                            '❌': f'{failure_count}',
                            '📨': f'{invited_count}',
                            '📊': f'{total_processed}/{total_members} processed',
                            '⏳': f'{remaining_daily} remaining'
                        })
                            
                except AddMemberError as e:
                    failure_count += 1
                    error_status = USER_STATUS_FAILED if e.retryable else 'permanent_failure'
                    error_msg = str(e)
                    
                    await self._mark_user(user_id, username, error_status, error_msg)
                    
                    # Mettre à jour la barre de progression avec l'erreur
                    progress_bar.update(1)
                    progress_bar.set_postfix({
                        '❌': f'{failure_count} (error)',
                        '✅': f'{success_count}',
                        '📨': f'{invited_count}',
                        '⏳': f'{(len(members) - (success_count + invited_count + failure_count))} left'
                    })
                    
                    # Journaliser l'erreur
                    log_level = 'error' if e.retryable else 'warning'
                    self._log_operation(log_level, 
                                      f"❌ Error on {username or user_id}: {error_msg}", 
                                      user_id,
                                      retryable=e.retryable)
                    
                    if not e.retryable:
                        continue  # Passer au membre suivant si l'erreur n'est pas réessayable
                        
                except Exception as e:
                    failure_count += 1
                    error_msg = f"⚠️ Unexpected error: {str(e)}"
                    
                    # ✅ Ajouter le préfixe "❎ " pour les erreurs d'entity
                    if "Could not find the input entity" in error_msg:
                        error_msg = f"❎ {error_msg}"
                    
                    await self._mark_user(user_id, username, USER_STATUS_ERROR, error_msg)
                    
                    # Mettre à jour la barre de progression avec l'erreur
                    progress_bar.update(1)
                    progress_bar.set_postfix({
                        '❌': f'{failure_count} (error)',
                        '✅': f'{success_count}',
                        '📨': f'{invited_count}',
                        '⏳': f'{(len(members) - (success_count + invited_count + failure_count))} left',
                        '⚠': 'Unexpected error'
                    })
                    
                    # Journaliser l'erreur avec plus de détails
                    self._log_operation('error', 
                                      f"❌ Unexpected error on {username or user_id}: {error_msg}", 
                                      user_id,
                                      exc_info=True)
                    
                    # Attendre un peu avant de continuer
                    await asyncio.sleep(5)
        finally:
            # Fermer la barre de progression avec un message de résumé
            progress_bar.close()
            
            # Afficher un résumé final
            total_processed = success_count + failure_count + invited_count
            success_rate = (success_count / total_processed * 100) if total_processed > 0 else 0
            
            print()
            self._log_operation('info',
                "✅ Operation completed - "
                f"Results: {success_count} • Failures: {failure_count} • Invites {invited_count} • Success rate: {success_rate:.1f}%"
            )
            
            # Enregistrer les compteurs globaux
            self.success_count += success_count
            self.failed_count += failure_count
            
            # Retourner le résumé
            summary = {
                'success': success_count,
                'failures': failure_count,
                'invites': invited_count,
                'total_attempted': success_count + failure_count + invited_count,  # Nombre total de tentatives effectuées
                'success_rate': success_rate,
                'remaining_daily': max(0, max_daily_adds - (success_count + todays_adds))
            }
        
        print()
        self._log_operation('info', 
                          "📊 Operation summary: {success_count} success, {failure_count} failures, {invited_count} invites",
                          **summary)
                          
        return success_count, failure_count, invited_count

    async def _read_members_from_csv(self, csv_file_path: str) -> List[Dict]:
        """
        Lit les membres à partir d'un fichier CSV de manière robuste.
        
        Args:
            csv_file_path: Chemin vers le fichier CSV
            
        Returns:
            List[Dict]: Liste des membres avec leurs informations
            
        Raises:
            FileNotFoundError: Si le fichier n'existe pas
            ValueError: Si le format du fichier est invalide
            csv.Error: En cas d'erreur de lecture du CSV
        """
        members = []
        try:
            with open(csv_file_path, mode='r', encoding='utf-8', newline='') as file:
                # Détecter le format du fichier CSV
                sample = file.read(4096)
                file.seek(0)
                
                try:
                    dialect = csv.Sniffer().sniff(sample)
                    has_header = csv.Sniffer().has_header(sample)
                except (csv.Error, UnicodeDecodeError):
                    # Utiliser les valeurs par défaut si la détection échoue
                    dialect = 'excel'
                    has_header = True
                
                # Lire le fichier avec le bon dialecte
                csv_reader = csv.DictReader(file, dialect=dialect)
                
                # Vérifier que le fichier contient une colonne d'identifiant (id ou user_id)
                if not hasattr(csv_reader, 'fieldnames') or not csv_reader.fieldnames:
                    raise ValueError("CSV file seems empty or has invalid headers")
                
                # Vérifier si le fichier utilise 'id' ou 'user_id' comme colonne d'identifiant
                id_columns = [col for col in csv_reader.fieldnames if col.lower() in ['id', 'user_id']]
                if not id_columns:
                    raise ValueError("CSV file must contain an 'id' or 'user_id' column")
                
                # Utiliser la première colonne d'identifiant trouvée (préférer 'user_id' si les deux existent)
                id_column = 'user_id' if 'user_id' in id_columns else id_columns[0]
                self._log_operation('debug', f"Using column '{id_column}' as user ID")
                
                # Lire et valider chaque ligne
                for row_num, row in enumerate(csv_reader, 1):
                    try:
                        # Nettoyer les valeurs vides
                        row = {k: v.strip() if isinstance(v, str) else v for k, v in row.items() if v is not None}
                        
                        # Vérifier que l'ID utilisateur est présent et valide
                        if id_column not in row or not str(row[id_column]).strip():
                            self._log_operation('warning', f"Line {row_num}: User ID missing or empty in column '{id_column}'")
                            continue
                            
                        try:
                            user_id = int(str(row[id_column]).strip())
                            if user_id <= 0:
                                raise ValueError("🔄 User ID must be a positive number")
                        except ValueError as e:
                            self._log_operation('warning', f"Line {row_num}: Invalid user ID in column '{id_column}': {row[id_column]}")
                            continue
                        
                        # Créer un dictionnaire avec les champs de base
                        member = {
                            'id': user_id,
                            'username': row.get('username', '').strip(),
                            'first_name': row.get('first_name', '').strip(),
                            'last_name': row.get('last_name', '').strip(),
                            'source_file': csv_file_path,
                            'row_number': row_num
                        }
                        
                        # Ajouter des champs supplémentaires s'ils existent
                        for key, value in row.items():
                            if key not in member and value and str(value).strip():
                                member[key] = str(value).strip()
                        
                        members.append(member)
                        
                    except Exception as e:
                        self._log_operation('warning', f"Line {row_num} ignored: {str(e)}", **row)
                        continue
            
            if not members:
                self._log_operation('warning', "🔄 No valid members found in the CSV file")
            else:
                self._log_operation('info', f"🔄 {len(members)} members loaded from the CSV file {csv_file_path}")
                
            return members
            
        except FileNotFoundError as e:
            self._log_operation('error', f"🔄 File not found: {csv_file_path}")
            raise
            
        except csv.Error as e:
            line_no = getattr(e, 'line_num', 'unknown')
            error_msg = f"🔄 CSV format error at line {line_no}: {str(e)}"
            self._log_operation('error', error_msg)
            raise ValueError(error_msg) from e
            
        except Exception as e:
            self._log_operation('error', f"🔄 Unexpected error while reading the CSV file: {str(e)}")
            raise
    
    async def add_members_from_csv(
        self,
        csv_file: str,
        target_entity: str,
        delay: int = 120,
        max_csv_adds: Optional[int] = None,
        skip_errors: bool = True,
    ) -> Tuple[int, int]:
        if max_csv_adds is None:
            max_csv_adds = getattr(self.config, 'MAX_CSV_ADDS', 0)
        """
        Ajoute des membres à un groupe cible depuis un fichier CSV.
        
        Args:
            csv_file: Chemin vers le fichier CSV contenant les membres
            target_entity: Nom d'utilisateur ou ID du groupe cible
            delay: Délai entre chaque ajout en secondes
            max_csv_adds: Nombre maximum d'ajouts à partir du fichier CSV (0 = illimité)
            skip_errors: Si True, continue même en cas d'erreur de lecture du fichier
            
        Returns:
            Tuple[int, int]: (nombre d'ajouts réussis, nombre d'échecs)
            
        Raises:
            FileNotFoundError: Si le fichier n'existe pas et skip_errors=False
            ValueError: Si le format du fichier est invalide et skip_errors=False
        """
        try:
            # Lire les membres depuis le CSV
            members = await self._read_members_from_csv(csv_file)
            
            if not members:
                self._log_operation('warning', '🔄 No valid members found in the CSV file')
                return 0, 0, 0
                
            # Limiter le nombre de membres à traiter si max_csv_adds est défini et > 0
            if max_csv_adds and max_csv_adds > 0:
                members = members[:max_csv_adds]
                self._log_operation('info', f'🔢 CSV file limit applied: {max_csv_adds} maximum members')
            
            # Enregistrer le début de l'opération
            self._log_operation(
                'info',
                f"🔄 Start adding {len(members)} members from {csv_file}",
                source_file=csv_file,
                member_count=len(members),
                target_entity=target_entity
            )
            
            success, failed, invited = await self.add_members(
                members=members,
                target_entity=target_entity,
                delay=delay,
                max_daily_adds=None,
                total_members=len(members)
            )
            
            # Enregistrer la fin de l'opération
            self._log_operation(
                'info',
                f"🔄 Add completed: {success} successes, {invited} invites, {failed} failures",
                source_file=csv_file,
                success_count=success,
                failure_count=failed,
                invited_count=invited,
            )
            
            return success, failed, invited
            
        except FileNotFoundError as e:
            error_msg = f"🔄 CSV file not found: {csv_file}"
            if skip_errors:
                self._log_operation('error', error_msg)
                return 0, 0, 0
            raise AddMemberError(error_msg, retryable=False) from e
            
        except ValueError as e:
            error_msg = f"🔄 Invalid CSV file format: {str(e)}"
            if skip_errors:
                self._log_operation('error', error_msg)
                return 0, 0, 0
            raise AddMemberError(error_msg, retryable=False) from e
            
        except Exception as e:
            error_msg = f"🔄 Unexpected error while reading the CSV file: {str(e)}"
            if skip_errors:
                self._log_operation('error', error_msg, exc_info=True)
                return 0, 0, 0
            raise AddMemberError(error_msg, retryable=True) from e
        
    async def _add_single_member(
        self,
        user_id: int,
        username: str,
        target_entity,
        delay: int,
        attempt: int = 1,
        max_attempts: int = 1,
    ) -> Tuple[str, str, bool]:
        
        # Vérifier si le groupe est un supergroupe/canal
        is_megagroup_or_channel = getattr(target_entity, 'megagroup', False) or hasattr(target_entity, 'broadcast')
        megagroup_or_channel_name = getattr(target_entity, 'title', f"ID:{getattr(target_entity, 'id', 'unknown')}")
        
        # Journalisation détaillée
        logger.debug(f"🔄 Attempt {attempt}/{max_attempts} - Adding user {username or user_id} to {megagroup_or_channel_name} (ID: {getattr(target_entity, 'id', 'N/A')})")
            
        try:
            # Utiliser les usernames du CSV avec fallback vers user_id si username est vide
            user_identifier = username if username and username.strip() else user_id
            
            if is_megagroup_or_channel:
                logger.debug(f"🔄 Using InviteToChannelRequest for {megagroup_or_channel_name}")
                
                # Ajout d'un utilisateur à un canal/supergroupe
                await self.client(InviteToChannelRequest(
                    channel=target_entity,
                    users=[user_identifier]
                ))
                    
            else:
                logger.debug(f"🔄 Using AddChatUserRequest for {megagroup_or_channel_name}")
                
                # Ajout d'un utilisateur à un groupe standard
                await self.client(AddChatUserRequest(
                    user_id=user_identifier,
                    fwd_limit=0,
                    chat_id=target_entity.id
                ))
                
            # Succès de l'ajout
            #await self._send_invitation(user_id, username, target_entity)
            success_msg = f"✅ User ({username or user_id}) is successfully added to {megagroup_or_channel_name}"
            logger.info(f"{success_msg}")
            self._log_operation('info', success_msg, user_id, send_notification=True)
            # Marquer l'utilisateur comme invité dans la base de données
            await self._mark_user(
                user_id=user_id,
                username=username,
                status=USER_STATUS_ADDED,
                exception_message=success_msg  #exception_message=None, pour ne pas afficher le message de succès dans la section exception_message de la base de donnée.                                         
                )
            return USER_STATUS_ADDED, success_msg, True                      
                    
            
        except Exception as e:
            # D'abord, convertir l'erreur en notre hiérarchie personnalisée
            custom_error = handle_telegram_error(e)
            logger.warning(f"⚠️ {custom_error.__class__.__name__}: {custom_error.message}")
            # Vérifier le type d'erreur avec isinstance()
            if isinstance(custom_error, UserPrivacyRestrictedError):
                error_msg = f"🔒 User ({username or user_id}) has privacy restrictions"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                    
            elif isinstance(custom_error, UserNotMutualContactError):
                error_msg = f"🔒 User ({username or user_id}) must be a mutual contact to be added"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, UserChannelsTooMuchError):
                error_msg = f"❎ User ({username or user_id}) has joined too many groups or channels"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                                               
            elif isinstance(custom_error, ChatMemberAddFailedError):
                error_msg = f"❎ Failed to add user ({username or user_id}) to {megagroup_or_channel_name}: {custom_error.message}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
            
            elif isinstance(custom_error, ChatWriteForbiddenError):
                error_msg = f"🚫 Bot doesn't have permission to write in {megagroup_or_channel_name}"
                logger.error(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True  

            elif isinstance(custom_error, UserBannedInChannelError):
                error_msg = f"🚫 User ({username or user_id}) is banned from {megagroup_or_channel_name}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True

            elif isinstance(custom_error, UserNotParticipantError):
                error_msg = f"🚫 User ({username or user_id}) is not a participant in {megagroup_or_channel_name}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True

            elif isinstance(custom_error, UsersTooMuchError):
                wait_time = getattr(custom_error, 'wait_time', 300)  # 5 minutes par défaut
                error_msg = f"⏳ Too many users added at once, waiting {wait_time}s before retry..."
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                await asyncio.sleep(wait_time)
                return USER_STATUS_FAILED, error_msg, False

            elif isinstance(custom_error, BotsTooMuchError):
                error_msg = f"🚫 Too many bots in {megagroup_or_channel_name}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, BotGroupsBlockedError):
                error_msg = f"🚫 Bot can't be added to {megagroup_or_channel_name}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, (ChannelInvalidError, ChatInvalidError)):
                error_msg = f"🚫 Invalid chat: {megagroup_or_channel_name}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, ChannelPrivateError):
                error_msg = f"🚫 {megagroup_or_channel_name} is private or access denied"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, InputUserDeactivatedError):
                error_msg = f"🚫 User ({username or user_id}) was deleted"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, UserBlockedError):
                error_msg = f"🚫 User ({username or user_id}) has blocked the bot"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, UserBotError):
                error_msg = f"🚫 Bot admin rights issue in {megagroup_or_channel_name}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, UserIdInvalidError):
                error_msg = f"🚫 Invalid user ID: {user_id}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, UserKickedError):
                error_msg = f"🚫 User ({username or user_id}) was kicked from {megagroup_or_channel_name}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                
            elif isinstance(custom_error, ChatAdminRequiredError):
                error_msg = f"🚫 Admin rights required in {megagroup_or_channel_name}"
                logger.warning(error_msg)
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                return USER_STATUS_FAILED, error_msg, True
                        
            elif isinstance(custom_error, TelegramConnectionError):
                # Pour les erreurs de connexion, arrêter le programme avec un message clair
                error_msg = "🔌 CONNECTION ERROR: Client disconnected from Telegram"
                logger.error(error_msg)
                print("\n" + "="*60)
                print("🔌 CONNECTION ERROR")
                print("="*60)
                print("The client has been disconnected from Telegram.")
                print("Please restart the program once the connection is restored.")
                print("="*60)
                
                # Marquer l'utilisateur avec un message de connexion
                await self._mark_user(
                    user_id=user_id,
                    username=username,
                    status=USER_STATUS_ERROR,
                    exception_message="Connection lost - program stopped"
                )
                
                # Arrêter le programme
                import sys
                sys.exit(1)
                        
            elif isinstance(custom_error, TooManyRequestsError):
                # Gestion spécifique de TooManyRequestsError
                backoff_time = custom_error.seconds
                logger.warning(f"🔄 Too many requests: Waiting for {backoff_time} seconds...")
                
                if self.bot_inviter and attempt >= max_attempts - 1:
                    logger.info(f"🤖 Attempting to send invitation after too many requests error...")
                    operation_status = await self._send_invitation(user_id, username, target_entity)
                    if operation_status == USER_STATUS_INVITED:
                        return USER_STATUS_INVITED, "✅ Invitation sent after too many requests error", False
                logger.info(f"🔄 Waiting for {backoff_time} seconds before retrying...")
                await asyncio.sleep(backoff_time)
                
                if attempt < max_attempts:
                    return await self._add_single_member(
                        user_id=user_id,
                        username=username,
                        target_entity=target_entity,
                        delay=delay,
                        attempt=attempt + 1,
                        max_attempts=max_attempts,
                    )
                    
                return USER_STATUS_FAILED, f"❌ Failed after {max_attempts} attempts: Too many requests", True
            
            # Pour toutes les autres erreurs non gérées
            else:
                logger.error(f"⚠️ Unexpected error: {str(e)}")
                return USER_STATUS_ERROR, f"⚠️ Unexpected error: {str(e)}", False
        except asyncio.CancelledError:
            self._log_operation('info', "Task cancelled by user", user_id)
            raise

    
    async def _get_group_invite_link(self, target_entity):
        """
        Récupère un lien d'invitation pour le groupe cible.
        
        Args:
            target_entity: L'entité du groupe ou canal cible
            
        Returns:
            str: Le lien d'invitation ou None en cas d'erreur
        """
        try:
            # Try to retrieve existing invite links
            try:
                # Note: get_invites no longer exists in Telethon, we directly create the invite
                pass
            except Exception as e:
                logger.debug(f"❎ Method get_invites not available: {e}")
            
            # If no link exists, try to create a new one
            try:
                result = await self.client(ExportChatInviteRequest(target_entity))
                if hasattr(result, 'link'):
                    return result.link
            except Exception as e:
                logger.warning(f"❎ Unable to create a new invite link: {e}")
            
            # If no link exists, return a base link
            if hasattr(target_entity, 'username'):
                return f"https://t.me/{target_entity.username}"
            else:
                return f"https://t.me/c/{str(abs(target_entity.id)).replace('-100', '')}"
                
        except Exception as e:
            logger.error(f"❎ Error retrieving invite link: {e}")
            return None
            
    async def _send_invitation(
        self, 
        user_id: int, 
        username: str = None, 
        target_entity = None
    ) -> str:
        """
        Envoie une invitation à un utilisateur via le bot.
        
        Args:
            user_id: ID de l'utilisateur à inviter
            username: Nom d'utilisateur (optionnel, utilisé pour le suivi)
            target_entity: Entité du groupe cible
            
        Returns:
            str: Statut de l'opération (USER_STATUS_INVITED ou USER_STATUS_FAILED)
        """
        if not self.bot_inviter:
            logger.warning("❎ No invitation bot configured")
            return USER_STATUS_FAILED
            
        try:
            # Get the invite link for the group
            result = await self.client(ExportChatInviteRequest(
                peer=target_entity,
                legacy_revoke_permanent=False
            ))
            
            invite_link = result.link
            logger.debug(f"✅ Invite link generated: {invite_link}")
            
            # Send the invite link to the user via the bot
            operation_status = await self.bot_inviter.send_invitation(user_id, invite_link, str(target_entity.title))
            
            if operation_status:
                success_msg = f"✅ Invitation sent successfully to user ({username or user_id})"
                logger.info(f"{success_msg}")
                self._log_operation('warning', success_msg, user_id, send_notification=True)
                # Marquer l'utilisateur comme invité dans la base de données
                await self._mark_user(
                    user_id=user_id,
                    username=username,
                    status=USER_STATUS_INVITED,
                    exception_message=success_msg  #exception_message=None, pour ne pas afficher le message de succès dans la section exception_message de la base de donnée.   
                )
                return USER_STATUS_INVITED
            else:
                error_msg = f"❎ Failed to send invitation to user ({username or user_id})"
                logger.warning(f"{error_msg}")
                self._log_operation('warning', error_msg, user_id, send_notification=True)
                await self._mark_user(
                    user_id=user_id,
                    username=username,
                    status=USER_STATUS_FAILED,
                    exception_message=error_msg
                )
                return USER_STATUS_FAILED
                
        except Exception as e:
            error_msg = f"❎ Error sending invitation: {e}"
            logger.error(f"{error_msg}")
            await self._mark_user(
                user_id=user_id,
                username=username,
                status=USER_STATUS_FAILED,
                exception_message=error_msg
            )
            return USER_STATUS_FAILED


    async def _mark_user(
        self, 
        user_id: int, 
        username: str = None, 
        status: str = None, 
        exception_message: str = None
    ) -> str:
        """
        Marque un utilisateur dans la base de données.
        
        Args:
            user_id: ID de l'utilisateur
            username: Nom d'utilisateur (optionnel)
            status: Statut de l'utilisateur (ex: 'added', 'invited', 'failed')
            exception_message: Message d'erreur éventuel (optionnel)
            
        Returns:
            str: Une des constantes USER_STATUS_* selon le résultat de l'opération
                  (ex: USER_STATUS_ADDED, USER_STATUS_FAILED, etc.)
        """
        if not user_id:
            self._log_operation('error', "Cannot mark user: missing user_id")
            return USER_STATUS_FAILED
            
        max_retries = 3
        retry_delay = 1.0  # Délai initial de 1 seconde
        
        for attempt in range(max_retries):
            try:
                operation_status = await self.db.add_user(
                    user_id=user_id,
                    username=username or '',
                    account_phone=self.account_phone,
                    status=status,
                    exception_message=exception_message or ''
                )               
                return operation_status
                
            except Exception as e:
                if attempt < max_retries - 1:
                    # Attente exponentielle avec jitter avant de réessayer
                    wait_time = retry_delay * (2 ** attempt) * (0.5 + random.random())
                    self._log_operation('warning', 
                        f"Retry {attempt + 1}/{max_retries} in {wait_time:.1f}s: {str(e)}", 
                        user_id
                    )
                    await asyncio.sleep(wait_time)
                    continue
                    
                self._log_operation('error', 
                    f"Failed to mark user after {max_retries} attempts: {str(e)}", 
                    user_id,
                    exc_info=True
                )
                return USER_STATUS_FAILED
            
            
    async def _is_user_in_group_or_channel(self, user_id: int, target_entity) -> bool:
        """
        Vérifie si un utilisateur est déjà membre d'un groupe ou d'un canal.
        Utilise d'abord la base de données, puis une vérification par itération sur les participants.
        
        Args:
            user_id: ID de l'utilisateur à vérifier
            target_entity: Entité du groupe ou du canal cible
            
        Returns:
            bool: True si l'utilisateur est déjà dans le groupe ou canal, False sinon ou en cas d'erreur
        """
        if not user_id:
            logger.warning("❌ Invalid user ID provided to _is_user_in_group_or_channel")
            return False
        
        # 1. Vérification dans la base de données (pas d'appel API)
        try:
            if await self.db.member_succefully_added(user_id):
                logger.debug(f"ℹ️ User ({user_id}) is already in the group or channel (database)")
                await self._mark_user(
                    user_id=user_id,
                    username=username,
                    status=USER_STATUS_ALREADY_IN_GROUP_OR_CHANNEL,
                    exception_message=f"❎ User ({username or user_id}) is already in the target group or channel) from (database)"
                )
                self._log_operation('info', f"❎ User ({username or user_id}) is already in the target group or channel", user_id, send_notification=True)
                return USER_STATUS_ALREADY_IN_GROUP_OR_CHANNEL 
        except Exception as e:
            logger.warning(f"⚠️ Error checking database: {e}")
        
        # 2. Vérification par itération sur les participants (un seul appel API)
        try:
            # Un seul appel API pour récupérer les participants
            participants = await self.client.get_participants(target_entity, limit=200)
            
            # Vérification locale (pas d'appel API supplémentaire)
            if any(participant.id == user_id for participant in participants):
                # Récupération du nom d'utilisateur uniquement si nécessaire pour les logs
                username = f"user_{user_id}"
                try:
                    user_entity = next((p for p in participants if p.id == user_id), None)
                    if user_entity:
                        username = getattr(user_entity, 'username', username)
                except Exception as e:
                    logger.debug(f"ℹ️ Couldn't get username for {user_id}: {e}")
                
                logger.info(f"ℹ️ User ({username or user_id}) is found in the target group or channel")
                
                # Directement marquer dans la base de données 
                await self._mark_user(
                    user_id=user_id,
                    username=username,
                    status=USER_STATUS_ALREADY_IN_GROUP_OR_CHANNEL,
                    exception_message=f"❎ User ({username or user_id}) is already in the target group or channel"
                )
                self._log_operation('info', f"❎ User ({username or user_id}) is already in the target group or channel", user_id, send_notification=True)
                return USER_STATUS_ALREADY_IN_GROUP_OR_CHANNEL
                
            return False
            
        except ConnectionError as e:
            # Gérer spécifiquement les erreurs de connexion Telethon
            if "Cannot send requests while disconnected" in str(e):
                logger.warning(f"🔌 Client disconnected - cannot check user presence")
                return False  # Retourner False pour continuer avec d'autres utilisateurs
            else:
                logger.error(f"⚠️ Connection error: {e}")
                return False
        except OSError as e:
            # Gérer les erreurs réseau Windows (timeout sémaphore, etc.)
            if any(term in str(e).lower() for term in [
                "délai de temporisation de sémaphore a expiré",  # Français
                "sémaphore",                                     # Français
                "réseau",                                      # Timeout générique 
                "semaphore",                                   # Timeout générique 
                "network",                                     # Timeout générique                                 
                "network timeout",                             # Timeout réseau
                "semaphore timeout",                           # Anglais
                "the semaphore timeout period expired",        # Anglais formel
                "nom réseau spécifié n'est plus disponible",   # FR: Network name no longer available
                "network name is no longer available",         # EN: Network name no longer available
                "connection reset",                            # Connection reset
                "connection aborted",                          # Connection aborted
                "connection lost",                             # Connection lost
                "connection failed"                            # Connection failed
            ]):
                logger.warning(f"🔌 Network timeout - cannot check user presence")
                return False  # Return False to continue with other users
            else:
                logger.error(f"⚠️ Network error: {e}")
                return False
        except Exception as e:
            logger.error(f"❌ Error checking user presence: {e}", exc_info=True)
            return False