
"""
Package pour l'interaction avec l'API Telegram.

Ce package fournit des classes pour :
- Gérer les connexions aux comptes Telegram
- Scraper les membres d'un groupe ou canal source
- Ajouter des membres à un groupe ou canal cible
"""

from .telegram_client import TelegramClientManager, active_clients, cleanup_all_sessions, get_active_sessions_count, list_active_sessions
from .scraper import SourceEntityScraper
from .adder import MemberAdder

__all__ = [
    'TelegramClientManager', 
    'SourceEntityScraper', 
    'MemberAdder',
    'active_clients',
    'cleanup_all_sessions',
    'get_active_sessions_count',
    'list_active_sessions'
]