"""
Point d'entrée principal de l'application. 
"""
import asyncio
import logging
import sys
import getpass
import os
from datetime import datetime
from typing import List, Optional, Tuple

from config.settings import Config
from database.db_manager import db_manager, init_database
from sessions.session_manager import session_manager
from security.license_manager import LicenseManager
from telegram import TelegramClientManager
from telegram.telegram_client import cleanup_all_sessions
from telegram.scraper import SourceEntityScraper
from telegram.adder import MemberAdder, DailyLimitReachedError
from telethon.errors import AuthKeyUnregisteredError, UsernameNotOccupiedError, ChannelPrivateError, UserBannedInChannelError
import re
import sqlite3

# Import pour PyQt et les notifications par bot
try:
    from PyQt6.QtWidgets import QApplication
    PYQT_AVAILABLE = True
except ImportError:
    PYQT_AVAILABLE = False

# Import pour les notifications par bot
try:
    # Ajouter le chemin du dossier setup au sys.path pour importer les modules
    setup_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'setup', 'src')
    if setup_path not in sys.path:
        sys.path.insert(0, setup_path)
    
    from telegram_manager.notifications.bot_notifier import BotNotifier
    from telegram_manager.core.telegram_client import TelegramClientWrapper
    from telegram_manager.core.config import Config as TelegramConfig
    BOT_NOTIFICATIONS_AVAILABLE = True
except ImportError as e:
    print(f"ℹ️  Bot notifications not available: {e}")
    BOT_NOTIFICATIONS_AVAILABLE = False

class EmojiLogFormatter(logging.Formatter):
    """Formateur de logs personnalisé avec des emojis et couleurs pour une meilleure lisibilité."""
    # Niveaux de log avec leurs emojis et couleurs correspondants
    LEVEL_EMOJIS = {
        'DEBUG': '🐛',
        'INFO': 'ℹ️',
        'WARNING': '⚠️',
        'ERROR': '❌',
        'CRITICAL': '🔥',
    }
    
    # Couleurs pour la console (ANSI escape codes)
    COLORS = {
        'DEBUG': '\033[36m',     # Cyan
        'INFO': '\033[32m',      # Vert
        'WARNING': '\033[33m',   # Jaune
        'ERROR': '\033[31m',     # Rouge
        'CRITICAL': '\033[31;1m',# Rouge gras
        'RESET': '\033[0m',      # Réinitialisation
    }
    
    def format(self, record):
        # Récupérer le format de base
        log_fmt = self._get_format(record.levelno)
        formatter = logging.Formatter(log_fmt, datefmt='%Y-%m-%d %H:%M:%S')
        
        # Formater le message
        formatted = formatter.format(record)
        
        # Si c'est un fichier, pas de couleurs ANSI
        if not hasattr(record, 'is_console') or not record.is_console:
            return formatted
            
        # Ajouter des couleurs pour la console
        level_color = self.COLORS.get(record.levelname, '')
        return f"{level_color}{formatted}{self.COLORS['RESET']}"
    
    def _get_format(self, levelno):
        # Format pour la console
        if levelno >= logging.ERROR:
            return f"%(asctime)s - %(levelname)s %(message)s"
        elif levelno >= logging.WARNING:
            return f"%(asctime)s - %(levelname)s %(message)s"
        elif levelno >= logging.INFO:
            return f"%(asctime)s - %(levelname)s %(message)s"
        else:  # DEBUG
            return f"%(asctime)s - %(levelname)s [%(filename)s:%(lineno)d] %(message)s"

# Configuration du logger racine
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Supprimer les gestionnaires existants
for handler in logger.handlers[:]:
    logger.removeHandler(handler)

# Créer un formateur avec emojis
formatter = EmojiLogFormatter()

# Gestionnaire pour la console
console_handler = logging.StreamHandler()
console_handler.setFormatter(formatter)
# Ajouter un attribut personnalisé pour identifier la console
console_handler.is_console = True
logger.addHandler(console_handler)

# Gestionnaire pour le fichier de log (sans couleurs)
# Utilisation d'un fichier de log temporaire pour éviter les conflits
import tempfile
import os

# Créer un fichier de log temporaire dans le dossier temporaire système
temp_log_file = os.path.join(tempfile.gettempdir(), 'telegram_member_manager.log')

# Utilisation de RotatingFileHandler avec une taille maximale de 5 Mo et 3 fichiers de sauvegarde
from logging.handlers import RotatingFileHandler

file_handler = RotatingFileHandler(
    temp_log_file, 
    encoding='utf-8',
    maxBytes=5*1024*1024,  # 5 Mo
    backupCount=3
)

logger.info(f"ℹ️  Logging events to file: {temp_log_file}")
file_formatter = logging.Formatter(
    '%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
file_handler.setFormatter(file_formatter)
logger.addHandler(file_handler)

# Configuration des niveaux de log pour les bibliothèques tierces
logging.getLogger('telethon').setLevel(logging.WARNING)
logging.getLogger('aiohttp').setLevel(logging.WARNING)
logging.getLogger('asyncio').setLevel(logging.WARNING)
logging.getLogger('sqlalchemy.engine').setLevel(logging.WARNING)  # Réduire les logs SQL
logging.getLogger('PIL').setLevel(logging.WARNING)  # Réduire les logs de PIL/Pillow

# Filtre personnalisé pour les logs de déconnexion
class ConnectionFilter(logging.Filter):
    def filter(self, record):
        # Masquer les messages de déconnexion courants
        if 'Disconnected from' in record.getMessage():
            return False
        # Masquer les messages de reconnexion
        if 'Connection to' in record.getMessage() and 'complete' in record.getMessage():
            return False
        return True

class DatabaseLockFilter(logging.Filter):
    def filter(self, record):
        # Masquer les messages de verrouillage de base de données
        message = str(record.getMessage()).lower()
        if any(term in message for term in [
            'database is locked',
            'cannot get difference for group/channel',
            'misusing the session',
            'unhandled exception from keepalive_handle',
            'task exception was never retrieved',
            'impossible to retrieve the source group/channel title',
            'connection error: database is locked',
            'error accessing the target group/channel : database is locked',
            'safety level may not be changed inside a transaction',
            'task was destroyed but it is pending',
            'coroutine ignored generatorExit',
            'coroutine ignored generatorexit',
            'coroutine ignored generator exit',
            'coroutine ignored generator_exit',
            'coroutine ignored generator error'
        ]):
            return False
        return True

def setup_logging_filters():
    # Créer et ajouter les filtres
    connection_filter = ConnectionFilter()
    db_filter = DatabaseLockFilter()
    
    # Appliquer les filtres à tous les handlers existants
    for handler in logging.root.handlers:
        handler.addFilter(connection_filter)
        handler.addFilter(db_filter)
    
    # Configurer le logger de telethon
    telethon_logger = logging.getLogger('telethon')
    telethon_logger.setLevel(logging.ERROR)  # Ne montrer que les erreurs
    for handler in telethon_logger.handlers:
        handler.addFilter(db_filter)

# Configurer les filtres de logs
setup_logging_filters()

# Variable globale pour le bot notifier
bot_notifier = None

async def init_bot_notifier(account_phone: str):
    """Initialise le bot notifier pour les notifications en créant une connexion dédiée."""
    global bot_notifier
    if not BOT_NOTIFICATIONS_AVAILABLE:
        return None
        
    try:
        # Importer les modules nécessaires
        setup_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'setup', 'src')
        if setup_path not in sys.path:
            sys.path.insert(0, setup_path)
            
        from telegram import TelegramClientManager
        from telegram_manager.core.telegram_client import TelegramClientWrapper
        from telegram_manager.core.config import Config as TelegramConfig
            
        # Créer un client manager temporaire pour le bot notifier
        client_manager = TelegramClientManager(account_phone)
            
        if await client_manager.connect():
            # Attendre que le client soit pleinement authentifié
            max_wait = 10  # 10 secondes max
            wait_time = 0
            while wait_time < max_wait:
                try:
                    # Vérifier si le client est connecté et authentifié
                    if client_manager.client and await client_manager.client.is_user_authorized():
                        user_info = await client_manager.client.get_me()
                        if user_info:
                            break
                except Exception:
                    pass
                    
                await asyncio.sleep(1)
                wait_time += 1
                
            # Vérifier finale
            if client_manager.client and await client_manager.client.is_user_authorized():
                try:
                    user_info = await client_manager.client.get_me()
                    if user_info:
                        # Créer un wrapper temporaire pour le bot notifier
                        # en utilisant le client existant
                        telegram_config = TelegramConfig()
                        client_wrapper = TelegramClientWrapper(telegram_config.config)
                            
                        # Remplacer le client interne par celui du manager
                        client_wrapper.client = client_manager.client
                        client_wrapper._is_connected = True
                        client_wrapper._user = user_info
                        client_wrapper.phone = account_phone
                            
                        # Créer le bot notifier
                        bot_notifier = BotNotifier(client_wrapper)
                        if await bot_notifier.start():
                            print(f"✅ Bot notifications enabled for account {account_phone}")
                            return bot_notifier
                        else:
                            print(f"⚠️  Bot notifications failed to start for account {account_phone}")
                            return None
                    else:
                        print(f"⚠️  Cannot get user info for bot notifications with account {account_phone}")
                        return None
                except Exception as e:
                    print(f"⚠️  Error getting user info for bot notifications: {e}")
                    return None
            else:
                print(f"⚠️  Cannot connect to Telegram for bot notifications with account {account_phone}")
                return None
        else:
            print(f"⚠️  Cannot connect to Telegram for bot notifications with account {account_phone}")
            return None
                
    except Exception as e:
        print(f"⚠️  Error initializing bot notifier: {e}")
        return None

async def send_bot_notification(message: str, is_error: bool = False):
    """Envoie une notification via le bot si disponible."""
    global bot_notifier
    if bot_notifier:
        try:
            await bot_notifier.send_notification(message, is_error)
        except Exception as e:
            print(f"⚠️  Error sending bot notification: {e}")
    else:
        print(f"ℹ️  Bot not available for notification: {message[:50]}...")

async def cleanup_bot_notifier():
    """Nettoie le bot notifier."""
    global bot_notifier
    if bot_notifier:
        try:
            await bot_notifier.close()
            bot_notifier = None
        except Exception as e:
            print(f"⚠️  Error cleaning up bot notifier: {e}")

# Ajouter le filtre au logger racine
for handler in logging.root.handlers:
    handler.addFilter(ConnectionFilter())

async def get_group_info(account_phone: str) -> Tuple[str, str]:
    """
    Demande à l'utilisateur les informations sur les groupes ou canal source et cible.
    Vérifie d'abord s'il existe une session précédente.
    
    Args:
        account_phone: Numéro de téléphone du compte
        
    Returns:
        Tuple[str, str]: (groupe/canal_cible, groupe/canal_source)
        
    Raises:
        SystemExit: Si l'utilisateur interrompt la saisie (Ctrl+C ou fermeture du terminal)
    """
    def safe_input(prompt: str) -> str:
        """Gère la saisie utilisateur avec gestion des interruptions."""
        try:
            return input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\n[INFO] Application shutdown...")
            raise SystemExit(0)
        
    # Vérifier s'il existe une session précédente
    last_session = session_manager.get_last_session(account_phone)
    if last_session and last_session.get('target_entity') and last_session.get('source_entity'):
        try:
            print("\nℹ️  === 📡Previous session found📡 ===")
            print(f"Previous target group [or] channel: {last_session['target_entity']}")
            print(f"Previous source group [or] channel: {last_session['source_entity']}")
            print("\nDo you want to use these groups or channels? (Yes/No) ")
            use_previous = safe_input("[" + "Y".upper() + "/" + "n".lower() + "] (default: yes)").lower()
            
            if use_previous in ('', 'o', 'oui', 'y', 'yes'):
                return last_session['target_entity'], last_session['source_entity']
        except SystemExit:
            raise
        except Exception as e:
            logger.warning(f"ℹ️  Error while retrieving previous session: {e}")
            print("\nUsing manual input...\n")
    
    # Display usage instructions
    print("\nℹ️  === 💻Usage instructions💻 ===")
    print("1. Format of group or channel links:")
    print("   - Public link : https://t.me/group-or-channel_name")
    print("   - Private link : https://t.me/group_or_channel_private_id")
    print("\n2. Ensure you are an administrator or have the necessary permissions :")
    print(" - (view members, add members) between the two groups or channels")
    print("=" * 32 + "\n")

    # Ask for user input
    target_entity = ""
    while not target_entity:
        try:
            target_entity = safe_input("🛃 Enter the link of the target group or channel (where to add members): ")
            if not target_entity:
                print("ℹ️  Please enter a valid group or channel link.")
        except SystemExit:
            raise
        except Exception as e:
            logger.error(f"ℹ️  Error while entering the target group or channel link: {e}")
            print("ℹ️  Error while entering. Please try again.")
    
    source_entity = ""
    while True:
        try:
            source_entity = safe_input("\n🛃 Enter the link of the source group or channel (where to retrieve members): ")
            
            if not source_entity:
                # Vérifier si des fichiers CSV existent déjà
                available_csvs = list_available_csv_files()
                if available_csvs:
                    print(f"\nℹ️  CSV files found : {', '.join(available_csvs)}")
                    print("ℹ️  You can use these CSV files to add members without scraping.")
                    break
                else:
                    print("\nℹ️  No CSV files found. Please enter a source group or channel to retrieve members.")
            else:
                break
        except SystemExit:
            raise
        except Exception as e:
            logger.error(f"ℹ️  Error while entering the source group or channel link: {e}")
            print("ℹ️  Error while entering. Please try again.")
    
    # Save the session for future use
    try:
        session_manager.save_session(account_phone, source_entity, target_entity)
    except Exception as e:
        logger.warning(f"ℹ️  Unable to save the session: {e}")
    
    return target_entity, source_entity

def get_physical_sessions():
    """
    Scan les dossiers de sessions physiques pour trouver les comptes existants.
    
    Returns:
        List[str]: Liste des numéros de téléphone des sessions physiques existantes,
                  triées par date de création (plus ancien au plus récent)
    """
    from pathlib import Path
    
    sessions_with_dates = []
    
    # Scanner les dossiers account_sessions
    account_sessions_dir = Path("sessions/telegram_sessions/account_sessions")
    if account_sessions_dir.exists():
        for account_dir in account_sessions_dir.iterdir():
            if account_dir.is_dir():
                # Extraire le numéro du nom du dossier "account_242069230959"
                if account_dir.name.startswith("account_"):
                    phone = account_dir.name.replace("account_", "")
                    # Formater avec le +
                    if phone.isdigit():
                        # Récupérer la date de création du dossier
                        creation_time = account_dir.stat().st_ctime
                        sessions_with_dates.append((f"+{phone}", creation_time))
    
    # Fallback : scanner l'ancien emplacement
    old_sessions_dir = Path("sessions")
    if old_sessions_dir.exists():
        for session_file in old_sessions_dir.glob("session_*.session"):
            # Extraire le numéro du nom de fichier "session_242069230959.session"
            phone = session_file.stem.replace("session_", "")
            if phone.isdigit():
                # Récupérer la date de création du fichier
                creation_time = session_file.stat().st_ctime
                sessions_with_dates.append((f"+{phone}", creation_time))
    
    # Dédupliquer (garder la date la plus ancienne si doublon)
    unique_sessions = {}
    for phone, creation_time in sessions_with_dates:
        if phone not in unique_sessions or creation_time < unique_sessions[phone]:
            unique_sessions[phone] = creation_time
    
    # Trier par date de création (plus ancien au plus récent)
    sorted_sessions = sorted(unique_sessions.items(), key=lambda x: x[1])
    
    # Retourner seulement les numéros de téléphone
    return [phone for phone, _ in sorted_sessions]

async def delete_telegram_sessions():
    """
    Permet à l'utilisateur de supprimer les fichiers de session Telegram de son choix.
    """
    import os
    from pathlib import Path
    
    # Rechercher les sessions dans la nouvelle structure organisée
    sessions_dir = Path("sessions/telegram_sessions")
    
    # Récupérer tous les fichiers .session dans les sous-dossiers
    session_files = []
    
    # Rechercher dans account_sessions (uniquement les comptes, pas les bots)
    account_sessions_dir = sessions_dir / "account_sessions"
    if account_sessions_dir.exists():
        for account_dir in account_sessions_dir.iterdir():
            if account_dir.is_dir():
                session_files.extend(list(account_dir.glob("*.session")))
    
    # Fallback : rechercher dans l'ancien emplacement pour compatibilité
    app_data = os.environ.get('APPDATA', os.path.expanduser('~'))
    old_sessions_dir = Path(app_data) / 'TelegramManager' / 'data' / 'session'
    if old_sessions_dir.exists():
        session_files.extend(list(old_sessions_dir.glob("*.session")))
    
    if not session_files:
        print("\nℹ️  No Telegram session files found.")
        input("\nPlease restart the program to continue...")
        return
    
    # Trier les sessions par type puis par numéro de téléphone
    session_files.sort(key=lambda x: (x.parent.parent.name if x.parent.parent.name in ["account_sessions", "bot_sessions"] else "legacy", x.name))
    
    print("\n" + "="*60)
    print("🗑️ TELEGRAM SESSION MANAGEMENT")
    print("="*60)
    print("Account sessions available (bots will be automatically deleted):")
    
    for i, session_file in enumerate(session_files, 1):
        # Déterminer le type de session et extraire le numéro
        grandparent_dir = session_file.parent.parent.name
        
        if grandparent_dir == "account_sessions":
            session_type = "👤 Account"
            # Extraire le numéro de "session_242069230959.session"
            phone = session_file.name.replace("session_", "").replace(".session", "")
            display_phone = f"+{phone}" if phone.isdigit() else phone
            
            # Vérifier si une session de bot correspondante existe
            bot_session_folder = sessions_dir / "bot_sessions" / f"bot_{phone}"
            bot_status = "🤖 Bot exists" if bot_session_folder.exists() else "ℹ️ No bot"
        elif grandparent_dir == "bot_sessions":
            # Ne devrait pas apparaître car on ne liste pas les bots
            continue
        else:
            session_type = "📁 Legacy"
            phone = session_file.name.replace("session_", "").replace(".session", "")
            display_phone = f"+{phone}" if phone.isdigit() else phone
            bot_status = "N/A"
        
        file_size = session_file.stat().st_size
        mod_time = session_file.stat().st_mtime
        
        print(f"  {i}. {session_type} - {display_phone} ({bot_status})")
        print(f"     File : {session_file}")
        print(f"     Size : {file_size:,} bytes")
        print(f"     Modified : {datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')}")
        print()
    
    print("0. Cancel")
    print("="*60)
    
    while True:
        try:
            choice = input("\n🔢 Choose the number of the session to delete (0 to cancel) : ").strip()
            
            if choice == '0':
                print("\n❌ Operation cancelled.")
                return
            
            choice_num = int(choice)
            if 1 <= choice_num <= len(session_files):
                selected_file = session_files[choice_num - 1]
                
                # Déterminer le type de session et le dossier à supprimer
                parent_dir = selected_file.parent
                grandparent_dir = selected_file.parent.parent.name
                
                if grandparent_dir == "account_sessions":
                    session_type = "Account"
                    # Extraire le numéro de "session_242069230959.session"
                    phone = selected_file.name.replace("session_", "").replace(".session", "")
                    display_phone = f"+{phone}" if phone.isdigit() else phone
                    folder_to_delete = parent_dir  # account_242069230959
                elif grandparent_dir == "bot_sessions":
                    session_type = "Bot"
                    # Extraire le numéro de "session_bot_242069230959.session"
                    phone = selected_file.name.replace("session_bot_", "").replace(".session", "")
                    display_phone = f"+{phone}" if phone.isdigit() else phone
                    folder_to_delete = parent_dir  # bot_242069230959
                else:
                    session_type = "Legacy"
                    phone = selected_file.name.replace("session_", "").replace(".session", "")
                    display_phone = f"+{phone}" if phone.isdigit() else phone
                    folder_to_delete = selected_file  # Just the file for legacy
                
                # Confirmation de suppression
                if grandparent_dir in ["account_sessions", "bot_sessions"]:
                    print(f"\n⚠️  ATTENTION : You are about to delete the {session_type.lower()} session {display_phone}")
                    print(f"   Folder to delete : {folder_to_delete}")
                    print(f"   This will delete ALL files in this folder!")
                else:
                    print(f"\n⚠️  ATTENTION : You are about to delete the legacy session {display_phone}")
                    print(f"   File : {selected_file}")
                
                print("   This action is irreversible!")
                print("   The session will need to be recreated to use this account.")
                
                confirm = input("\nAre you sure you want to continue? (Yes/No) : ").lower().strip()
                
                if confirm in ('o', 'oui', 'y', 'yes'):
                    try:
                        if grandparent_dir == "account_sessions":
                            # Supprimer tout le dossier du compte
                            import shutil
                            shutil.rmtree(folder_to_delete)
                            print(f"\n✅ {session_type} session {display_phone} deleted successfully!")
                            print(f"✅ Folder {folder_to_delete.name} and all its contents deleted!")
                            
                            # Supprimer automatiquement la session du bot correspondant
                            bot_session_folder = sessions_dir / "bot_sessions" / f"bot_{phone}"
                            if bot_session_folder.exists():
                                shutil.rmtree(bot_session_folder)
                                print(f"✅ Bot session {display_phone} automatically deleted!")
                                print(f"✅ Bot folder {bot_session_folder.name} and all its contents deleted!")
                                
                                # Supprimer aussi la session du bot du gestionnaire
                                bot_phone = f"bot_{phone}"
                                session_manager.clear_session(bot_phone)
                                print(f"✅ Internal bot session data deleted for {display_phone}")
                            else:
                                print(f"ℹ️  No bot session found for {display_phone}")
                                
                        elif grandparent_dir == "bot_sessions":
                            # Supprimer tout le dossier du bot
                            import shutil
                            shutil.rmtree(folder_to_delete)
                            print(f"\n✅ {session_type} session {display_phone} deleted successfully!")
                            print(f"✅ Folder {folder_to_delete.name} and all its contents deleted!")
                        else:
                            # Supprimer seulement le fichier legacy
                            selected_file.unlink()
                            print(f"\n✅ Legacy session {display_phone} deleted successfully!")
                        
                        # Supprimer aussi la session du gestionnaire si elle existe
                        session_manager.clear_session(phone)
                        print(f"✅ Internal session data deleted for {display_phone}")
                        
                        # Vérifier et supprimer toutes les données associées dans le session manager
                        all_sessions = session_manager.get_all_sessions()
                        associated_sessions = [s_phone for s_phone in all_sessions.keys() 
                                            if phone in s_phone or s_phone.replace('bot_', '') == phone]
                        
                        for associated_phone in associated_sessions:
                            if associated_phone != phone:  # Éviter de supprimer deux fois le même
                                session_manager.clear_session(associated_phone)
                                print(f"✅ Associated session data deleted for {associated_phone}")
                        
                        if len(associated_sessions) > 1:
                            print(f"✅ Total {len(associated_sessions)} session entries cleaned from session database")
                        
                    except Exception as e:
                        print(f"\n❌ Error deleting session : {e}")
                else:
                    print("\n❌ Deletion cancelled.")
                
                input("\nPlease restart the program to continue...")
                return
            else:
                print(f"❌ Invalid choice. Please choose between 0 and {len(session_files)}")
                
        except ValueError:
            print("❌ Please enter a valid number.")
        except KeyboardInterrupt:
            print("\n\n❌ Operation cancelled.")
            return

async def main():
    """Fonction principale asynchrone."""
    # Configurer les filtres de logs
    setup_logging_filters()
    
    try:
        # Vérification de la licence
        if not check_license():
            return

        # Vérification des sessions existantes (scan des dossiers physiques)
        sessions = get_physical_sessions()
        if not sessions:
            print("\nℹ️  No existing sessions found.")
            print("📱 We will create your first session.")
            
            # Demander directement le numéro de téléphone pour créer la première session
            phone = input("\n📱 Enter your phone number (e.g., +1234567890) : ").strip()
            if not phone:
                print("❌ No phone number provided.")
                return
                
            print(f"ℹ️  Creating a new session for the number {phone}...")
            session_manager.save_session(phone, "", "")
            print("✅ Session created successfully!")
        else:
            # Afficher les sessions disponibles
            print("\n📱 Sessions available :")
            for i, session in enumerate(sessions, 1):
                print(f"  {i}. {session}")

            # Demander le numéro de téléphone du compte à utiliser
            phone = input("\n📱 Enter the phone number of the account to use : ").strip()
            if not phone:
                print("❌ No phone number provided.")
                return

        # Vérifier si la session existe, sinon en créer une nouvelle
        if not session_manager.session_exists(phone):
            print(f"ℹ️  Session {phone} does not exist. Creating it...")
            session_manager.save_session(phone, "", "")
            print("✅ Session created successfully!")

        # Demander les informations sur les groupes source et cible
        target_entity, source_entity = await get_group_info(phone)

        # Menu principal
        while True:
            print("\n" + "="*50)
            print("📱 MAIN MENU")
            print("="*50)
            print("1. Retrieve members from a source group [or channel]")
            print("2. Add members to the target group [or channel]")
            print("3. Change account")
            print("4. Delete a Telegram session")
            print("5. Quit")
            print("="*50)

            choice = input("\n🔢 Choose an option (1-5) : ").strip()

            if choice == '1':
                # Scraper les membres
                await scrape_members(phone, source_entity)
            elif choice == '2':
                # Ajouter des membres
                # Utiliser directement le numéro de téléphone connu
                await add_members_to_group(target_entity, source_entity, phone)
                # Nettoyer le bot notifier
                await cleanup_bot_notifier()
            elif choice == '3':
                # Changer de compte
                return await main()
            elif choice == '4':
                # Supprimer une session Telegram
                await delete_telegram_sessions()
            elif choice == '5':
                # Quitter
                print("\n✅ You have exited the program!")
                return
            else:
                print("\n❌ Invalid choice. Please try again.")
    except KeyboardInterrupt:
        print("\n\n❌ Operation interrupted by the user.")
    except Exception as e:
        logger.critical(f"Critical error: {e}", exc_info=True)
        return 1
    finally:
        # Nettoyer le bot notifier
        await cleanup_bot_notifier()
        # Fermer les connexions à la base de données
        await db_manager.close()
    
    return 0

async def scrape_members(phone: str, entity_link: str) -> int:
    """
    Scraper les membres d'un groupe avec gestion améliorée des erreurs et du feedback utilisateur.
    
    Args:
        phone: Numéro de téléphone du compte à utiliser
        entity_link: Lien ou ID du groupe source
        
    Returns:
        int: Nombre de membres récupérés, ou 0 en cas d'échec
    """
    from utils.progress import ProgressBar
    from database.db_manager import db_manager
    
    print("\n" + "="*50)
    print("🔍 STARTING MEMBERS RETRIEVAL")
    print("="*50)
    print(f"📱 Account : {phone}")
    print(f"👥 Source entity : {entity_link}")
    
    # Initialiser la base de données avec le groupe source
    try:
        # ✅ Récupérer le titre du groupe pour un nom de base de données plus lisible
        entity_title = None
        try:
            from telegram.telegram_client import TelegramClientManager
            temp_client = TelegramClientManager(phone)
            await temp_client.connect()
            
            try:
                target_entity = await temp_client.client.get_entity(entity_link)
                entity_title = getattr(target_entity, 'title', None)
                if entity_title:
                    print(f"📝 Source entity group[or channel] detected : '{entity_title}'")
            except Exception as e:
                logger.warning(f"Impossible to retrieve the entity title : {e}")
            finally:
                await temp_client.disconnect()
        except Exception as e:
            logger.warning(f"Impossible to connect to retrieve the entity title : {e}")
        
        await db_manager.initialize(entity_link, entity_title)
    except Exception as e:
        print(f"❌ Error initializing the database : {e}")
        return 0
    
    client = None
    try:
        print(f"\n🔍 Starting members retrieval with account '{phone}'...")
        
        # Connexion au compte avec gestion améliorée des erreurs
        print("\n🔑 Connecting to Telegram account...")
        client = TelegramClientManager(phone)
        
        try:
            if not await client.connect():
                logger.error("ℹ️  Failed to connect to the account")
                print("❌ Impossible to connect to the account. Verify your credentials and try again.")
                return 0
        except Exception as e:
            logger.error(f"ℹ️  Connection error: {e}")
            print(f"❌ Connection error: {str(e)[:200]}")
            return 0
            
        # Vérification de l'accès au groupe source
        print("\n🔍 Searching for the source group[or channel]...")
        try:
            entity = await client.client.get_entity(entity_link)
            entity_title = getattr(entity, 'title', 'Group or channel without name')
            print(f"✅ Group or channel found : {entity_title}")
        except Exception as e:
            logger.error(f"ℹ️  Impossible to find the group or channel {entity_link}: {e}")
            print("\n❌ Impossible to access the source group/channel. Verify that :")
            print("   - The link is correct")
            print("   - The account is a member of the group or channel")
            print("   - The group or channel is not restricted to reading")
            return 0
            
        # Début du scraping
        print("\n📊 Starting members retrieval...")
        try:
            scraper = SourceEntityScraper(client.client)
            members, existing_count = await scraper.get_members(entity_link)
            count = len(members)
            
            if count > 0:
                logger.info(f"ℹ️  {count} members retrieved successfully")
                print(f"\n✅ {count} members have been retrieved successfully!")
                print("📄 Members have been saved to custom CSV files according to the account used.")
                print("   ℹ️  Each Telegram account has its own CSV file to avoid conflicts.")
            else:
                logger.warning("ℹ️  No members were retrieved")
                print("\nℹ️  No members were retrieved. Verify that :")
                print("   - The group or channel contains members")
                print("   - The account has the necessary permissions")
                print("   - The group or channel is not restricted to reading")
                
            return count
            
        except Exception as e:
            logger.error(f"ℹ️  Error during members retrieval: {e}", exc_info=True)
            print(f"\n❌ An error occurred during members retrieval : {str(e)[:200]}")
            return 0
            
    except Exception as e:
        logger.error(f"ℹ️  Unexpected error: {e}", exc_info=True)
        print(f"\n❌ Une erreur inattendue est survenue : {str(e)[:200]}")
        return 0
        
    finally:
        if client:
            await client.disconnect()

def find_csv_for_account(account_phone, account=None, source_entity=None):
    """
    Trouve le fichier CSV approprié pour un compte donné.
    
    Args:
        account_phone: Numéro de téléphone du compte
        account: Objet account (optionnel, pour obtenir le téléphone si non fourni)
        source_entity: Nom du groupe source (optionnel, pour affiner la recherche)
        
    Returns:
        str: Chemin vers le fichier CSV à utiliser
    """
    import os
    import glob
    import re
    
    # Si account_phone n'est pas fourni mais qu'on a l'account, essayer de l'obtenir
    if (not account_phone or account_phone == 'unknown') and account:
        try:
            # Essayer d'obtenir le téléphone depuis l'account
            if hasattr(account, 'phone_number'):
                account_phone = account.phone_number
            elif hasattr(account, 'phone'):
                account_phone = account.phone
            elif hasattr(account, 'client'):
                # Essayer d'obtenir les infos depuis le client
                import asyncio
                try:
                    me = asyncio.run(account.client.get_me())
                    account_phone = getattr(me, 'phone', None)
                except:
                    pass
        except Exception:
            pass
    
    if account_phone and account_phone != 'unknown':
        # Nettoyer le numéro de téléphone pour correspondre au format du nom de fichier
        # Remplacer uniquement les caractères non valides pour les noms de fichiers, mais garder le +
        clean_phone = account_phone.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
        phone_without_plus = clean_phone.replace('+', '')  # Numéro sans + pour l'ancien format
        
        # Si source_entity est fourni, chercher d'abord les fichiers spécifiques à ce groupe
        if source_entity:
            # Extraire et nettoyer le lien du groupe pour le nom de fichier
            if 't.me/' in source_entity:
                clean_entity_link = source_entity.split('t.me/')[-1]
            else:
                clean_entity_link = source_entity
            
            # Nettoyer le lien pour le nom de fichier
            clean_entity_link = re.sub(r'[^\w\s-]', '', clean_entity_link)
            clean_entity_link = re.sub(r'[-\s]+', '_', clean_entity_link)
            clean_entity_link = clean_entity_link [:50]  # Limiter la longueur
            
            # Chercher le fichier spécifique au compte et groupe (format préféré avec +)
            account_csv = f"csv_data/members_+{phone_without_plus}_{clean_entity_link}.csv"
            if os.path.exists(account_csv):
                print(f"✅ CSV file found for account {account_phone} and entity {source_entity} : {account_csv}")
                return account_csv
            else:
                print(f"⚠️  CSV file {account_csv} not found, searching for other files for this account...")
        
        # Chercher tous les fichiers pour ce compte (avec ou sans groupe, avec ou sans +)
        # Essayer d'abord avec le + (format personnalisé)
        account_files_with_plus = glob.glob(f"csv_data/members_+{phone_without_plus}_*.csv")
        if account_files_with_plus:
            print(f"📁 CSV files found for the account {account_phone} (format with +) : {', '.join(account_files_with_plus)}")
            selected_file = account_files_with_plus[0]
            print(f"🔄 Using file : {selected_file}")
            return selected_file
        
        # Ensuite essayer sans le + (format original)
        account_files = glob.glob(f"csv_data/members_{phone_without_plus}_*.csv")
        if account_files:
            print(f"📁 CSV files found for the account {account_phone} (original format) : {', '.join(account_files)}")
            selected_file = account_files[0]
            print(f"🔄 Using file : {selected_file}")
            return selected_file
        
        # Fallback ancien format (sans groupe)
        old_format_csv = f"csv_data/members_{phone_without_plus}.csv"
        if os.path.exists(old_format_csv):
            print(f"✅ CSV file found (old format) for account {account_phone} : {old_format_csv}")
            return old_format_csv
        else:
            # Fallback ancien format avec +
            old_format_csv_with_plus = f"csv_data/members_+{phone_without_plus}.csv"
            if os.path.exists(old_format_csv_with_plus):
                print(f"✅ CSV file found (old format with +) for account {account_phone} : {old_format_csv_with_plus}")
                return old_format_csv_with_plus
            print(f"⚠️  No file found for account {account_phone}, searching for other files...")
    
    # Lister tous les fichiers members_*.csv disponibles
    csv_files = glob.glob("csv_data/members_*.csv")
    if csv_files:
        print(f"📁 Available CSV files: {', '.join(csv_files)}")
        # Utiliser le premier fichier trouvé
        selected_file = csv_files[0]
        print(f"🔄 Using file : {selected_file}")
        return selected_file
    
    # Vérifier aussi dans le répertoire principal (compatibilité avec anciens fichiers)
    csv_files_main = glob.glob("members_*.csv")
    if csv_files_main:
        print(f"📁 Available CSV files in main directory (legacy): {', '.join(csv_files_main)}")
        selected_file = csv_files_main[0]
        print(f"🔄 Using legacy file : {selected_file}")
        return selected_file
    
    # Fallback absolu - créer un fichier avec timestamp si aucun fichier n'existe
    import time
    timestamp = int(time.time())
    fallback_file = f"csv_data/members_fallback_{timestamp}.csv"
    print(f"⚠️  No CSV file found, using fallback file : {fallback_file}")
    print("   ℹ️  Please first retrieve members to create a valid CSV file")
    return fallback_file

def list_available_csv_files():
    """
    Liste tous les fichiers CSV de membres disponibles.
    
    Returns:
        list: Liste des fichiers CSV disponibles
    """
    import os
    import glob
    
    # Lister uniquement les fichiers members_*.csv (fichiers personnalisés)
    csv_files = glob.glob("csv_data/members_*.csv")
    
    # Ajouter le fichier par défaut s'il existe et qu'il n'y a pas d'autres fichiers
    if not csv_files:
        from config.settings import Config
        if os.path.exists("csv_data/members.csv"):  # Vérification directe du fichier par défaut
            csv_files.append("csv_data/members.csv")
    
    # Ajouter les fichiers legacy du répertoire principal pour compatibilité
    legacy_files = glob.glob("members_*.csv")
    if legacy_files:
        csv_files.extend(legacy_files)
    
    return sorted(csv_files)

async def add_members_to_group(target_entity, source_info=None, account_phone=None):
    """
    Ajoute les membres à un groupe ou canal cible.
    
    Args:
        target_entity: Lien ou nom du groupe cible
        source_info: Informations sur la source des membres
        account_phone: Numéro de téléphone du compte à utiliser
    """
    from telegram.adder import MemberAdder
    from utils.progress import ProgressBar
    
    # Convertir account_phone en liste pour compatibilité avec logique existante
    phone_numbers = [account_phone] if account_phone else []  
    from database.db_manager import db_manager
    
    print("\n" + "="*50)
    print("🚀 STARTING MEMBERS ADDITION")
    print("="*50)
    print(f"🎯 Target entity : {target_entity}")
    print(f"📂 Source members : {source_info if source_info else 'Default CSV file'}")
    
    # Initialize the database with the source group
    try:
        # ✅ Récupérer le titre du groupe source pour un nom de base de données plus lisible
        entity_title = None
        if source_info:
            try:
                from telegram.telegram_client import TelegramClientManager
                temp_client = TelegramClientManager(account_phone)
                await temp_client.connect()
                
                try:
                    source_entity = await temp_client.client.get_entity(source_info)
                    entity_title = getattr(source_entity, 'title', None)
                    if entity_title:
                        print(f"📝 Source entity title detected : '{entity_title}'")
                except Exception as e:
                    logger.warning(f"Impossible to retrieve the source entity title : {e}")
                finally:
                    await temp_client.disconnect()
            except Exception as e:
                logger.warning(f"Impossible to connect to retrieve the source entity title : {e}")
        
        await db_manager.initialize(source_info if source_info else "default_source", entity_title)
    except Exception as e:
        print(f"❌ Error initializing the database : {e}")
        return
    
    # Do not create a backup here, we will do it just before adding members
    backup_created = False
    
    try:
        # ✅ Détection automatique du fichier CSV selon le compte et groupe source
        csv_file = find_csv_for_account(account_phone, None, source_info)
        
        try:
            with open(csv_file, 'r', encoding='utf-8') as f:
                member_count = sum(1 for _ in f) - 1  # Compter les lignes - l'en-tête
                if member_count <= 0:
                    print(f"\n❌ Error : The CSV file {csv_file} is empty or does not contain valid members.")
                    print("   ℹ️  Please first retrieve members before launching the addition.")
                    return
                print(f"\n✅ {member_count} members found in the CSV file {csv_file}")
        except FileNotFoundError:
            print(f"\n❌ Error : The CSV file {csv_file} does not exist.")
            print("   ℹ️  Please first retrieve members before launching the addition.")
            return
        except Exception as e:
            print(f"\n❌ Error reading the CSV file {csv_file}:")
            print(f"   ℹ️  {str(e)}")
            return
        
        # Verify bot token
        bot_token = Config.BOT_TOKEN
        if not bot_token:
            print("\n⚠️  Warning : No bot token configured.")
            print("   ℹ️  Message invitations will not be available.")
            print("   ℹ️  To activate this feature, add BOT_TOKEN in your .env file")
        else:
            print("\n🤖 Bot token detected. Message invitations will be sent via the bot.")
        
        # Récupérer l'entité du groupe cible (une seule fois pour tous les comptes)
        try:
            from telegram.telegram_client import TelegramClientManager
            temp_client = TelegramClientManager(account_phone)
            await temp_client.connect()
            target_entity = await temp_client.client.get_entity(target_entity)
            await temp_client.disconnect()
            print(f"\n✅ Target entity validated : {target_entity}")
        except AuthKeyUnregisteredError as e:
            # Gestion spécifique : clé non enregistrée
            logger.error(f"Authentication key unregistered for account {account_phone}: {e}")
            print(f"\n❌ Authentication error for account {account_phone}")
            print("The account session is invalid or has been revoked.")
            print("Possible solutions:")
            print("1. Delete the current session and re-authenticate the account")
            print("2. Use a different account")
            print("3. Check if the account is still active on Telegram")
            print(f"- Technical details: {e}")
            return
        except (UsernameNotOccupiedError, ChannelPrivateError, UserBannedInChannelError) as e:
            # Gestion spécifique : nom d'utilisateur invalide ou accès refusé
            logger.error(f"Cannot access group/channel '{target_entity}': {e}")
            print(f"\n❌ Invalid target group/channel: {target_entity}")
            print("The username or link is not valid or accessible.")
            print("Possible solutions:")
            print("1. Verify the group/channel link is correct")
            print("2. Ensure the account has access to the group/channel")
            print("3. Use the direct ID instead of username if available")
            print("4. Check if the group is private or if you're banned from it")
            print(f"- Technical details: {e}")
            return
        except ValueError as e:
            # Gestion spécifique : erreur de valeur (souvent liée au bot token)
            if "bytes or str expected, not" in str(e):
                logger.error(f"Bot token error for account {account_phone}: {e}")
                print(f"\n❌ Bot token configuration error")
                print("The bot token is invalid or not properly configured.")
                print("Possible solutions:")
                print("1. Verify the bot token is correct and active")
                print("2. Check if the bot has the necessary permissions")
                print("3. Re-generate a new bot token from @BotFather")
                print("4. Use the account directly instead of bot if token issues persist")
                print(f"- Technical details: {e}")
                return
            else:
                # Autres erreurs de valeur
                logger.error(f"Value error: {e}")
                print(f"\n❌ Configuration error: {e}")
                print(f"- Technical details: {e}")
                return
        except Exception as e:
            logger.error(f"Error accessing the target group/channel : {e}", exc_info=True)
            print(f"\n❌ Error accessing the target group/channel : {e}")
            print("Verify that the link is correct and that the account has access to the group or channel.")
            print("ℹ️ If database is locked, Close the program(click on 'Stop' button) and restart it(click on 'Start' button)")
            print(f"ℹ️ Detailed error : {e}")
            return
            
    except Exception as e:
        logger.error(f"Error preparing members addition : {e}", exc_info=True)
        
        # En cas d'erreur, proposer de restaurer la sauvegarde
        if 'backup_path' in locals() and backup_path and backup_path.exists():
            print(f"\n❌ An error occurred. Do you want to restore the backup? (Y/n)")
            if input().lower() in ('', 'o', 'oui', 'y', 'yes'):
                try:
                    import shutil
                    shutil.copy2(backup_path, db_manager.db_path)
                    print("✅ Database restored from backup.")
                except Exception as restore_error:
                    print(f"❌ Error during the restoration : {restore_error}")
                    print(f"You can manually restore the backup from : {backup_path}")
        
        raise  # Relancer l'exception pour une gestion ultérieure
    
    # For each account
    for phone in phone_numbers:
        client = None
        try:
            print("\n" + "-"*50)
            print(f"📱 ACCOUNT PROCESSING : {phone}")
            print("-"*50)
            
            # Connect to the account with improved error handling
            print("\n🔑 Connecting to Telegram account...")
            from telegram.telegram_client import TelegramClientManager
            client = TelegramClientManager(phone)
            await client.connect()
            target_title = getattr(target_entity, 'title', 'Group or channel without name')
            print(f"✅ Target group or channel found : {target_title}")
            
            # Verify admin rights
            try:
                me = await client.client.get_me()
                participant = await client.client.get_permissions(target_entity, me)
                if not (participant.is_admin or participant.is_creator):
                    print("❌ Error : The account does not have admin rights on the target group or channel.")
                    print("   The account must be an admin with member addition rights.")
                    return
            except Exception as e:
                logger.error(f"Error verifying admin rights : {e}", exc_info=True)
                print("⚠️  Impossible to verify admin rights. The addition may fail.")
            
            # Verify if the group is a channel
            if hasattr(target_entity, 'broadcast') and target_entity.broadcast:
                print("ℹ️  The target entity is a channel. Only admins can add members.")
            
        except Exception as e:
            logger.error(f"Error accessing the target group/channel : {e}", exc_info=True)
            print(f"❌ Error accessing the target group/channel : {str(e)[:200]}")
            print("   Verify that the link is correct and that the account has access to the group or channel.")
            print("   - Ensure that the account is a member of the group or channel")
            print(f"   - Detailed error : {str(e)[:200]}")
            return
        
        # Create a backup before starting the addition
        print("\n💾 Creating a backup of the database...")
        try:
            from database.db_manager import db_manager
            # ✅ Récupérer les titres des entités cibles et sources pour l'organisation des dossiers
            target_title = getattr(target_entity, 'title', None)
            source_title = getattr(source_entity, 'title', None) if hasattr(source_entity, 'title') else None
            if not source_title and isinstance(source_entity, str) and 't.me/' in source_entity:
                source_title = source_entity.split('t.me/')[-1].split('/')[-1]
            backup_path = await db_manager.create_backup(target_entity, target_title, source_title)
            if backup_path:
                print(f"✅ Backup created : {backup_path}")
            else:
                print("⚠️  Impossible to create a backup. Do you want to continue? (Y/n)")
                if input().lower() not in ('', 'o', 'oui', 'y', 'yes'):
                    print("❌ Operation cancelled by user.")
                    return
        except Exception as e:
            logger.error(f"Error creating backup : {e}", exc_info=True)
            print("⚠️  Error creating backup. Do you want to continue? (Y/n)")
            if input().lower() not in ('', 'o', 'oui', 'y', 'yes'):
                print("❌ Operation cancelled by user.")
                return
            
        # Create MemberAdder instance with the bot token
        print("\n🛠  Initializing the member adder tool...")
        try:
            # Utiliser la fonction d'initialisation existante pour éviter la double initialisation
            bot_notifier = await init_bot_notifier(phone) if bot_token else None
            
            adder = MemberAdder(
                client=client.client, 
                account_phone=phone,
                bot_token=bot_token if bot_token else None
            )
            
            # Passer le bot notifier au MemberAdder
            if bot_notifier:
                adder.bot_notifier = bot_notifier
            
            print("✅ Member adder tool initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing MemberAdder: {e}", exc_info=True)
            print(f"❌ Error initializing member adder tool : {str(e)[:200]}")
            
            # In case of error, offer to restore the backup
            if 'backup_path' in locals() and backup_path and backup_path.exists():
                print(f"\n❌ An error occurred. Do you want to restore the backup? (Y/n)")
                if input().lower() in ('', 'o', 'oui', 'y', 'yes'):
                    try:
                        import shutil
                        shutil.copy2(backup_path, db_manager.db_path)
                        print("✅ Database restored from backup.")
                    except Exception as restore_error:
                        print(f"❌ Error during the restoration : {restore_error}")
                        print(f"You can manually restore the backup from : {backup_path}")
            continue
        
        # Add members from the CSV file with a progress bar
        print(f"\n🚀 Starting member addition to group or channel '{target_title}'...")
        try:
            # Sauvegarder les statistiques avant l'ajout
            stats_before = await db_manager.get_daily_stats(account_phone=account_phone)
            
            # Appel de la méthode avec gestion robuste du retour
            await adder.add_members_from_csv(
                csv_file=csv_file,
                target_entity=target_entity,
                delay=Config.DELAY_BETWEEN_ADDS,
                max_csv_adds=Config.MAX_CSV_ADDS,
                skip_errors=True
            )   
            
            # Récupérer les statistiques actuelles
            current_stats = await db_manager.get_daily_stats(account_phone=account_phone)
            success = current_stats["success"]
            failed = current_stats["failed"]
            invited = current_stats["invited"]

        except DailyLimitReachedError as e:
            # Récupérer les statistiques actuelles pour affichage
            stats = await db_manager.get_daily_stats(account_phone=account_phone)
            success = stats["success"]
            failed = stats["failed"]
            invited = stats["invited"]
            
            # Gérer spécifiquement la limite quotidienne atteinte
            logger.warning(f"Daily limit reached for account {e.account_phone}: {e.todays_adds}/{e.max_daily}")
            print(f"\n⚠️ Daily limit reached for account {e.account_phone}")
            print(f"   Already {e.todays_adds}/{e.max_daily} additions today")
            print("   Wait 24 hours or use another account to continue.")
            
            # Envoyer la notification par bot
            await send_bot_notification(
                f"⚠️ Daily limit reached for account {e.account_phone}: {e.todays_adds}/{e.max_daily} additions today",
                True
            )

        except Exception as e:
            # En cas d'erreur, essayer de récupérer les statistiques actuelles
            try:
                stats = await db_manager.get_daily_stats(account_phone=account_phone)
                success = stats["success"]
                failed = stats["failed"]
                invited = stats["invited"]
            except:
                success = 0
                failed = 0
                invited = 0
                
            logger.error(f"Error adding members: {e}", exc_info=True)
            print(f"\n❌ An error occurred while adding members : {str(e)[:200]}")

            # En cas d'erreur, proposer de restaurer la sauvegarde
            if 'backup_path' in locals() and backup_path and backup_path.exists():
                print(f"\n❌ An error occurred. Do you want to restore the backup? (Y/n)")
                if input().lower() in ('', 'o', 'oui', 'y', 'yes'):
                    try:
                        import shutil
                        shutil.copy2(backup_path, db_manager.db_path)
                        print("✅ Database restored from backup.")
                    except Exception as restore_error:
                        print(f"❌ Error during the restoration : {restore_error}")
                        print(f"You can manually restore the backup from : {backup_path}")
            continue
        
        # Affichage des statistiques quotidiennes
        print("\n" + "="*50)
        print("📊 DAILY STATISTICS")
        print("="*50)
        print(f"📝 Account used : {phone}")
        print(f"🎯 Target entity : {target_title}")
        print(f"✅ Members added today : {success}")
        print(f"📨 Invitations sent today : {invited}")
        print(f"❌ Failures today : {failed}")
        print("="*50)
        
        if success > 0:
            print(f"\n🔔 Total of {success} members have been successfully added to the group or channel '{target_title}'!")
            
            # Create a backup after successful additions
            try:
                print("\n🔄 Creating a backup after successful additions...")
                source_title = getattr(source_entity, 'title', None) if hasattr(source_entity, 'title') else None
                if not source_title and isinstance(source_entity, str) and 't.me/' in source_entity:
                    source_title = source_entity.split('t.me/')[-1].split('/')[-1]
                new_backup = await db_manager.create_backup(target_entity, target_title, source_title)
                if new_backup:
                    print(f"✅ New backup created : {new_backup}")
            except Exception as backup_error:
                logger.error(f"Error creating backup : {backup_error}", exc_info=True)
                print("⚠️  Impossible to create a new backup")
        
        # Vérification de la limite quotidienne
        remaining_adds = max(0, Config.MAX_DAILY_ADDS - success)
        if remaining_adds <= 0:
            print(f"\n⚠️ Daily limit of {Config.MAX_DAILY_ADDS} additions reached for this account.")
            print("   Wait 24 hours or use another account to continue.")
            
            # Envoyer la notification par bot
            await send_bot_notification(
                f"⚠️ Daily limit of {Config.MAX_DAILY_ADDS} additions reached for account {account_phone}",
                True
            )
        else:
            print(f"\nℹ️  You can still add {remaining_adds} members today with this account.")
            
            # Envoyer la notification par bot pour les ajouts restants
            await send_bot_notification(
                f"ℹ️  You can still add {remaining_adds} members today with account {account_phone}",
                False
            )
    
    # Afficher un message de fin avec des informations sur les sauvegardes
    print()
    print("\n" + "="*50)
    print("🏁 END OF THE ADDITION")
    print("="*50)
    print("ℹ️  The database backups are available in the folder :")
    backup_dir = db_manager.get_backup_dir(target_entity)
    print(f"   {backup_dir}")
    print("="*50)

def handle_exception(exc_type, exc_value, exc_traceback):
    """Custom exception handling for uncaught exceptions."""
    # Ignore KeyboardInterrupt to allow a clean shutdown
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    
    # Ignorer les erreurs de verrouillage de base de données
    if exc_type == sqlite3.OperationalError and "database is locked" in str(exc_value).lower():
        return
    
    # Log the exception
    logger.error("Unhandled exception", exc_info=(exc_type, exc_value, exc_traceback))

async def shutdown():
    """Cleanup function at program shutdown."""
    logger.info("ℹ️  Cleanup in progress before shutdown...")
    
    # Close the database connection
    try:
        await db_manager.close()
        logger.info("ℹ️  Database connection closed")
    except Exception as e:
        logger.error(f"ℹ️  Error closing the database connection : {e}")
    
    # Close the Telegram clients
    try:
        from telegram.telegram_client import active_clients
        for client in active_clients.values():
            await client.disconnect()
        logger.info("ℹ️  All Telegram clients have been disconnected")
    except Exception as e:
        logger.error(f"ℹ️  Error disconnecting clients : {e}")
    
    logger.info("ℹ️  Program shutdown completed.\n")
    
    # Fermer les gestionnaires de logs
    for handler in logger.handlers[:]:
        handler.close()
        logger.removeHandler(handler)

def prompt_api_modification() -> bool:
    """
    Demande à l'utilisateur s'il souhaite modifier les identifiants API actuels.
    
    Returns:
        bool: True si les identifiants ont été modifiés, False sinon
    """
    def safe_input(prompt: str) -> str:
        """Handle user input with exception handling."""
        try:
            return input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[INFO] Closing the application...")
            raise SystemExit(0)

    # Verify if the credentials have already been initialized and are valid
    if not Config._credentials_initialized or not Config._api_id or not Config._api_hash:
        # No valid credentials, do not propose modification
        return False

    print("\n🔑 === MODIFICATION OF THE API CREDENTIALS ===")
    print("ℹ️  API credentials found in the configuration.")
    print("\nDo you want to modify your current Telegram API credentials?")
    print("[Y]es / [N]o (default: Yes)")

    while True:
        try:
            choice = safe_input("> ").lower() or 'n'

            if choice in ('', 'n', 'non', 'no'):
                print("\n✅ Using the current API credentials.")
                return False
            elif choice in ('o', 'oui', 'y', 'yes'):
                print("\n🔄 Modifying API credentials...")

                # Reset the credentials in the configuration
                Config._api_id = None
                Config._api_hash = None
                Config._credentials_initialized = False

                # Demander directement de nouveaux identifiants (contourner la vérification des variables d'environnement)
                from config.settings import prompt_api_credentials, save_to_env
                new_api_id, new_api_hash = prompt_api_credentials()
                save_to_env(new_api_id, new_api_hash, '')

                # Recharger les variables d'environnement avec les nouvelles valeurs
                from dotenv import load_dotenv
                load_dotenv(override=True)

                # Reset the initialization state to force reload
                Config._credentials_initialized = False
                Config._ensure_credentials_initialized()

                print("\n✅ API credentials modified successfully!")
                return True

            else:
                print("❌ Invalid response. Please answer 'Y' or 'N'.")

        except SystemExit:
            raise
        except Exception as e:
            logger.error(f"Error during API credentials modification : {e}")
            print(f"\n❌ An unexpected error occurred : {e}")
            print("✅ Using the current API credentials (default).")
            return False

def check_license() -> bool:
    try:
        license_manager = LicenseManager()
        
        # Essayer de valider la licence existante
        result = license_manager.validate_license()
        
        if result['valid']:
            print(f" 📶 {result['message']}")
            print(f" 📆 Expiry date : {result['expiry_date'].strftime('%m/%d/%Y')}")
            print(f" 📅 Days remaining : {result['days_remaining']}")
                        
            return True
        
        # Si la licence n'est pas valide, demander une nouvelle clé
        print("\nℹ️  It may be that the license is invalid or expired")
        print(f"ℹ️  {result['message']}")
        print("\nℹ️  To obtain a license key, you can pay to generate one. \n>> Click on 'Generate a license'")
        print("🛃 If you already have a key, please enter it below :\n")
        
        
        while True:
            try:
                license_key = input("🛅 License key (click on 'stop' or enter 'exit' to quit) : ").strip()
                
                if license_key.lower() == 'exit':
                    print("\nℹ️  Closing the application...")
                    return False
                    
                result = license_manager.validate_license(license_key)
                
                if result['valid']:
                    # Save the valid license key
                    if license_manager.save_license_key(license_key):
                        print("\n✅ [SUCCESS] License saved successfully!")
                        print(f"ℹ️  Expiry date : {result['expiry_date'].strftime('%m/%d/%Y')}")
                        print(f"ℹ️  Days remaining : {result['days_remaining']}")

                    else:
                        print("\n🛂 Impossible to save the license. Check write permissions.")
                        return False
                else:
                    print(f"\n🛃 {result['message']}")
                    print("ℹ️  Please try again or contact support.")
                    
            except KeyboardInterrupt:
                print("\nℹ️  Operation cancelled by the user.")
                return False
            except Exception as e:
                print(f"\n🛂 Error validating the license : {e}")
                return False
                
    except Exception as e:
        print(f"\n🛃 Critical error during license verification : {e}")
        return False

async def main_wrapper():
    """Wrapper for the main function with error handling."""
    try:
        # Vérifier la licence avant de démarrer (appel synchrone)
        if not check_license():
            print("\n❌ Access denied. The program will stop.")
            sys.exit(1)

        # D'abord valider/initialiser les identifiants API
        Config._ensure_credentials_initialized()
        
        # Ensuite demander si l'utilisateur veut modifier les identifiants API
        api_modified = prompt_api_modification()

        # Démarrer le programme principal
        result = await main()
        # Nettoyage normal uniquement si main() s'est terminé sans exception
        await shutdown()
        return result
        
    except asyncio.CancelledError:
        # Handle asynchronous cancellation
        print("\nℹ️  Operation cancelled.")
        await shutdown()
        return 1
    except KeyboardInterrupt:
        print("\nℹ️  Operation cancelled by the user.")
        await shutdown()
        return 0
    except Exception as e:
        # Handle other exceptions
        error_msg = f"🛂 An unexpected error occurred : {e}"
        print(f"\n❌ {error_msg}")
        logger.critical(error_msg, exc_info=True)
        return 1

if __name__ == "__main__":
    # Configurer le gestionnaire d'exceptions global
    sys.excepthook = handle_exception
    
    try:
        # Lancer le programme avec gestion des erreurs et nettoyage
        exit_code = asyncio.run(main_wrapper())
        
        # ✅ Nettoyer toutes les sessions Telegram à la fin
        asyncio.run(cleanup_all_sessions())
        
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n👋 Program interrupted by user")
        # Nettoyer même en cas d'interruption
        asyncio.run(cleanup_all_sessions())
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        # Nettoyer même en cas d'erreur fatale
        asyncio.run(cleanup_all_sessions())
        sys.exit(1)