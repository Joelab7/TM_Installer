"""
Gestion des licences et clés d'accès pour l'application.
"""
import os
import json
import base64
import hashlib
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

# Gestion des imports conditionnels pour Windows
if sys.platform == 'win32':
    try:
        import pywin32  # pyright: ignore[reportMissingImports]  # noqa: F401
    except ImportError:
        # Si pywin32 n'est pas installé, on continue sans
        pass

from cryptography.fernet import Fernet

# Configuration du chemin du module
MODULE_DIR = Path(__file__).parent.absolute()

class LicenseManager:
    """
    Gère la génération, le chiffrement et la validation des clés de licence.
    """
    
    def __init__(self, app_name: str = "TelegramMembersManager"):
        """
        Initialise le gestionnaire de licence.
        
        Args:
            app_name: Nom de l'application pour le fichier de licence
        """
        self.app_name = app_name
        
        # Définir les deux emplacements de licence
        # 1. Emplacement APPDATA
        if os.name == 'nt':  # Windows
            app_data = os.getenv('APPDATA', '')
            if app_data:
                self.appdata_dir = Path(app_data) / 'TelegramManager'
            else:
                self.appdata_dir = Path.home() / 'AppData' / 'Roaming' / 'TelegramManager'
        else:  # Linux/Mac
            self.appdata_dir = Path.home() / '.config' / 'telegram_manager'
        
        # 2. Emplacement de l'exécutable
        if getattr(sys, 'frozen', False):
            # Si l'application est packagée (ex: pyinstaller)
            self.exe_dir = Path(sys.executable).parent
        else:
            # En développement
            self.exe_dir = MODULE_DIR.parent.parent  # Remonter au dossier App
        
        # Créer les dossiers de licence s'ils n'existent pas
        self.appdata_license_dir = self.appdata_dir / "license_key"
        self.appdata_license_file = self.appdata_license_dir / "license.key"
        
        self.exe_license_dir = self.exe_dir / "license_key"
        self.exe_license_file = self.exe_license_dir / "license.key"
        
        # Utiliser le fichier de licence APPDATA comme référence principale
        self.license_file = self.appdata_license_file
        
        # Créer les répertoires s'ils n'existent pas
        os.makedirs(self.appdata_license_dir, exist_ok=True, mode=0o700)
        os.makedirs(self.exe_license_dir, exist_ok=True, mode=0o700)
        
        # Si le fichier de licence existe déjà ailleurs, le copier au nouvel emplacement
        self._migrate_existing_license()
        
        # Initialiser le chiffrement
        self.master_key = self._generate_master_key()
        self.cipher_suite = Fernet(self.master_key)
    
    def _migrate_existing_license(self):
        """
        Recherche et migre une licence existante depuis un emplacement antérieur vers les deux emplacements actuels.
        """
        # Liste des emplacements à vérifier
        possible_locations = []
        
        # Emplacements standards Windows
        if os.name == 'nt':  # Windows
            app_data = os.getenv('APPDATA', '')
            if app_data:
                for folder in ['TelegramManager', 'Telegram_Manager', 'TelegramMembersManager']:
                    possible_locations.append(Path(app_data) / folder / 'license_key' / 'license.key')
        
        # Emplacement Linux/Mac
        possible_locations.append(Path.home() / '.config' / 'telegram_manager' / 'license_key' / 'license.key')
        
        # Anciens emplacements de l'application
        if getattr(sys, 'frozen', False):
            possible_locations.append(Path(sys._MEIPASS) / 'license_key' / 'license.key')
        else:
            possible_locations.append(MODULE_DIR.parent.parent / 'license_key' / 'license.key')
        
        # Vérifier chaque emplacement potentiel
        license_found = False
        for old_license_file in possible_locations:
            if old_license_file.exists() and old_license_file != self.appdata_license_file and old_license_file != self.exe_license_file:
                try:
                    # Lire l'ancienne licence
                    with open(old_license_file, 'r') as f:
                        license_key = f.read().strip()
                    
                    # Essayer de valider la licence
                    if self.validate_license(license_key)['valid']:
                        # Sauvegarder dans les deux emplacements
                        self.save_license_key(license_key)
                        print(f"[INFO] Licence migrée depuis: {old_license_file}")
                        license_found = True
                        
                except Exception as e:
                    print(f"[WARNING] Erreur lors de la migration de la licence depuis {old_license_file}: {e}")
        
        # Si aucune licence n'a été trouvée, vérifier si l'un des emplacements actuels contient une licence valide
        if not license_found:
            for license_file in [self.appdata_license_file, self.exe_license_file]:
                if license_file.exists():
                    try:
                        with open(license_file, 'r') as f:
                            license_key = f.read().strip()
                        if license_key and self.validate_license(license_key)['valid']:
                            # Synchroniser les deux emplacements
                            self.save_license_key(license_key)
                            return True
                    except Exception as e:
                        print(f"[WARNING] Erreur lors de la validation de la licence à {license_file}: {e}")
        
        return license_found
    
    def _generate_master_key(self) -> bytes:
        """
        Génère une clé maître basée sur des informations système.
        
        Returns:
            bytes: Clé maître encodée en base64
        """
        # Utilisation d'une graine basée sur des informations système
        seed = f"{os.environ.get('COMPUTERNAME', '')}{os.environ.get('USERNAME', '')}"
        return base64.urlsafe_b64encode(
            hashlib.sha256(seed.encode()).digest()
        )
    
    def generate_license_key(self, validity_days: int = 30) -> str:
        """
        Génère une nouvelle clé de licence.
        
        Args:
            validity_days: Nombre de jours de validité de la clé
            
        Returns:
            str: Clé de licence générée
        """
        expiry_date = datetime.utcnow() + timedelta(days=validity_days)
        license_data = {
            'generated_date': datetime.utcnow().isoformat(),
            'expiry_date': expiry_date.isoformat(),
            'validity_days': validity_days
        }
        
        # Sérialisation et chiffrement des données
        license_json = json.dumps(license_data).encode()
        encrypted_license = self.cipher_suite.encrypt(license_json)
        
        # Encodage en base64 pour le stockage
        return base64.urlsafe_b64encode(encrypted_license).decode()
    
    def save_license_key(self, license_key: str) -> bool:
        """
        Enregistre la clé de licence dans les deux emplacements (APPDATA et répertoire de l'exécutable).
        
        Args:
            license_key: Clé de licence à enregistrer
            
        Returns:
            bool: True si l'enregistrement a réussi dans au moins un emplacement, False sinon
        """
        success = False
        
        # Essayer d'enregistrer dans APPDATA
        try:
            with open(self.appdata_license_file, 'w') as f:
                f.write(license_key)
            success = True
        except IOError as e:
            print(f"[WARNING] Impossible d'enregistrer la licence dans {self.appdata_license_file}: {e}")
        
        # Essayer d'enregistrer dans le répertoire de l'exécutable
        try:
            with open(self.exe_license_file, 'w') as f:
                f.write(license_key)
            success = True
        except IOError as e:
            print(f"[WARNING] Impossible d'enregistrer la licence dans {self.exe_license_file}: {e}")
        
        return success
    
    def load_license_key(self) -> Optional[str]:
        """
        Charge la clé de licence en vérifiant d'abord APPDATA, puis le répertoire de l'exécutable.
        
        Returns:
            str: Clé de licence ou None si introuvable
        """
        # Essayer de charger depuis APPDATA en premier
        try:
            if self.appdata_license_file.exists():
                with open(self.appdata_license_file, 'r') as f:
                    key = f.read().strip()
                    if key:  # Si la clé n'est pas vide
                        return key
        except IOError as e:
            print(f"[WARNING] Impossible de charger la licence depuis {self.appdata_license_file}: {e}")
        
        # Si pas trouvée dans APPDATA, essayer le répertoire de l'exécutable
        try:
            if self.exe_license_file.exists():
                with open(self.exe_license_file, 'r') as f:
                    key = f.read().strip()
                    if key:  # Si la clé n'est pas vide
                        # Si la clé est valide, la sauvegarder dans APPDATA
                        if self.validate_license(key)['valid']:
                            self.save_license_key(key)
                        return key
        except IOError as e:
            print(f"[WARNING] Impossible de charger la licence depuis {self.exe_license_file}: {e}")
        
        return None
    
    def validate_license(self, license_key: str = None) -> dict:
        """
        Valide une clé de licence.
        
        Args:
            license_key: Clé à valider (si None, charge depuis le fichier)
            
        Returns:
            dict: Résultat de la validation avec les clés:
                - valid (bool): Si la clé est valide
                - message (str): Message d'information
                - expiry_date (datetime): Date d'expiration si valide
        """
        if not license_key:
            license_key = self.load_license_key()
            if not license_key:
                return {
                    'valid': False,
                    'message': 'No license key found.'
                }
        
        try:
            # Décodage et déchiffrement
            encrypted_license = base64.urlsafe_b64decode(license_key)
            license_json = self.cipher_suite.decrypt(encrypted_license)
            license_data = json.loads(license_json)
            
            # Vérification de la date d'expiration
            expiry_date = datetime.fromisoformat(license_data['expiry_date'])
            if datetime.utcnow() > expiry_date:
                return {
                    'valid': False,
                    'message': 'License key expired.'
                }
                
            return {
                'valid': True,
                'message': 'License key valid.',
                'expiry_date': expiry_date,
                'days_remaining': (expiry_date - datetime.utcnow()).days
            }
            
        except Exception as e:
            return {
                'valid': False,
                'message': f'Invalid license key: {str(e)}'
            }

def main():
    """
    Point d'entrée pour la gestion des clés de licence.
    """
    import argparse
    
    parser = argparse.ArgumentParser(description='License key management')
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Commande pour générer une nouvelle clé
    gen_parser = subparsers.add_parser('generate', help='Generate a new license key')
    gen_parser.add_argument('--days', type=int, default=30, help='Validity duration in days')
    
    # Commande pour valider une clé
    val_parser = subparsers.add_parser('validate', help='Validate a license key')
    val_parser.add_argument('--key', help='License key to validate (optional, uses default file)')
    
    args = parser.parse_args()
    
    license_manager = LicenseManager()
    
    if args.command == 'generate':
        key = license_manager.generate_license_key(args.days)
        if license_manager.save_license_key(key):
            print(f"License key generated and saved: {key}")
            print(f"File: {license_manager.license_file}")
    
    elif args.command == 'validate':
        result = license_manager.validate_license(args.key)
        print(f"Valid: {result['valid']}")
        print(f"Message: {result['message']}")
        if 'expiry_date' in result:
            print(f"Expires on: {result['expiry_date']} (in {result.get('days_remaining', 0)} days)")
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
