"""
Module pour afficher des barres de progression dans la console.
"""
import sys
import time
import math
from typing import Optional

# Détection du support des couleurs ANSI
def supports_color() -> bool:
    """Détecte si le terminal supporte les couleurs ANSI."""
    try:
        import sys
        import os
        
        # Vérifier si on est dans un terminal PyQt (QTextEdit ou similaire)
        # Dans ce cas, on désactive les couleurs pour éviter les codes visibles
        if 'PyQt6' in sys.modules or 'PyQt5' in sys.modules:
            # Vérifier si on est dans un environnement GUI
            try:
                from PyQt6.QtWidgets import QApplication
                if QApplication.instance():
                    # On est dans une application PyQt, désactiver les couleurs
                    # pour éviter les codes ANSI visibles dans les QTextEdit
                    return False
            except:
                pass
        
        # Vérifier si on est dans un terminal
        if not hasattr(sys.stdout, 'isatty') or not sys.stdout.isatty():
            return False
        
        # Vérifier les variables d'environnement
        term = os.environ.get('TERM', '')
        if term in ('dumb', 'unknown', ''):
            return False
        
        # Vérifier si on est dans Windows avec support ANSI
        if sys.platform == 'win32':
            try:
                import ctypes
                import ctypes.wintypes
                
                # Activer les couleurs ANSI sur Windows 10+
                kernel32 = ctypes.windll.kernel32
                ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
                
                # Obtenir le handle de la console
                stdout_handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
                if stdout_handle:
                    mode = ctypes.wintypes.DWORD()
                    if kernel32.GetConsoleMode(stdout_handle, ctypes.byref(mode)):
                        # Essayer d'activer le mode virtuel
                        kernel32.SetConsoleMode(stdout_handle, mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING)
                        return True
            except:
                return False
        
        return True
    except:
        return False

# Détection du mode de sortie (console vs PyQt)
def get_output_mode() -> str:
    """Détecte si on doit utiliser les couleurs ANSI ou HTML."""
    try:
        import os
        
        # Vérifier les variables d'environnement FORCÉES
        force_html = os.environ.get('FORCE_HTML_COLORS')
        progress_html = os.environ.get('PROGRESS_HTML_MODE')
        if force_html == '1' or progress_html == '1':
            return 'html'
        
        import sys
        
        # Vérifier si on est dans un environnement PyQt
        if ('PyQt6' in sys.modules or 'PyQt5' in sys.modules):
            try:
                from PyQt6.QtWidgets import QApplication
                if QApplication.instance():
                    return 'html'
            except:
                pass
        
        return 'ansi'
    except:
        return 'ansi'

# Codes couleur pour la barre de progression bleue
class Colors:
    output_mode = get_output_mode()
    
    if output_mode == 'html':
        # Couleurs HTML pour PyQt QTextEdit
        BLUE = '<span style="color: #3498db;">'  # Bleu clair
        BLUE_BOLD = '<span style="color: #2980b9; font-weight: bold;">'  # Bleu gras
        RESET = '</span>'
        WHITE = '<span style="color: #ffffff;">'  # Blanc
        GRAY = '<span style="color: #95a5a6;">'   # Gris
    elif supports_color():
        # Codes couleur ANSI pour la console
        BLUE = '\033[94m'      # Bleu clair
        BLUE_BOLD = '\033[94;1m'  # Bleu clair gras
        RESET = '\033[0m'      # Réinitialisation
        WHITE = '\033[97m'     # Blanc
        GRAY = '\033[90m'      # Gris
    else:
        # Couleurs vides si le terminal ne supporte pas ANSI
        BLUE = ''
        BLUE_BOLD = ''
        RESET = ''
        WHITE = ''
        GRAY = ''

def format_time(seconds: float) -> str:
    """Formate un temps en secondes en une chaîne lisible."""
    if seconds < 60:
        return f"{int(seconds)}s"
    minutes = int(seconds // 60)
    seconds = int(seconds % 60)
    if minutes < 60:
        return f"{minutes}m {seconds:02d}s"
    hours = minutes // 60
    minutes = minutes % 60
    return f"{hours}h {minutes:02d}m {seconds:02d}s"

class ProgressBar:
    """Affiche une barre de progression dans la console."""
    
    def __init__(self, total: int, description: str = "Progression", length: int = 50):
        """
        Initialise la barre de progression.
        
        Args:
            total: Nombre total d'étapes
            description: Description à afficher avant la barre
            length: Longueur de la barre en caractères
        """
        self.total = total
        self.description = description
        self.length = length
        self.start_time = time.time()
        self.last_update = 0
        
    def update(self, progress: int) -> None:
        """
        Met à jour la barre de progression.
        
        Args:
            progress: Progression actuelle (doit être <= total)
        """
        current_time = time.time()
        # Évite de rafraîchir trop souvent (max 10 fois par seconde)
        if current_time - self.last_update < 0.1 and progress < self.total:
            return
            
        self.last_update = current_time
        elapsed = current_time - self.start_time
        
        # Calcul du pourcentage
        percent = min(1.0, progress / self.total)
        filled_length = int(self.length * percent)
        
        # Construction de la barre selon le mode de sortie
        if Colors.output_mode == 'html':
            bar = (f"{Colors.BLUE_BOLD}{'█' * filled_length}{Colors.RESET}" + 
                   f"{Colors.GRAY}{'░' * (self.length - filled_length)}{Colors.RESET}")
        else:
            bar = (f"{Colors.BLUE_BOLD}{'█' * filled_length}{Colors.RESET}" + 
                   f"{Colors.GRAY}{'░' * (self.length - filled_length)}{Colors.RESET}")
        
        # Calcul du temps restant
        if progress > 0 and progress < self.total:
            remaining = (elapsed / progress) * (self.total - progress)
            eta = f" | Remaining time: {Colors.BLUE}{format_time(remaining)}{Colors.RESET}"
        else:
            eta = ""
            
        # Affichage selon le mode de sortie
        if Colors.output_mode == 'html':
            # Mode HTML pour PyQt - utiliser print() qui sera capturé par le processus
            print(f"{self.description}: |{bar}| {Colors.BLUE}{progress}/{self.total}{Colors.RESET} "
                  f"({Colors.BLUE}{percent:.1%}{Colors.RESET}) | Elapsed time: {Colors.BLUE}{format_time(elapsed)}{Colors.RESET}{eta}", end='\r')
        else:
            # Mode ANSI pour la console
            sys.stdout.write(f"\r{self.description}: |{bar}| {Colors.BLUE}{progress}/{self.total}{Colors.RESET} "
                           f"({Colors.BLUE}{percent:.1%}{Colors.RESET}) | Elapsed time: {Colors.BLUE}{format_time(elapsed)}{Colors.RESET}{eta}")
            sys.stdout.flush()
        
        # Si c'est terminé, on va à la ligne
        if progress >= self.total:
            print()

def countdown(seconds: int, message: str = "Waiting") -> None:
    """
    Affiche un compte à rebours avec une barre de progression.
    
    Args:
        seconds: Nombre de secondes à attendre
        message: Message à afficher avant le compte à rebours
    """
    if seconds <= 0:
        return
        
    if Colors.output_mode == 'html':
        print(f"⏳ {message} (waiting {format_time(seconds)})...")
    else:   
        print(f"⏳ {message} (waiting {format_time(seconds)})...")
    
    # Si le temps est court, on utilise un simple sleep
    if seconds <= 5:
        time.sleep(seconds)
        return
    
    # Pour les temps plus longs, on affiche une barre de progression
    start_time = time.time()
    last_update = 0
    bar_length = 30
    
    try:
        while True:
            elapsed = time.time() - start_time
            remaining = max(0, seconds - elapsed)
            
            # Calcul du pourcentage de progression
            percent = min(1.0, elapsed / seconds)
            
            # Mise à jour de l'affichage au maximum une fois par seconde
            if time.time() - last_update >= 1.0:
                # Calcul des éléments de la barre de progression
                filled = int(bar_length * percent)
                bar = (f"{Colors.BLUE_BOLD}{'█' * filled}{Colors.RESET}" + 
                       f"{Colors.GRAY}{'░' * (bar_length - filled)}{Colors.RESET}")
                
                # Affichage du temps restant formaté
                time_str = format_time(remaining)
                
                # Écriture de la barre de progression selon le mode de sortie
                if Colors.output_mode == 'html':
                    print(f"\r{message}: |{bar}| {Colors.BLUE}{time_str}{Colors.RESET} remaining ({Colors.BLUE}{percent:.1%}{Colors.RESET})", end='')
                else:
                    sys.stdout.write(f"\r{message}: |{bar}| {Colors.BLUE}{time_str}{Colors.RESET} remaining ({Colors.BLUE}{percent:.1%}{Colors.RESET})")
                    sys.stdout.flush()
                last_update = time.time()
            
            # Vérification si le compte à rebours est terminé
            if remaining <= 0:
                break
                
            # Pause pour éviter de surcharger le CPU
            time.sleep(0.1)
            
    except KeyboardInterrupt:
        if Colors.output_mode == 'html':
            print(f"\n\n⚠️  {Colors.BLUE}Countdown interrupted by user.{Colors.RESET}")
        else:
            print(f"\n\n⚠️  {Colors.BLUE}Countdown interrupted by user.{Colors.RESET}")
        return
    finally:
        # Nettoyage de la ligne à la fin
        if Colors.output_mode == 'html':
            print("\r" + " " * (len(message) + bar_length + 30) + "\r", end='')
        else:
            sys.stdout.write("\r" + " " * (len(message) + bar_length + 30) + "\r")
            sys.stdout.flush()
        
    if Colors.output_mode == 'html':
        print(f"\r✅ {Colors.BLUE}Countdown completed{Colors.RESET}" + " " * 50)
    else:
        print(f"\r✅ {Colors.BLUE}Countdown completed{Colors.RESET}" + " " * 50)
