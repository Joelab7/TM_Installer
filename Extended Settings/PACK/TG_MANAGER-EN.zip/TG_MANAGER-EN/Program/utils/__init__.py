"""
Package d'utilitaires généraux.

Ce package contient des fonctions utilitaires partagées à travers l'application,
telles que la gestion des logs, les helpers de formatage, etc.
"""

# Indique que ce dossier est un package Python
