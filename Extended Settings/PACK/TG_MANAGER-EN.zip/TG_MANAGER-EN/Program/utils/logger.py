"""
Configuration des logs de l'application.

Ce module configure le système de journalisation de l'application
avec des formateurs personnalisés et des gestionnaires pour la sortie console et fichier.
"""
import logging
import logging.handlers
import os
import sys
from typing import Optional

from config.settings import Config


def setup_logger(name: Optional[str] = None) -> logging.Logger:
    """
    Configure et retourne un logger avec des gestionnaires pour la console et le fichier.
    
    Args:
        name: Nom du logger (optionnel). Si non spécifié, le logger racine est utilisé.
        
    Returns:
        logging.Logger: Instance du logger configuré
    """
    # Créer le formateur
    formatter = logging.Formatter(
        fmt=Config.LOG_FORMAT,
        datefmt=Config.LOG_DATE_FORMAT
    )
    
    # Créer le logger
    logger = logging.getLogger(name)
    logger.setLevel(Config.LOG_LEVEL)
    
    # Éviter la propagation au logger racine pour éviter les doublons
    logger.propagate = False
    
    # Vérifier si le logger a déjà des gestionnaires pour éviter les doublons
    if not logger.handlers:
        # Gestionnaire pour la console
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # Gestionnaire pour le fichier avec rotation
        try:
            # Créer le répertoire des logs si nécessaire
            log_dir = os.path.dirname(os.path.abspath(Config.LOG_FILE))
            if log_dir and not os.path.exists(log_dir):
                os.makedirs(log_dir, exist_ok=True)
            
            # Configurer la rotation des fichiers de log (1 fichier de 10 Mo, 5 fichiers de backup)
            file_handler = logging.handlers.RotatingFileHandler(
                Config.LOG_FILE,
                maxBytes=10*1024*1024,  # 10 Mo
                backupCount=5,
                encoding='utf-8'
            )
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
            
        except (IOError, OSError) as e:
            logger.error(f"Error configuring log file: {e}")
    
    return logger


# Créer un logger par défaut pour une utilisation immédiate
logger = setup_logger(__name__)

if __name__ == "__main__":
    # Example usage
    logger = setup_logger("example")
    logger.debug("Debug message")
    logger.info("Info message")
    logger.warning("Warning message")
    logger.error("Error message")
    logger.critical("Critical message")
