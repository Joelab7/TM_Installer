import sqlite3
from pathlib import Path

def check_database(db_path='telegram_users.db'):
    if not Path(db_path).exists():
        print(f"Error: The file {db_path} does not exist.")
        return

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Liste des tables
        print("\n=== TABLES ===")
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        
        if not tables:
            print("No tables found in the database.")
            return
            
        for table in tables:
            table_name = table[0]
            print(f"\nTable: {table_name}")
            print("Structure:")
            
            # Structure de la table
            cursor.execute(f"PRAGMA table_info({table_name});")
            columns = cursor.fetchall()
            print([col[1] for col in columns])  # Affiche les noms des colonnes
            
            # Aperçu des données (premières lignes)
            try:
                cursor.execute(f"SELECT * FROM {table_name} LIMIT 3;")
                rows = cursor.fetchall()
                print(f"Data (max 3 rows): {rows}")
            except Exception as e:
                print(f"Error reading data: {e}")
        
    except Exception as e:
        print(f"Error reading database: {e}")
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    check_database()