"""
Package de gestion de la base de données.

Ce package contient les modèles de données, les schémas de base de données
et les fonctions d'accès aux données.
"""

from .db_manager import db_manager, DatabaseManager, init_database, get_db_path, get_db

__all__ = [
    'db_manager',
    'DatabaseManager',
    'init_database',
    'get_db_path',
    'get_db'
]
