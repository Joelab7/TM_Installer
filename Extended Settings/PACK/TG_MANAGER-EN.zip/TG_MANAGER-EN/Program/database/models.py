"""
Modèles de données pour l'application.
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

# Base pour les modèles SQLAlchemy
Base = declarative_base()

class AddedUser(Base):
    """Modèle pour les utilisateurs ajoutés à un groupe ou canal."""
    __tablename__ = 'added_users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(255), nullable=True)
    account_phone = Column(String(50), primary_key=True)
    added_at = Column(DateTime, default=datetime.now)
    status = Column(String(50), default='pending')
    exception_message = Column(Text, nullable=True)
    
    def __repr__(self):
        return f"<AddedUser(id={self.id}, username={self.username}, account_phone={self.account_phone})>"
