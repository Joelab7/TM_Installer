"""
Gestionnaire de base de données asynchrone avec SQLAlchemy et aiosqlite.
"""
import os
import logging
import asyncio
import random
import threading
import time
from typing import AsyncGenerator, Optional, List, Dict, Any, Tuple, Set
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, update, delete, insert, text, func, distinct, create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv

from .models import Base, AddedUser
from functools import wraps
from typing import Optional, Callable, Any, TypeVar, Awaitable

# Configuration du logger
logger = logging.getLogger(__name__)

# Type variable for generic function return type
T = TypeVar('T')

class DatabaseLock:
    """Gestionnaire de verrous pour la base de données"""
    _locks = {}
    _lock = asyncio.Lock()
    
    @classmethod
    async def acquire(cls, key: str, timeout: float = 30.0) -> bool:
        """Acquiert un verrou pour une clé donnée"""
        start_time = asyncio.get_event_loop().time()
        
        async with cls._lock:
            if key not in cls._locks:
                cls._locks[key] = asyncio.Lock()
        
        while True:
            if not cls._locks[key].locked():
                await cls._locks[key].acquire()
                return True
                
            if (asyncio.get_event_loop().time() - start_time) > timeout:
                return False
                
            # Attente aléatoire pour éviter les collisions
            await asyncio.sleep(0.1 + random.uniform(0, 0.1))
    
    @classmethod
    def release(cls, key: str) -> None:
        """Libère un verrou pour une clé donnée"""
        if key in cls._locks and cls._locks[key].locked():
            cls._locks[key].release()

def with_db_lock(key: str = None, key_func: Callable = None, timeout: float = 30.0):
    """
    Décorateur pour gérer les accès concurrents à la base de données.
    
    Args:
        key: Clé de verrou statique
        key_func: Fonction pour générer une clé de verrou dynamique
        timeout: Délai maximum d'attente pour l'acquisition du verrou (secondes)
    """
    if key is None and key_func is None:
        raise ValueError("Either 'key' or 'key_func' must be provided")
        
    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @wraps(func)
        async def wrapper(*args, **kwargs) -> T:
            # Déterminer la clé de verrou
            final_key = key
            if key_func is not None:
                try:
                    final_key = key_func(*args, **kwargs)
                except Exception as e:
                    logger.error(f"Error generating lock key: {e}")
                    final_key = f"error_{func.__name__}"
            
            if not final_key:
                final_key = f"default_{func.__name__}"
            
            lock_acquired = await DatabaseLock.acquire(final_key, timeout)
            if not lock_acquired:
                raise TimeoutError(f"Could not acquire database lock for key: {final_key}")
                
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Error in locked function {func.__name__}: {e}", exc_info=True)
                raise
            finally:
                DatabaseLock.release(final_key)
                
        return wrapper
    return decorator

from pathlib import Path
import re

def sanitize_filename(name: str) -> str:
    """Nettoie une chaîne pour en faire un nom de fichier valide."""
    if not name:
        return ""
    # Remplacer les caractères non alphanumériques par des underscores
    return re.sub(r'[^\w\-_.]', '_', str(name)).strip('_')

def get_db_path(entity_name: str, entity_title: str = None) -> Path:
    """
    Retourne le chemin du fichier de base de données pour un groupe ou canal Telegram donné.
    
    Args:
        entity_name: Nom de l'entité ou URL (obligatoire).
        entity_title: Titre réel du groupe ou canal Telegram (optionnel, prioritaire si fourni).
        
    Returns:
        Path: Chemin complet vers le fichier de base de données
        
    Raises:
        ValueError: Si aucun nom de groupe ou canal Telegram n'est fourni
    """
    if not entity_name:
        raise ValueError("A source entity tile(group or channel name) is required to create the database")
    
    # ✅ Utiliser le titre réel du groupe ou canal si disponible, sinon le lien nettoyé
    if entity_title and entity_title.strip():
        # Utiliser le titre réel du groupe ou canal (plus lisible)
        base_name = entity_title.strip()
        logger.info(f"📝 Using the source entity title for the database : '{base_name}'")
    else:
        # Fallback : utiliser le lien nettoyé (ancien comportement)
        if isinstance(entity_name, str):
            # Supprimer le préfixe d'URL si présent
            if entity_name.startswith(('http://', 'https://', 't.me/', '@')):
                # Extraire le dernier segment de l'URL
                entity_name = entity_name.split('/')[-1]
            
            # Supprimer les caractères spéciaux et les espaces
            base_name = re.sub(r'[^a-zA-Z0-9_-]', '_', entity_name)
            # Supprimer les underscores multiples et ceux au début/fin
            base_name = re.sub(r'_{2,}', '_', base_name).strip('_')
            logger.info(f"📝 Using the cleaned URL for the database : '{base_name}'")   
        else:
            raise ValueError("The group or channel name must be a string")
    
    if not base_name:
        raise ValueError("Invalid entity name after processing")
        
    # Nettoyer le nom final pour le fichier (caractères valides uniquement)
    clean_name = re.sub(r'[^a-zA-Z0-9_-]', '_', base_name)
    clean_name = re.sub(r'_{2,}', '_', clean_name).strip('_')
    
    if not clean_name:
        raise ValueError("Invalid entity name after cleaning")
        
    db_name = f"{clean_name}_telegram_users.db"
    
    # Créer le dossier data s'il n'existe pas
    data_dir = Path(__file__).parent.parent / 'data'
    data_dir.mkdir(exist_ok=True)
        
    return data_dir / db_name

class DatabaseManager:
    """Gestionnaire de base de données asynchrone."""
    
    def __init__(self):
        self.engine = None
        self.async_session = None
        self.db_path = None
        self._backup_thread = None
        self._stop_backup = threading.Event()
        self._backup_in_progress = threading.Lock()
        self._last_backup_time = {}
        self._active_backups = set()
        # ✅ Ajouter un verrou pour éviter les réinitialisations concurrentes
        self._init_lock = asyncio.Lock()
        self._is_initialized = False
        
    async def initialize(self, source_entity: str, entity_title: str = None):
        """
        Initialise la connexion à la base de données pour un groupe ou canal source.
        Protégé contre les réinitialisations concurrentes.
        
        Args:
            source_entity: Nom ou URL du groupe ou canal source (obligatoire)
            entity_title: Titre réel du groupe ou canal Telegram (optionnel, pour un nom de fichier plus lisible)
            
        Raises:
            ValueError: Si le groupe ou canal source n'est pas valide
        """
        if not source_entity:
            raise ValueError("A source group or channel name is required to create the database")
        
        # ✅ Utiliser un verrou pour éviter les réinitialisations concurrentes
        async with self._init_lock:
            # Si déjà initialisé avec le même groupe ou canal, ne pas réinitialiser
            if self._is_initialized and self.db_path:
                current_db_path = get_db_path(source_entity, entity_title)
                if str(self.db_path) == str(current_db_path):
                    logger.debug(f"Database already initialized for {source_entity}, skipping")
                    return
                else:
                    logger.info(f"Reinitializing database for different group: {source_entity}")
            
            # Fermer l'ancienne connexion si elle existe
            if self.engine:
                await self.close()
        
        try:
            # ✅ Obtenir le chemin de la base de données avec le titre de l'entité si disponible
            self.db_path = get_db_path(source_entity, entity_title)
            db_url = f'sqlite:///{self.db_path}'
            
            # Créer le moteur de base de données synchrone temporairement
            self.engine = create_engine(
                db_url,
                echo=False,
                future=True,
                connect_args={
                    "timeout": 30,
                    "check_same_thread": False,
                    "isolation_level": None,
                    "cached_statements": 0,
                    "uri": True
                }
            )
            
            # Créer les tables si elles n'existent pas et configurer les PRAGMA
            with self.engine.begin() as conn:
                Base.metadata.create_all(conn)
                # ✅ Configurer les paramètres SQLite après la création des tables
                conn.execute(text("PRAGMA journal_mode=WAL"))
                conn.execute(text("PRAGMA synchronous=NORMAL"))
                conn.execute(text("PRAGMA cache_size=-10000"))
                conn.execute(text("PRAGMA temp_store=memory"))
                conn.execute(text("PRAGMA busy_timeout=30000"))
                conn.execute(text("PRAGMA journal_size_limit=1048576"))
                conn.execute(text("PRAGMA mmap_size=268435456"))
                conn.execute(text("PRAGMA auto_vacuum=INCREMENTAL"))
            
            # Créer une fabrique de sessions synchrone temporairement
            self.async_session = sessionmaker(
                self.engine, 
                expire_on_commit=False
            )
                
            # ✅ Marquer comme initialisé
            self._is_initialized = True
            logger.info(f"Database initialized: {self.db_path}")
            
            # La sauvegarde automatique est maintenant gérée par le système de points de contrôle
            logger.info("The automatic backup is now managed by the checkpoint system")
            
        except Exception as e:
            logger.error(f"Error initializing the database: {e}")
            self.engine = None
            self.async_session = None
            self.db_path = None
            self._is_initialized = False
            raise
        
    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[Any, None]:
        """
        Fournit une session de base de données asynchrone en tant que gestionnaire de contexte.
        Optimisé pour le multi-comptes avec gestion des verrous et des erreurs.
        
        Exemple d'utilisation:
            async with db.get_session() as session:
                result = session.execute(select(...))
                # Traiter les résultats
        
        Gère automatiquement les transactions et la fermeture des sessions.
        """
        if not self.async_session:
            raise RuntimeError("The database manager is not initialized. Call manager.initialize() first")
        
        session = self.async_session()
        try:
            yield session
        except Exception as e:
            # En cas d'erreur, on rollback et on relance l'erreur
            session.rollback()
            logger.error(f"Database transaction error: {e}", exc_info=True)
            raise
        finally:
            # Toujours fermer la session pour libérer les ressources
            try:
                session.close()
            except Exception as e:
                logger.warning(f"Error closing database session: {e}")
    
    @with_db_lock(key_func=lambda self, user_id=None, username=None, account_phone=None, **kwargs: f"user_{user_id or ''}_{account_phone or ''}")
    async def add_user(self, user_id: int, username: str = '', account_phone: str = '', status: str = 'pending', exception_message: str = '') -> bool:
        """
        Ajoute un utilisateur à la base de données s'il n'existe pas déjà.
        Si l'utilisateur existe déjà, ne fait rien et retourne False.
        
        Args:
            user_id: ID de l'utilisateur à ajouter
            username: Nom d'utilisateur (optionnel)
            account_phone: Numéro de téléphone du compte qui effectue l'ajout
            status: Statut de l'ajout (par défaut: 'pending')
            exception_message: Message d'erreur éventuel (optionnel)
            
        Returns:
            bool: True si l'utilisateur a été ajouté, False s'il existe déjà ou en cas d'erreur
        """
        if not user_id or not account_phone:
            logger.warning(f"Invalid parameters for add_user: user_id={user_id}, account_phone={account_phone}")
            return False

        max_retries = 3  # Réduit à 3 tentatives
        retry_delay = 0.5  # Délai initial de 0.5 seconde

        for attempt in range(max_retries):
            try:
                async with self.get_session() as session:
                    # Vérifier si l'utilisateur existe déjà pour ce compte
                    existing = session.execute(
                        select(AddedUser)
                        .where(
                            (AddedUser.id == user_id) & 
                            (AddedUser.account_phone == account_phone)
                        )
                        .with_for_update(skip_locked=True)  # Ignorer les lignes verrouillées
                    )
                    existing = existing.scalar_one_or_none()
                    
                    if existing:
                        logger.debug(f"User {user_id} already exists with status '{existing.status}' for account {account_phone}")
                        return False
                    
                    # Ajouter le nouvel utilisateur
                    user = AddedUser(
                        id=user_id,
                        username=username,
                        account_phone=account_phone,
                        status=status,
                        exception_message=exception_message,
                        added_at=datetime.now()
                    )
                    session.add(user)
                    session.commit()  # Commit manuel requis pour les sessions synchrones
                    logger.debug(f"Successfully added user {user_id} with status {status}")
                    return True
                        
            except Exception as e:
                error_msg = str(e).lower()
                
                # Vérifier si c'est une erreur de verrouillage ou de temporisation
                is_lock_error = any(lock_error in error_msg for lock_error in [
                    'database is locked', 
                    'locked', 
                    'busy', 
                    'timeout',
                    'operational error',
                    'cannot start a transaction'
                ])
                
                if is_lock_error and attempt < max_retries - 1:
                    # Attente exponentielle avec jitter
                    wait_time = retry_delay * (2 ** attempt) * (0.5 + random.random())
                    logger.warning(f"Database busy, retry {attempt + 1}/{max_retries} in {wait_time:.2f}s...")
                    await asyncio.sleep(wait_time)
                    continue
                    
                # Journaliser l'erreur
                log_level = logging.ERROR if attempt == max_retries - 1 else logging.WARNING
                logger.log(
                    log_level,
                    f"Error in add_user (attempt {attempt + 1}/{max_retries}): {e}",
                    extra={
                        'user_id': user_id,
                        'account_phone': account_phone,
                        'status': status,
                        'exception_message': str(e)
                    },
                    exc_info=attempt == max_retries - 1  # Stack trace seulement à la dernière tentative
                )
                
                # Si c'était la dernière tentative, on échoue
                if attempt == max_retries - 1:
                    logger.error(f"Failed to add user {user_id} after {max_retries} attempts")
                    return False
        
        return False  # Ne devrait jamais arriver ici
    
    @with_db_lock(key_func=lambda self, account_phone: f"count_adds_{account_phone}")
    async def get_todays_adds_count(self, account_phone: str) -> int:
        """
        Récupère le nombre d'ajouts effectués aujourd'hui par un compte.
        Utilise le fuseau horaire UTC pour la comparaison des dates.
        
        Args:
            account_phone: Numéro de téléphone du compte à vérifier
            
        Returns:
            int: Nombre d'ajouts effectués aujourd'hui, ou 0 en cas d'erreur
            
        Note:
            La date est basée sur le fuseau horaire UTC pour la cohérence.
            En cas d'erreur, la méthode retourne 0 pour éviter de bloquer le flux.
            Les erreurs sont loggées pour le débogage.
        """
        if not account_phone:
            logger.warning("Attempt to count adds without specifying a phone number")
            return 0
            
        try:
            # Obtenir la date UTC actuelle
            utc_now = datetime.utcnow()
            utc_today = utc_now.date()
            utc_tomorrow = utc_today + timedelta(days=1)
            
            async with self.get_session() as session:
                # Utilisation de paramètres nommés pour éviter les injections SQL
                stmt = text("""
                    SELECT COUNT(*) 
                    FROM added_users 
                    WHERE account_phone = :account_phone 
                    AND added_at >= :today_start 
                    AND added_at < :tomorrow_start
                    AND (status IN ('added', '✅ added'))
                """)
                
                result = session.execute(stmt, {
                    'account_phone': account_phone,
                    'today_start': datetime.combine(utc_today, datetime.min.time()),
                    'tomorrow_start': datetime.combine(utc_tomorrow, datetime.min.time())
                })
                
                count = result.scalar() or 0
                logger.debug(
                    f"Counting adds today for {account_phone}: "
                    f"{count} (at {utc_now.strftime('%d-%m-%Y %H:%M:%S')} UTC)"
                )
                return count
                
        except Exception as e:
            logger.error(f"Error counting adds today for {account_phone}: {e}", exc_info=True)
            # En cas d'erreur, on retourne 0 pour éviter de bloquer le flux
            return 0
            
    async def member_succefully_added(self, user_id: int) -> bool:
        """
        Vérifie si un membre est déjà marqué comme existant dans la base de données.
        
        Args:
            user_id: ID de l'utilisateur à vérifier
            
        Returns:
            bool: True si le membre est déjà dans le groupe cible, False sinon ou en cas d'erreur
            
        Note:
            Cette méthode vérifie tous les statuts qui indiquent un ajout avec succès dans le groupe :
            - Statuts de succès: '✅ added', 
            En cas d'erreur, la méthode retourne False par défaut pour éviter de bloquer le flux.
        """
        if not user_id:
            logger.warning("Invalid user ID for member existence check")
            return False
            
        try:
            async with self.get_session() as session:
                stmt = select(AddedUser).where(
                    (AddedUser.id == user_id) &
                    (
                        # Statuts de succès - utilisateur déjà dans le groupe
                        (AddedUser.status == '✅ added')            # ✅ Uniquement ajouté avec succès
                        #(AddedUser.status == '✅ invited') |           
                        # Statuts d'échec - éviter de retenter
                        #(AddedUser.status == '❌ failed') |           
                        #(AddedUser.status == '❎ failed')     
                    )   
                )
                result = session.execute(stmt)
                exists = result.scalar() is not None
                logger.debug(f"Checking if member {user_id} is already added (success): {exists}")
                return exists
                
        except Exception as e:
            logger.error(f"Error checking if member {user_id} is in the target group or channel: {e}", exc_info=True)
            # En cas d'erreur, on considère que le membre n'est pas dans le groupe
            return False
            
    async def get_total_users_count(self) -> int:
        """
        Compte le nombre total d'utilisateurs uniques dans la base de données.
        
        Returns:
            int: Nombre total d'utilisateurs uniques
        """
        try:
            async with self.get_session() as session:
                stmt = select(func.count(distinct(AddedUser.id)))
                result = session.execute(stmt)
                count = result.scalar() or 0
                return count
        except Exception as e:
            logger.error(f"Error counting total users: {e}")
            return 0
                
    async def get_daily_stats(self, account_phone: str, date: datetime = None) -> dict:
        """
        Récupère les statistiques d'ajout des membres pour un compte et une date donnés.
        
        Args:
            account_phone: Numéro de téléphone du compte
            date: Date pour laquelle récupérer les statistiques (par défaut: aujourd'hui)
            
        Returns:
            dict: Dictionnaire contenant les statistiques (success, failed, invited)
        """
        if not self.async_session:
            logger.warning("Database not initialized. Call initialize() first.")
            return {"success": 0, "failed": 0, "invited": 0}
            
        if date is None:
            date = datetime.utcnow().date()
            
        start_date = datetime.combine(date, datetime.min.time())
        end_date = datetime.combine(date, datetime.max.time())
        
        try:
            async with self.get_session() as session:
                # Compter les succès (ajouts réussis)
                success_count = session.execute(
                    select(func.count())
                    .where(AddedUser.account_phone == account_phone)
                    .where(AddedUser.status == '✅ added')
                    .where(AddedUser.added_at.between(start_date, end_date))
                )
                success = success_count.scalar() or 0
                
                # Compter les échecs
                failed_count = session.execute(
                    select(func.count())
                    .where(AddedUser.account_phone == account_phone)
                    .where(AddedUser.status.in_(['❌ failed', '❎ failed']))
                    .where(AddedUser.added_at.between(start_date, end_date))
                )
                failed = failed_count.scalar() or 0
                
                # Compter les invitations
                invited_count = session.execute(
                    select(func.count())
                    .where(AddedUser.account_phone == account_phone)
                    .where(AddedUser.status == '✅ invited')
                    .where(AddedUser.added_at.between(start_date, end_date))
                )
                invited = invited_count.scalar() or 0
                
                return {
                    "success": success,
                    "failed": failed,
                    "invited": invited
                }
                
        except Exception as e:
            logger.error(f"Error getting daily stats for account {account_phone}: {e}")
            return {"success": 0, "failed": 0, "invited": 0}
            
    async def get_users_by_telegram_id(self, telegram_id: int) -> List[AddedUser]:
        """
        Récupère tous les utilisateurs avec un ID Telegram donné, peu importe le compte.
        
        Args:
            telegram_id: L'ID Telegram de l'utilisateur à rechercher
            
        Returns:
            Liste des objets AddedUser trouvés
        """
        try:
            async with self.get_session() as session:
                query = text("""
                    SELECT * FROM added_users 
                    WHERE id = :telegram_id
                """)
                result = session.execute(
                    query, 
                    {"telegram_id": str(telegram_id)}
                )
                return [AddedUser(**dict(row)) for row in result.mappings().all()]
        except Exception as e:
            logger.error(f"Error getting users by Telegram ID: {e}")
            return []

    async def close(self):
        """
        Ferme proprement les connexions à la base de données.
        
        Cette méthode doit être appelée à l'arrêt de l'application pour libérer
        correctement les ressources système. Elle peut être appelée plusieurs fois
        sans effet secondaire.
        
        Note:
            Cette méthode est idempotente et peut être appelée plusieurs fois sans problème.
        """
        # Arrêter le thread de sauvegarde automatique s'il est en cours
        await self.stop_auto_backup()
        
        try:
            if self.engine:
                self.engine.dispose()  # Remove await for synchronous engine
                logger.info("Database connection closed successfully")
        except Exception as e:
            logger.error(f"Error closing database connection: {e}", exc_info=True)
        finally:
            # Reset all attributes even in case of error
            self.engine = None
            self.async_session = None
            self.db_path = None
            # ✅ Réinitialiser le flag d'initialisation
            self._is_initialized = False

    def get_backup_dir(self, target_entity: str, target_title: str = None, source_title: str = None) -> Path:
        """
        Retourne le dossier de sauvegarde pour une entité cible donné.
        
        Args:
            target_entity: Nom du groupe ou canal cible (peut être une URL ou un nom simple)
            target_title: Titre réel de l'entité cible (optionnel, prioritaire si fourni)
            source_title: Titre réel de l'entité source pour créer un sous-dossier (optionnel)
            
        Returns:
            Path: Chemin complet du dossier de sauvegarde pour cette entité
        """
        if not target_entity:
            target_entity = "default"
        
        # Fonction pour nettoyer le nom en préservant les espaces et les parenthèses
        def clean_group_name(name, suffix):
            # Supprimer le suffixe s'il est présent
            clean_name = name.replace(f' {suffix}', '').strip()
            # Nettoyer les caractères spéciaux mais garder les espaces
            clean_name = re.sub(r'[\\/*?:"<>|]', '', clean_name)
            # Supprimer les espaces multiples
            clean_name = ' '.join(clean_name.split())
            # Reconstruire avec le suffixe
            return f"{clean_name} {suffix}"
            
        # Traitement du nom de l'entité cible
        target_suffix = '(Target Entity) 🎯'
        
        # Si target_entity est un objet avec un attribut title, utiliser ce titre
        if hasattr(target_entity, 'title') and target_entity.title:
            clean_title = str(target_entity.title).strip()
            safe_target = clean_group_name(clean_title, target_suffix)
            logger.debug(f"📝 Using the target entity's title for the backup: '{safe_target}'")
        # Sinon, utiliser target_title s'il est fourni
        elif target_title and target_title.strip():
            clean_title = target_title.strip()
            safe_target = clean_group_name(clean_title, target_suffix)
            logger.debug(f"📝 Using the provided target title for the backup: '{safe_target}'")
        else:
            # Fallback : utiliser l'identifiant de l'entité
            entity_id = str(target_entity).strip()
            # Nettoyer l'ID s'il s'agit d'une URL ou d'une mention
            if entity_id.startswith(('http://', 'https://', 't.me/', '@')):
                entity_id = entity_id.split('/')[-1]
            # Nettoyer les caractères problématiques
            safe_target = clean_group_name(entity_id, target_suffix)
            logger.debug(f"📝 Using the cleaned entity ID for the backup: '{safe_target}'")
        
        if not safe_target:
            safe_target = "default (Target Entity)"
        
        # Créer le chemin de base pour les sauvegardes dans un dossier 'backups' à côté de la base de données
        # Exemple: /chemin/vers/la/base/de/donnees/backups 
        backup_base_dir = Path(self.db_path).parent / "backups 💾"
        
        # Créer le chemin complet du dossier cible en ajoutant le nom sécurisé
        # Exemple: /chemin/vers/la/base/de/donnees/backups/Mon Groupe (Target Entity)
        backup_dir = backup_base_dir / safe_target
        
        # Si un titre de l'entité source est fourni, créer un sous-dossier pour cette entité source
        if source_title and source_title.strip():
            source_suffix = '(Source Entity) 📰'
            source_name = source_title.strip()
            if source_suffix not in source_name:
                source_name = f"{source_name} {source_suffix}"
            safe_source = clean_group_name(source_name, source_suffix)
            backup_dir = backup_dir / safe_source
            logger.debug(f"📝 Using source group title for subfolder: '{safe_source}'")
        else:
            backup_dir = backup_base_dir / safe_target
        
        # S'assurer que les dossiers existent
        backup_dir.mkdir(parents=True, exist_ok=True)
        
        logger.debug(f"Backup directory for {target_entity}: {backup_dir}")
        return backup_dir
    
    def _get_backup_key(self, target_entity: str) -> str:
        """Génère une clé unique pour une sauvegarde."""
        return f"{self.db_path}:{target_entity}"
        
    async def create_backup(self, target_entity: str, target_title: str = None, source_title: str = None, force: bool = False) -> Optional[Path]:
        """
        Crée une sauvegarde de la base de données actuelle.
        
        Args:
            target_entity: Nom du groupe ou canal cible pour organiser les sauvegardes
            target_title: Titre réel de l'entité cible (optionnel, pour un nom de dossier plus lisible)
            source_title: Titre réel de l'entité source pour créer un sous-dossier (optionnel)
            force: Si True, force la création de la sauvegarde même si une sauvegarde récente existe
            
        Returns:
            Path: Chemin vers la sauvegarde créée, ou None en cas d'erreur ou si une sauvegarde récente existe
        """
        if not self.db_path or not target_entity:
            logger.warning("Unable to create a backup: missing database path or target group")
            return None
            
        backup_key = self._get_backup_key(target_entity)
        
        # Vérifier si une sauvegarde a déjà été faite récemment (dans les 5 dernières minutes)
        last_backup = self._last_backup_time.get(backup_key)
        if not force and last_backup and (datetime.now() - last_backup) < timedelta(minutes=5):
            logger.debug(f"A backup has already been made recently for {target_entity}")
            return None
            
        # Vérifier si une sauvegarde est déjà en cours pour cette cible
        if backup_key in self._active_backups:
            logger.debug(f"A backup is already in progress for {target_entity}")
            return None
            
        self._active_backups.add(backup_key)
        
        try:
            # ✅ Utiliser le titre de l'entité cible pour un nom de dossier plus lisible
            # et créer un sous-dossier pour l'entité source si spécifiée
            backup_dir = self.get_backup_dir(target_entity, target_title, source_title)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # Obtenir le nom de la base de données source sans l'extension
            db_name = Path(self.db_path).stem
            
            # Créer le nom du fichier de sauvegarde avec le nom de la base, la date et l'heure
            backup_filename = f"{db_name}_{timestamp}.db"
            backup_path = backup_dir / backup_filename
            
            # S'assurer que le répertoire de sauvegarde existe
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            # Créer une copie de la base de données
            import shutil
            shutil.copy2(self.db_path, backup_path)
            
            # Mettre à jour l'heure de la dernière sauvegarde
            self._last_backup_time[backup_key] = datetime.now()
            
            logger.info(f"Backup created: {backup_path}")
            return backup_path
            
        except Exception as e:
            logger.error(f"Error creating backup: {e}", exc_info=True)
            return None
            
        finally:
            # Retirer la sauvegarde des sauvegardes en cours
            self._active_backups.discard(backup_key)
            
    def start_auto_backup(self, target_entity: str, interval_minutes: int = 1):
        """
        Démarre la sauvegarde automatique de la base de données.
        
        Args:
            target_entity: Nom de l'entité cible pour les sauvegardes
            interval_minutes: Intervalle entre les sauvegardes en minutes (par défaut: 1)
        """
        if not target_entity:
            logger.error("Unable to start automatic backup: no target group specified")
            return
            
        if self._backup_thread is not None and self._backup_thread.is_alive():
            logger.info("Automatic backup is already in progress")
            return
            
        # Nettoyer le nom de l'entité cible
        safe_target = sanitize_filename(str(target_entity).strip())
        if safe_target.startswith('https___t.me_'):
            safe_target = safe_target[len('https___t.me_'):]
            
        logger.info(f"Setting up automatic backup for entity: {safe_target}")
        
        self._stop_backup.clear()
        
        async def backup_loop():
            logger.info(f"Starting automatic backup for '{safe_target}' every {interval_minutes} minutes")
            
            while not self._stop_backup.is_set():
                try:
                    # Créer une sauvegarde avec l'entité cible nettoyé (pas de titre disponible en auto-backup)
                    # Pour les sauvegardes automatiques, on ne spécifie pas de source
                    backup_path = await self.create_backup(safe_target, source_title="AutoBackup")
                    if backup_path:
                        logger.info(f"Backup created: {backup_path}")
                    
                    # Attendre l'intervalle spécifié ou jusqu'à ce qu'on nous demande d'arrêter
                    for _ in range(interval_minutes * 60):
                        if self._stop_backup.is_set():
                            break
                        await asyncio.sleep(1)
                        
                except Exception as e:
                    logger.error(f"Error in backup loop: {e}", exc_info=True)
                    await asyncio.sleep(60)  # Attendre 1 minute en cas d'erreur avant de réessayer
            
            logger.info("Automatic backup stopped")
        
        # Démarrer la boucle de sauvegarde dans un nouveau thread avec une boucle d'événements
        def run_backup_loop():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(backup_loop())
            finally:
                loop.close()
        
        self._backup_thread = threading.Thread(target=run_backup_loop, daemon=True)
        self._backup_thread.start()
    
    async def stop_auto_backup(self):
        """Arrête la sauvegarde automatique."""
        if self._backup_thread is not None:
            self._stop_backup.set()
            self._backup_thread.join(timeout=5.0)
            self._backup_thread = None
            logger.info("Automatic backup stopped")


# Configuration de la base de données
# L'initialisation de la connexion se fera via DatabaseManager.initialize()

# Instance globale du gestionnaire de base de données
db_manager = DatabaseManager()

# Fonction utilitaire pour initialiser la base de données au démarrage
async def init_database(source_entity: str = None, entity_title: str = None) -> bool:
    """
    Initialise la base de données au démarrage de l'application.
    
    Args:
        source_entity: Nom du groupe ou canal source pour la base de données
        enity_title: Titre réel du groupe ou canal (optionnel, pour un nom de fichier plus lisible)
        
    Returns:
        bool: True si l'initialisation a réussi, False sinon
    """
    if not source_entity:
        logger.warning("No source group provided, database initialization is deferred")
        return False
        
    try:
        await db_manager.initialize(source_entity, entity_title)
        return True
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        return False

# Fonction utilitaire pour obtenir une session de base de données
@asynccontextmanager
async def get_db() -> AsyncGenerator[Any, None]:
    """
    Fournit une session de base de données asynchrone.
    
    Yields:
        AsyncSession: Session de base de données
        
    Raises:
        RuntimeError: If the database manager is not initialized
    """
    if not hasattr(db_manager, 'async_session') or not db_manager.async_session:
        raise RuntimeError("Database manager is not initialized. Call db_manager.initialize() first")
    
    async with db_manager.get_session() as session:
        yield session
