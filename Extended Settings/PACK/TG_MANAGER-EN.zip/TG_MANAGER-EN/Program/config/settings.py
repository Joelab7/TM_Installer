"""
Configuration de l'application.

Ce module contient tous les paramètres de configuration de l'application,
y compris les paramètres de l'API Telegram, les chemins de fichiers,
et d'autres paramètres globaux.
"""
import os
import re
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

# Charger les variables d'environnement depuis le fichier .env
load_dotenv()

def is_valid_api_id(api_id: str) -> bool:
    """Vérifie si l'API ID est valide."""
    return api_id.isdigit() and len(api_id) >= 5

def is_valid_api_hash(api_hash: str) -> bool:
    """Vérifie si l'API HASH est valide."""
    return bool(re.match(r'^[a-f0-9]{32}$', api_hash))

def get_phone_number() -> str:
    """Demande le numéro de téléphone de manière interactive."""
    while True:
        phone = input("\nEnter your phone number (e.g., +1234567890) : ").strip().lower()
        if phone.startswith('+') and phone[1:].isdigit() and len(phone) > 8:
            return phone
        print("❌ Invalid format. Use the international format (e.g., +1234567890)")

def prompt_api_credentials():
    """Demande les identifiants API de manière interactive."""
    print("\n🔑 Configuring Telegram API credentials")
    print("ℹ️ Get it on https://my.telegram.org/")
    print("-" * 60)
    
    while True:
        api_id = input("Enter your API ID : ").strip()
        if is_valid_api_id(api_id):
            break
        print("❌ API ID invalid. Must contain only digits (at least 5).")
    
    while True:
        api_hash = input("Enter your API HASH : ").strip()
        if is_valid_api_hash(api_hash):
            break
        print("❌ API HASH invalid. Must be 32 characters long.")
    
    return api_id, api_hash

def save_to_env(api_id: str, api_hash: str, phone: Optional[str] = None):
    """Enregistre les identifiants dans le fichier .env"""
    env_path = Path('.env')
    env_vars = {}
    
    # Lire le contenu existant si le fichier existe
    if env_path.exists():
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    try:
                        key, value = line.split('=', 1)
                        env_vars[key] = value.strip('\'"')
                    except ValueError:
                        continue
    
    # Mettre à jour les valeurs
    env_vars['API_ID'] = api_id
    env_vars['API_HASH'] = api_hash
    if phone:
        env_vars['PHONE_NUMBERS'] = phone
    
    # Écrire le fichier .env
    with open(env_path, 'w', encoding='utf-8') as f:
        for key, value in env_vars.items():
            f.write(f'{key}="{value}"\n')
    
    print("\n✅ Configuration saved successfully in .env")
    return True

class Config:
    """Classe de configuration centrale pour l'application."""
    
    # Fichiers
    DB_FILE = 'telegram_users.db'  # Sera mis à jour dynamiquement
    LOG_FILE = os.getenv('LOG_FILE', 'telegram_bot.log')
    SESSION_DIR = os.getenv('SESSION_DIR', 'sessions')
    
    @classmethod
    def get_db_file(cls, source_entity: str = None) -> str:
        """Retourne le nom du fichier de base de données pour un groupe ou canal source donné."""
        from database.db_manager import sanitize_filename
        if source_entity:
            safe_name = sanitize_filename(source_entity)
            return f'{safe_name}_telegram_users.db'
        return 'telegram_users.db'
    
    @classmethod
    def update_db_path(cls, source_entity: str = None):
        """Met à jour le chemin de la base de données."""
        cls.DB_FILE = cls.get_db_file(source_entity)

    # Créer le répertoire des sessions si nécessaire
    os.makedirs(SESSION_DIR, exist_ok=True)

    # ===== IDENTIFIANTS API =====
    @classmethod
    def load_api_credentials(cls):
        """Charge ou demande les identifiants API."""
        api_id = os.getenv('API_ID', '')
        api_hash = os.getenv('API_HASH', '')
        
        if not api_id or not api_hash or not is_valid_api_id(api_id) or not is_valid_api_hash(api_hash):
            print("\n🔧 Required configuration : Missing or invalid Telegram API credentials")
            print("Do you want to configure the credentials now? (Yes/No) ")
            if input().strip().lower() in ('o', 'oui', 'y', 'yes'):
                api_id, api_hash = prompt_api_credentials()
                save_to_env(api_id, api_hash, '')
                # Recharger les variables d'environnement
                load_dotenv(override=True)
                api_id = os.getenv('API_ID', '')
                api_hash = os.getenv('API_HASH', '')
            else:
                print("\n❌ Required configuration. Cannot continue without valid API credentials.")
                raise ValueError("Missing or invalid API credentials")
        
        return int(api_id), api_hash
    
    # Variables de classe pour stocker les identifiants
    _api_id = None
    _api_hash = None
    _credentials_initialized = False
    
    @classmethod
    def _ensure_credentials_initialized(cls):
        """S'assure que les identifiants sont initialisés."""
        if not cls._credentials_initialized:
            print("\n" + "="*60)
            print("TELEGRAM API CONFIGURATION".center(60))
            print("="*60)
            try:
                cls._api_id, cls._api_hash = cls.load_api_credentials()
                cls._credentials_initialized = True
                print("\nConfiguration required for Telegram API")
                print("-" * 40)
                
                # Save the information in the .env file
                save_to_env(cls._api_id, cls._api_hash, '')
                print("\n✅ Configuration completed successfully!")
                print("-"*60 + "\n")
            except ValueError as e:
                #print(f"\n❌ Configuration error : {e}")
                exit(1)
    
    @classmethod
    def get_api_id(cls):
        """Retrieve the API ID, initializing if necessary."""
        cls._ensure_credentials_initialized()
        return cls._api_id
        
    @classmethod
    def get_api_hash(cls):
        """Récupère le hash de l'API, en initialisant si nécessaire."""
        cls._ensure_credentials_initialized()
        return cls._api_hash
    
    # ===== CONFIGURATION ADMIN =====
    ADMIN_TELEGRAM_IDS = [int(id_str.strip()) for id_str in os.getenv('ADMIN_TELEGRAM_IDS', '6240754744').split(',') if id_str.strip().isdigit()]
    
    @classmethod
    def is_admin(cls, user_id: int) -> bool:
        """Vérifie si l'utilisateur est un administrateur.
        
        Args:
            user_id: ID Telegram de l'utilisateur à vérifier
            
        Returns:
            bool: True si l'utilisateur est administrateur, False sinon
        """
        return user_id in cls.ADMIN_TELEGRAM_IDS
    PHONE_NUMBERS = [p.strip() for p in os.getenv('PHONE_NUMBERS', '').split(',') if p.strip()]
    BOT_TOKEN = os.getenv('BOT_TOKEN', '')

    # ===== GESTION DES SESSIONS =====
    # Nettoyage automatique des anciennes sessions
    AUTO_CLEANUP_SESSIONS = os.getenv('AUTO_CLEANUP_SESSIONS', 'true').lower() == 'true'
    # Âge maximum des sessions en jours avant nettoyage
    SESSION_MAX_AGE_DAYS = int(os.getenv('SESSION_MAX_AGE_DAYS', 90))
    # Clé de chiffrement pour les sessions
    SESSION_ENCRYPTION_KEY = os.getenv('SESSION_ENCRYPTION_KEY')
    
    # ===== LIMITES =====
    MAX_DAILY_ADDS = int(os.getenv('MAX_DAILY_ADDS', 50))
    MAX_CSV_ADDS = int(os.getenv('MAX_CSV_ADDS', 0))
    
    # ===== DÉLAIS =====
    DELAY_BETWEEN_ADDS = int(os.getenv('DELAY_BETWEEN_ADDS', 300))
    MIN_DAILY_INTERVAL = int(os.getenv('MIN_DAILY_INTERVAL', 86400))

    # ===== PERFORMANCES =====
    BATCH_SIZE = int(os.getenv('BATCH_SIZE', 100))  # Taille des lots
    # Intervalle entre les points de contrôle (nombre d'opérations)
    CHECKPOINT_INTERVAL = int(os.getenv('CHECKPOINT_INTERVAL', 10))
    AUTO_BACKUP_INTERVAL = int(os.getenv('AUTO_BACKUP_INTERVAL', 60))  # 1 minutes par défaut
    API_TIMEOUT = int(os.getenv('API_TIMEOUT', 30))  # secondes
    MAX_RETRIES = int(os.getenv('MAX_RETRIES', 3))  # Tentatives de reconnexion

    # ===== CONFIGURATION DES LOGS =====
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FORMAT = '%(asctime)s - %(levelname)s - %(message)s'
    LOG_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
    

    # ===== CONFIGURATION DE LA BASE DE DONNÉES =====
    # Paramètres de connexion à la base de données SQLite
    DB_CONNECTION_PARAMS = {
        'check_same_thread': False,
        'timeout': 60.0,
        'isolation_level': 'IMMEDIATE',
        'detect_types': 1 | 2  # PARSE_DECLTYPES | PARSE_COLNAMES
    }

    # Paramètres WAL pour SQLite
    WAL_SETTINGS = {
        'journal_mode': 'WAL',
        'journal_size_limit': 16384,  # 16MB
        'busy_timeout': 30000,  # 30 secondes
        'synchronous': 'NORMAL',
        'cache_size': -2000  # 2MB
    }

    # Configuration des tables de la base de données
    TABLES = {
        'added_users': """
            CREATE TABLE IF NOT EXISTS added_users (
                id INTEGER,
                username TEXT,
                account_phone TEXT,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id, account_phone)
            )
        """,
        'checkpoints': """
            CREATE TABLE IF NOT EXISTS checkpoints (
                operation_id TEXT PRIMARY KEY,
                last_processed_id INTEGER,
                processed_count INTEGER,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """,
        'failed_adds': """
            CREATE TABLE IF NOT EXISTS failed_adds (
                user_id INTEGER PRIMARY KEY,
                error_type TEXT,
                error_count INTEGER DEFAULT 1,
                last_attempt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                exception_message TEXT
            )
        """
    }

    # Index de la base de données
    INDEXES = [
        "CREATE INDEX IF NOT EXISTS idx_added_users_account ON added_users(account_phone, added_at)",
        "CREATE INDEX IF NOT EXISTS idx_failed_adds_attempt ON failed_adds(last_attempt)",
        "CREATE INDEX IF NOT EXISTS idx_failed_adds_type ON failed_adds(error_type, error_count)"
    ]
    
    @classmethod
    def get_db_connection_params(cls, source_entity: str = None):
        """
        Retourne les paramètres de connexion à la base de données avec le chemin du fichier.
        
        Args:
            source_entity: Nom du groupe ou canal source pour la base de données
        """
        from database.db_manager import get_db_path
        
        # Obtenir le chemin de la base de données pour le groupe ou canal source
        db_path = get_db_path(source_entity)
        
        # Créer le dossier data s'il n'existe pas
        db_path.parent.mkdir(parents=True, exist_ok=True)
        
        params = cls.DB_CONNECTION_PARAMS.copy()
        params['database'] = str(db_path)
        return params
