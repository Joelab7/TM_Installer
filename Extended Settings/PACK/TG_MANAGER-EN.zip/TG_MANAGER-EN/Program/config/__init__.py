"""
Package de configuration de l'application.

Ce package contient tous les paramètres de configuration de l'application,
y compris les paramètres de l'API Telegram, les chemins de fichiers,
et d'autres paramètres globaux.
"""

# Indique que ce dossier est un package Python
