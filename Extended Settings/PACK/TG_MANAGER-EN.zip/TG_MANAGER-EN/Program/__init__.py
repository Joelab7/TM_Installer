"""
Package principal de l'application Telegram Member Manager.
"""

# Ce fichier permet à Python de traiter le répertoire comme un package
