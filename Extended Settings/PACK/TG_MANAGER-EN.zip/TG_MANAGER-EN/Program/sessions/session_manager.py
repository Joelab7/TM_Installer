"""
Gestion avancée des sessions persistantes pour l'application.

Ce module permet de sauvegarder et de restaurer l'état des sessions
entre les exécutions du programme, avec chiffrement et rotation des fichiers.
"""
import json
import os
import logging
import asyncio
from datetime import datetime
from typing import Dict, Any, Optional, List, Callable, Awaitable
from pathlib import Path
import hashlib
import base64

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from config.settings import Config

logger = logging.getLogger(__name__)

class EncryptionManager:
    """Gestion du chiffrement/déchiffrement des sessions."""
    
    def __init__(self, encryption_key: Optional[str] = None):
        """Initialise le gestionnaire de chiffrement."""
        self.key = self._generate_key(encryption_key or self._get_default_key())
        self.cipher_suite = Fernet(self.key)
    
    @staticmethod
    def _get_default_key() -> str:
        """Génère une clé par défaut basée sur des informations système."""
        system_id = hashlib.sha256(os.environ.get('COMPUTERNAME', '').encode()).hexdigest()
        return f"{system_id[:32]}"  # 32 caractères max pour la clé
    
    @staticmethod
    def _generate_key(password: str) -> bytes:
        """Génère une clé de chiffrement à partir d'un mot de passe."""
        password = password.encode()
        salt = b'salt_'  # Ajoutez un sel pour renforcer la sécurité
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password))
    
    def encrypt(self, data: str) -> str:
        """Chiffre les données."""
        return self.cipher_suite.encrypt(data.encode()).decode()
    
    def decrypt(self, encrypted_data: str) -> str:
        """Déchiffre les données."""
        return self.cipher_suite.decrypt(encrypted_data.encode()).decode()

class SessionObserver:
    """Interface pour les observateurs de sessions."""
    
    def on_session_updated(self, phone: str, session_data: Dict[str, Any]):
        """Appelé lorsqu'une session est mise à jour."""
        pass
    
    def on_session_deleted(self, phone: str):
        """Appelé lorsqu'une session est supprimée."""
        pass


class SessionManager:
    """Gestionnaire avancé de sessions persistantes avec chiffrement et rotation."""
    
    _observers: List[SessionObserver] = []
    
    @classmethod
    def add_observer(cls, observer: SessionObserver):
        """Ajoute un observateur pour les changements de session."""
        if observer not in cls._observers:
            cls._observers.append(observer)
    
    @classmethod
    def remove_observer(cls, observer: SessionObserver):
        """Retire un observateur."""
        if observer in cls._observers:
            cls._observers.remove(observer)
    
    def __init__(self, session_file: str = 'session.json', max_backups: int = 5, 
                 encryption_key: Optional[str] = None):
        """
        Initialise le gestionnaire de session simplifié.
        
        Args:
            session_file: Nom du fichier de session (stocké dans le dossier de configuration)
            max_backups: Nombre maximum de sauvegardes à conserver
            encryption_key: Non utilisé (conservé pour compatibilité)
        """
        # Utiliser AppData pour le stockage des sessions
        app_data = os.environ.get('APPDATA', os.path.expanduser('~'))
        self.session_dir = Path(app_data) / 'TelegramManager' / 'data' / 'session'
        self.session_file = self.session_dir / session_file
        self.max_backups = max_backups
        self.sessions = self._load_sessions()
        
        # Création du dossier de sessions s'il n'existe pas
        self.session_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Session manager initialized. File: {self.session_file}")
    
    def _migrate_old_session_format(self, data: str) -> Dict:
        """
        Tente de migrer les données de l'ancien format vers le nouveau format.
        
        Args:
            data: Données brutes du fichier de session
            
        Returns:
            Dict: Données migrées ou dictionnaire vide en cas d'échec
        """
        try:
            # Si les données sont déjà au bon format
            if data.strip().startswith('{'):
                return json.loads(data)
                
            # Si les données sont chiffrées, on essaie de les déchiffrer
            try:
                decrypted = self.encryption.decrypt(data)
                if decrypted.strip().startswith('{'):
                    return json.loads(decrypted)
            except Exception:
                pass
                
            # Si on arrive ici, on crée une nouvelle session vide
            logger.warning("Unrecognized session format, creating a new session")
            return {}
            
        except Exception as e:
            logger.error(f"Error migrating old session format: {e}")
            return {}
    
    def _load_sessions(self) -> Dict:
        """
        Charge les sessions depuis le fichier JSON.
        
        Returns:
            Dict: Dictionnaire contenant les sessions chargées ou un dictionnaire vide
        """
        try:
            if not self.session_file.exists():
                return {}
                
            with open(self.session_file, 'r', encoding='utf-8') as f:
                return json.load(f)
                
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding session file: {e}")
            self._backup_corrupted_file()
            return {}
            
        except Exception as e:
            logger.error(f"Error loading session: {e}", exc_info=True)
            return {}
    
    def _save_sessions(self):
        """Sauvegarde les sessions dans un fichier JSON lisible."""
        try:
            # Création d'une sauvegarde avant modification
            self._rotate_backups()
            
            # Formatage des données pour une meilleure lisibilité
            formatted_sessions = {}
            for phone, data in self.sessions.items():
                formatted_sessions[phone] = {
                    'created_at': data.get('created_at'),
                    'last_updated': datetime.utcnow().isoformat(),
                    'source_entity': data.get('source_entity'),
                    'target_entity': data.get('target_entity'),
                    'extra': data.get('extra', {})
                }
            
            # Écriture en JSON formaté
            temp_file = f"{self.session_file}.tmp"
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(formatted_sessions, f, indent=2, ensure_ascii=False, sort_keys=True)
                
            # Renommage atomique
            if self.session_file.exists():
                os.replace(temp_file, self.session_file)
            else:
                os.rename(temp_file, self.session_file)
                
        except Exception as e:
            logger.error(f"Error saving session: {e}", exc_info=True)
            if os.path.exists(temp_file):
                os.unlink(temp_file)
                
    def _backup_corrupted_file(self):
        """Crée une sauvegarde d'un fichier de session corrompu."""
        if not self.session_file.exists():
            return
            
        backup_name = f"{self.session_file}.corrupted.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        try:
            self.session_file.rename(backup_name)
            logger.warning(f"Corrupted session file backed up as: {backup_name}")
        except Exception as e:
            logger.error(f"Failed to backup corrupted session file: {e}")
    
    def _rotate_backups(self):
        """Effectue une rotation des sauvegardes."""
        if not self.session_file.exists():
            return
            
        # Création du dossier de sauvegarde s'il n'existe pas
        backup_dir = self.session_dir / 'backups'
        backup_dir.mkdir(exist_ok=True)
        
        # Format du nom de fichier de sauvegarde
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = backup_dir / f"{self.session_file.stem}_{timestamp}{self.session_file.suffix}"
        
        try:
            # Création de la nouvelle sauvegarde
            import shutil
            shutil.copy2(self.session_file, backup_file)
            
            # Nettoyage des anciennes sauvegardes
            backups = sorted(backup_dir.glob(f"{self.session_file.stem}_*{self.session_file.suffix}"))
            for old_backup in backups[:-(self.max_backups - 1)]:
                try:
                    old_backup.unlink()
                except Exception as e:
                    logger.warning(f"Failed to delete old backup {old_backup}: {e}")
                    
        except Exception as e:
            logger.error(f"Error rotating backups: {e}")
    
    def get_last_session(self, account_phone: str) -> Optional[Dict]:
        """
        Récupère la dernière session pour un compte donné.
        
        Args:
            account_phone: Numéro de téléphone du compte
            
        Returns:
            Optional[Dict]: Dictionnaire contenant les informations de session ou None
            
        Note:
            Les données sensibles comme les tokens sont automatiquement nettoyées
        """
        session = self.sessions.get(account_phone, {})
        return self._clean_sensitive_data(session.copy()) if session else None
        
    def _clean_sensitive_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Nettoie les données sensibles d'une session."""
        sensitive_keys = ['auth_key', 'api_key', 'token', 'password', 'secret']
        for key in list(data.keys()):
            if any(sk in key.lower() for sk in sensitive_keys) and data[key]:
                data[key] = '***REDACTED***'
        return data
    
    async def _notify_observers_async(self, method_name: str, *args, **kwargs):
        """Notifie tous les observateurs de manière asynchrone."""
        if not self._observers:
            return

        async def notify(observer, method, *a, **kw):
            try:
                method_to_call = getattr(observer, method)
                if asyncio.iscoroutinefunction(method_to_call):
                    return await method_to_call(*a, **kw)
                else:
                    return method_to_call(*a, **kw)
            except Exception as e:
                logger.error(f"Error in observer {observer}.{method}: {e}")
                return None

        # Exécution en parallèle avec un timeout
        tasks = []
        for observer in self._observers:
            task = asyncio.create_task(
                notify(observer, method_name, *args, **kwargs),
                name=f"notify_{observer.__class__.__name__}_{method_name}"
            )
            tasks.append(task)

        # Attendre que toutes les notifications soient terminées (avec timeout)
        done, pending = await asyncio.wait(
            tasks,
            timeout=30.0,  # 30 secondes de timeout
            return_when=asyncio.ALL_COMPLETED
        )

        # Annuler les tâches en attente
        for task in pending:
            task.cancel()

    def save_session(self, account_phone: str, source_entity: str = None, 
                    target_entity: str = None, **extra_data):
        """
        Sauvegarde les informations de session pour un compte (synchrone).
        
        Args:
            account_phone: Numéro de téléphone du compte
            source_entity: Lien ou ID du groupe ou canal source (optionnel)
            target_entity: Lien ou ID du groupe ou canal cible (optionnel)
            **extra_data: Données supplémentaires à sauvegarder
        """
        now = datetime.utcnow().isoformat()
        
        if account_phone not in self.sessions:
            self.sessions[account_phone] = {
                'created_at': now,
                'last_updated': now,
                'source_entity': source_entity,
                'target_entity': target_entity,
                'extra': extra_data or {}
            }
        else:
            self.sessions[account_phone].update({
                'last_updated': now,
                'source_entity': source_entity or self.sessions[account_phone].get('source_entity'),
                'target_entity': target_entity or self.sessions[account_phone].get('target_entity'),
                'extra': {**self.sessions[account_phone].get('extra', {}), **extra_data}
            })
        
        self._save_sessions()

    async def save_session_async(self, account_phone: str, source_entity: str = None, 
                               target_entity: str = None, **extra_data):
        """
        Sauvegarde les informations de session pour un compte (asynchrone).
        
        Args:
            account_phone: Numéro de téléphone du compte
            source_entity: Lien ou ID du groupe ou canal source (optionnel)
            target_entity: Lien ou ID du groupe ou canal cible (optionnel)
            **extra_data: Données supplémentaires à sauvegarder
        """
        # Mise à jour locale
        self.save_session(account_phone, source_entity, target_entity, **extra_data)
        
        # Notification asynchrone des observateurs
        if account_phone in self.sessions:
            await self._notify_observers_async(
                'on_session_updated', 
                account_phone, 
                self.sessions[account_phone]
            )
    
    def clear_session(self, account_phone: str):
        """
        Supprime les informations de session pour un compte (synchrone).
        
        Args:
            account_phone: Numéro de téléphone du compte
        """
        if account_phone in self.sessions:
            # Notifier les observateurs avant la suppression (synchrone)
            for observer in self._observers:
                try:
                    observer.on_session_deleted(account_phone)
                except Exception as e:
                    logger.error(f"Error notifying observer {observer} of deletion: {e}")
            
            del self.sessions[account_phone]
            self._save_sessions()
    
    async def clear_session_async(self, account_phone: str):
        """
        Supprime les informations de session pour un compte (asynchrone).
        
        Args:
            account_phone: Numéro de téléphone du compte
        """
        if account_phone in self.sessions:
            # Notification asynchrone avant suppression
            await self._notify_observers_async('on_session_deleted', account_phone)
            
            # Mettre à jour les sessions au lieu de les supprimer
            self._update_session_entity(account_phone, source_entity=None, target_entity=None)
    
    def cleanup_old_sessions(self, max_age_days: int = 90):
        """
        Nettoie les sessions plus anciennes qu'un certain nombre de jours.
        
        Args:
            max_age_days: Âge maximum en jours avant suppression (par défaut: 90 jours)
            
        Returns:
            int: Nombre de sessions supprimées
        """
        if not self.sessions:
            return 0
            
        threshold = datetime.utcnow() - timedelta(days=max_age_days)
        deleted = 0
        
        for phone in list(self.sessions.keys()):  # Copie des clés pour itération sûre
            session = self.sessions[phone]
            last_updated = datetime.fromisoformat(session.get('last_updated', '1970-01-01'))
            
            if last_updated < threshold:
                # Mettre à jour les sessions au lieu de les supprimer
                self._update_session_entity(phone, source_entity=None, target_entity=None)
                deleted += 1
                
        if deleted > 0:
            self._save_sessions()
            
        return deleted
    
    def get_all_sessions(self) -> Dict[str, Dict]:
        """
        Récupère toutes les sessions avec des données nettoyées.
        
        Returns:
            Dict[str, Dict]: Dictionnaire de toutes les sessions
        """
        return {phone: self._clean_sensitive_data(data.copy()) 
                for phone, data in self.sessions.items()}
                
    def list_sessions(self) -> List[str]:
        """
        Liste les numéros de téléphone des sessions disponibles.
        
        Returns:
            List[str]: Liste des numéros de téléphone des sessions disponibles
        """
        return list(self.sessions.keys())
        
    def session_exists(self, phone: str) -> bool:
        """
        Vérifie si une session existe pour le numéro de téléphone donné.
        
        Args:
            phone: Numéro de téléphone à vérifier
            
        Returns:
            bool: True si une session existe, False sinon
        """
        return phone in self.sessions

# Instance globale du gestionnaire de sessions
# Utilise la clé de chiffrement de l'environnement si disponible
encryption_key = os.environ.get('SESSION_ENCRYPTION_KEY')
session_manager = SessionManager(encryption_key=encryption_key)

# Vérification des sessions au démarrage
if hasattr(Config, 'AUTO_UPDATE_SESSIONS') and Config.AUTO_UPDATE_SESSIONS:
    try:
        logger.info("Checking sessions at startup...")
        # Ici, vous pouvez ajouter une logique pour mettre à jour les sessions
        # en fonction des configurations actuelles si nécessaire
    except Exception as e:
        logger.error(f"Error checking sessions: {e}")
