#!/usr/bin/env python3
"""
Utilitaire de gestion des licences pour l'application Telegram Members Manager.

Ce script permet de générer, valider et gérer les clés de licence.
"""
import sys
import argparse
from pathlib import Path

# Ajouter le répertoire parent au chemin Python
sys.path.insert(0, str(Path(__file__).parent.absolute()))

from security.license_manager import LicenseManager

def generate_license(days: int = 30):
    """Génère une nouvelle clé de licence."""
    try:
        manager = LicenseManager()
        key = manager.generate_license_key(days)
        if manager.save_license_key(key):
            print("[SUCCESS] License generated successfully!")
            print(f"File: {manager.license_file}")
            print(f"Key: {key}")
            return True
    except Exception as e:
        print(f"[ERROR] Error generating license: {e}")
        return False

def validate_license(key: str = None):
    """Valide une clé de licence."""
    try:
        manager = LicenseManager()
        result = manager.validate_license(key)
        
        if result['valid']:
            print("[SUCCESS] License is valid!")
            print(f"Expiration date: {result['expiry_date'].strftime('%m/%d/%Y')}")
            print(f"Days remaining: {result['days_remaining']}")
            return True
        else:
            print(f"[ERROR] {result['message']}")
            return False
    except Exception as e:
        print(f"[ERROR] Error validating license: {e}")
        return False

def show_license_info():
    """Affiche les informations de la licence actuelle."""
    try:
        manager = LicenseManager()
        key = manager.load_license_key()
        
        if not key:
            print("[INFO] No license key found.")
            return False
            
        print("=== License information ===")
        print(f"File: {manager.license_file}")
        print(f"Key: {key[:10]}...{key[-10:]}")
        
        return validate_license(key)
    except Exception as e:
        print(f"[ERROR] {e}")
        return False

def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='License manager')
    subparsers = parser.add_subparsers(dest='command', help='Commande à exécuter')
    
    # Commande generate
    gen_parser = subparsers.add_parser('generate', help='Generate a new license key')
    gen_parser.add_argument('--days', type=int, default=30, help='Validity duration in days (default: 30)')
    
    # Commande validate
    val_parser = subparsers.add_parser('validate', help='Validate a license key')
    val_parser.add_argument('--key', help='Key to validate (optional, uses default file)')
    
    # Commande info
    subparsers.add_parser('info', help='Show license information')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    try:
        if args.command == 'generate':
            generate_license(args.days)
        elif args.command == 'validate':
            validate_license(args.key)
        elif args.command == 'info':
            show_license_info()
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error : {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
