import asyncio
import os
import sys
from pathlib import Path
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from database.models import Base

async def init_db():
    # Création du dossier data s'il n'existe pas
    data_dir = Path(__file__).parent / 'data'
    data_dir.mkdir(exist_ok=True)
    
    # Configuration de l'URL de la base de données
    db_path = data_dir / 'telegram_users.db'
    db_url = f'sqlite+aiosqlite:///{db_path}'
    
    # Création du moteur SQLAlchemy
    engine = create_async_engine(
        db_url,
        echo=True,
        future=True,
        connect_args={"check_same_thread": False}
    )
    
    # Création des tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    print(f"✅ Database initialized successfully in : {db_path}")
    return engine

if __name__ == "__main__":
    try:
        asyncio.run(init_db())
    except Exception as e:
        print(f"❌ Error initializing database : {e}")
        sys.exit(1)
