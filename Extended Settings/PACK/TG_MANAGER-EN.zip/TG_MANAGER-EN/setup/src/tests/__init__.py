"""Package contenant les tests de l'application."""

# Ce fichier est nécessaire pour que Python reconnaisse le répertoire comme un package
# et permette l'importation des modules de test.
