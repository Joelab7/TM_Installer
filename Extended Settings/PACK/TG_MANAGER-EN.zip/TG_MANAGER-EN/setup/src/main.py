"""Point d'entrée principal de l'application."""
import sys
import os
from pathlib import Path

# Ajouter le répertoire src au PYTHONPATH
src_dir = Path(__file__).parent
sys.path.insert(0, str(src_dir))

import asyncio
import logging
import qasync
from PyQt6.QtWidgets import QApplication, QToolTip
from PyQt6.QtGui import QPalette, QColor
from telegram_manager.ui.main_window import MainWindow
from telegram_manager.core.config import Config
from telegram_manager.core.app_state import app_state_manager

def setup_logging():
    """Configure le système de journalisation."""
    # Créer un formateur
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Configurer le gestionnaire de fichier
    file_handler = logging.FileHandler('app.log', encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    
    # Configurer le gestionnaire de console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    
    # Configurer le logger racine
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    
    # Configurer le niveau de log pour certaines bibliothèques
    logging.getLogger('telethon').setLevel(logging.INFO)
    logging.getLogger('qasync').setLevel(logging.INFO)
    logging.getLogger('asyncio').setLevel(logging.INFO)

def clean_bot_notifier_sessions():
    """Nettoie les dossiers bot_notifier_sessions au démarrage de l'application."""
    import shutil
    import glob
    
    logger = logging.getLogger(__name__)
    
    # Chemins des dossiers à nettoyer
    setup_sessions_dir = Path(__file__).parent / "sessions" / "bot_notifier_sessions"
    program_sessions_dir = Path(__file__).parent.parent.parent / "Program" / "sessions" / "bot_notifier_sessions"
    
    # Fonction pour nettoyer un dossier
    def clean_directory(directory_path):
        try:
            if directory_path.exists() and directory_path.is_dir():
                # Supprimer tous les fichiers .session dans le dossier
                session_files = glob.glob(str(directory_path / "*.session"))
                removed_count = 0
                
                for session_file in session_files:
                    try:
                        os.remove(session_file)
                        removed_count += 1
                        logger.debug(f"Session file removed: {session_file}")
                    except Exception as e:
                        logger.warning(f"Failed to remove session file {session_file}: {e}")
                
                # Supprimer aussi les fichiers .session-journal s'ils existent
                journal_files = glob.glob(str(directory_path / "*.session-journal"))
                for journal_file in journal_files:
                    try:
                        os.remove(journal_file)
                        logger.debug(f"Journal file removed: {journal_file}")
                    except Exception as e:
                        logger.warning(f"Failed to remove journal file {journal_file}: {e}")
                
                if removed_count > 0:
                    logger.info(f"Cleaned {removed_count} bot notifier session files from {directory_path}")
                else:
                    logger.debug(f"No bot notifier session files to clean in {directory_path}")
            else:
                logger.debug(f"Bot notifier sessions directory does not exist: {directory_path}")
                
        except Exception as e:
            logger.error(f"Error cleaning bot notifier sessions directory {directory_path}: {e}")
    
    # Nettoyer les deux dossiers
    logger.info("Starting cleanup of bot notifier sessions...")
    clean_directory(setup_sessions_dir)
    clean_directory(program_sessions_dir)
    logger.info("Bot notifier sessions cleanup completed")

def apply_tooltip_style(app, window):
    """Applique le style des tooltips en fonction du thème actuel."""
    logger = logging.getLogger(__name__)
    try:
        # Détecter si le thème sombre est actif
        is_dark = False
        if hasattr(window, '_current_theme'):
            is_dark = window._current_theme == 'dark'
        elif hasattr(window, 'home_widget') and hasattr(window.home_widget, '_current_theme'):
            is_dark = window.home_widget._current_theme == 'dark'
        
        # Appliquer les couleurs appropriées
        if is_dark:
            # Thème sombre : texte blanc sur fond sombre
            tooltip_style = """
            QToolTip {
                background-color: #2d2d2d !important;
                color: #ffffff !important;
                border: 1px solid #404040 !important;
                border-radius: 4px;
                padding: 3px 6px;
                font-size: 12px;
            }
            """
            palette = app.palette()
            palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(45, 45, 45))   # Fond sombre
            palette.setColor(QPalette.ColorRole.ToolTipText, QColor(255, 255, 255)) # Texte blanc
        else:
            # Thème clair : texte noir sur fond blanc
            tooltip_style = """
            QToolTip {
                background-color: #ffffff !important;
                color: #2c3e50 !important;
                border: 1px solid #d0d0d0 !important;
                border-radius: 4px;
                padding: 3px 6px;
                font-size: 12px;
            }
            """
            palette = app.palette()
            palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(255, 255, 255)) # Fond blanc
            palette.setColor(QPalette.ColorRole.ToolTipText, QColor(44, 62, 80))     # Texte foncé
        
        app.setStyleSheet(tooltip_style)
        app.setPalette(palette)
        
        logger.info(f"Style des tooltips appliqué pour thème {'sombre' if is_dark else 'clair'}")
        
    except Exception as e:
        logger.error(f"Erreur lors de l'application du style des tooltips: {e}")

def main():
    """Point d'entrée principal de l'application."""
    # Configuration du logging
    setup_logging()
    logger = logging.getLogger(__name__)
    
    try:
        # Nettoyer les sessions de bot notifier au démarrage
        clean_bot_notifier_sessions()
        
        # Mettre à jour l'état de l'application (démarrage)
        app_state_manager.update_app_status(True, str(Path(__file__).parent))
        logger.info("État de l'application mis à jour: démarrage")
        
        # Charger la configuration
        config = Config()
        app_config = config.get_section('app')
        
        # Créer l'application Qt
        app = QApplication(sys.argv)
        app.setApplicationName("Telegram Manager")
        
        # Appliquer le style et le thème
        if 'style' in app_config:
            app.setStyle(app_config['style'])
        if 'theme' in app_config:
            app.setStyleSheet(f"""
                QWidget {{
                    background-color: {'#f0f0f0' if app_config['theme'] == 'light' else '#333'};
                    color: {'#000' if app_config['theme'] == 'light' else '#fff'};
                }}
                
                /* Style pour les tooltips - visible sur les deux thèmes */
                QToolTip {{
                    color: #5a4a3a;
                    background-color: #f0e6d2;
                    border: 1px solid #d4c8b0;
                    padding: 6px 10px;
                    border-radius: 4px;
                    font-size: 12px;
                }}
            """)
        
        # Configurer la boucle d'événements asynchrone avec qasync
        loop = qasync.QEventLoop(app)
        asyncio.set_event_loop(loop)
        
        # Créer et afficher la fenêtre principale
        logger.info("Création de la fenêtre principale")
        window = MainWindow(config)
        
        window.show()
        logger.info("Fenêtre principale affichée")
        
        # Appliquer le style des tooltips adapté au thème
        apply_tooltip_style(app, window)
        
        # Lancer la boucle d'événements
        logger.info("Démarrage de la boucle d'événements")
        with loop:
            loop.run_forever()
            
    except Exception as e:
        logger.critical("Une erreur non gérée s'est produite", exc_info=True)
        return 1
    finally:
        # Nettoyer les ressources
        if 'loop' in locals():
            loop.close()
            
    return 0

class MainWindow(MainWindow):
    def closeEvent(self, event):
        """Gère l'événement de fermeture de la fenêtre."""
        try:
            # Mettre à jour l'état de l'application (fermeture)
            app_state_manager.update_app_status(False)
            logging.info("État de l'application mis à jour: fermeture")
            
            # Si le client Telegram est connecté, effectuer une déconnexion douce
            if hasattr(self, 'telegram_client') and self.telegram_client:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    asyncio.create_task(self.telegram_client.disconnect(force=False))
                else:
                    loop.run_until_complete(self.telegram_client.disconnect(force=False))
        except Exception as e:
            logging.error(f"Erreur lors de la fermeture de l'application: {e}")
        finally:
            # Accepter l'événement de fermeture
            event.accept()

if __name__ == "__main__":
    sys.exit(main())
