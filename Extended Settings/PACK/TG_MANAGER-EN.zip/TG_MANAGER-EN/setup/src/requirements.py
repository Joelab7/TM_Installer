from setuptools import setup, find_packages

setup(
    name="telegram_manager",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        'PyQt6>=6.4.0',
        'qasync>=0.23.0',
        'telethon>=1.34.0',
        'cryptography>=3.4.7',
        'python-dotenv>=0.19.0',
        'pyperclip>=1.8.2',
        'pillow>=8.3.1',
        'qdarkstyle>=3.0.2',
        'sqlalchemy>=2.0.0',
        'alembic>=1.12.1',
        'asyncpg>=0.28.0',
        'aiosqlite>=0.19.0',
        'python-dateutil>=2.8.2',
        'pytz>=2023.3',
        'tqdm>=4.65.0',
        'pylint>=2.17.5',
        'pytest>=7.3.1',
        'pytest-asyncio>=0.21.0',
        'black>=22.3.0',
        'isort>=5.10.1',
        'mypy>=0.910',
        'send2trash',
    ],
    python_requires='>=3.8',
)











