"""
Configuration de l'application, y compris les clés API et les paramètres.
"""
import os
from pathlib import Path
from typing import Optional

# Dossier de base de l'application
BASE_DIR = Path(__file__).parent.parent.parent

# Chargement des variables d'environnement
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / '.env')
except ImportError:
    pass  # Le module python-dotenv n'est pas installé

# Configuration de Coinbase Commerce
COINBASE_COMMERCE_API_KEY = os.getenv('COINBASE_COMMERCE_API_KEY', '09d01d95-cc11-4e13-80e6-38feada66971')
COINBASE_WEBHOOK_SECRET = os.getenv('COINBASE_WEBHOOK_SECRET', 'votre_webhook_secret')

# Configuration du bot Telegram
BOT_TOKEN = os.getenv('BOT_TOKEN')

# Configuration des prix (en USD)
LICENSE_PRICES = {
    '1_month': 19.99
}

# Configuration de la licence
DEFAULT_LICENSE_DURATION = 30  # jours
