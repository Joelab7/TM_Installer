"""Configuration du système de journalisation pour l'application."""
import logging
import os
from pathlib import Path
from typing import Optional


def setup_logger(name: str, log_level: str = "INFO", log_file: Optional[str] = None) -> logging.Logger:
    """Configure et retourne un logger personnalisé.
    
    Args:
        name: Nom du logger (généralement __name__)
        log_level: Niveau de journalisation (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Chemin vers le fichier de log (optionnel)
        
    Returns:
        logging.Logger: Instance du logger configuré
    """
    # Créer le logger
    logger = logging.getLogger(name)
    
    # Éviter la propagation vers le logger racine
    logger.propagate = False
    
    # Définir le niveau de journalisation
    level = getattr(logging, log_level.upper(), logging.INFO)
    logger.setLevel(level)
    
    # Vérifier si le logger a déjà des handlers (éviter les doublons)
    if logger.handlers:
        return logger
    
    # Créer le formateur
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Handler pour la console
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Handler pour le fichier si spécifié
    if log_file:
        try:
            # Créer le répertoire des logs s'il n'existe pas
            log_dir = os.path.dirname(log_file)
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)
            
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        except Exception as e:
            logger.error(f"Impossible de configurer la journalisation dans le fichier {log_file}: {e}")
    
    return logger


def get_logs_dir() -> Path:
    """Retourne le répertoire de stockage des logs.
    
    Returns:
        Path: Chemin vers le répertoire de logs
    """
    # Chemin par défaut: répertoire de l'application/logs
    app_dir = Path(__file__).parent.parent.parent
    logs_dir = app_dir / "logs"
    
    # Créer le répertoire s'il n'existe pas
    logs_dir.mkdir(exist_ok=True, mode=0o755)
    
    return logs_dir


# Créer un logger par défaut pour le module
logger = setup_logger(
    name=__name__,
    log_level=os.getenv("LOG_LEVEL", "INFO"),
    log_file=str(get_logs_dir() / "telegram_manager.log")
)
