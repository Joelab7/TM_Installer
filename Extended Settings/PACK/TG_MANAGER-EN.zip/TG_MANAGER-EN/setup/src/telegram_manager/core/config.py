"""Gestion de la configuration de l'application."""
import os
import configparser
from pathlib import Path
from typing import Dict, Any, Optional

class Config:
    """Classe de configuration de l'application."""
    
    def __init__(self, config_path: Optional[str] = None):
        """Initialise la configuration.
        
        Args:
            config_path: Chemin vers le fichier de configuration.
        """
        self.config = self._load_config(config_path)
    
    @staticmethod
    def _load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
        """Charge la configuration depuis un fichier .ini.
        
        Args:
            config_path: Chemin vers le fichier de configuration.
            
        Returns:
            Un dictionnaire contenant la configuration chargée.
            
        Raises:
            FileNotFoundError: Si le fichier de configuration n'existe pas.
            configparser.Error: En cas d'erreur de lecture du fichier.
        """
        if config_path is None:
            # Par défaut, on cherche config.ini dans le répertoire racine du projet
            config_path = Path(__file__).parent.parent.parent.parent / 'config.ini'
            
            # Vérifier si le fichier existe, sinon essayer de le créer avec des valeurs par défaut
            if not config_path.exists():
                # Créer un fichier de configuration par défaut
                default_config = {
                    'telegram': {
                        'api_id': '',
                        'api_hash': '',
                        'phone': ''
                    },
                    'app': {
                        'language': 'fr',
                        'style': 'Fusion',
                        'theme': 'light'
                    },
                    'database': {
                        'url': 'sqlite:///telegram_manager.db'
                    },
                    'logging': {
                        'level': 'INFO',
                        'file': 'app.log'
                    }
                }
                
                # Créer le répertoire parent s'il n'existe pas
                config_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Écrire la configuration par défaut
                config = configparser.ConfigParser()
                for section, values in default_config.items():
                    config[section] = values
                    
                with open(config_path, 'w', encoding='utf-8') as f:
                    config.write(f)
                    
                print(f"Fichier de configuration créé à l'emplacement : {config_path}")
    
        # Lire la configuration
        config = configparser.ConfigParser()
        config.read(config_path, encoding='utf-8')
        
        # Convertir en dictionnaire
        config_dict = {}
        for section in config.sections():
            config_dict[section] = dict(config[section])
            
        return config_dict
    
    def get(self, section: str, key: str, default: Any = None) -> Any:
        """Récupère une valeur de configuration.
        
        Args:
            section: Section de configuration
            key: Clé de configuration
            default: Valeur par défaut si la clé n'existe pas
            
        Returns:
            La valeur de configuration ou la valeur par défaut
        """
        return self.config.get(section, {}).get(key, default)
    
    def get_section(self, section: str, default: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Récupère une section complète de la configuration.
        
        Args:
            section: Le nom de la section à récupérer.
            default: Valeur par défaut si la section n'existe pas.
            
        Returns:
            Un dictionnaire contenant les paires clé-valeur de la section.
        """
        return dict(self.config.get(section, default or {}))
        
    def save(self, config_path: Optional[str] = None) -> None:
        """Sauvegarde la configuration dans un fichier.
        
        Args:
            config_path: Chemin vers le fichier de configuration. Si None, utilise le chemin d'origine.
            
        Raises:
            IOError: Si la sauvegarde échoue.
        """
        if config_path is None:
            config_path = Path(__file__).parent.parent.parent.parent / 'config.ini'
            
        # Créer le répertoire parent s'il n'existe pas
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        
        # Convertir le dictionnaire en objet ConfigParser
        config_parser = configparser.ConfigParser()
        for section, values in self.config.items():
            config_parser[section] = values
            
        # Écrire dans le fichier
        with open(config_path, 'w', encoding='utf-8') as configfile:
            config_parser.write(configfile)


def load_config(config_path: str = None) -> Dict[str, Any]:
    """Fonction utilitaire pour charger la configuration.
    
    Args:
        config_path: Chemin vers le fichier de configuration.
        
    Returns:
        Un dictionnaire contenant la configuration chargée.
    """
    return Config(config_path).config
