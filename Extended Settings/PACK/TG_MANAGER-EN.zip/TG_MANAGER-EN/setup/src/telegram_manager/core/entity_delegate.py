"""
Délégué personnalisé pour QListView avec rendu optimisé et interactivité
Sans création de widgets individuels
"""
from PyQt6.QtWidgets import QStyledItemDelegate, QStyleOptionViewItem
from PyQt6.QtCore import Qt, QSize, QRect, pyqtSignal
from PyQt6.QtGui import QPainter, QColor, QFont, QPen, QCursor
import logging

class EntityDelegate(QStyledItemDelegate):
    """Délégué optimisé pour afficher les entités avec boutons interactifs"""
    
    # Signaux pour les interactions
    copy_id_clicked = pyqtSignal(dict)
    copy_link_clicked = pyqtSignal(dict)
    entity_clicked = pyqtSignal(dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.logger = logging.getLogger(__name__)
        self.hovered_row = -1
        self.button_areas = {}  # Stocke les zones des boutons
        self.is_dark_theme = False  # État du thème
        
    def set_theme(self, is_dark: bool):
        """Définit le thème actuel pour adapter les couleurs"""
        self.is_dark_theme = is_dark
        
    def paint(self, painter, option, index):
        """Dessine l'entité sans créer de widget"""
        try:
            entity = index.data(Qt.ItemDataRole.UserRole)
            if not entity:
                return
            
            # Sauvegarder l'état du painter
            painter.save()
            
            # Zone de l'item
            rect = option.rect
            
            # Fond adapté au thème
            is_hovered = (index.row() == self.hovered_row)
            
            if self.is_dark_theme:
                # Thème sombre
                if is_hovered:
                    painter.fillRect(rect, QColor("#34495e"))  # Gris foncé hover
                else:
                    painter.fillRect(rect, QColor("#2c3e50"))  # Gris foncé normal
            else:
                # Thème clair
                if is_hovered:
                    painter.fillRect(rect, QColor("#f0f0f0"))  # Gris clair hover
                else:
                    painter.fillRect(rect, QColor("#ffffff"))  # Blanc normal
            
            # Bordure pour les admins adaptée au thème
            if entity.get('is_admin', False):
                if self.is_dark_theme:
                    painter.setPen(QPen(QColor("#9b59b6"), 2))  # Violet pour thème sombre
                else:
                    painter.setPen(QPen(QColor("#3498db"), 2))  # Bleu pour thème clair
                painter.drawRect(rect.adjusted(1, 1, -1, -1))
            
            # Avatar
            avatar_rect = QRect(rect.left() + 10, rect.top() + 5, 40, 40)
            self._paint_avatar(painter, avatar_rect, entity)
            
            # Texte principal
            title_rect = QRect(avatar_rect.right() + 15, rect.top() + 5, 
                             rect.width() - 250, 20)
            self._paint_title(painter, title_rect, entity)
            
            # Type et membres
            info_rect = QRect(avatar_rect.right() + 15, rect.top() + 25, 
                            rect.width() - 250, 15)
            self._paint_info(painter, info_rect, entity)
            
            # Boutons
            button_rect = QRect(rect.right() - 180, rect.top() + 10, 170, 30)
            self._paint_buttons(painter, button_rect, entity, index.row())
            
            # Restaurer le painter
            painter.restore()
            
        except Exception as e:
            self.logger.error(f"[DELEGATE] Erreur paint: {e}")
            # S'assurer que le painter est restauré même en cas d'erreur
            painter.restore()
    
    def sizeHint(self, option, index):
        """Taille adaptative pour chaque item"""
        # Largeur : prendre toute la largeur disponible
        # Hauteur : fixe pour un rendu propre
        return QSize(option.rect.width() if option.rect else -1, 50)
    
    def editorEvent(self, event, model, option, index):
        """Gère les clics sans créer d'éditeurs"""
        try:
            if event.type() == event.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                entity = index.data(Qt.ItemDataRole.UserRole)
                if not entity:
                    return False
                
                pos = event.position().toPoint()
                rect = option.rect
                
                # Zone des boutons
                button_rect = QRect(rect.right() - 180, rect.top() + 10, 170, 30)
                
                if button_rect.contains(pos):
                    # Clic sur les boutons
                    button_x = pos.x() - button_rect.left()
                    
                    if button_x < 85:  # Bouton Copier ID
                        self.copy_id_clicked.emit(entity)
                        return True
                    else:  # Bouton Copier Lien
                        self.copy_link_clicked.emit(entity)
                        return True
                else:
                    # Clic sur l'entité
                    self.entity_clicked.emit(entity)
                    return True
            
            elif event.type() == event.Type.MouseMove:
                # Effet hover
                new_hovered_row = index.row()
                if new_hovered_row != self.hovered_row:
                    self.hovered_row = new_hovered_row
                    # Forcer le repaint
                    if model:
                        model.dataChanged.emit(index, index)
            
            return False
            
        except Exception as e:
            self.logger.error(f"[DELEGATE] Erreur editorEvent: {e}")
            return False
    
    def _paint_avatar(self, painter, rect, entity):
        """Dessine l'avatar"""
        try:
            # Couleur basée sur l'ID
            colors = ['#e57373', '#64b5f6', '#81c784', '#ffb74d', '#ba68c8']
            color = colors[entity.get('id', 0) % len(colors)]
            
            # Cercle de fond
            painter.setBrush(QColor(color))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(rect)
            
            # Première lettre
            title = entity.get('title', 'Sans titre')
            first_letter = title[0].upper() if title else '?'
            
            painter.setPen(QColor(Qt.GlobalColor.white))
            font = QFont()
            font.setBold(True)
            font.setPointSize(14)
            painter.setFont(font)
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, first_letter)
            
        except Exception as e:
            self.logger.error(f"[DELEGATE] Erreur avatar: {e}")
    
    def _paint_title(self, painter, rect, entity):
        """Dessine le titre"""
        try:
            title = entity.get('title', 'Sans titre')
            
            # Badge admin
            if entity.get('is_admin', False):
                title = f"👑 {title}"
                # Couleur admin adaptée au thème
                if self.is_dark_theme:
                    painter.setPen(QColor("#9b59b6"))  # Violet pour thème sombre
                else:
                    painter.setPen(QColor("#3498db"))  # Bleu pour thème clair
            else:
                # Couleur du texte adaptée au thème
                if self.is_dark_theme:
                    painter.setPen(QColor("#ecf0f1"))  # Texte clair pour thème sombre
                else:
                    painter.setPen(QColor("#2c3e50"))  # Texte foncé pour thème clair
            
            font = QFont()
            font.setBold(True)
            font.setPointSize(10)
            painter.setFont(font)
            
            painter.drawText(rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, title)
            
        except Exception as e:
            self.logger.error(f"[DELEGATE] Erreur titre: {e}")
    
    def _paint_info(self, painter, rect, entity):
        """Dessine les informations secondaires"""
        try:
            # Type d'entité
            if entity.get('is_bot', False):
                type_text = "🤖 Bot"
            elif entity.get('is_private_chat', False):
                type_text = "💬 Private Chat"
            elif entity.get('is_channel', False):
                type_text = "📢 Channel"
            elif entity.get('is_group', False):
                type_text = "🎭 Group"
            else:
                type_text = "❓ Unknown"
            
            # Nombre de membres/subscribers selon le type
            members = entity.get('members_count', 0)
            if members > 0:
                if entity.get('is_channel', False):
                    type_text += f" • {members:,} subscriber{'s' if members != 1 else ''}"
                else:
                    type_text += f" • {members:,} member{'s' if members != 1 else ''}"
            
            # Username
            username = entity.get('username')
            if username:
                type_text += f" • @{username}"
            
            # Couleur du texte adaptée au thème
            if self.is_dark_theme:
                painter.setPen(QColor("#bdc3c7"))  # Gris clair pour thème sombre
            else:
                painter.setPen(QColor("#7f8c8d"))  # Gris foncé pour thème clair
            font = QFont()
            font.setPointSize(8)
            painter.setFont(font)
            
            painter.drawText(rect, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, type_text)
            
        except Exception as e:
            self.logger.error(f"[DELEGATE] Erreur info: {e}")
    
    def _paint_buttons(self, painter, rect, entity, row):
        """Dessine les boutons interactifs"""
        try:
            # Fond des boutons adapté au thème
            if self.is_dark_theme:
                painter.setBrush(QColor("#764ba2"))  # Violet pour thème sombre
            else:
                painter.setBrush(QColor("#3498db"))  # Bleu pour thème clair
            
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(rect, 5, 5)
            
            # Séparateur adapté au thème
            if self.is_dark_theme:
                painter.setPen(QPen(QColor("#5f3a8e"), 1))  # Violet foncé
            else:
                painter.setPen(QPen(QColor("#2980b9"), 1))  # Bleu foncé
            painter.drawLine(rect.center().x(), rect.top() + 5, 
                           rect.center().x(), rect.bottom() - 5)
            
            # Texte des boutons (toujours blanc pour contraste)
            painter.setPen(QColor(Qt.GlobalColor.white))
            font = QFont()
            font.setBold(True)
            font.setPointSize(8)
            painter.setFont(font)
            
            # Bouton Copier ID
            id_rect = rect.adjusted(5, 0, -rect.width()//2 - 5, 0)
            painter.drawText(id_rect, Qt.AlignmentFlag.AlignCenter, "Copy > ID")
            
            # Bouton Copier Lien
            link_rect = rect.adjusted(rect.width()//2 + 5, 0, -5, 0)
            painter.drawText(link_rect, Qt.AlignmentFlag.AlignCenter, "Copy > Link")
            
            # Stocker les zones pour les clics
            self.button_areas[row] = {
                'id': id_rect,
                'link': link_rect
            }
            
        except Exception as e:
            self.logger.error(f"[DELEGATE] Erreur boutons: {e}")
