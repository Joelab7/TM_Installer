"""
Gestion avancée des sessions persistantes pour l'application.

Ce module permet de sauvegarder et de restaurer l'état des sessions
entre les exécutions du programme, avec chiffrement et rotation des fichiers.
"""
import json
import os
import logging
import asyncio
from datetime import datetime
from typing import Dict, Any, Optional, List, Callable, Awaitable
from pathlib import Path
import hashlib
import base64

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from config.settings import Config

logger = logging.getLogger(__name__)

class EncryptionManager:
    """Gestion du chiffrement/déchiffrement des sessions."""
    
    def __init__(self, encryption_key: Optional[str] = None):
        """Initialise le gestionnaire de chiffrement."""
        self.key = self._generate_key(encryption_key or self._get_default_key())
        self.cipher_suite = Fernet(self.key)
    
    @staticmethod
    def _get_default_key() -> str:
        """Génère une clé par défaut basée sur des informations système."""
        system_id = hashlib.sha256(os.environ.get('COMPUTERNAME', '').encode()).hexdigest()
        return f"{system_id[:32]}"  # 32 caractères max pour la clé
    
    @staticmethod
    def _generate_key(password: str) -> bytes:
        """Génère une clé de chiffrement à partir d'un mot de passe."""
        password = password.encode()
        salt = b'salt_'  # Ajoutez un sel pour renforcer la sécurité
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password))
    
    def encrypt(self, data: str) -> str:
        """Chiffre les données."""
        return self.cipher_suite.encrypt(data.encode()).decode()
    
    def decrypt(self, encrypted_data: str) -> str:
        """Déchiffre les données."""
        return self.cipher_suite.decrypt(encrypted_data.encode()).decode()

class SessionObserver:
    """Interface pour les observateurs de sessions."""
    
    def on_session_updated(self, phone: str, session_data: Dict[str, Any]):
        """Appelé lorsqu'une session est mise à jour."""
        pass
    
    def on_session_deleted(self, phone: str):
        """Appelé lorsqu'une session est supprimée."""
        pass

class SessionManager:
    """Gestionnaire avancé de sessions persistantes avec chiffrement et rotation."""
    
    _observers: List[SessionObserver] = []
    
    @classmethod
    def add_observer(cls, observer: 'SessionObserver'):
        """Ajoute un observateur pour les changements de session."""
        if observer not in cls._observers:
            cls._observers.append(observer)
    
    @classmethod
    def remove_observer(cls, observer: 'SessionObserver'):
        """Retire un observateur."""
        if observer in cls._observers:
            cls._observers.remove(observer)
    
    def __init__(self, session_file: str = 'session.json', max_backups: int = 5, 
                 encryption_key: Optional[str] = None):
        """
        Initialise le gestionnaire de session.
        
        Args:
            session_file: Nom du fichier de session
            max_backups: Nombre maximum de sauvegardes à conserver
            encryption_key: Clé de chiffrement optionnelle
        """
        self.config = Config()
        self.session_dir = Path(self.config.SESSION_DIR)
        self.session_file = self.session_dir / session_file
        self.max_backups = max_backups
        self.encryption_manager = EncryptionManager(encryption_key)
        
        # Créer le répertoire de session s'il n'existe pas
        self.session_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_backup_files(self) -> List[Path]:
        """Retourne la liste des fichiers de sauvegarde triés par date."""
        if not self.session_file.exists():
            return []
            
        base_name = self.session_file.stem
        ext = self.session_file.suffix
        pattern = f"{base_name}.bak_*{ext}"
        
        backup_files = sorted(
            self.session_dir.glob(pattern),
            key=os.path.getmtime,
            reverse=True
        )
        return backup_files
    
    def _rotate_backups(self):
        """Effectue une rotation des sauvegardes."""
        if not self.session_file.exists():
            return
            
        backup_files = self._get_backup_files()
        
        # Supprimer les anciennes sauvegardes si nécessaire
        while len(backup_files) >= self.max_backups:
            old_backup = backup_files.pop()
            old_backup.unlink()
        
        # Renommer le fichier actuel en sauvegarde
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = self.session_file.with_name(
            f"{self.session_file.stem}.bak_{timestamp}{self.session_file.suffix}"
        )
        self.session_file.rename(backup_file)
    
    async def save_session(self, phone: str, session_data: Dict[str, Any]):
        """
        Sauvegarde les données de session.
        
        Args:
            phone: Numéro de téléphone associé à la session
            session_data: Données de session à sauvegarder
        """
        try:
            # Créer une copie des données pour éviter les modifications
            data = session_data.copy()
            data['_last_updated'] = datetime.now().isoformat()
            
            # Convertir en JSON et chiffrer
            json_data = json.dumps(data, indent=2)
            encrypted_data = self.encryption_manager.encrypt(json_data)
            
            # Sauvegarder l'ancienne version si elle existe
            if self.session_file.exists():
                self._rotate_backups()
            
            # Écrire les nouvelles données
            self.session_file.write_text(encrypted_data)
            
            # Notifier les observateurs
            for observer in self._observers:
                try:
                    observer.on_session_updated(phone, data)
                except Exception as e:
                    logger.error(f"Erreur lors de la notification de l'observateur: {e}")
            
            logger.info(f"Session sauvegardée pour {phone}")
            
        except Exception as e:
            logger.error(f"Erreur lors de la sauvegarde de la session: {e}")
            raise
    
    async def load_session(self, phone: str) -> Optional[Dict[str, Any]]:
        """
        Charge les données de session.
        
        Args:
            phone: Numéro de téléphone associé à la session
            
        Returns:
            Les données de session ou None si introuvable
        """
        try:
            if not self.session_file.exists():
                return None
                
            # Lire et déchiffrer les données
            encrypted_data = self.session_file.read_text()
            json_data = self.encryption_manager.decrypt(encrypted_data)
            data = json.loads(json_data)
            
            # Vérifier si la session est expirée (plus de 7 jours)
            last_updated = datetime.fromisoformat(data.get('_last_updated', '2000-01-01'))
            if (datetime.now() - last_updated).days > 7:
                logger.info(f"Session expirée pour {phone}")
                return None
                
            return data
            
        except Exception as e:
            logger.error(f"Erreur lors du chargement de la session: {e}")
            return None
    
    async def delete_session(self, phone: str):
        """
        Supprime les données de session.
        
        Args:
            phone: Numéro de téléphone associé à la session
        """
        try:
            if self.session_file.exists():
                self.session_file.unlink()
                
            # Notifier les observateurs
            for observer in self._observers:
                try:
                    observer.on_session_deleted(phone)
                except Exception as e:
                    logger.error(f"Erreur lors de la notification de l'observateur: {e}")
            
            logger.info(f"Session supprimée pour {phone}")
            
        except Exception as e:
            logger.error(f"Erreur lors de la suppression de la session: {e}")
            raise

# Instance globale du gestionnaire de sessions
# Utilise la clé de chiffrement de l'environnement si disponible
encryption_key = os.environ.get('SESSION_ENCRYPTION_KEY')
session_manager = SessionManager(encryption_key=encryption_key)
