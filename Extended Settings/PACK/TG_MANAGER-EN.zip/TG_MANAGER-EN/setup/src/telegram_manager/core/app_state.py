"""
Gestionnaire d'état global de l'application pour le bot Telegram.
Permet au bot de connaître l'état de l'application même quand elle n'est pas ouverte.
"""
import os
import json
import logging
from datetime import datetime
from typing import Optional, Dict, Any
from pathlib import Path

logger = logging.getLogger(__name__)

class AppStateManager:
    """
    Gestionnaire d'état global de l'application.
    Stocke les informations sur l'état de connexion, la licence, etc.
    """
    
    def __init__(self):
        """Initialise le gestionnaire d'état."""
        # Chemin vers le fichier d'état
        self.state_file = Path.home() / ".telegram_manager_state.json"
        
        # État actuel
        self._current_state = {
            "app_running": False,
            "last_update": None,
            "user_info": None,
            "license_info": None,
            "session_active": False,
            "app_path": None
        }
        
        # Charger l'état sauvegardé
        self._load_state()
    
    def _load_state(self):
        """Charge l'état depuis le fichier."""
        try:
            if self.state_file.exists():
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    saved_state = json.load(f)
                    # Fusionner avec l'état par défaut
                    self._current_state.update(saved_state)
                    logger.info(f"State loaded: {self._current_state}")
        except Exception as e:
            logger.error(f"Error loading the state: {e}")
    
    def _save_state(self):
        """Sauvegarde l'état dans le fichier."""
        try:
            self._current_state["last_update"] = datetime.now().isoformat()
            
            # Créer le répertoire parent si nécessaire
            self.state_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(self._current_state, f, indent=2, default=str)
            logger.debug("State saved successfully")
        except Exception as e:
            logger.error(f"Error while saving the state: {e}")
    
    def update_app_status(self, running: bool, app_path: str = None):
        """
        Met à jour le statut de l'application.
        
        Args:
            running: Si l'application est en cours d'exécution
            app_path: Chemin vers l'exécutable de l'application
        """
        self._current_state["app_running"] = running
        if app_path:
            self._current_state["app_path"] = app_path
        self._save_state()
    
    def update_user_info(self, user_info: Dict[str, Any]):
        """
        Met à jour les informations de l'utilisateur connecté.
        
        Args:
            user_info: Informations de l'utilisateur (nom, téléphone, etc.)
        """
        self._current_state["user_info"] = user_info
        self._current_state["session_active"] = True
        self._save_state()
    
    def update_license_info(self, license_info: Dict[str, Any]):
        """
        Met à jour les informations de licence.
        
        Args:
            license_info: Informations de licence (validité, expiration, etc.)
        """
        self._current_state["license_info"] = license_info
        self._save_state()
    
    def clear_session(self):
        """Efface les informations de session (déconnexion)."""
        self._current_state["session_active"] = False
        self._current_state["user_info"] = None
        self._save_state()
    
    def get_current_state(self) -> Dict[str, Any]:
        """
        Retourne l'état actuel de l'application.
        
        Returns:
            Dictionnaire contenant l'état complet
        """
        return self._current_state.copy()
    
    def is_app_running(self) -> bool:
        """Vérifie si l'application est en cours d'exécution."""
        return self._current_state.get("app_running", False)
    
    def get_user_info(self) -> Optional[Dict[str, Any]]:
        """Retourne les informations de l'utilisateur connecté."""
        return self._current_state.get("user_info")
    
    def get_license_info(self) -> Optional[Dict[str, Any]]:
        """Retourne les informations de licence."""
        return self._current_state.get("license_info")
    
    def is_session_active(self) -> bool:
        """Vérifie si une session est active."""
        return self._current_state.get("session_active", False)

# Instance globale du gestionnaire d'état
app_state_manager = AppStateManager()
