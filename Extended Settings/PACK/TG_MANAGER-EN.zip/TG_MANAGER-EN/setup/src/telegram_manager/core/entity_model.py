"""
Modèle QAbstractItemModel optimisé pour afficher les entités sans créer de widgets
Utilise le backend C++ pour le traitement des données
"""
from PyQt6.QtCore import QAbstractItemModel, QModelIndex, Qt, QVariant
from PyQt6.QtGui import QIcon, QPixmap, QPainter, QColor
import logging
from typing import List, Dict, Any, Optional

class EntityModel(QAbstractItemModel):
    """Modèle optimisé pour afficher les entités sans création massive de widgets"""
    
    def __init__(self, entity_loader=None, parent=None):
        super().__init__(parent)
        self.entity_loader = entity_loader
        self.entities = []  # Liste plate des entités
        self.filtered_entities = []
        self.role_filter = None  # None, 'admin', ou 'member'
        self.entity_type_filter = None  # None, 'groups', 'channels', 'bots', 'chats'
        self.search_filter = None  # Filtre de recherche
        self.headers = ["Entity", "Type", "Members", "Actions"]
        self.logger = logging.getLogger(__name__)
        
    def set_entities(self, entities_data: Dict[str, Any], entity_type: str = None):
        """Définit les données des entités depuis le loader C++ pour un type spécifique."""
        self.beginResetModel()
        
        try:
            self.entities = []
            
            # Si entity_type est spécifié, ne charger que ce type
            if entity_type and entity_type in entities_data:
                # Aplatir les entités pour ce type spécifique
                for role in ['admin', 'member']:
                    role_entities = entities_data[entity_type].get(role, [])
                    for entity in role_entities:
                        entity['entity_type'] = entity_type
                        entity['role'] = role
                        entity['is_admin'] = (role == 'admin')
                        self.entities.append(entity)
            else:
                # Ancien comportement : tous les types
                for entity_type in ['groups', 'channels', 'bots', 'chats']:
                    for role in ['admin', 'member']:
                        role_entities = entities_data.get(entity_type, {}).get(role, [])
                        for entity in role_entities:
                            entity['entity_type'] = entity_type
                            entity['role'] = role
                            entity['is_admin'] = (role == 'admin')
                            self.entities.append(entity)
            
            # Trier les entités par admin puis par titre
            self.entities.sort(key=lambda x: (not x.get('is_admin', False), x.get('title', '').lower()))
            self.logger.info(f"[MODEL] Tri Python effectué pour {len(self.entities)} entités")
            
            self.logger.info(f"[MODEL] {len(self.entities)} entités chargées pour {entity_type or 'tous'}")
            
            # Appliquer les filtres existants
            self._apply_filter()
            
        except Exception as e:
            self.logger.error(f"[MODEL] Erreur lors du chargement: {e}", exc_info=True)
        
        self.endResetModel()
    
    def set_search_filter(self, search_text):
        """Définit un filtre de recherche et met à jour le modèle."""
        self.beginResetModel()
        self.search_filter = search_text.lower() if search_text else None
        self._apply_filter()
        self.endResetModel()
    
    def set_entity_type_filter(self, entity_type_filter):
        """Définit un filtre par type d'entité et met à jour le modèle."""
        self.beginResetModel()
        self.entity_type_filter = entity_type_filter
        self._apply_filter()
        self.endResetModel()
    
    def set_role_filter(self, role_filter):
        """Définit un filtre par rôle (admin/member) et met à jour le modèle."""
        self.beginResetModel()
        self.role_filter = role_filter
        self._apply_filter()
        self.endResetModel()
    
    def _apply_filter(self):
        """Aplique les filtres (rôle, type d'entité et recherche) aux entités."""
        self.filtered_entities = []
        
        for entity in self.entities:
            # Filtrer par type d'entité si spécifié
            if self.entity_type_filter and entity.get('entity_type') != self.entity_type_filter:
                continue
            
            # Filtrer par rôle si spécifié
            if self.role_filter and entity.get('role') != self.role_filter:
                continue
            
            # Filtrer par recherche si spécifié
            if self.search_filter:
                title = (entity.get('title') or '').lower()
                username = (entity.get('username') or '').lower()
                if self.search_filter not in title and self.search_filter not in username:
                    continue
            
            self.filtered_entities.append(entity)
    
    def filter_entities(self, search_text: str):
        """Filtre les entités avec le backend C++"""
        if not search_text:
            return self.entities
        
        if self.entity_loader and hasattr(self.entity_loader, 'filter_entities'):
            # Filtrage C++
            return self.entity_loader.filter_entities(self.entities, search_text.lower())
        else:
            # Fallback Python
            search_text = search_text.lower()
            return [
                entity for entity in self.entities
                if search_text in entity.get('title', '').lower() 
                or search_text in entity.get('username', '').lower()
            ]
    
    # Méthodes requises de QAbstractItemModel
    def rowCount(self, parent=QModelIndex()):
        return len(self.filtered_entities)
    
    def columnCount(self, parent=QModelIndex()):
        return len(self.headers)
    
    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or index.row() >= len(self.filtered_entities):
            return QVariant()
        
        entity = self.filtered_entities[index.row()]
        column = index.column()
        
        if role == Qt.ItemDataRole.DisplayRole:
            return self._get_display_data(entity, column)
        elif role == Qt.ItemDataRole.DecorationRole and column == 0:
            return self._get_avatar(entity)
        elif role == Qt.ItemDataRole.ToolTipRole:
            return self._get_tooltip(entity)
        elif role == Qt.ItemDataRole.UserRole:
            return entity  # Données complètes pour les actions
        
        return QVariant()
    
    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return self.headers[section] if section < len(self.headers) else QVariant()
        return QVariant()
    
    def index(self, row, column, parent=QModelIndex()):
        if not self.hasIndex(row, column, parent):
            return QModelIndex()
        return self.createIndex(row, column)
    
    def parent(self, child):
        return QModelIndex()
    
    # Méthodes utilitaires
    def _get_display_data(self, entity: Dict, column: int) -> QVariant:
        """Retourne les données à afficher pour une colonne"""
        try:
            if column == 0:  # Titre
                title = entity.get('title', 'Sans titre')
                if entity.get('is_admin', False):
                    title = f"👑 {title}"
                return title
            elif column == 1:  # Type
                if entity.get('is_bot', False):
                    return "🤖 Bot"
                elif entity.get('is_private_chat', False):
                    return "💬 Private Chat"
                elif entity.get('is_channel', False):
                    return "📢 Channel"
                elif entity.get('is_group', False):
                    return "🎭 Group"
                else:
                    return "❓ Unknown"
            elif column == 2:  # Members/Subscribers
                count = entity.get('members_count', 0)
                if count > 0:
                    if entity.get('is_channel', False):
                        return f"{count:,} subscriber{'s' if count != 1 else ''}"
                    else:
                        return f"{count:,} member{'s' if count != 1 else ''}"
                return "-"
            elif column == 3:  # Actions
                return "📋 Copy | 🔗 Link"
        except Exception as e:
            self.logger.error(f"[MODEL] Erreur display data: {e}")
        return QVariant()
    
    def _get_avatar(self, entity: Dict) -> QIcon:
        """Génère un avatar sans créer de widget"""
        try:
            # Avatar par défaut avec première lettre
            title = entity.get('title', 'Sans titre')
            first_letter = title[0].upper() if title else '?'
            
            # Couleur basée sur l'ID
            colors = ['#e57373', '#64b5f6', '#81c784', '#ffb74d', '#ba68c8']
            color = colors[entity.get('id', 0) % len(colors)]
            
            # Créer une icône simple
            pixmap = QPixmap(32, 32)
            pixmap.fill(Qt.GlobalColor.transparent)
            
            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            
            # Cercle de fond
            painter.setBrush(QColor(color))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(2, 2, 28, 28)
            
            # Texte
            painter.setPen(QColor(Qt.GlobalColor.white))
            painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, first_letter)
            
            painter.end()
            return QIcon(pixmap)
            
        except Exception as e:
            self.logger.error(f"[MODEL] Erreur avatar: {e}")
            return QIcon()
    
    def _get_tooltip(self, entity: Dict) -> QVariant:
        """Retourne le tooltip pour l'entité"""
        try:
            tooltip_parts = []
            
            if entity.get('is_admin', False):
                tooltip_parts.append("👑 Administrator")
            
            if entity.get('username'):
                tooltip_parts.append(f"@{entity['username']}")
            
            if entity.get('members_count', 0) > 0:
                count = entity['members_count']
                if entity.get('is_channel', False):
                    tooltip_parts.append(f"{count:,} subscriber{'s' if count != 1 else ''}")
                else:
                    tooltip_parts.append(f"{count:,} member{'s' if count != 1 else ''}")
            
            # Retourner du texte simple (plus fiable que l'HTML)
            return " | ".join(tooltip_parts) if tooltip_parts else entity.get('title', '')
            
        except Exception as e:
            self.logger.error(f"[MODEL] Erreur tooltip: {e}")
            return QVariant()
