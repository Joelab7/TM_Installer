"""
Wrapper Python pour le chargement des entités (version simplifiée)
"""
import logging
from typing import Dict, List, Any

class FastEntityLoader:
    """Loader d'entités optimisé en Python"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def load_entities(self, telegram_data: Dict[str, Any]) -> Dict[str, List[Dict]]:
        """Charge les entités en utilisant le backend Python"""
        try:
            self.logger.info("Chargement des entités avec backend Python")
            return self._load_entities_python(telegram_data)
                
        except Exception as e:
            self.logger.error(f"Erreur lors du chargement: {e}")
            return {}
    
    def _load_entities_python(self, telegram_data: Dict[str, Any]) -> Dict[str, List[Dict]]:
        """Backend Python optimisé pour le chargement des entités"""
        entities = {
            'groups': {'admin': [], 'member': []},
            'channels': {'admin': [], 'member': []},
            'bots': {'admin': [], 'member': []},
            'chats': {'admin': [], 'member': []}
        }
        
        # Logique de chargement Python
        if not telegram_data:
            return entities
            
        # Traiter les différents types d'entités
        for entity in telegram_data:
            try:
                entity_data = self._process_entity(entity)
                if entity_data:
                    category = self._get_entity_category(entity_data)
                    role = 'admin' if entity_data.get('is_admin', False) else 'member'
                    entities[category][role].append(entity_data)
            except Exception as e:
                self.logger.warning(f"Erreur lors du traitement d'une entité: {e}")
                continue
        
        self.logger.info(f"Chargement terminé: {sum(len(v) for cat in entities.values() for v in cat.values())} entités")
        return entities
    
    def _process_entity(self, entity: Any) -> Dict[str, Any]:
        """Traite une entité brute en données structurées"""
        if hasattr(entity, '__dict__'):
            # Objet Telegram
            return {
                'id': getattr(entity, 'id', None),
                'title': getattr(entity, 'title', None) or getattr(entity, 'first_name', None),
                'username': getattr(entity, 'username', None),
                'invite_link': getattr(entity, 'invite_link', None),
                'is_admin': getattr(entity, 'is_admin', False),
                'is_bot': getattr(entity, 'bot', False),
                'is_private_chat': getattr(entity, 'private', False),
                'is_group': getattr(entity, 'group', False),
                'is_channel': getattr(entity, 'channel', False),
                'members_count': getattr(entity, 'participants_count', 0)
            }
        elif isinstance(entity, dict):
            # Dictionnaire
            return entity.copy()
        else:
            return {}
    
    def _get_entity_category(self, entity_data: Dict[str, Any]) -> str:
        """Détermine la catégorie de l'entité"""
        if entity_data.get('is_bot'):
            return 'bots'
        elif entity_data.get('is_channel'):
            return 'channels'
        elif entity_data.get('is_group'):
            return 'groups'
        elif entity_data.get('is_private_chat'):
            return 'chats'
        else:
            # Détection automatique
            if entity_data.get('members_count', 0) > 2:
                return 'groups'
            else:
                return 'chats'
    
    def filter_entities(self, entities: List[Dict], search_term: str) -> List[Dict]:
        """Filtre les entités avec recherche Python"""
        if not search_term:
            return entities
            
        search_term = search_term.lower()
        return [
            entity for entity in entities
            if search_term in entity.get('title', '').lower() 
            or search_term in entity.get('username', '').lower()
        ]
    
    def sort_entities(self, entities: List[Dict]) -> List[Dict]:
        """Trie les entités (admins en premier)"""
        return sorted(
            entities,
            key=lambda x: (not x.get('is_admin', False), x.get('title', '').lower())
        )
