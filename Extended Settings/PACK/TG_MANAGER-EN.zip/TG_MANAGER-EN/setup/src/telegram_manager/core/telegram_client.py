"""
Module client pour l'API Telegram.

Ce module gère la connexion à l'API Telegram et fournit
une interface simplifiée pour les opérations courantes.
"""
import asyncio
import logging
import os
import time
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Union, BinaryIO, List, Tuple

# Import Qt pour le traitement des images
from PyQt6.QtCore import Qt, QSize, QObject, pyqtSignal
from PyQt6.QtGui import QColor, QPixmap, QImage, QPainter, QPen, QFont
from PyQt6.QtWidgets import QApplication, QLabel

from telethon import TelegramClient, events
from telethon.errors import (
    SessionPasswordNeededError,
    PhoneCodeInvalidError,
    PhoneCodeExpiredError,
    PhoneNumberInvalidError,
    FloodWaitError,
    PhoneCodeEmptyError,
    PhoneNumberUnoccupiedError,
    PhoneNumberBannedError,
    PhoneNumberFloodError,
    PhonePasswordFloodError
)
from telethon.tl.types import User, UpdateShortMessage, UpdateNewChannelMessage, Updates, InputPeerUser, InputPeerChat, InputPeerChannel

from .session_manager import session_manager
from .config import Config

# Configurer le logger pour Telethon
telethon_logger = logging.getLogger('telethon')
# Réduire le niveau de détail pour les logs de connexion
telethon_logger.setLevel(logging.WARNING)

# Désactiver les logs verbeux inutiles
logging.getLogger('telethon.network.mtprotosender').setLevel(logging.ERROR)
logging.getLogger('telethon.network.connection').setLevel(logging.ERROR)
logging.getLogger('telethon.crypto').setLevel(logging.ERROR)
logging.getLogger('telethon.extensions').setLevel(logging.ERROR)

logger = logging.getLogger(__name__)

class TelegramClientWrapper(QObject):
    # Signal émis lorsque le compte connecté change
    account_changed = pyqtSignal()
    """
    Gère la connexion à l'API Telegram avec support avancé des sessions et du 2FA.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialise le gestionnaire de client.
        
        Args:
            config: Configuration optionnelle. Si non fournie, charge la configuration par défaut
        """
        super().__init__()  # Initialisation de la classe parente QObject
        print("Initializing TelegramClientWrapper")  # Initialization log
        
        
        # Charger la configuration
        self.config = Config()
        
        # Si une configuration est fournie, mettre à jour avec les valeurs fournies
        if config:
            for section, values in config.items():
                if section in self.config.config:
                    self.config.config[section].update(values)
                else:
                    self.config.config[section] = values
        
        # Initialiser les attributs
        self.client = None
        self.phone = None
        self.phone_code_hash = None
        self._is_connected = False
        self._connecting = False  # Flag pour éviter les conflits pendant la connexion
        self._user = None
        self._session_path = None
        self._2fa_attempts = 0
        self._last_2fa_attempt = 0
        
        # Récupérer les informations de l'API
        telegram_config = self.config.get_section('telegram', {})
        self.api_id = telegram_config.get('api_id')
        self.api_hash = telegram_config.get('api_hash')
        
        if not self.api_id or not self.api_hash:
            raise ValueError("Telegram API credentials (api_id and api_hash) are required")
        
        # Configurer le client avec des paramètres optimisés
        self._setup_client()
    
    async def check_session(self) -> bool:
        """Vérifie si une session valide existe.
        
        Returns:
            bool: True si une session valide existe, False sinon
        """
        try:
            if not self.client:
                self._setup_client()
                
            # Vérifier si le client est déjà connecté
            if self._is_connected:
                return True
                
            # Vérifier si le fichier de session existe
            session_file = Path(f"sessions/telegram_session.session")
            if not session_file.exists():
                return False
                
            # Essayer de se connecter sans interaction utilisateur
            try:
                # On utilise une connexion rapide juste pour vérifier la validité
                await self.client.connect()
                if await self.client.is_user_authorized():
                    self._is_connected = True
                    return True
                return False
            except Exception as e:
                logger.warning(f"Session verification failed: {e}")
                return False
            finally:
                # Toujours se déconnecter après la vérification
                await self.client.disconnect()
                self._is_connected = False
                
        except Exception as e:
            logger.error(f"Session verification failed: {e}")
            return False
    
    def _setup_client(self):
        """Configure le client Telegram with optimized parameters."""
        # Créer le répertoire de session s'il n'existe pas
        session_dir = Path(self.config.get('app', 'session_dir', 'sessions'))
        session_dir.mkdir(parents=True, exist_ok=True)
        
        # Utiliser un nom de session basé sur le numéro de téléphone si disponible
        session_name = 'telegram_session'
        if self.phone:
            # Nettoyer le numéro de téléphone pour le nom de fichier
            clean_phone = ''.join(c for c in self.phone if c.isdigit())
            session_name = f'session_{clean_phone}'
        
        self._session_path = str(session_dir / session_name)
        logger.info(f"Session directory: {self._session_path}")
        
        # Configure the Telegram client with optimized parameters
        print(f"Creating Telegram client with session: {session_name}")  # Client creation log
        
        try:
            self.client = TelegramClient(
                session=self._session_path,
                api_id=int(self.api_id),
                api_hash=self.api_hash,
                device_model="Telegram Manager",
                app_version="5.0.2",
                system_version="Windows 10 & 11",
                receive_updates=False,  # Désactiver les mises à jour inutiles
                base_logger=telethon_logger,
                connection_retries=3,   # Réduire le nombre de tentatives
                request_retries=2,      # Réduire le nombre de tentatives
                flood_sleep_threshold=0, # Désactiver le flood sleep
                retry_delay=1,          # Délai entre les tentatives
                auto_reconnect=True     # Reconnexion automatique
            )
            print("Client Telegram created successfully")  # Log de succès
            
        except Exception as e:
            print(f"Failed to create Telegram client: {str(e)}")  # Log d'erreur
            raise
    
    def update_config(self, config: Dict[str, Any]) -> None:
        """Update the Telegram client configuration."
        
        Args:
            config: Dictionnaire contenant les nouvelles valeurs de configuration
        """
        try:
            # Mettre à jour les identifiants API s'ils sont fournis
            if 'api_id' in config and config['api_id']:
                self.api_id = config['api_id']
                logger.info("API ID updated")
                
            if 'api_hash' in config and config['api_hash']:
                self.api_hash = config['api_hash']
                logger.info("API Hash updated")
                
            # If the client is already initialized, restart it with the new parameters
            if self.client:
                logger.info("Restarting the client with the new configuration...")
                asyncio.create_task(self._restart_client())
                
        except Exception as e:
            logger.error(f"Failed to update configuration: {e}")
            raise
            
    async def _restart_client(self):
        """Restart the client with the current configuration."""
        try:
            if self.client and self._is_connected:
                await self.client.disconnect()
                self._is_connected = False
                
            self._setup_client()
            await self.client.connect()
            
            if await self.client.is_user_authorized():
                self._is_connected = True
                logger.info("Client restarted successfully with the new configuration")
            else:
                logger.warning("Client restarted but not authorized, a reconnection will be necessary")
                
        except Exception as e:
            logger.error(f"Failed to restart client: {e}")
            self._is_connected = False
    
    
    def __del__(self):
        """Destructeur de la classe, appelé lors de la suppression de l'instance."""
        if hasattr(self, 'client') and self.client:
            try:
                # Utiliser une déconnexion douce pour maintenir la session
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    asyncio.create_task(self.disconnect(force=False))
                else:
                    loop.run_until_complete(self.disconnect(force=False))
            except Exception as e:
                logger.warning(f"Failed to disconnect in destructor: {e}")
    
    def _setup_event_handlers(self):
        """Configure les gestionnaires d'événements pour le client."""
        @self.client.on(events.NewMessage())
        async def handler(event):
            logger.debug(f"Message received: {event.message}")
            
        @self.client.on(events.MessageDeleted())
        async def handler(event):
            logger.debug(f"Message deleted: {event.deleted_ids}")
    
    async def connect(self, max_retries: int = 3) -> bool:
        """
        Établit une connexion avec l'API Telegram.
        
        Args:
            max_retries: Nombre maximum de tentatives de connexion
            
        Returns:
            bool: True si la connexion a réussi, False sinon
        """
        if self._is_connected and await self.is_user_authorized():
            logger.debug("Already connected and authorized")
            return True
            
        # Avoid multiple connections
        if self._connecting:
            logger.debug("Connection already in progress, waiting...")
            # Wait for the connection to finish
            while self._connecting:
                await asyncio.sleep(0.1)
            return self._is_connected
            
        # Reset connection state
        self._is_connected = False
        self._user = None
        self._connecting = True
            
        try:
            for attempt in range(1, max_retries + 1):
                try:
                    logger.info(f"Connection attempt {attempt}/{max_retries}...")
                    
                    # Essayer de se connecter
                    await self.client.connect()
                    self._is_connected = True
                    
                    # Vérifier si l'utilisateur est déjà autorisé
                    if await self.is_user_authorized():
                        logger.info(f"Connected successfully to Telegram as {getattr(self._user, 'username', 'unknown')}")
                        return True
                    
                    logger.info("Connection established, waiting for authentication...")
                    return True
                    
                except FloodWaitError as e:
                    wait_seconds = e.seconds
                    wait_minutes = wait_seconds // 60
                    
                    logger.warning(f"Too many connection attempts. Waiting for {wait_seconds} seconds...")
                    
                    # Afficher un message d'attente
                    print(f"\n⚠️  TOO MANY CONNECTION ATTEMPTS")
                    print("="*50)
                    print(f"\n❌ You must wait {wait_seconds} seconds ({wait_minutes} minutes)")
                    print("   before trying to reconnect again.")
                    print("\nThis delay is imposed by Telegram for security reasons.")
                    
                    # Wait for the necessary time
                    await asyncio.sleep(wait_seconds)
                    logger.info("End of wait, new connection attempt...")
                    
                except Exception as e:
                    logger.error(f"Failed to connect (attempt {attempt}/{max_retries}): {e}")
                    
                    if attempt == max_retries:
                        logger.error("Maximum number of connection attempts reached")
                        self._is_connected = False
                        return False
                    
                    # Exponential backoff before retry
                    wait_time = min(2 ** attempt, 30)  # Maximum 30 seconds
                    logger.info(f"New attempt in {wait_time} seconds...")
                    await asyncio.sleep(wait_time)
            
            self._is_connected = False
            return False
            
        finally:
            self._connecting = False
    
    async def send_code(self, phone: str, max_retries: int = 3) -> Union[bool, str]:
        """Envoie un code de vérification au numéro spécifié.
        
        Args:
            phone: Numéro de téléphone au format international (e.g., +1234567890)
            max_retries: Nombre maximum de tentatives d'envoi
            
        Returns:
            Union[bool, str]: 
                - True si le code a été envoyé avec succès ou si l'utilisateur est déjà connecté
                - str: Message d'erreur en cas d'échec
        """
        logger.info(f"Sending code to number {phone}")
        
        # Basic phone number verification
        if not phone or not phone.startswith('+'):
            return "The phone number must start with a '+' followed by the country code"
        
        # Nettoyer le numéro de téléphone
        phone = ''.join(c for c in phone if c.isdigit() or c == '+')
        
        for attempt in range(1, max_retries + 1):
            try:
                logger.info(f"Attempt to send code {attempt}/{max_retries}...")
                
                # Connect if not already connected
                if not await self.connect():
                    error_msg = "Failed to connect to Telegram server"
                    logger.error(error_msg)
                    if attempt == max_retries:
                        return error_msg
                    await asyncio.sleep(1)
                    continue
                
                # Vérifier si l'utilisateur est déjà autorisé avec une session valide
                if await self.is_user_authorized():
                    # Récupérer les informations de l'utilisateur
                    user_info = await self.get_me()
                    if user_info and user_info.get('phone'):
                        current_phone = user_info['phone']
                        
                        # If the number matches, return True as the user is already connected
                        if current_phone and current_phone.lstrip('+') == phone.lstrip('+'):
                            logger.info(f"User already connected with this number: {phone}")
                            return True
                        
                        # If the number does not match, delete the session file
                        logger.warning(f"Session already exists with a different number: {current_phone}. Cleaning up the session...")
                    
                    # Save the session path
                    session_path = self._session_path
                    
                    # Disconnect properly
                    try:
                        await self.disconnect(force=True)
                    except Exception as e:
                        logger.warning(f"Error during disconnection: {e}")
                    
                    # Supprimer le fichier de session
                    try:
                        if session_path and os.path.exists(session_path + '.session'):
                            os.remove(session_path + '.session')
                            logger.info("Old session file deleted")
                    except Exception as e:
                        logger.warning(f"Error during session file deletion: {e}")
                    
                    # Create a new client instance
                    api_id = self.config.get('telegram', {}).get('api_id')
                    api_hash = self.config.get('telegram', {}).get('api_hash')
                    self.client = TelegramClient(
                        session=session_path,
                        api_id=int(api_id),
                        api_hash=api_hash,
                        device_model="Telegram Manager",
                        app_version="1.0.2",
                        system_version="Windows 10",
                        receive_updates=False,
                        connection_retries=5,
                        request_retries=3,
                        flood_sleep_threshold=10,
                        retry_delay=1,
                        auto_reconnect=True
                    )
                    
                    # Réinitialiser l'état
                    self._is_connected = False
                    self._user = None
                    self.phone = None
                    self.phone_code_hash = None
                
                # Envoyer la demande de code
                try:
                    result = await self.client.send_code_request(phone)
                    if not hasattr(result, 'phone_code_hash') or not result.phone_code_hash:
                        error_msg = "Invalid server response"
                        logger.error(error_msg)
                        if attempt == max_retries:
                            return error_msg
                        await asyncio.sleep(1)
                        continue
                    
                    self.phone = phone
                    self.phone_code_hash = result.phone_code_hash
                    logger.info(f"Code sent successfully to the number {phone}")
                    return True
                    
                except FloodWaitError as fwe:
                    wait_time = fwe.seconds
                    error_msg = (
                        f"Too many attempts. Please wait {wait_time} seconds "
                        f"before retrying."
                    )
                    logger.warning(f"FloodWaitError: {error_msg}")
                    return error_msg
                    
                except PhoneNumberInvalidError:
                    error_msg = "Invalid phone number"
                    logger.warning(error_msg)
                    return error_msg
                    
                except Exception as e:
                    error_msg = str(e).lower()
                    logger.exception(f"Error during code verification (attempt {attempt}/{max_retries})")
                    
                    # Gestion spécifique de l'erreur "all available options"
                    if any(keyword in error_msg for keyword in ['all available options', 'returned when all available options', 'no more options']):
                        error_msg = (
                            "Telegram has exhausted all available means to send verification codes for this number. "
                            "This can occur after several consecutive attempts. "
                            "Please wait at least 1 hour before retrying."
                        )
                        logger.warning(f"Limitation of sending detected: {error_msg}")
                        return error_msg

                    if attempt == max_retries:
                        return f"Failed to send code after {max_retries} attempts: {str(e)}"
                    
                    # Exponential backoff before retry
                    wait_time = 2 ** attempt
                    logger.info(f"New attempt in {wait_time} seconds...")
                    await asyncio.sleep(wait_time)
            
            except Exception as e:
                logger.exception(f"Unexpected error during attempt {attempt}/{max_retries}")
                if attempt == max_retries:
                    return f"Unexpected error: {str(e)}"
                
                # Exponential backoff before retry
                await asyncio.sleep(2 ** attempt)
        
        return "Failed to send code after several attempts"
    
    async def sign_in(self, code: str, max_retries: int = 3) -> Union[bool, str]:
        """Tente de se connecter avec le code de vérification.
        
        Args:
            code: Code de vérification reçu par SMS ou mot de passe 2FA
            max_retries: Nombre maximum de tentatives de connexion
            
        Returns:
            Union[bool, str]: 
                - True if the connection is successful
                - '2FA_NEEDED' if two-factor authentication is required
                - str with error message in case of failure
        """
        if not self.phone or not self.phone_code_hash:
            return "Please first request a verification code"
            
        # Clean the code
        code = code.strip()
        
        # If the code is a 2FA password (can contain letters)
        is_2fa = not (code.isdigit() and len(code) == 5)
        
        for attempt in range(1, max_retries + 1):
            logger.info(f"Connection attempt {attempt}/{max_retries}...")
            
            # Vérifier la connexion
            if not await self.connect():
                error_msg = "Failed to connect to Telegram"
                logger.error(error_msg)
                if attempt == max_retries:
                    return error_msg
                await asyncio.sleep(1)
                continue
            
            # Vérifier si l'utilisateur est déjà connecté avec une session valide
            if await self.is_user_authorized():
                logger.info(f"Already connected as {getattr(self._user, 'username', 'unknown')}")
                return True
            
            # Try to connect with the code or 2FA password
            try:
                if is_2fa:
                    # Si c'est un mot de passe 2FA
                    await self.client.sign_in(password=code)
                else:
                    # Si c'est un code de vérification
                    await self.client.sign_in(
                        phone=self.phone,
                        code=code,
                        phone_code_hash=self.phone_code_hash
                    )
                
                # Si on arrive ici, la connexion a réussi
                self._is_connected = True
                # Get user information
                await self.get_me()
                logger.info(f"Connected successfully to the Telegram API as {getattr(self._user, 'username', 'unknown')}")
                # Emit the account changed signal
                self.account_changed.emit()
                return True
                
            except SessionPasswordNeededError:
                logger.info("Two-factor authentication required")
                return "2FA_NEEDED"
                
            except PhoneCodeInvalidError:
                if attempt == max_retries:
                    return "Invalid verification code"
                logger.warning("Invalid verification code, new attempt...")
                await asyncio.sleep(1)
                continue
                
            except PhoneCodeExpiredError:
                return "Verification code expired. Please request a new code"
                
            except FloodWaitError as fwe:
                wait_time = fwe.seconds
                error_msg = (
                    f"Too many attempts. Please wait {wait_time} seconds "
                    f"before retrying."
                )
                logger.warning(f"FloodWaitError: {error_msg}")
                return error_msg
                
            except Exception as e:
                logger.exception(f"Unexpected error during attempt {attempt}/{max_retries}")
                if attempt == max_retries:
                    return f"Unexpected error: {str(e)}"
                
                # Exponential backoff before retry
                wait_time = 2 ** attempt
                logger.info(f"New attempt in {wait_time} seconds...")
                await asyncio.sleep(wait_time)
                continue
        
        # If we get here, all attempts have failed
        return "Failed to connect after several attempts"
    
    def is_connected(self) -> bool:
        """Check if the client is connected and authenticated.
        
        Returns:
            bool: True si connecté et authentifié, False sinon
        """
        return self._is_connected and self._user is not None
        
    async def is_user_authorized(self) -> bool:
        """Vérifie si l'utilisateur est déjà autorisé avec une session valide.
        
        Returns:
            bool: True si l'utilisateur est déjà connecté avec une session valide, False sinon
        """
        if not self.client:
            logger.warning("No Telegram client initialized")
            return False
            
        # Vérifier si nous avons déjà un utilisateur en cache
        if self._user is not None and self._is_connected:
            return True
            
        # Vérifier si l'utilisateur est déjà en cache et connecté
        if self._user is not None and self._is_connected:
            logger.debug("User already cached and connected")
            return True
            
        # Vérifier la connexion et l'autorisation
        try:
            # Vérifier et établir la connexion si nécessaire
            if not self.client or not self.client.is_connected():
                logger.debug("Connection attempt...")
                if not await self.connect():
                    logger.warning("Connection failed")
                    return False
            
            # Check if the user is authorized
            if not await self.client.is_user_authorized():
                logger.debug("User is not authorized")
                self._is_connected = False
                self._user = None
                return False
            
            # Get user information
            self._user = await self.client.get_me()
            if not self._user:
                logger.warning("Failed to retrieve user information")
                self._is_connected = False
                self._user = None
                return False
                
            # Update connection state
            self._is_connected = True
            
            # Mettre à jour le numéro de téléphone si disponible
            if hasattr(self._user, 'phone') and self._user.phone:
                self.phone = self._user.phone
                
            logger.debug(f"User authorized: {getattr(self._user, 'username', 'unknown')} (Phone: {getattr(self._user, 'phone', 'undefined')})")
            return True
            
        except Exception as e:
            logger.error(f"Error during authentication verification: {e}", exc_info=True)
            self._is_connected = False
            self._user = None
            return False
            
    async def get_me(self) -> Optional[Any]:
        """Récupère les informations de l'utilisateur connecté.
        
        Returns:
            L'objet User de Telethon ou None en cas d'erreur.
        """
        if not self.client or not self._is_connected:
            logger.warning("Failed to retrieve user information: client is not connected")
            return None
            
        try:
            self._user = await self.client.get_me()
            if not self._user:
                logger.error("No user data returned by client.get_me()")
                return None
                
            logger.debug(f"User information: {self._user}")
            
            # Update phone number if available
            if hasattr(self._user, 'phone') and self._user.phone:
                self.phone = self._user.phone
                
            return self._user
            
        except Exception as e:
            logger.exception(f"Error during user information retrieval: {e}")
            return None

    async def is_2fa_enabled(self) -> bool:
        """Check if two-factor authentication is enabled for the user.
        
        Returns:
            bool: True if 2FA is enabled, False otherwise or in case of error
        """
        if not self.client:
            logger.error("Client is not initialized")
            return False
            
        try:
            # Check if the user is authorized
            if not await self.is_user_authorized():
                logger.debug("User is not authorized, impossible to check 2FA")
                return False
                
            # Check if 2FA is enabled
            from telethon.tl.functions.account import GetPasswordRequest
            password_info = await self.client(GetPasswordRequest())
            return bool(password_info.hint)  # Si un indice de mot de passe existe, le 2FA est activé
            
        except Exception as e:
            logger.debug(f"Error during 2FA verification: {e}")
            return False
            
    async def check_2fa_password(self, password: str, max_retries: int = 3) -> Union[bool, str]:
        """
        Vérifie le mot de passe 2FA.
        
        Args:
            password: Mot de passe 2FA à vérifier
            max_retries: Nombre maximum de tentatives
            
        Returns:
            Union[bool, str]: 
                - True if the verification is successful
                - str: Error message in case of failure
        """
        if not password:
            return "2FA password cannot be empty"
            
        # Vérifier le délai entre les tentatives
        import time
        current_time = time.time()
        
        # Si moins de 5 secondes depuis la dernière tentative
        if current_time - self._last_2fa_attempt < 5:
            remaining = int(5 - (current_time - self._last_2fa_attempt))
            return f"Please wait {remaining} seconds before new attempt"
            
        self._last_2fa_attempt = current_time
        
        for attempt in range(1, max_retries + 1):
            try:
                if not await self.connect():
                    return "Failed to connect to Telegram servers"
                    
                # Tentative de connexion avec le mot de passe 2FA
                await self.client.sign_in(password=password)
                
                # Check if the user is now authorized
                if not await self.is_user_authorized():
                    if attempt < max_retries:
                        await asyncio.sleep(1)
                        continue
                    return "Failed 2FA authentication"
                
                # Réinitialiser le compteur de tentatives en cas de succès
                self._2fa_attempts = 0
                self._last_2fa_attempt = 0
                
                # Sauvegarder la session après une connexion réussie
                try:
                    await self.client.session.save()
                except Exception as e:
                    logger.warning(f"Error saving session: {e}")
                
                return True
                
            except SessionPasswordNeededError:
                self._2fa_attempts += 1
                remaining = max_retries - attempt
                last_error = "2FA password is incorrect"
                
                if remaining > 0:
                    last_error += f" (you have {remaining} remaining attempt{'s' if remaining > 1 else ''})"
                    
                if attempt < max_retries:
                    # Attendre un peu avant de réessayer (backoff exponentiel)
                    wait_time = min(2 ** attempt, 10)
                    await asyncio.sleep(wait_time)
                    continue
                    
                return last_error
                
            except FloodWaitError as fwe:
                return f"Too many attempts. Please wait {fwe.seconds} seconds before retrying."
                
            except Exception as e:
                logger.error(f"Error during 2FA verification: {e}")
                if attempt < max_retries:
                    await asyncio.sleep(1)
                    continue
                
                return f"Error during 2FA verification: {str(e)}"
        
        return "Failed 2FA verification after multiple attempts. Please try again later."
    
    async def __aenter__(self):
        """Support du gestionnaire de contexte asynchrone."""
        await self.connect()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Ferme la connexion à la sortie du contexte."""
        await self.disconnect()
        
    async def disconnect(self, force: bool = False) -> bool:
        """Ferme la connexion avec les serveurs Telegram.
        
        Args:
            force: Si True, force la déconnexion même si le client n'est pas connecté
            
        Returns:
            bool: True if the disconnection was successful, False otherwise
        """
        if not self.client:
            logger.debug("No client to disconnect")
            return True
            
        if not self._is_connected and not force:
            logger.debug("Client is not connected, no need to disconnect")
            return True
            
        try:
            # Se déconnecter proprement du client
            await self.client.disconnect()
            self._is_connected = False
            self.phone_code_hash = None
            logger.info("Disconnected from Telegram")
            return True
            
        except Exception as e:
            logger.error(f"Error during disconnection: {e}")
            # In case of error, force disconnection
            try:
                self.client._sender._transport._connected = False
                if hasattr(self.client, '_updates_coroutine'):
                    self.client._updates_coroutine.cancel()
                self._is_connected = False
                logger.warning("Forced disconnection after error")
                return True
            except Exception as inner_e:
                logger.error(f"Failed forced disconnection: {inner_e}")
                return False
                
    async def logout(self) -> bool:
        """
        Déconnecte l'utilisateur et supprime la session.
        
        Returns:
            bool: True si la déconnexion et la suppression de la session ont réussi, False sinon
        """
        try:
            # Se déconnecter d'abord
            await self.disconnect(force=True)
            
            # Supprimer la session si elle existe
            if self.client and hasattr(self.client, 'session'):
                session_path = self.client.session.filename if self.client.session else None
                if session_path and os.path.exists(session_path):
                    try:
                        os.remove(session_path)
                        logger.info(f"Session deleted: {session_path}")
                        
                        # Supprimer également le fichier .session-journal s'il existe
                        journal_path = f"{session_path}-journal"
                        if os.path.exists(journal_path):
                            os.remove(journal_path)
                            logger.info(f"Session journal file deleted: {journal_path}")
                        
                        return True
                    except Exception as e:
                        logger.error(f"Error during session deletion: {e}")
                        return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error during logout: {e}")
            return False

    async def get_invite_link(self, entity):
        """Récupère le lien d'invitation d'une entité (groupe/canal).
        
        Args:
            entity: L'entité ou l'ID de l'entité
                
        Returns:
            str: Lien d'invitation ou None si non disponible
        """
        if not self.client or not self.client.is_connected():
            logger.warning("Unable to retrieve invitation link: client is not connected")
            return None
            
        try:
            # Check if it's a supergroup or channel
            if hasattr(entity, 'megagroup') or hasattr(entity, 'broadcast'):
                # Essayer de récupérer le lien existant
                try:
                    from telethon.tl.functions.channels import GetFullChannelRequest
                    full_chat = await self.client(GetFullChannelRequest(channel=entity))
                    if hasattr(full_chat, 'exported_invite') and hasattr(full_chat.exported_invite, 'link'):
                        return full_chat.exported_invite.link
                except Exception as e:
                    logger.warning(f"Error during retrieval of existing link: {e}")
                
                # Si aucun lien existant et que l'utilisateur est administrateur, essayez de créer un nouveau lien
                try:
                    from telethon.tl.functions.messages import ExportChatInviteRequest
                    result = await self.client(ExportChatInviteRequest(entity))
                    if hasattr(result, 'link'):
                        return result.link
                except Exception as e:
                    logger.warning(f"Error during creation of new link: {e}")
                    
            # For basic groups
            elif hasattr(entity, 'participants_count'):
                try:
                    from telethon.tl.functions.messages import ExportChatInviteRequest
                    result = await self.client(ExportChatInviteRequest(entity))
                    if hasattr(result, 'link'):
                        return result.link
                except Exception as e:
                    logger.warning(f"Error during retrieval of group link: {e}")
                    
            logger.warning(f"Unable to generate invitation link for this entity type")
            return None
            
        except Exception as e:
            logger.error(f"Error during invitation link retrieval: {e}")
            return None
