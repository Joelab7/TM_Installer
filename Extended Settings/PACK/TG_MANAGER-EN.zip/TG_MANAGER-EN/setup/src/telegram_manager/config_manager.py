"""Gestionnaire de configuration pour le gestionnaire de membres Telegram."""
import os
import json
from pathlib import Path
from typing import Optional, Dict, Any

class ConfigManager:
    """Gestionnaire de configuration pour l'application."""
    
    def __init__(self, config_file: str = "config.json"):
        """Initialise le gestionnaire de configuration.
        
        Args:
            config_file: Chemin vers le fichier de configuration
        """
        self.config_file = Path(config_file)
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Charge la configuration depuis le fichier."""
        if not self.config_file.exists():
            return {
                "telegram": {
                    "bot_token": "",
                    "chat_id": "",
                    "notifications_enabled": False
                },
                "app": {
                    "data_dir": str(Path.home() / "telegram_manager"),
                    "theme": "light"
                }
            }
        
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            print(f"Erreur lors du chargement de la configuration: {e}")
            return {}
    
    def save_config(self) -> bool:
        """Sauvegarde la configuration dans le fichier."""
        try:
            # Créer le répertoire parent si nécessaire
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            return True
        except (IOError, TypeError) as e:
            print(f"Erreur lors de la sauvegarde de la configuration: {e}")
            return False
    
    def get_telegram_config(self) -> Dict[str, Any]:
        """Récupère la configuration Telegram."""
        return self.config.get("telegram", {})
    
    def update_telegram_config(self, bot_token: str, chat_id: str, enabled: bool) -> bool:
        """Met à jour la configuration Telegram."""
        if "telegram" not in self.config:
            self.config["telegram"] = {}
            
        self.config["telegram"].update({
            "bot_token": bot_token,
            "chat_id": chat_id,
            "notifications_enabled": enabled
        })
        
        return self.save_config()
    
    def is_telegram_configured(self) -> bool:
        """Vérifie si la configuration Telegram est complète."""
        telegram_config = self.get_telegram_config()
        return all([
            telegram_config.get("bot_token"),
            telegram_config.get("chat_id"),
            telegram_config.get("notifications_enabled", False)
        ])
    
    def get_telegram_token(self) -> Optional[str]:
        """Récupère le token du bot Telegram."""
        return self.get_telegram_config().get("bot_token")
    
    def get_telegram_chat_id(self) -> Optional[str]:
        """Récupère l'ID du chat Telegram."""
        return self.get_telegram_config().get("chat_id")
    
    def are_notifications_enabled(self) -> bool:
        """Vérifie si les notifications sont activées."""
        return self.get_telegram_config().get("notifications_enabled", False)

# Instance globale du gestionnaire de configuration
config_manager = ConfigManager()
