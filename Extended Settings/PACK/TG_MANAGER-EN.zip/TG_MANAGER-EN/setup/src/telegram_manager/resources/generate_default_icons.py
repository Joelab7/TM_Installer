"""Script pour générer des icônes par défaut pour l'application."""
import os
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QIcon, QPixmap, QPainter, QColor, QFont, QFontMetrics
from PyQt6.QtCore import Qt, QSize

def create_icon(text, size=64, bg_color=QColor(66, 165, 245), text_color=Qt.GlobalColor.white):
    """Crée une icône avec du texte centré."""
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    
    # Dessiner un fond arrondi
    painter.setBrush(bg_color)
    painter.setPen(Qt.PenStyle.NoPen)
    painter.drawRoundedRect(0, 0, size, size, 15, 15)
    
    # Dessiner le texte
    font = QFont("Arial", size // 3, QFont.Weight.Bold)
    painter.setFont(font)
    painter.setPen(text_color)
    
    # Ajuster la taille du texte pour qu'il tienne dans l'icône
    metrics = QFontMetrics(font)
    text_width = metrics.horizontalAdvance(text)
    
    # Si le texte est trop large, réduire la taille de la police
    while text_width > size * 0.8 and font.pointSize() > 8:
        font.setPointSize(font.pointSize() - 1)
        metrics = QFontMetrics(font)
        text_width = metrics.horizontalAdvance(text)
    
    painter.setFont(font)
    
    # Centrer le texte
    x = (size - text_width) // 2
    y = (size + metrics.ascent() - metrics.descent()) // 2
    
    painter.drawText(x, y, text)
    painter.end()
    
    return pixmap

def save_icon(pixmap, filename, output_dir):
    """Enregistre l'icône dans un fichier."""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    path = os.path.join(output_dir, f"{filename}.png")
    pixmap.save(path, "PNG")
    print(f"Icône enregistrée : {path}")

def main():
    # Créer une application Qt (nécessaire pour QFont et QPainter)
    app = QApplication([])
    
    # Dossier de sortie pour les icônes
    output_dir = os.path.join(os.path.dirname(__file__), "icons")
    
    # Couleurs pour les icônes
    colors = {
        "app": QColor(66, 165, 245),     # Bleu
        "database": QColor(76, 175, 80),  # Vert
        "notification": QColor(255, 193, 7),  # Jaune
        "members": QColor(66, 165, 245),  # bleu
    }
    
    # Créer les icônes
    icons = [
        ("app_icon", "TM", colors["app"]),
        ("database_icon", "DB", colors["database"]),
        ("notification_icon", "NT", colors["notification"]),
        ("members_manager_icon", "MM", colors["members"]),
    ]
    
    # Générer et enregistrer les icônes
    for name, text, color in icons:
        pixmap = create_icon(text, 256, color)
        save_icon(pixmap, name, output_dir)
    
    print("Génération des icônes terminée !")

if __name__ == "__main__":
    main()
