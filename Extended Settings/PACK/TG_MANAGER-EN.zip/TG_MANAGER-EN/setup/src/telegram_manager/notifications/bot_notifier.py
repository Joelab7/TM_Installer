"""
Système de notification par bot Telegram pour le TG Manager.
Connecte les notifications de l'application à un bot qui notifie uniquement l'utilisateur connecté.
"""
import asyncio
import logging
import os
from typing import Optional, Dict, Any
from telethon import TelegramClient, events
from telethon.errors import RPCError, FloodWaitError
from ..core.config import Config
from ..config import BOT_TOKEN
from ..core.app_state import app_state_manager

logger = logging.getLogger(__name__)

# Stockage global pour les messages de licence (persiste entre les instances)
_GLOBAL_LICENSE_MESSAGES = []

# Ensemble pour suivre les messages déjà sauvegardés (éviter les doublons)
_GLOBAL_LICENSE_MESSAGE_HASHES = set()

class BotNotifier:
    """
    Gestionnaire de notifications par bot Telegram.
    Envoie les notifications de l'application via un bot directement à l'utilisateur connecté.
    """
    
    def __init__(self, telegram_client_wrapper):
        """
        Initialise le bot notifier avec le client Telegram principal.
        
        Args:
            telegram_client_wrapper: Instance du TelegramClientWrapper principal
        """
        self.telegram_client_wrapper = telegram_client_wrapper
        self.bot_client = None
        self.session_name = "bot_notifier"
        self._enabled = False
        self._user_chat_id = None
        self._user_info = None
        
        # Utiliser le stockage global pour les messages de licence
        # (pas de stockage local pour éviter les duplications)
        
        # Récupérer le token du bot depuis la configuration
        self.bot_token = BOT_TOKEN
        
        if not self.bot_token:
            logger.info("🤖 Bot notifications disabled: BOT_TOKEN not found")
            self._enabled = False
        else:
            # Afficher une version sécurisée du token pour le débogage
            token_preview = self.bot_token[:10] + "..." + self.bot_token[-10:] if len(self.bot_token) > 20 else "***"
            logger.info(f"🤖 Bot notifier initialized - will notify connected user")
            logger.info(f"🔑 Bot token configured: {token_preview}")
            self._enabled = True
        
    async def start(self) -> bool:
        """
        Démarre le client bot et configure la notification pour l'utilisateur connecté.
        
        Returns:
            bool: True si démarrage réussi
        """
        if not self._enabled:
            logger.info("🤖 Bot notifications disabled")
            return False
            
        try:
            logger.info("🚀 Starting bot notifier...")
            
            # Vérifier que le client principal est connecté
            if not self.telegram_client_wrapper.is_connected():
                logger.warning("🤖 Cannot start bot notifier: main client not connected")
                self._enabled = False
                return False
            
            logger.info("✅ Main client is connected")
            
            # Récupérer les informations de l'utilisateur connecté
            #logger.info("👤 Getting user info from main client...")
            user_info = await self.telegram_client_wrapper.get_me()
            if not user_info:
                logger.error("🤖 Cannot get user info from main client")
                self._enabled = False
                return False
            
            self._user_info = user_info
            self._user_chat_id = user_info.id
            
            #logger.info(f"👤 User info retrieved: {user_info.first_name} (@{getattr(user_info, 'username', 'N/A')})")
            #logger.info(f"🆔 User chat ID: {self._user_chat_id}")
            
            #logger.info(f"🤖 Bot will notify user: {user_info.first_name} (@{getattr(user_info, 'username', 'N/A')})")
            
            # Créer le client bot avec session unique
            from telethon import TelegramClient
            
            # Utiliser un chemin de session unique pour éviter les conflits
            import os
            import time
            
            # Créer un dossier spécifique pour les sessions de bot de notification
            bot_sessions_dir = "sessions/bot_notifier_sessions"
            os.makedirs(bot_sessions_dir, exist_ok=True)
            
            session_name = f"bot_notifier_{int(time.time())}"
            session_path = f"{bot_sessions_dir}/{session_name}"
            
            #logger.info(f"📁 Creating bot client with session: {session_path}")
            
            self.bot_client = TelegramClient(
                session=session_path,
                api_id=self.telegram_client_wrapper.api_id,
                api_hash=self.telegram_client_wrapper.api_hash
            )
            
            self.bot_client.parse_mode = 'html'
            self.bot_client.flood_sleep_threshold = 0
            
            #logger.info("🔧 Bot client configured")
            
            # Démarrer avec le token du bot
            #logger.info("🔑 Starting bot client with token...")
            try:
                await self.bot_client.start(bot_token=self.bot_token)
                #logger.info("✅ Bot client started successfully")
            except Exception as e:
                # Gestion spécifique du FloodWaitError
                if "FloodWaitError" in str(e) or "wait" in str(e).lower():
                    import re
                    # Extraire le temps d'attente du message d'erreur
                    match = re.search(r'wait of (\d+) seconds', str(e).lower())
                    if match:
                        wait_time = int(match.group(1))
                        max_wait_time = 300  # Maximum 5 minutes d'attente
                        
                        if wait_time <= max_wait_time:
                            logger.warning(f"⚠️ Bot rate limited: Waiting {wait_time} seconds before retry...")
                            await asyncio.sleep(wait_time)
                            # Réessayer après l'attente
                            await self.bot_client.start(bot_token=self.bot_token)
                            logger.info("✅ Bot client started successfully after flood wait")
                        else:
                            logger.warning(f"⚠️ Bot rate limited for {wait_time}s (too long), continuing without notifications")
                            logger.info("💡 The program will continue but bot notifications will be disabled")
                            self._enabled = False
                            return False
                    else:
                        logger.error(f"❌ Unknown flood wait format: {e}")
                        raise
                elif "OperationalError" in str(e) or "database" in str(e).lower():
                    logger.warning(f"⚠️ Bot session database error, trying with clean session: {e}")
                    # Essayer avec une session propre
                    import shutil
                    try:
                        if os.path.exists(session_path + ".session"):
                            shutil.move(session_path + ".session", session_path + ".session.backup")
                        await self.bot_client.start(bot_token=self.bot_token)
                        logger.info("✅ Bot client started successfully with clean session")
                    except Exception as e2:
                        logger.error(f"❌ Failed to start bot even with clean session: {e2}")
                        raise
                else:
                    raise
            
            # Récupérer les infos du bot
            bot_info = await self.bot_client.get_me()
            logger.info(f"🤖 Bot started: @{bot_info.username} ({bot_info.first_name})")
            
            # Ajouter un gestionnaire pour la commande /start
            @self.bot_client.on(events.NewMessage(incoming=True, pattern='/start'))
            async def handle_start_command(event):
                """Gère la commande /start du bot."""
                try:
                    logger.info(f"📩 Received /start command from user {event.sender_id}")
                    
                    # Envoyer le rapport d'état complet
                    await self.send_app_status_report()
                    
                    logger.info(f"✅ Status report sent to user {event.sender_id}")
                    
                except Exception as e:
                    logger.error(f"❌ Error handling /start command: {e}")
            
            # Vérifier si l'utilisateur a déjà démarré une conversation avec le bot
            #logger.info("🔍 Checking user authorization...")
            auth_success = await self._ensure_user_authorization()
            if not auth_success:
                logger.warning("⚠️ Bot started but user needs to start conversation first")
                logger.info("💡 Please start a conversation with @TManagerSoftware_bot to receive notifications")
            else:
                logger.info("✅ User authorization confirmed - notifications ready")
            
            # Envoyer les messages de licence sauvegardés s'il y en a
            global _GLOBAL_LICENSE_MESSAGES, _GLOBAL_LICENSE_MESSAGE_HASHES
            if _GLOBAL_LICENSE_MESSAGES:
                #logger.info(f"🤖 Sending {len(_GLOBAL_LICENSE_MESSAGES)} saved license messages")
                for message in _GLOBAL_LICENSE_MESSAGES:
                    await self.send_notification(message, False)
                # Vider la liste globale ET les hashes après envoi
                _GLOBAL_LICENSE_MESSAGES.clear()
                _GLOBAL_LICENSE_MESSAGE_HASHES.clear()
            else:
                logger.info("ℹ️ No saved license messages to send")
            
            # Envoyer le rapport d'état complet de l'application
            logger.info("📊 Sending app status report...")
            try:
                await self.send_app_status_report()
            except Exception as e:
                logger.warning(f"⚠️ Could not send initial status report: {e}")
            
            #logger.info("🎉 Bot notifier startup completed successfully")
            logger.info("✅ Bot notifier started successfully - ready to send notifications")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error starting bot notifier: {e}")
            logger.error(f"❌ Error type: {type(e).__name__}")
            import traceback
            logger.error(f"❌ Full traceback: {traceback.format_exc()}")
            self._enabled = False
            return False
    
        
    async def _ensure_user_authorization(self):
        """
        Vérifie si l'utilisateur a autorisé le bot et l'invite à le faire si nécessaire.
        """
        try:
            logger.info(f"🔍 Checking authorization for user {self._user_chat_id}")
            
            # Essayer d'envoyer un message test pour vérifier l'autorisation
            test_message = "🤖 Telegram Manager Bot is now active!\n\nYou can now receive notifications about your license status and application updates."
            
            try:
                # Vérifier que le bot client est bien connecté
                if not self.bot_client:
                    logger.error("❌ Bot client is None")
                    return False
                
                # Vérifier que l'ID utilisateur est valide
                if not self._user_chat_id:
                    logger.error("❌ User chat ID is None or empty")
                    return False
                
                logger.info(f"✅ Bot client and user ID validated, sending message...")
                
                await self.bot_client.send_message(
                    entity=self._user_chat_id,
                    message=test_message,
                    link_preview=False
                )
                
                logger.info(f"✅ SUCCESS: Message sent to user {self._user_chat_id}")
                return True
                
            except Exception as e:
                error_msg = str(e)
                logger.error(f"❎ FAILED to send message: {error_msg}")
                #logger.error(f"❌ Error type: {type(e).__name__}")
                
                # En cas d'erreur, afficher un message simple
                logger.warning(f"⚠️ Cannot send notifications - please start the bot with this account to receive notifications")
                return False
                    
        except Exception as e:
            logger.error(f"❌ Critical error in _ensure_user_authorization: {e}")
            logger.error(f"❌ Error type: {type(e).__name__}")
            return False
    
    def _show_authorization_instructions(self, situation: str):
        """
        Affiche les instructions pour que l'utilisateur autorise le bot.
        
        Args:
            situation: Type de situation ("start_conversation", "blocked", "general_error")
        """
        try:
            bot_username = "@TManagerSoftware_bot"  # Nom du bot par défaut
            
            instructions = {
                "start_conversation": [
                    "🔔 **Bot Authorization Required**",
                    "",
                    f"To receive notifications from Telegram Manager:",
                    "",
                    f"1️⃣ Open Telegram and search for: {bot_username}",
                    f"2️⃣ Click on the bot and press **'Start'**",
                    f"3️⃣ The bot will then be able to send you notifications",
                    "",
                    "✅ After starting the bot, click 'Start' again in Telegram Manager",
                    "",
                    f"🔗 Direct link: https://t.me/{bot_username.replace('@', '')}"
                ],
                "blocked": [
                    "🚫 **Bot Blocked**",
                    "",
                    f"You have blocked {bot_username}",
                    "",
                    "To receive notifications:",
                    f"1️⃣ Open Telegram and go to: {bot_username}",
                    f"2️⃣ Click 'Unblock' button",
                    f"3️⃣ Then click 'Start' again in Telegram Manager",
                    "",
                    f"🔗 Direct link: https://t.me/{bot_username.replace('@', '')}"
                ],
                "general_error": [
                    "❎ **Notification Authorization Failed**",
                    "",
                    f"Unable to send notifications through {bot_username}",
                    "",
                    "Please try:",
                    f"1️⃣ Make sure you have started {bot_username}",
                    f"2️⃣ Check that the bot is not blocked",
                    f"3️⃣ Restart Telegram Manager",
                    "",
                    f"🔗 Direct link: https://t.me/{bot_username.replace('@', '')}"
                ]
            }
            
            message = "\n".join(instructions.get(situation, instructions["general_error"]))
            
            # Afficher les instructions dans la console
            print("\n" + "="*60)
            print(message)
            print("="*60 + "\n")
            
            # Logger les instructions
            logger.info(f"Authorization instructions shown for situation: {situation}")
            
        except Exception as e:
            logger.error(f"Error showing authorization instructions: {e}")
    
        
    async def send_notification(self, message: str, is_error: bool = False) -> bool:
        """
        Envoie une notification via le bot à l'utilisateur connecté.
        
        Args:
            message: Message de notification
            is_error: Si True, formate comme une erreur
            
        Returns:
            bool: True si envoi réussi
        """
        if not self._enabled or not self.bot_client or not self._user_chat_id:
            return False
            
        try:
            # Formater le message
            formatted_message = self._format_message(message, is_error)
            
            # Envoyer le message directement à l'utilisateur connecté
            await self.bot_client.send_message(
                entity=self._user_chat_id,
                message=formatted_message,
                link_preview=False
            )
            
            logger.debug(f"🤖 Notification sent to user {self._user_chat_id}: {message[:50]}...")
            return True
            
        except FloodWaitError as e:
            logger.warning(f"🤖 Flood wait: {e.seconds}s")
            await asyncio.sleep(e.seconds)
            return await self.send_notification(message, is_error)
            
        except RPCError as e:
            logger.error(f"🤖 RPC error sending notification: {e}")
            return False
            
        except Exception as e:
            logger.error(f"🤖 Error sending notification: {e}")
            return False
    
    def _format_message(self, message: str, is_error: bool) -> str:
        """Formate le message pour le bot."""
        # Détecter le préfixe selon l'émoji dans le message original
        message_lower = message.lower()

        if "📱" in message:
            prefix = "💻 <b>Connected</b>"
        elif "✅" in message:
            prefix = "✅ <b>Success</b>"        
        elif "❌" in message or "❎" in message:
            prefix = "❎ <b>Failed</b>"
        elif "🛑" in message or "⛔" in message or "🚨" in message or "🚫" in message or "⚠️" in message:
            prefix = "🚨 <b>Alert</b>"
        elif "ℹ️" in message:
            prefix = "ℹ️ <b>Info</b>"
        elif "🚀" in message:
            prefix = "🚀 <b>Starting</b>"
        elif is_error:
            prefix = "⚠️ <b>Error</b>"
        else:
            prefix = "ℹ️ <b>Info</b>"
            
        # Nettoyer le message des émojis existants pour éviter les doublons
        clean_message = message.strip()
        for emoji in ["🚀", "✅", "❎", "❌", "🛑", "⛔", "ℹ️", "🚫", "⚠️", "🚨"]:
            clean_message = clean_message.replace(emoji, "").strip()
            
        return f"{prefix}\n{clean_message}"
    
    def save_license_message(self, message: str):
        """
        Sauvegarde un message de licence pour l'envoyer au prochain démarrage du bot.
        Évite les doublons en utilisant un hash du message.
        
        Args:
            message: Message de licence à sauvegarder
        """
        global _GLOBAL_LICENSE_MESSAGES, _GLOBAL_LICENSE_MESSAGE_HASHES
        
        # Calculer un hash simple du message pour éviter les doublons
        message_hash = hash(message.strip())
        
        # Vérifier si le message a déjà été sauvegardé
        if message_hash not in _GLOBAL_LICENSE_MESSAGE_HASHES:
            _GLOBAL_LICENSE_MESSAGES.append(message)
            _GLOBAL_LICENSE_MESSAGE_HASHES.add(message_hash)
            logger.info(f"🤖 License message saved globally: {message[:50]}...")
        #else:
        #    logger.debug(f"🤖 Duplicate license message ignored: {message[:50]}...")
    
    async def test_connection(self) -> bool:
        """
        Teste la connexion du bot avec l'utilisateur connecté.
        
        Returns:
            bool: True si connexion fonctionnelle
        """
        if not self._enabled or not self.bot_client or not self._user_chat_id:
            return False
            
        try:
            await self.bot_client.send_message(self._user_chat_id, "🤖 Bot connection test successful")
            return True
        except Exception as e:
            logger.error(f"❌ Bot connection test failed: {e}")
            return False
    
    async def send_app_status_report(self):
        """
        Envoie un rapport complet sur l'état de l'application Telegram Manager.
        """
        try:
            # Récupérer l'état actuel de l'application
            state = app_state_manager.get_current_state()
            
            # Construire le message de rapport
            report_lines = ["<b>Telegram Manager Status Report</b>", ""]
            
            # État de l'application
            if state.get("app_running"):
                report_lines.append("📱 <b>Application Status</b>: Running")
            else:
                report_lines.append("❌ <b>Application Status</b>: Not Running")
                report_lines.append("")
                report_lines.append("⚠️ <b>Please open Telegram Manager first</b>")
                report_lines.append("📁 Make sure the application is running and a Telegram account is connected.")
            
            # Informations de session
            if state.get("session_active") and state.get("user_info"):
                user_info = state["user_info"]
                report_lines.append("")
                report_lines.append("👤 <b>Active Session</b>:")
                
                # Construire le nom sans afficher "None"
                first_name = user_info.get('first_name', '')
                last_name = user_info.get('last_name', '')
                name_parts = [part for part in [first_name, last_name] if part and part.strip()]
                full_name = ' '.join(name_parts) if name_parts else 'N/A'
                
                report_lines.append(f"🔹 <b>Name</b>: {full_name}")
                if user_info.get('username'):
                    report_lines.append(f"🔹 <b>Username</b>: @{user_info['username']}")
                if user_info.get('phone'):
                    report_lines.append(f"🔹 <b>Phone</b>: {user_info['phone']}")
                if user_info.get('verified'):
                    report_lines.append("🔹 <b>Verified</b>: ✅")
                if user_info.get('premium'):
                    report_lines.append("🔹 <b>Premium</b>: ⭐")
            else:
                report_lines.append("")
                report_lines.append("🔴 <b>No Active Session</b>")
                report_lines.append("📱 Please connect a Telegram account in Telegram Manager")
            
            # Informations de licence
            if state.get("license_info"):
                license_info = state["license_info"]
                report_lines.append("")
                report_lines.append("🔐 <b>License Information</b>:")
                
                if license_info.get("valid"):
                    report_lines.append("✅ <b>Status</b>: Valid")
                    if license_info.get("expiry_date"):
                        from datetime import datetime
                        expiry = datetime.fromisoformat(license_info["expiry_date"])
                        report_lines.append(f"📅 <b>Expiry Date</b>: {expiry.strftime('%m/%d/%Y')}")
                    if license_info.get("days_remaining"):
                        days = license_info["days_remaining"]
                        if days > 19:
                            report_lines.append(f"🟢 <b>Days Remaining</b>: {days}")
                        elif days > 7:
                            report_lines.append(f"🟡 <b>Days Remaining</b>: {days}")
                        else:
                            report_lines.append(f"🔴 <b>Days Remaining</b>: {days} (⚠️ Expiring Soon)")
                else:
                    report_lines.append("❌ <b>Status</b>: Invalid/Expired")
                    report_lines.append(f"📝 <b>Message</b>: {license_info.get('message', 'No details')}")
                    report_lines.append("")
                    report_lines.append("🛒 <b>To renew your license</b>:")
                    report_lines.append("1. Open Telegram Manager")
                    report_lines.append("2. Click on 'Generate license'")
                    report_lines.append("3. Complete the payment process")
            else:
                report_lines.append("")
                report_lines.append("❓ <b>License Information</b>: Not Available")
                report_lines.append("🔄 Please open Telegram Manager to check license status")
            
            # Dernière mise à jour
            if state.get("last_update"):
                from datetime import datetime
                last_update = datetime.fromisoformat(state["last_update"])
                report_lines.append("")
                report_lines.append(f"⏱️ <b>Last Update</b>: {last_update.strftime('%m/%d/%Y %H:%M:%S')}")
            
            # Envoyer le rapport
            report_message = "\n".join(report_lines)
            await self.send_notification(report_message, False)
            
            logger.info("📊 App status report sent successfully")
            
        except Exception as e:
            error_msg = f"❌ Error sending app status report: {e}"
            logger.error(error_msg)
            await self.send_notification(error_msg, True)
    
    async def close(self):
        """Ferme le client bot."""
        if self.bot_client:
            await self.bot_client.disconnect()
            self.bot_client = None
            logger.info("🤖 Bot notifier closed")
    
    @property
    def enabled(self) -> bool:
        """Vérifie si le bot notifier est activé."""
        return self._enabled
    
    @property
    def user_info(self) -> Optional[Dict[str, Any]]:
        """Retourne les informations de l'utilisateur connecté."""
        return self._user_info

class NotificationManager:
    """
    Gestionnaire central des notifications qui combine UI et bot.
    """
    
    def __init__(self, ui_callback=None, telegram_client_wrapper=None):
        """
        Initialise le gestionnaire de notifications.
        
        Args:
            ui_callback: Callback pour les notifications UI (ex: profile_widget.add_notification)
            telegram_client_wrapper: Client Telegram principal pour récupérer la session utilisateur
        """
        logger.info("🔧 Initializing NotificationManager...")
        
        self.ui_callback = ui_callback
        self.telegram_client_wrapper = telegram_client_wrapper
        self.bot_notifier = None
        self._enabled = True
        
        logger.info(f"📞 Telegram client wrapper provided: {telegram_client_wrapper is not None}")
        logger.info(f"🎨 UI callback provided: {ui_callback is not None}")
        
        # Initialiser le bot notifier si le client est disponible
        if telegram_client_wrapper:
            logger.info("🤖 Creating BotNotifier instance...")
            self.bot_notifier = BotNotifier(telegram_client_wrapper)
            logger.info(f"🤖 Bot notifier enabled: {self.bot_notifier.enabled}")
            
            # Le démarrage du bot sera géré par le MainWindow après que la boucle asyncio soit active
            logger.info("ℹ️ Bot notifier startup will be handled by MainWindow")
        else:
            logger.warning("⚠️ No telegram_client_wrapper provided - bot notifications disabled")
    
    async def _start_bot_notifier(self):
        """Démarre le bot notifier de manière asynchrone."""
        logger.info("🚀 _start_bot_notifier called...")
        
        if self.bot_notifier:
            logger.info("🤖 Bot notifier instance exists, attempting to start...")
            try:
                logger.info("📞 Checking if telegram client is connected...")
                if self.telegram_client_wrapper and self.telegram_client_wrapper.is_connected():
                    logger.info("✅ Telegram client is connected, starting bot...")
                    success = await self.bot_notifier.start()
                    if success:
                        logger.info("✅ Bot notifier started successfully")
                    else:
                        logger.warning("⚠️ Bot notifier failed to start")
                else:
                    logger.warning("⚠️ Telegram client not connected - cannot start bot notifier")
            except Exception as e:
                logger.error(f"❌ Error starting bot notifier: {e}")
                logger.error(f"❌ Error type: {type(e).__name__}")
        else:
            logger.warning("⚠️ No bot notifier instance to start")
    
    async def send_notification(self, message: str, is_error: bool = False, bot_only: bool = False):
        """
        Envoie une notification via UI et/ou bot.
        
        Args:
            message: Message de notification
            is_error: Si True, formate comme une erreur
            bot_only: Si True, n'envoie que via le bot
        """
        if not self._enabled:
            return
            
        # Envoyer via l'UI si disponible et non bot_only
        if self.ui_callback and not bot_only:
            try:
                self.ui_callback(message, is_error)
            except Exception as e:
                logger.error(f"❌ Error sending UI notification: {e}")
        
        # Envoyer via le bot si disponible
        if self.bot_notifier:
            try:
                await self.bot_notifier.send_notification(message, is_error)
            except Exception as e:
                logger.error(f"❌ Error sending bot notification: {e}")
    
    def enable(self):
        """Active les notifications."""
        self._enabled = True
        
    def disable(self):
        """Désactive les notifications."""
        self._enabled = False
    
    @property
    def enabled(self) -> bool:
        """Vérifie si les notifications sont activées."""
        return self._enabled
    
    @property
    def bot_enabled(self) -> bool:
        """Vérifie si les notifications par bot sont activées."""
        return self.bot_notifier and self.bot_notifier.enabled
