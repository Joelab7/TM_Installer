"""
Module pour l'intégration avec l'API Coinbase Commerce.
"""
import hmac
import hashlib
import json
import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple, Any, Union

import requests
from PyQt6.QtCore import QObject, pyqtSignal

from ..utils.device_id import get_or_create_device_id, get_device_fingerprint

class CoinbaseCommerceClient(QObject):
    """Client pour interagir avec l'API Coinbase Commerce."""
    
    # Signaux
    payment_verified = pyqtSignal(dict)  # Émis lorsque le paiement est vérifié
    payment_failed = pyqtSignal(str)     # Émis en cas d'échec du paiement
    
    def __init__(self, api_key: str, webhook_secret: str, parent=None):
        """
        Initialise le client Coinbase Commerce.
        
        Args:
            api_key: Clé API de Coinbase Commerce
            webhook_secret: Secret pour vérifier les webhooks
            parent: Widget parent
        """
        super().__init__(parent)
        self.api_key = api_key
        self.webhook_secret = webhook_secret
        self.base_url = "https://api.commerce.coinbase.com"
        self.session = requests.Session()
        self.session.headers.update({
            'X-CC-Api-Key': self.api_key,
            'X-CC-Version': '2018-03-22',
            'Content-Type': 'application/json'
        })
    
    def create_charge(self, amount: float, 
                     currency: str = 'USD', 
                     name: str = "License Premium", 
                     description: str = "Premium access to the software",
                     user_data: Optional[Dict[str, Any]] = None) -> Optional[Dict]:
        """
        Crée une nouvelle charge (paiement) sur Coinbase Commerce.
        
        Args:
            amount: Montant à payer
            currency: Devise (par défaut: USD)
            name: Nom du produit
            description: Description du produit
            user_data: Données utilisateur supplémentaires à inclure dans les métadonnées
            
        Returns:
            Dictionnaire contenant les informations de paiement ou None en cas d'erreur
        """
        url = f"{self.base_url}/charges"
        
        # Arrondir à 2 décimales pour éviter les erreurs
        amount = round(float(amount), 2)
        
        # Générer un identifiant de transaction unique
        transaction_id = f"tx_{uuid.uuid4().hex[:16]}"
        
        # Récupérer l'identifiant unique de l'appareil
        device_id = get_or_create_device_id()
        
        # Préparer les métadonnées
        metadata = {
            "transaction_id": transaction_id,
            "device_id": device_id,
            "license_type": "premium",
            "created_at": datetime.utcnow().isoformat() + "Z"
        }
        
        # Ajouter les données utilisateur si fournies
        if user_data and isinstance(user_data, dict):
            metadata.update({
                k: str(v) for k, v in user_data.items()
                if k not in metadata and not k.startswith('_')
            })
        
        # Ajouter l'empreinte de l'appareil
        try:
            fingerprint_data = get_device_fingerprint()
            metadata.update({
                'device_fingerprint': fingerprint_data['fingerprint'],
                'device_info': json.dumps(fingerprint_data['info'])
            })
        except Exception as e:
            logging.warning(f"Could not generate device fingerprint: {e}")
        
        data = {
            "name": name,
            "description": description,
            "local_price": {
                "amount": str(amount),
                "currency": currency
            },
            "pricing_type": "fixed_price",
            "metadata": metadata
        }
        
        try:
            response = self.session.post(url, json=data)
            response.raise_for_status()
            return response.json()['data']
        except Exception as e:
            logging.error(f"Error creating charge: {str(e)}")
            return None
    
    def verify_webhook(self, request_body: bytes, signature_header: str) -> bool:
        """
        Vérifie la signature du webhook reçu de Coinbase Commerce.
        
        Args:
            request_body: Corps de la requête brute (bytes)
            signature_header: Valeur de l'en-tête X-CC-Webhook-Signature
            
        Returns:
            bool: True si la signature est valide, False sinon
        """
        try:
            if not signature_header or not request_body:
                logging.warning("Missing signature header or request body")
                return False
            
            # La signature Coinbase peut contenir plusieurs algorithmes: "sha256=hash1,sha1=hash2"
            # On cherche spécifiquement la signature sha256
            signatures = signature_header.split(',')
            sha256_signature = None
            
            for sig in signatures:
                sig = sig.strip()
                if sig.startswith('sha256='):
                    sha256_signature = sig[7:]  # Enlever 'sha256='
                    break
            
            if not sha256_signature:
                logging.error("No sha256 signature found in webhook header")
                return False
            
            # Calculer la signature attendue
            hmac_key = self.webhook_secret.encode('utf-8')
            expected_signature = hmac.new(hmac_key, request_body, hashlib.sha256).hexdigest()
            
            # Comparer avec la signature reçue (comparaison sécurisée)
            is_valid = hmac.compare_digest(expected_signature, sha256_signature)
            
            if not is_valid:
                logging.error(f"Webhook signature mismatch. Expected: {expected_signature}, Got: {sha256_signature}")
            else:
                logging.info("Webhook signature verified successfully")
            
            return is_valid
            
        except Exception as e:
            logging.error(f"Error verifying webhook: {str(e)}")
            return False
    
    def handle_webhook_event(self, request_body: bytes, signature_header: str) -> dict:
        """
        Traite un événement webhook de Coinbase Commerce.
        
        Args:
            request_body: Corps de la requête brute (bytes)
            signature_header: Valeur de l'en-tête X-CC-Webhook-Signature
            
        Returns:
            dict: Résultat du traitement avec les clés:
                - success (bool): Si le webhook est valide et traité
                - event_type (str): Type d'événement
                - data (dict): Données de l'événement
                - error (str): Message d'erreur si échec
        """
        try:
            # Vérifier la signature
            if not self.verify_webhook(request_body, signature_header):
                return {
                    'success': False,
                    'error': 'Invalid webhook signature'
                }
            
            # Parser le corps du webhook
            try:
                event_data = json.loads(request_body.decode('utf-8'))
            except json.JSONDecodeError as e:
                logging.error(f"Invalid JSON in webhook: {e}")
                return {
                    'success': False,
                    'error': f'Invalid JSON: {str(e)}'
                }
            
            # Extraire les informations de l'événement
            event_type = event_data.get('event', {}).get('type', '')
            event_data_payload = event_data.get('event', {}).get('data', {})
            
            logging.info(f"Webhook event received: {event_type}")
            
            # Traiter les différents types d'événements
            if event_type == 'charge:confirmed':
                logging.info("Payment confirmed via webhook")
                return {
                    'success': True,
                    'event_type': event_type,
                    'data': event_data_payload,
                    'message': 'Payment confirmed via webhook'
                }
            
            elif event_type == 'charge:completed':
                logging.info("Payment completed via webhook")
                return {
                    'success': True,
                    'event_type': event_type,
                    'data': event_data_payload,
                    'message': 'Payment completed via webhook'
                }
            
            elif event_type == 'charge:failed':
                logging.warning("Payment failed via webhook")
                return {
                    'success': True,
                    'event_type': event_type,
                    'data': event_data_payload,
                    'message': 'Payment failed via webhook'
                }
            
            else:
                logging.info(f"Unhandled webhook event type: {event_type}")
                return {
                    'success': True,
                    'event_type': event_type,
                    'data': event_data_payload,
                    'message': f'Webhook event: {event_type}'
                }
                
        except Exception as e:
            logging.error(f"Error processing webhook event: {str(e)}")
            return {
                'success': False,
                'error': f'Webhook processing error: {str(e)}'
            }
    
    def diagnose_webhook_issue(self, sample_payload: dict = None) -> dict:
        """
        Diagnostique les problèmes potentiels avec la configuration du webhook.
        
        Args:
            sample_payload: Payload de test optionnel
            
        Returns:
            dict: Résultats du diagnostic
        """
        diagnostic_results = {
            'api_key_valid': bool(self.api_key and len(self.api_key) > 20),
            'webhook_secret_valid': bool(self.webhook_secret and len(self.webhook_secret) > 10),
            'webhook_secret_format': None,
            'sample_signature': None,
            'recommendations': []
        }
        
        # Vérifier le format du webhook secret
        if self.webhook_secret:
            if self.webhook_secret.startswith('-----BEGIN'):
                diagnostic_results['webhook_secret_format'] = 'PEM format (correct for webhooks)'
            else:
                diagnostic_results['webhook_secret_format'] = 'Unknown format'
                diagnostic_results['recommendations'].append('Webhook secret should be in PEM format from Coinbase Commerce')
        
        # Générer une signature de test
        if sample_payload:
            try:
                test_payload = json.dumps(sample_payload).encode('utf-8')
                test_signature = hmac.new(
                    self.webhook_secret.encode('utf-8'), 
                    test_payload, 
                    hashlib.sha256
                ).hexdigest()
                diagnostic_results['sample_signature'] = f"sha256={test_signature}"
            except Exception as e:
                diagnostic_results['sample_signature_error'] = str(e)
        
        # Recommandations
        if not diagnostic_results['api_key_valid']:
            diagnostic_results['recommendations'].append('API key appears invalid - check Coinbase Commerce dashboard')
        
        if not diagnostic_results['webhook_secret_valid']:
            diagnostic_results['recommendations'].append('Webhook secret is missing or invalid - regenerate from Coinbase Commerce')
        
        return diagnostic_results
    
    def verify_payment(self, charge_id: str, expected_device_id: Optional[str] = None) -> Tuple[bool, Optional[Dict]]:
        """
        Vérifie le statut d'un paiement et valide l'identité de l'appareil.
        
        Args:
            charge_id: ID de la charge à vérifier
            expected_device_id: ID de l'appareil attendu (optionnel)
            
        Returns:
            Tuple (success, data) où success indique si la requête a réussi
            et data contient les informations de la charge ou un message d'erreur
        """
        success, data = self.check_payment_status(charge_id)
        
        if not success or not data:
            return False, data
            
        # Vérifier que le paiement provient bien du même appareil
        if expected_device_id is not None:
            metadata = data.get('metadata', {})
            if metadata.get('device_id') != expected_device_id:
                logging.warning(
                    f"Device ID mismatch: expected {expected_device_id}, "
                    f"got {metadata.get('device_id')}"
                )
                return False, {
                    'error': 'device_mismatch',
                    'message': 'The payment does not come from the same device'
                }
                
        return True, data
    
    def check_payment_status(self, charge_id: str) -> Tuple[bool, Optional[Dict]]:
        """
        Vérifie le statut d'un paiement.
        
        Args:
            charge_id: ID de la charge à vérifier
            
        Returns:
            Tuple (success, data) où success indique si la requête a réussi
            et data contient les informations de la charge ou un message d'erreur
        """
        if not charge_id or not isinstance(charge_id, str):
            return False, {"error": "Invalid transaction ID"}
            
        url = f"{self.base_url}/charges/{charge_id}"
        
        try:
            response = self.session.get(url)
            response.raise_for_status()
            data = response.json()['data']
            
            # Vérifier si le paiement est confirmé
            timeline = data.get('timeline', [])
            if not timeline:
                return False, {"error": "No payment history found"}
                
            last_status = timeline[-1].get('status', '').upper()
            
            # Logging détaillé pour le débogage
            logging.info(f"Payment status check for {charge_id}: {last_status}")
            logging.debug(f"Full timeline: {timeline}")
            
            # Dictionnaire des statuts de paiement
            status_info = {
                'CONFIRMED': (True, 'Payment confirmed'),
                'COMPLETED': (True, 'Payment completed'),
                'RESOLVED': (True, 'Payment resolved'),
                'PENDING': (False, 'Payment pending'),
                'EXPIRED': (False, 'Payment expired'),
                'CANCELED': (False, 'Payment canceled'),
                'FAILED': (False, 'Payment failed')
            }
            
            # Vérifier le statut
            if last_status in status_info:
                is_success, message = status_info[last_status]
                if is_success:
                    return True, data
                else:
                    return False, {"error": message, "status": last_status}
            
            # Si le statut n'est pas reconnu
            return False, {
                "error": f"Unknown payment status: {last_status}",
                "status": last_status
            }
                
        except requests.exceptions.RequestException as e:
            logging.error(f"Network error during payment verification: {str(e)}")
            return False, {"error": f"Network error: {str(e)}"}
            
        except (ValueError, KeyError) as e:
            logging.error(f"Error processing response: {str(e)}")
            return False, {"error": "Invalid payment response received from server"}
            
        except Exception as e:
            logging.error(f"Unexpected error during payment verification: {str(e)}")
            return False, {"error": f"Unexpected error: {str(e)}"}
    
    def get_payment_url(self, charge_data: Dict) -> Optional[str]:
        """
        Extracts the payment URL from the charge data.
        
        Args:
            charge_data: Données de la charge renvoyées par create_charge
            
        Returns:
            URL de paiement ou None si non trouvé
        """
        try:
            return charge_data.get('hosted_url')
        except (KeyError, AttributeError):
            return None
    
    def cancel_charge(self, charge_id: str) -> bool:
        """
        Annule/expire une charge sur Coinbase Commerce.
        
        Note: Selon la documentation Coinbase, on ne peut pas vraiment "annuler" 
        une charge, mais on peut la marquer comme expirée.
        
        Args:
            charge_id: ID de la charge à annuler
            
        Returns:
            True si l'annulation a réussi, False sinon
        """
        try:
            if not charge_id or not isinstance(charge_id, str):
                logging.error("Invalid charge ID for cancellation")
                return False
            
            # Essayer plusieurs approches pour annuler la charge
            
            # Approche 1: Mettre à jour avec cancelled=true
            url = f"{self.base_url}/charges/{charge_id}"
            cancel_data = {
                "cancelled": True
            }
            
            response = self.session.put(url, json=cancel_data)
            
            # Si PUT fonctionne, c'est bon
            if response.status_code == 200:
                logging.info(f"Charge {charge_id} cancelled successfully via PUT")
                return True
            
            # Approche 2: Essayer POST /cancel (certains endpoints l'acceptent)
            cancel_url = f"{self.base_url}/charges/{charge_id}/cancel"
            response = self.session.post(cancel_url)
            
            if response.status_code == 200:
                logging.info(f"Charge {charge_id} cancelled successfully via POST")
                return True
            
            # Approche 3: Mettre à jour avec un timestamp expiré
            from datetime import datetime, timedelta
            expired_time = (datetime.utcnow() - timedelta(hours=1)).isoformat() + 'Z'
            
            expire_data = {
                "expires_at": expired_time
            }
            
            response = self.session.put(url, json=expire_data)
            
            if response.status_code == 200:
                logging.info(f"Charge {charge_id} expired successfully")
                return True
            
            # Si rien ne fonctionne, on log mais on retourne True pour ne pas bloquer
            logging.warning(f"Could not cancel charge {charge_id}, but continuing...")
            return True
            
        except requests.exceptions.RequestException as e:
            logging.error(f"Network error during charge cancellation: {str(e)}")
            # On retourne True pour ne pas bloquer l'interface même si l'API échoue
            return True
            
        except Exception as e:
            logging.error(f"Unexpected error during charge cancellation: {str(e)}")
            # On retourne True pour ne pas bloquer l'interface même si l'API échoue
            return True
