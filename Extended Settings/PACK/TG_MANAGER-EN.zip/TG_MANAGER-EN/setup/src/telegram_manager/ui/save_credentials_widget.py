"""Widget pour sauvegarder manuellement les informations d'identification Telegram."""
import json
import logging
from pathlib import Path
from typing import Dict, List

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
    QPushButton, QMessageBox, QFrame, QApplication, QSizePolicy
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QPalette

from ..core.config import Config


class CredentialEntry(QFrame):
    """Widget individuel pour une entrée d'informations d'identification."""
    
    entry_changed = pyqtSignal()
    remove_requested = pyqtSignal()
    
    def __init__(self, phone: str = "", api_id: str = "", api_hash: str = "", parent=None):
        super().__init__(parent)
        self.setFrameStyle(QFrame.Shape.Box)
        self.is_saved = False
        self.entry_number = 1  # Valeur par défaut
        
        # S'assurer que les paramètres sont bien des chaînes de caractères valides
        phone = "" if phone is None or phone is False or str(phone).lower() == "false" else str(phone)
        api_id = "" if api_id is None or api_id is False or str(api_id).lower() == "false" else str(api_id)
        api_hash = "" if api_hash is None or api_hash is False or str(api_hash).lower() == "false" else str(api_hash)
        
        self.setup_ui(phone, api_id, api_hash)
    
    def setup_ui(self, phone: str, api_id: str, api_hash: str):
        """Configure l'interface utilisateur en disposition horizontale."""
        # Layout qui s'étire
        layout = QHBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(2)
        
        # Permettre l'étirement horizontal
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        
        # Numéro de l'entrée
        self.number_label = QLabel(f"{self.entry_number}")
        self.number_label.setFixedSize(25, 25)
        self.number_label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.number_label.setStyleSheet("""
            QLabel {
                font-weight: bold;
                font-size: 10px;
            }
        """)
        layout.addWidget(self.number_label)
        
        # Label Phone
        self.phone_label = QLabel("Phone:")
        self.phone_label.setFixedSize(48, 25)
        self.phone_label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.phone_label.setStyleSheet("font-size: 10px;")
        layout.addWidget(self.phone_label)
        
        # Champ numéro de téléphone - qui s'étire
        self.phone_edit = QLineEdit(phone)
        self.phone_edit.setPlaceholderText("+123456789")
        self.phone_edit.setMinimumWidth(60)
        self.phone_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.phone_edit.textChanged.connect(self.entry_changed.emit)
        layout.addWidget(self.phone_edit)
        
        # Bouton de copie pour le téléphone - étiré
        self.copy_phone_btn = QPushButton("📰")
        self.copy_phone_btn.setFixedSize(20, 22)
        self.copy_phone_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.copy_phone_btn.setStyleSheet("""
            QPushButton {
                min-width: 20px;
                max-width: 20px;
                min-height: 22px;
                max-height: 22px;
                padding: 0px;
                margin: 0px;
                border: 1px solid #ccc;
                border-radius: 2px;
                font-size: 8px;
            }
        """)
        self.copy_phone_btn.setToolTip("Copy Phone Number")
        self.copy_phone_btn.setVisible(False)
        self.copy_phone_btn.clicked.connect(self.copy_phone)
        layout.addWidget(self.copy_phone_btn)
        
        # Label API ID
        self.api_id_label = QLabel("API ID:")
        self.api_id_label.setFixedSize(45, 25)
        self.api_id_label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.api_id_label.setStyleSheet("font-size: 9px;")
        layout.addWidget(self.api_id_label)
        
        # Champ API ID - qui s'étire
        self.api_id_edit = QLineEdit(api_id)
        self.api_id_edit.setPlaceholderText("123...")
        self.api_id_edit.setMinimumWidth(40)
        self.api_id_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.api_id_edit.textChanged.connect(self.entry_changed.emit)
        layout.addWidget(self.api_id_edit)
        
        # Bouton de copie pour l'API ID - étiré
        self.copy_api_id_btn = QPushButton("📰")
        self.copy_api_id_btn.setFixedSize(20, 22)
        self.copy_api_id_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.copy_api_id_btn.setStyleSheet("""
            QPushButton {
                min-width: 20px;
                max-width: 20px;
                min-height: 22px;
                max-height: 22px;
                padding: 0px;
                margin: 0px;
                border: 1px solid #ccc;
                border-radius: 2px;
                font-size: 8px;
            }
        """)
        self.copy_api_id_btn.setToolTip("Copy API ID")
        self.copy_api_id_btn.setVisible(False)
        self.copy_api_id_btn.clicked.connect(self.copy_api_id)
        layout.addWidget(self.copy_api_id_btn)
        
        # Label API Hash
        self.api_hash_label = QLabel("API Hash:")
        self.api_hash_label.setFixedSize(60, 25)
        self.api_hash_label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.api_hash_label.setStyleSheet("font-size: 9px;")
        layout.addWidget(self.api_hash_label)
        
        # Champ API Hash - qui s'étire
        self.api_hash_edit = QLineEdit(api_hash)
        self.api_hash_edit.setPlaceholderText("32 chars...")
        self.api_hash_edit.setMinimumWidth(60)
        self.api_hash_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.api_hash_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_hash_edit.textChanged.connect(self.entry_changed.emit)
        layout.addWidget(self.api_hash_edit)
        
        # Bouton de copie pour l'API Hash - étiré
        self.copy_api_hash_btn = QPushButton("📰")
        self.copy_api_hash_btn.setFixedSize(20, 22)
        self.copy_api_hash_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.copy_api_hash_btn.setStyleSheet("""
            QPushButton {
                min-width: 20px;
                max-width: 20px;
                min-height: 22px;
                max-height: 22px;
                padding: 0px;
                margin: 0px;
                border: 1px solid #ccc;
                border-radius: 2px;
                font-size: 8px;
            }
        """)
        self.copy_api_hash_btn.setToolTip("Copy API Hash")
        self.copy_api_hash_btn.setVisible(False)
        self.copy_api_hash_btn.clicked.connect(self.copy_api_hash)
        layout.addWidget(self.copy_api_hash_btn)
        
        # Bouton de sauvegarde - étiré
        self.save_btn = QPushButton("Save")
        self.save_btn.setFixedSize(30, 24)
        self.save_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.save_btn.setToolTip("Save entry")
        self.save_btn.clicked.connect(self.save_this_entry)
        layout.addWidget(self.save_btn)
        
        # Bouton de suppression - taille FIXE dans tous les états
        self.remove_btn = QPushButton("✕")
        self.remove_btn.setFixedSize(20, 20)  # Taille fixe absolue
        self.remove_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.remove_btn.setToolTip("Remove entry")
        self.remove_btn.clicked.connect(self.remove_requested.emit)
        layout.addWidget(self.remove_btn)
        
        # Style initial
        self.update_style()
    
    def update_style(self):
        """Met à jour le style en fonction de l'état de sauvegarde."""
        data = self.get_data()
        is_empty = not (data['phone'].strip() or data['api_id'].strip() or data['api_hash'].strip())
        
        # Si l'entrée est sauvegardée mais vide, la traiter comme vide pour permettre la suppression
        if self.is_saved and is_empty:
            # Détecter le thème plus simplement
            try:
                # Utiliser le widget parent SaveCredentialsWidget
                parent = self
                while parent and not hasattr(parent, 'is_dark_theme'):
                    parent = parent.parent()
                
                is_dark = parent.is_dark_theme() if parent and hasattr(parent, 'is_dark_theme') else False
            except:
                is_dark = False
            
            if is_dark:
                self.setStyleSheet("""
                    QFrame {
                        border: 1px solid #ff9800;
                        border-radius: 4px;
                        background-color: #4a3426;
                        margin: 2px;
                        padding: 2px;
                    }
                    QFrame QLabel {
                        color: #ffffff !important;
                        background-color: transparent;
                    }
                """)
            else:
                self.setStyleSheet("""
                    QFrame {
                        border: 1px solid #ff9800;
                        border-radius: 4px;
                        background-color: #fff3e0;
                        margin: 2px;
                        padding: 2px;
                    }
                """)
            # Rendre les champs éditables pour permettre la modification
            self.phone_edit.setReadOnly(False)
            self.api_id_edit.setReadOnly(False)
            self.api_hash_edit.setReadOnly(False)
            # Forcer les mêmes tailles que l'état normal
            self.phone_edit.setMinimumWidth(60)
            self.phone_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            self.api_id_edit.setMinimumWidth(40)
            self.api_id_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            self.api_hash_edit.setMinimumWidth(60)
            self.api_hash_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            # Cacher les boutons de copie
            self.copy_phone_btn.setVisible(False)
            self.copy_api_id_btn.setVisible(False)
            self.copy_api_hash_btn.setVisible(False)
            # Afficher Save et Remove pour permettre la suppression
            self.save_btn.setFixedSize(25, 20)
            self.save_btn.setVisible(True)
            self.remove_btn.setVisible(True)  # Taille déjà fixe à 20x20
        elif self.is_saved and not is_empty:
            # Détecter le thème plus simplement
            try:
                # Utiliser le widget parent SaveCredentialsWidget
                parent = self
                while parent and not hasattr(parent, 'is_dark_theme'):
                    parent = parent.parent()
                
                is_dark = parent.is_dark_theme() if parent and hasattr(parent, 'is_dark_theme') else False
            except:
                is_dark = False
            
            if is_dark:
                # Thème sombre - couleurs bleues plus sombres
                self.setStyleSheet("""
                    QFrame {
                        border: 1px solid #64b5f6;
                        border-radius: 4px;
                        background-color: #1e3a5f;
                        margin: 2px;
                        padding: 2px;
                    }
                    QLineEdit[readOnly="true"] {
                        background-color: #2c5282;
                        border: 1px solid #42a5f5;
                        color: #e3f2fd;
                        padding: 2px;
                        border-radius: 3px;
                    }
                    QFrame QLabel {
                        color: #ffffff !important;
                        background-color: transparent;
                    }
                """)
            else:
                # Thème clair - couleurs bleues normales
                self.setStyleSheet("""
                    QFrame {
                        border: 1px solid #2196F3;
                        border-radius: 4px;
                        background-color: #e3f2fd;
                        margin: 2px;
                        padding: 2px;
                    }
                    QLineEdit[readOnly="true"] {
                        background-color: #bbdefb;
                        border: 1px solid #1976d2;
                        color: #0d47a1;
                        padding: 2px;
                        border-radius: 3px;
                    }
                """)
            # Rendre les champs en lecture seule MAIS garder la même politique de taille
            self.phone_edit.setReadOnly(True)
            self.api_id_edit.setReadOnly(True)
            self.api_hash_edit.setReadOnly(True)
            # Forcer les mêmes tailles que l'état normal
            self.phone_edit.setMinimumWidth(60)
            self.phone_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            self.api_id_edit.setMinimumWidth(40)
            self.api_id_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            self.api_hash_edit.setMinimumWidth(60)
            self.api_hash_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            # Afficher les boutons de copie
            self.copy_phone_btn.setVisible(True)
            self.copy_api_id_btn.setVisible(True)
            self.copy_api_hash_btn.setVisible(True)
            # Cacher Save, garder Remove visible
            self.save_btn.setVisible(False)
            self.remove_btn.setVisible(True)  # Taille déjà fixe à 20x20
        elif is_empty:
            # Détecter le thème plus simplement
            try:
                # Utiliser le widget parent SaveCredentialsWidget
                parent = self
                while parent and not hasattr(parent, 'is_dark_theme'):
                    parent = parent.parent()
                
                is_dark = parent.is_dark_theme() if parent and hasattr(parent, 'is_dark_theme') else False
            except:
                is_dark = False
            
            if is_dark:
                self.setStyleSheet("""
                    QFrame {
                        border: 1px solid #4d4d4d;
                        border-radius: 4px;
                        background-color: #2d2d2d;
                        margin: 2px;
                        padding: 2px;
                    }
                    QFrame QLabel {
                        color: #ffffff !important;
                        background-color: transparent;
                    }
                    QLineEdit {
                        background-color: #3d3d3d;
                        border: 1px solid #4d4d4d;
                        color: #ffffff;
                        padding: 2px;
                        border-radius: 3px;
                    }
                """)
            else:
                self.setStyleSheet("""
                    QFrame {
                        border: 1px solid #e0e0e0;
                        border-radius: 4px;
                        background-color: #fafafa;
                        margin: 2px;
                        padding: 2px;
                    }
                """)
            # Rendre les champs éditables
            self.phone_edit.setReadOnly(False)
            self.api_id_edit.setReadOnly(False)
            self.api_hash_edit.setReadOnly(False)
            # Forcer les mêmes tailles que l'état normal
            self.phone_edit.setMinimumWidth(60)
            self.phone_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            self.api_id_edit.setMinimumWidth(40)
            self.api_id_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            self.api_hash_edit.setMinimumWidth(60)
            self.api_hash_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            # Cacher les boutons de copie
            self.copy_phone_btn.setVisible(False)
            self.copy_api_id_btn.setVisible(False)
            self.copy_api_hash_btn.setVisible(False)
            # Boutons réduits
            self.save_btn.setFixedSize(25, 20)
            self.save_btn.setVisible(True)
            self.remove_btn.setVisible(True)  # Taille déjà fixe à 20x20
        else:
            # Détecter le thème plus simplement
            try:
                # Utiliser le widget parent SaveCredentialsWidget
                parent = self
                while parent and not hasattr(parent, 'is_dark_theme'):
                    parent = parent.parent()
                
                is_dark = parent.is_dark_theme() if parent and hasattr(parent, 'is_dark_theme') else False
            except:
                is_dark = False
            
            if is_dark:
                self.setStyleSheet("""
                    QFrame {
                        border: 1px solid #d0d0d0;
                        border-radius: 4px;
                        background-color: #3d3d3d;
                        margin: 2px;
                        padding: 2px;
                    }
                    QFrame:hover {
                        border-color: #64b5f6;
                        background-color: #4a4a4a;
                    }
                    QFrame QLabel {
                        color: #ffffff !important;
                        background-color: transparent;
                    }
                    QLineEdit {
                        background-color: #2d2d2d;
                        border: 1px solid #4d4d4d;
                        color: #ffffff;
                        padding: 2px;
                        border-radius: 3px;
                    }
                    QLineEdit:focus {
                        border-color: #64b5f6;
                        background-color: #3d3d3d;
                    }
                """)
            else:
                self.setStyleSheet("""
                    QFrame {
                        border: 1px solid #d0d0d0;
                        border-radius: 4px;
                        background-color: #ffffff;
                        margin: 2px;
                        padding: 2px;
                    }
                    QFrame:hover {
                        border-color: #2196F3;
                        background-color: #f8f9fa;
                    }
                """)
            # Rendre les champs éditables
            self.phone_edit.setReadOnly(False)
            self.api_id_edit.setReadOnly(False)
            self.api_hash_edit.setReadOnly(False)
            # Forcer les mêmes tailles que l'état normal
            self.phone_edit.setMinimumWidth(60)
            self.phone_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            self.api_id_edit.setMinimumWidth(40)
            self.api_id_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            self.api_hash_edit.setMinimumWidth(60)
            self.api_hash_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            # Cacher les boutons de copie
            self.copy_phone_btn.setVisible(False)
            self.copy_api_id_btn.setVisible(False)
            self.copy_api_hash_btn.setVisible(False)
            # Boutons normaux
            self.save_btn.setFixedSize(30, 22)
            self.save_btn.setVisible(True)
            self.remove_btn.setVisible(True)  # Taille déjà fixe à 20x20
    
    def set_saved(self, saved: bool):
        """Définit l'état de sauvegarde."""
        self.is_saved = saved
        self.update_style()
    
    def set_number(self, number: int):
        """Définit le numéro de l'entrée."""
        self.entry_number = number
        self.number_label.setText(f"{number}")
        # Forcer la mise à jour immédiate de l'affichage
        self.number_label.repaint()
        self.number_label.update()  # Forcer la mise à jour de l'affichage
    
    def get_data(self) -> Dict[str, str]:
        """Retourne les données de l'entrée."""
        return {
            'phone': self.phone_edit.text().strip(),
            'api_id': self.api_id_edit.text().strip(),
            'api_hash': self.api_hash_edit.text().strip()
        }
    
    def copy_phone(self):
        """Copie le numéro de téléphone dans le presse-papiers."""
        try:
            phone = self.phone_edit.text().strip()
            clipboard = QApplication.clipboard()
            clipboard.setText(phone)
            
            # Feedback visuel temporaire
            original_text = self.copy_phone_btn.text()
            self.copy_phone_btn.setText("✓")
            QTimer.singleShot(1000, lambda: self.copy_phone_btn.setText(original_text))
            
        except Exception as e:
            logging.error(f"Error copying phone: {e}")
    
    def copy_api_id(self):
        """Copie l'API ID dans le presse-papiers."""
        try:
            api_id = self.api_id_edit.text().strip()
            clipboard = QApplication.clipboard()
            clipboard.setText(api_id)
            
            # Feedback visuel temporaire
            original_text = self.copy_api_id_btn.text()
            self.copy_api_id_btn.setText("✓")
            QTimer.singleShot(1000, lambda: self.copy_api_id_btn.setText(original_text))
            
        except Exception as e:
            logging.error(f"Error copying API ID: {e}")
    
    def copy_api_hash(self):
        """Copie l'API Hash dans le presse-papiers."""
        try:
            api_hash = self.api_hash_edit.text().strip()
            clipboard = QApplication.clipboard()
            clipboard.setText(api_hash)
            
            # Feedback visuel temporaire
            original_text = self.copy_api_hash_btn.text()
            self.copy_api_hash_btn.setText("✓")
            QTimer.singleShot(1000, lambda: self.copy_api_hash_btn.setText(original_text))
            
        except Exception as e:
            logging.error(f"Error copying API Hash: {e}")
    
    def save_this_entry(self):
        """Sauvegarde cette entrée individuelle."""
        logging.info("save_this_entry called!")
        data = self.get_data()
        logging.info(f"Entry data: {data}")
        
        # Vérifier si les champs ont du contenu (validation simple)
        if data['phone'].strip() or data['api_id'].strip() or data['api_hash'].strip():
            logging.info("Entry has content, proceeding with save...")
            self.set_saved(True)
            # Trouver le widget SaveCredentialsWidget parent
            parent_widget = self.parent()
            while parent_widget and not hasattr(parent_widget, 'save_individual_entry'):
                parent_widget = parent_widget.parent()
            
            if parent_widget and hasattr(parent_widget, 'save_individual_entry'):
                logging.info("Found parent widget with save_individual_entry method, calling it...")
                parent_widget.save_individual_entry(self)
                # Forcer la mise à jour du layout après sauvegarde
                QApplication.processEvents()
                self.update()
                self.repaint()
                # Forcer un deuxième appel à update_style pour garantir le layout
                QTimer.singleShot(100, self.update_style)
            else:
                logging.error("Could not find parent widget with save_individual_entry method!")
        else:
            logging.warning("Entry is empty, showing warning...")
            # Détecter le thème actuel
            try:
                parent = self
                while parent and not hasattr(parent, 'is_dark_theme'):
                    parent = parent.parent()
                is_dark = parent.is_dark_theme() if parent and hasattr(parent, 'is_dark_theme') else False
            except:
                is_dark = False
            
            # Créer le message box avec style approprié
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Warning")
            msg_box.setText("Please fill in at least one field before saving.")
            msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
            msg_box.button(QMessageBox.StandardButton.Ok).setText("OK")
            
            # Appliquer le style en fonction du thème
            if is_dark:
                msg_box.setStyleSheet("""
                    QMessageBox {
                        background-color: #2d2d2d;
                        border: none;
                    }
                    QMessageBox QLabel {
                        color: #ffffff;
                        background-color: transparent;
                        border: none;
                    }
                    QMessageBox QPushButton {
                        background-color: #3d3d3d;
                        color: #ffffff;
                        border: 1px solid #4d4d4d;
                        padding: 4px 8px;
                        border-radius: 4px;
                        min-width: 70px;
                    }
                    QMessageBox QPushButton:hover {
                        background-color: #4d4d4d;
                    }
                    QMessageBox QPushButton:pressed {
                        background-color: #2a6ea5;
                    }
                """)
            else:
                # Thème clair - style épuré sans bordures visibles
                msg_box.setStyleSheet("""
                    QMessageBox {
                        background-color: #ffffff;
                        border: none;
                        border-radius: 6px;
                    }
                    QMessageBox QLabel {
                        color: #000000;
                        background-color: transparent;
                        border: none;
                        margin-top: 8px;
                        padding-top: 4px;
                    }
                    QMessageBox QPushButton {
                        background-color: #f5f5f5;
                        color: #333333;
                        border: 1px solid #d0d0d0;
                        padding: 4px 8px;
                        border-radius: 4px;
                        min-width: 70px;
                    }
                    QMessageBox QPushButton:hover {
                        background-color: #e0e0e0;
                    }
                    QMessageBox QPushButton:pressed {
                        background-color: #d0d0d0;
                    }
                """)
            
            msg_box.exec()
    
    def is_valid(self) -> bool:
        """Vérifie si l'entrée est valide."""
        data = self.get_data()
        # Validation plus permissive : juste vérifier que les champs ne sont pas vides
        return (data['phone'].strip() and 
                data['api_id'].strip() and 
                data['api_hash'].strip())


class SaveCredentialsWidget(QWidget):
    """Widget principal pour sauvegarder les informations d'identification."""
    
    credentials_saved = pyqtSignal()
    
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        self.entries: List[CredentialEntry] = []
        self.setup_ui()
        self.load_existing_credentials()
    
    def is_dark_theme(self):
        """Détecte si le thème actuel est sombre."""
        bg_color = self.palette().color(self.backgroundRole())
        return bg_color.lightness() < 128
    
    def setup_ui(self):
        """Configure l'interface utilisateur."""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(8)
        
        # Limiter la taille maximale du widget pour éviter l'étirement
        self.setMaximumWidth(800)
        self.setMinimumWidth(600)
        
        # Header
        header_layout = QHBoxLayout()
        
        title_label = QLabel("Telegram Credentials Manager")
        title_label.setObjectName("title_label")
        title_label.setStyleSheet("""
            QLabel {
                font-size: 16px;
                font-weight: bold;
                color: #2c3e50;
            }
        """)
        header_layout.addWidget(title_label)
        
        header_layout.addStretch()
        
        # Boutons principaux
        self.add_btn = QPushButton("+ Add")
        self.add_btn.setToolTip("Add new credential entry")
        self.add_btn.clicked.connect(self.add_entry)
        
        header_layout.addWidget(self.add_btn)
        
        main_layout.addLayout(header_layout)
        
        # Description
        desc_label = QLabel("Add your Telegram API credentials, click Save to make them static and copyable.")
        desc_label.setObjectName("desc_label")
        desc_label.setStyleSheet("""
            QLabel {
                font-size: 11px;
                color: #7f8c8d;
                margin-bottom: 8px;
                border: none;
                background-color: transparent;
            }
        """)
        main_layout.addWidget(desc_label)
        
        # Zone de défilement pour les entrées
        from PyQt6.QtWidgets import QScrollArea
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll_area.setStyleSheet("""
            QScrollArea {
                border: 1px solid #d0d0d0;
                border-radius: 4px;
                background-color: #f8f9fa;
            }
            QScrollBar:vertical {
                background-color: #f1f1f1;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #bdc3c7;
                border-radius: 6px;
                min-height: 20px;
            }
        """)
        
        self.entries_widget = QWidget()
        self.entries_layout = QVBoxLayout(self.entries_widget)
        self.entries_layout.setSpacing(4)
        self.entries_layout.addStretch()
        
        self.scroll_area.setWidget(self.entries_widget)
        main_layout.addWidget(self.scroll_area, 1)
        
        # Compteur
        self.counter_label = QLabel("0 credential entries")
        self.counter_label.setObjectName("counter_label")
        self.counter_label.setStyleSheet("""
            QLabel {
                font-size: 11px;
                color: #7f8c8d;
                padding: 2px 6px;
                background-color: #f8f9fa;
                border-radius: 3px;
            }
        """)
        main_layout.addWidget(self.counter_label)
        
        self.update_styles()
        self.add_entry()
    
    def update_styles(self):
        """Met à jour les styles en fonction du thème."""
        if self.is_dark_theme():
            # Appliquer les styles spécifiques au titre et compteur
            if hasattr(self, 'counter_label'):
                self.counter_label.setStyleSheet("""
                    QLabel {
                        font-size: 11px;
                        color: #b0bec5;
                        padding: 2px 6px;
                        background-color: #2d3748;
                        border: 1px solid #4a5568;
                        border-radius: 3px;
                    }
                """)
            
            # Trouver et appliquer le style au titre
            title_label = self.findChild(QLabel, "title_label")
            if title_label:
                title_label.setStyleSheet("""
                    QLabel {
                        font-size: 16px;
                        font-weight: bold;
                        color: #2196F3;
                        border: none;
                        background-color: transparent;
                    }
                """)
            
            # Appliquer le style au scroll_area pour le thème sombre
            if hasattr(self, 'scroll_area'):
                self.scroll_area.setStyleSheet("""
                    QScrollArea {
                        border: 1px solid #4d4d4d;
                        border-radius: 4px;
                        background-color: #2b2b2b;
                    }
                    QScrollBar:vertical {
                        background-color: #3d3d3d;
                        width: 12px;
                        border-radius: 6px;
                    }
                    QScrollBar::handle:vertical {
                        background-color: #6d6d6d;
                        border-radius: 6px;
                        min-height: 20px;
                    }
                """)
            
            # Appliquer le style au sous-titre pour le thème sombre
            desc_label = self.findChild(QLabel, "desc_label")
            if desc_label:
                desc_label.setStyleSheet("""
                    QLabel {
                        font-size: 11px;
                        color: #b0bec5;
                        margin-bottom: 8px;
                        border: none;
                        background-color: transparent;
                    }
                """)
            
            self.setStyleSheet("""
                QPushButton {
                    background-color: #3d3d3d;
                    color: #ffffff;
                    border: 1px solid #4d4d4d;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-weight: bold;
                    min-width: 70px;
                }
                QPushButton:hover {
                    background-color: #4d4d4d;
                }
                QPushButton:pressed {
                    background-color: #2a6ea5;
                }
                QFrame QLabel {
                    color: #ffffff !important;
                    background-color: transparent;
                }
                QMessageBox {
                    background-color: #2d2d2d;
                    border: none;
                }
                QMessageBox QLabel {
                    color: #ffffff;
                    background-color: transparent;
                    border: none;
                }
                QMessageBox QPushButton {
                    background-color: #3d3d3d;
                    color: #ffffff;
                    border: 1px solid #4d4d4d;
                    padding: 4px 8px;
                    border-radius: 4px;
                }
                QScrollArea {
                    background-color: #2b2b2b;
                    border-color: #4d4d4d;
                }
            """)
        else:
            # Restaurer les styles par défaut pour le compteur
            if hasattr(self, 'counter_label'):
                self.counter_label.setStyleSheet("""
                    QLabel {
                        font-size: 11px;
                        color: #7f8c8d;
                        padding: 2px 6px;
                        background-color: #f8f9fa;
                        border-radius: 3px;
                    }
                """)
            
            # Restaurer le style par défaut du titre
            title_label = self.findChild(QLabel, "title_label")
            if title_label:
                title_label.setStyleSheet("""
                    QLabel {
                        font-size: 16px;
                        font-weight: bold;
                        color: #2c3e50;
                        border: none;
                        background-color: transparent;
                    }
                """)
            
            # Restaurer le style par défaut du scroll_area
            if hasattr(self, 'scroll_area'):
                self.scroll_area.setStyleSheet("""
                    QScrollArea {
                        border: 1px solid #d0d0d0;
                        border-radius: 4px;
                        background-color: #f8f9fa;
                    }
                    QScrollBar:vertical {
                        background-color: #f1f1f1;
                        width: 12px;
                        border-radius: 6px;
                    }
                    QScrollBar::handle:vertical {
                        background-color: #bdc3c7;
                        border-radius: 6px;
                        min-height: 20px;
                    }
                """)
            
            # Restaurer le style par défaut du sous-titre
            desc_label = self.findChild(QLabel, "desc_label")
            if desc_label:
                desc_label.setStyleSheet("""
                    QLabel {
                        font-size: 11px;
                        color: #7f8c8d;
                        margin-bottom: 8px;
                        border: none;
                        background-color: transparent;
                    }
                """)
            
            self.setStyleSheet("""
                QPushButton {
                    background-color: #f5f5f5;
                    color: #333333;
                    border: 1px solid #d0d0d0;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-weight: bold;
                    min-width: 70px;
                }
                QPushButton:hover {
                    background-color: #e0e0e0;
                }
                QPushButton:pressed {
                    background-color: #2196F3;
                    color: white;
                }
                QScrollArea {
                    background-color: #f8f9fa;
                    border-color: #d0d0d0;
                }
            """)
    
    def add_entry(self, phone: str = "", api_id: str = "", api_hash: str = ""):
        """Ajoute une nouvelle entrée."""
        # S'assurer que les paramètres sont bien des chaînes de caractères
        phone = str(phone) if phone is not None else ""
        api_id = str(api_id) if api_id is not None else ""
        api_hash = str(api_hash) if api_hash is not None else ""
        
        entry = CredentialEntry(phone, api_id, api_hash, self)
        entry.remove_requested.connect(lambda: self.remove_entry(entry))
        entry.entry_changed.connect(self.on_entry_changed)
        
        # Insérer avant le stretch final
        insert_index = self.entries_layout.count() - 1
        self.entries_layout.insertWidget(insert_index, entry)
        
        self.entries.append(entry)
        self.update_entry_numbers()
        self.update_counter()
        
        # Focus sur le premier champ vide
        if not phone:
            entry.phone_edit.setFocus()
    
    def is_entry_empty(self, entry: CredentialEntry) -> bool:
        """Vérifie si une entrée est vide."""
        data = entry.get_data()
        return not (data['phone'].strip() or data['api_id'].strip() or data['api_hash'].strip())
    
    def remove_entry(self, entry: CredentialEntry):
        """Supprime une entrée."""
        # Compter les entrées avec des données et les entrées vides
        entries_with_data = sum(1 for e in self.entries if not self.is_entry_empty(e))
        empty_entries = sum(1 for e in self.entries if self.is_entry_empty(e))
        
        # Cas 1: Si c'est la seule entrée ET qu'elle est vide, bloquer
        if len(self.entries) == 1 and self.is_entry_empty(entry):
            QMessageBox.warning(self, "Warning", "You must have at least one set of credentials.")
            return
        
        # Cas 2: Si on supprime une entrée vide et qu'il reste des entrées avec des données, permettre
        if self.is_entry_empty(entry) and entries_with_data > 0:
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Confirmation of removal")
            msg_box.setText("Are you sure you want to remove this empty entry ?")
            msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            msg_box.button(QMessageBox.StandardButton.Yes).setText("Yes")
            msg_box.button(QMessageBox.StandardButton.No).setText("No")
            
            reply = msg_box.exec()
            
            if reply == QMessageBox.StandardButton.Yes:
                self._perform_removal(entry)
            return
        
        # Cas 3: Si on supprime une entrée avec des données
        if not self.is_entry_empty(entry):
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Confirmation of removal")
            msg_box.setText("Are you sure you want to remove this saved entry ?")
            msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            msg_box.button(QMessageBox.StandardButton.Yes).setText("Yes")
            msg_box.button(QMessageBox.StandardButton.No).setText("No")
            
            reply = msg_box.exec()
            
            if reply == QMessageBox.StandardButton.Yes:
                self._perform_removal(entry)
                
                # Si c'était la dernière entrée avec des données, ajouter une entrée vide
                if entries_with_data == 1:
                    self.add_entry()
                    logging.info("Empty entry added after removal of the last entry with data")
            return
        
        # Cas 4: Autres cas (entrée vide mais pas d'entrées avec des données)
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Confirmation of removal")
        msg_box.setText("Are you sure you want to remove this entry ?")
        msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg_box.button(QMessageBox.StandardButton.Yes).setText("Yes")
        msg_box.button(QMessageBox.StandardButton.No).setText("No")
        
        reply = msg_box.exec()
        
        if reply == QMessageBox.StandardButton.Yes:
            self._perform_removal(entry)
    
    def _perform_removal(self, entry: CredentialEntry):
        """Effectue la suppression effective d'une entrée."""
        # Supprimer du fichier JSON
        try:
            import os
            app_data = os.environ.get('APPDATA', os.path.expanduser('~'))
            credentials_path = Path(app_data) / 'TelegramManager' / 'data' / 'identifiers' / 'credentials.json'
            
            if credentials_path.exists():
                with open(credentials_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # Trouver et supprimer l'entrée par téléphone ou par position
                entry_data = entry.get_data()
                original_accounts = data.get('accounts', [])
                
                # Supprimer l'entrée correspondante
                data['accounts'] = [
                    acc for acc in original_accounts 
                    if acc.get('phone') != entry_data['phone'] and 
                    original_accounts.index(acc) != self.entries.index(entry)
                ]
                
                # Sauvegarder le fichier mis à jour
                with open(credentials_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                
                logging.info(f"Removed entry from file: {entry_data['phone']}")
                
        except Exception as e:
            logging.error(f"Error removing entry from file: {e}")
            QMessageBox.critical(self, "Error", f"Failed to remove entry from file: {str(e)}")
        
        # Supprimer de l'interface
        self.entries_layout.removeWidget(entry)
        entry.deleteLater()
        self.entries.remove(entry)
        self.update_entry_numbers()
        self.update_counter()
    
    def update_entry_numbers(self):
        """Met à jour les numéros des entrées."""
        for i, entry in enumerate(self.entries, 1):
            entry.set_number(i)
    
    def update_counter(self):
        """Met à jour le compteur."""
        entry_count = len(self.entries)
        if entry_count == 1:
            self.counter_label.setText(f"{entry_count} credential entry")
        else:
            self.counter_label.setText(f"{entry_count} credential entries")
    
    def on_entry_changed(self):
        """Appelé lorsqu'une entrée est modifiée."""
        # Plus besoin de gérer l'état du bouton de sauvegarde global
        pass
    
    def save_individual_entry(self, entry: CredentialEntry):
        """Sauvegarde une entrée individuelle dans le fichier."""
        try:
            # Charger les données existantes
            import os
            # Utiliser AppData pour éviter les problèmes de permissions dans Program Files
            app_data = os.environ.get('APPDATA', os.path.expanduser('~'))
            credentials_path = Path(app_data) / 'TelegramManager' / 'data' / 'identifiers' / 'credentials.json'
            logging.info(f"Saving to: {credentials_path}")
            logging.info(f"File exists: {credentials_path.exists()}")
            
            # S'assurer que le répertoire existe
            credentials_path.parent.mkdir(parents=True, exist_ok=True)
            logging.info(f"Directory created/verified: {credentials_path.parent}")
            
            data = {'accounts': [], 'version': '1.0'}
            
            if credentials_path.exists():
                with open(credentials_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            
            # Mettre à jour ou ajouter l'entrée
            entry_data = entry.get_data()
            entry_found = False
            
            for i, account in enumerate(data['accounts']):
                if (account.get('phone') == entry_data['phone'] or 
                    self.entries.index(entry) == i):
                    data['accounts'][i] = entry_data
                    entry_found = True
                    break
            
            if not entry_found:
                data['accounts'].append(entry_data)
            
            # Sauvegarder dans le fichier
            logging.info(f"Attempting to save file to: {credentials_path}")
            logging.info(f"Data to save: {data}")
            
            with open(credentials_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                logging.info("File write operation completed")
            
            # Vérification immédiate
            if credentials_path.exists():
                logging.info(f"File saved successfully at: {credentials_path}")
                logging.info(f"File now exists: {credentials_path.exists()}")
                logging.info(f"File size: {credentials_path.stat().st_size} bytes")
                
                # Lire le fichier pour vérifier le contenu
                try:
                    with open(credentials_path, 'r', encoding='utf-8') as f:
                        saved_content = f.read()
                    logging.info(f"File content preview: {saved_content[:200]}...")
                except Exception as read_error:
                    logging.error(f"Error reading saved file: {read_error}")
            else:
                logging.error(f"CRITICAL: File does not exist after save attempt!")
                logging.error(f"Expected path: {credentials_path}")
                logging.error(f"Parent directory exists: {credentials_path.parent.exists()}")
                logging.error(f"Parent directory writable: {os.access(credentials_path.parent, os.W_OK)}")
            
            logging.info(f"Saved individual entry: {entry_data['phone']}")
            
            # Message de confirmation
            QMessageBox.information(
                self, "Success", 
                f"Credentials for phone number {entry_data['phone']} saved successfully!"
            )
            
        except Exception as e:
            logging.error(f"Error saving individual entry: {e}")
            QMessageBox.critical(
                self, "Error", 
                f"An error occurred while saving this entry: {str(e)}"
            )
    
    def load_existing_credentials(self):
        """Charge les informations d'identification existantes."""
        try:
            import os
            # Utiliser AppData pour éviter les problèmes de permissions dans Program Files
            app_data = os.environ.get('APPDATA', os.path.expanduser('~'))
            credentials_path = Path(app_data) / 'TelegramManager' / 'data' / 'identifiers' / 'credentials.json'
            logging.info(f"Looking for credentials file at: {credentials_path}")
            logging.info(f"File exists: {credentials_path.exists()}")
            
            if credentials_path.exists():
                logging.info(f"Credentials file found, loading...")
                with open(credentials_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                logging.info(f"Loaded data: {data}")
                
                # Vider les entrées actuelles sauf la première
                while len(self.entries) > 1:
                    last_entry = self.entries[-1]
                    self.entries_layout.removeWidget(last_entry)
                    last_entry.deleteLater()
                    self.entries.remove(last_entry)
                
                # Charger les credentials
                if 'accounts' in data:
                    for i, account in enumerate(data['accounts']):
                        if i == 0:
                            # Mettre à jour la première entrée
                            self.entries[0].phone_edit.setText(account.get('phone', ''))
                            self.entries[0].api_id_edit.setText(account.get('api_id', ''))
                            self.entries[0].api_hash_edit.setText(account.get('api_hash', ''))
                            self.entries[0].set_saved(True)
                            # Forcer les politiques de taille correctes
                            self.entries[0].phone_edit.setMinimumWidth(60)
                            self.entries[0].phone_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                            self.entries[0].api_id_edit.setMinimumWidth(40)
                            self.entries[0].api_id_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                            self.entries[0].api_hash_edit.setMinimumWidth(60)
                            self.entries[0].api_hash_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                            logging.info(f"Updated first entry with: {account}")
                        else:
                            # Ajouter une nouvelle entrée
                            entry = CredentialEntry(
                                account.get('phone', ''),
                                account.get('api_id', ''),
                                account.get('api_hash', ''),
                                self
                            )
                            entry.set_saved(True)
                            # Forcer les politiques de taille correctes
                            entry.phone_edit.setMinimumWidth(60)
                            entry.phone_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                            entry.api_id_edit.setMinimumWidth(40)
                            entry.api_id_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                            entry.api_hash_edit.setMinimumWidth(60)
                            entry.api_hash_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                            entry.remove_requested.connect(lambda e=entry: self.remove_entry(e))
                            entry.entry_changed.connect(self.on_entry_changed)
                            
                            insert_index = self.entries_layout.count() - 1
                            self.entries_layout.insertWidget(insert_index, entry)
                            
                            self.entries.append(entry)
                            logging.info(f"Added new entry: {account}")
                
                self.update_entry_numbers()
                self.update_counter()
                
                # Forcer la mise à jour de l'interface
                QApplication.processEvents()
                self.repaint()
                
                # Forcer la mise à jour du style pour toutes les entrées chargées
                for entry in self.entries:
                    entry.update_style()
                logging.info(f"Loaded {len(data.get('accounts', []))} existing credentials")
            else:
                logging.info("No existing credentials file found")
        
        except Exception as e:
            logging.error(f"Error loading existing credentials: {e}")
