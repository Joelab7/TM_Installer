"""Boîte de dialogue des paramètres de l'application."""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, 
    QFormLayout, QMessageBox, QWidget, QHBoxLayout, QToolTip, QApplication
)
from PyQt6.QtCore import Qt, pyqtSignal, QRect
from PyQt6.QtGui import QIcon, QFont, QPixmap
from pathlib import Path
from ..utils import set_window_icon


class SettingsDialog(QDialog):
    """Boîte de dialogue des paramètres avec un design professionnel."""
    
    settings_saved = pyqtSignal(dict)
    
    def __init__(self, config, parent=None):
        """Initialise la boîte de dialogue des paramètres.
        
        Args:
            config: Dictionnaire de configuration
            parent: Widget parent
        """
        super().__init__(parent)
        self.config = config
        self.setup_ui()
        self.apply_theme_style()
        
    def apply_theme_style(self):
        """Applique le style approprié en fonction du thème."""
        theme = 'light'
        if hasattr(self.parent(), 'config') and hasattr(self.parent().config, 'config'):
            theme = self.parent().config.config.get('app', {}).get('theme', 'light')
            
        if theme == 'dark':
            self.setStyleSheet("""
                QDialog {
                    background-color: #2b2b2b;
                    color: #ffffff;
                }
                QLabel {
                    color: #ffffff;
                }
                QGroupBox {
                    color: #ffffff;
                    border: 1px solid #3d3d3d;
                }
                QToolTip {
                    color: #ffffff;
                    background-color: #424242;
                    border: 1px solid #555555;
                    padding: 5px;
                    border-radius: 3px;
                }
                QLineEdit, QComboBox, QPushButton {
                    background-color: #3d3d3d;
                    color: #ffffff;
                    border: 1px solid #555555;
                    padding: 6px 12px;
                    border-radius: 4px;
                }
                QPushButton {
                    background-color: #4a90e2;
                    min-width: 90px;
                }
                /* Style spécifique pour le bouton de visibilité */
                QPushButton#visibilityButton {
                    background-color: #3d3d3d;
                    border: 1px solid #555555;
                    color: #ffffff;
                    min-width: 30px;
                    max-width: 30px;
                    min-height: 30px;
                    max-height: 30px;
                    padding: 0;
                    margin: 0;
                }
                QPushButton#visibilityButton:hover {
                    background-color: #4d4d4d;
                    border-color: #6c757d;
                }
                QPushButton#visibilityButton:pressed {
                    background-color: #5d5d5d;
                }
                QPushButton {
                    background-color: #4a90e2;
                    min-width: 90px;
                }
                QPushButton:hover {
                    background-color: #3a7bc8;
                }
                QPushButton#cancelButton {
                    background-color: #3d3d3d;
                    color: #ffffff;
                    border: 1px solid #555555;
                }
                QPushButton#cancelButton:hover {
                    background-color: #4d4d4d;
                }
                QPushButton:disabled {
                    background-color: #2d2d2d;
                    color: #666666;
                }
            """)
        else:
            self.setStyleSheet("""
                QDialog {
                    background-color: #f5f5f5;
                    color: #333333;
                }
                QLabel {
                    color: #333333;
                }
                QGroupBox {
                    color: #333333;
                    border: 1px solid #e0e0e0;
                }
                QLineEdit, QComboBox, QPushButton {
                    background-color: #ffffff;
                    color: #333333;
                    border: 1px solid #cccccc;
                    padding: 6px 12px;
                    border-radius: 4px;
                }
                QPushButton {
                    background-color: #4a90e2;
                    color: white;
                    min-width: 90px;
                }
                QPushButton:hover {
                    background-color: #3a7bc8;
                }
                QPushButton#cancelButton {
                    background-color: #f0f0f0;
                    color: #333333;
                    border: 1px solid #cccccc;
                }
                QPushButton#cancelButton:hover {
                    background-color: #e0e0e0;
                }
                QPushButton:disabled {
                    background-color: #f5f5f5;
                    color: #999999;
                }
            """)
        
    def setup_ui(self):
        """Configure l'interface utilisateur de la boîte de dialogue."""
        self.setWindowTitle("Settings")
        set_window_icon(self, "settings")
        self.setMinimumWidth(450)        
        
        # Layout principal
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # En-tête
        header = QLabel("Settings of the application")
        header.setStyleSheet("""
            font-size: 16px;
            font-weight: 600;
            color: #2196F3;  /* Bleu plus clair pour un meilleur contraste */
            padding-bottom: 10px;
            border-bottom: 1px solid #e0e0e0;
            margin-bottom: 15px;
        """)
        layout.addWidget(header)
        
        # Formulaire des paramètres
        form_layout = QFormLayout()
        form_layout.setContentsMargins(5, 5, 5, 5)
        form_layout.setSpacing(15)
        
        # Section API Telegram
        telegram_section = QLabel("Telegram API Settings")
        telegram_section.setStyleSheet("""
            font-size: 14px;
            font-weight: 600;
            color: #2196F3;  /* Bleu plus clair pour la section API */
            margin-top: 5px;
        """)
        layout.addWidget(telegram_section)
        
        # Champs API ID
        self.api_id_edit = QLineEdit()
        self.api_id_edit.setPlaceholderText("Enter your API ID")
        self.api_id_edit.setToolTip("")
        # DÉSACTIVÉ TEMPORAIREMENT - Les tooltips pourraient créer des fenêtres blanches
        # self.api_id_edit.enterEvent = lambda e: self._show_tooltip("Identifiant d'API Telegram", self.api_id_edit)
        # self.api_id_edit.leaveEvent = lambda e: QToolTip.hideText()
        
        # Champs API Hash
        self.api_hash_edit = QLineEdit()
        self.api_hash_edit.setPlaceholderText("Enter your API Hash")
        self.api_hash_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_hash_edit.setToolTip("")
        # DÉSACTIVÉ TEMPORAIREMENT - Les tooltips pourraient créer des fenêtres blanches
        # self.api_hash_edit.enterEvent = lambda e: self._show_tooltip("Clé secrète d'API Telegram", self.api_hash_edit)
        # self.api_hash_edit.leaveEvent = lambda e: QToolTip.hideText()
        
        # Afficher/masquer le mot de passe
        self.show_password_btn = QPushButton()
        
        # Créer des labels pour les icônes avec style adaptatif
        self.eye_icon = QLabel("👁️")
        self.eye_slash_icon = QLabel("👁️‍🗨️")
        
        # Style pour les labels d'icônes
        icon_style = """
            QLabel {
                padding: 0;
                margin: 0;
                font-size: 16px;
                qproperty-alignment: AlignCenter;
                background: transparent;
                color: #ffffff;
            }
        """
        self.eye_icon.setStyleSheet(icon_style)
        self.eye_slash_icon.setStyleSheet(icon_style)
        
        # Créer un widget conteneur pour l'icône
        icon_container = QWidget()
        icon_layout = QHBoxLayout(icon_container)
        icon_layout.setContentsMargins(0, 0, 0, 0)
        icon_layout.addWidget(self.eye_slash_icon)
        
        # Configurer le bouton
        self.show_password_btn.setLayout(icon_layout)
        self.show_password_btn.setCheckable(True)
        self.show_password_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.show_password_btn.setToolTip("Show/Hide API Hash")
        
        # Stocker la référence au layout d'icônes pour le basculement
        self.icon_layout = icon_layout
        
        # Définir un ID pour le bouton pour le style CSS
        self.show_password_btn.setObjectName("visibilityButton")
        
        # Style par défaut (sera écrasé par apply_theme_style si nécessaire)
        self.show_password_btn.setStyleSheet("""
            QPushButton#visibilityButton {
                border: 1px solid #cccccc;
                border-radius: 4px;
                background: transparent;
                color: #495057;
                padding: 0;
                margin: 0;
                min-width: 30px;
                max-width: 30px;
                min-height: 30px;
                max-height: 30px;
                font-size: 16px;
            }
            QPushButton#visibilityButton:hover {
                background: #e9ecef;
                border-color: #adb5bd;
            }
            QPushButton#visibilityButton:pressed {
                background: #dee2e6;
            }
        """)
        self.show_password_btn.toggled.connect(self.toggle_password_visibility)
        
        # Layout pour le champ de mot de passe avec le bouton d'affichage
        password_layout = QHBoxLayout()
        password_layout.addWidget(self.api_hash_edit)
        password_layout.addWidget(self.show_password_btn)
        
        # Ajout des champs au formulaire
        form_layout.addRow("<b>API ID:</b>", self.api_id_edit)
        form_layout.addRow("<b>API Hash:</b>", password_layout)
        
        # Charger les valeurs actuelles
        self.load_current_values()
        
        # Boutons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)
        
        # Bouton Annuler
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.setObjectName("cancelButton")
        self.cancel_btn.clicked.connect(self.reject)
        
        # Bouton Enregistrer
        self.save_btn = QPushButton("Save")
        self.save_btn.setDefault(True)
        self.save_btn.clicked.connect(self.save_settings)
        
        # Ajout des boutons avec espacement
        button_layout.addStretch()
        button_layout.addWidget(self.cancel_btn)
        button_layout.addWidget(self.save_btn)
        
        # Définir les tailles minimales pour une apparence cohérente
        min_button_width = 100
        self.cancel_btn.setMinimumWidth(min_button_width)
        self.save_btn.setMinimumWidth(min_button_width)
        
        # Ajout des layouts au layout principal
        layout.addLayout(form_layout)
        layout.addStretch()
        layout.addLayout(button_layout)
        
        # Ajuster la taille de la fenêtre
        self.adjustSize()
    
    def _show_tooltip(self, text, widget):
        """Affiche une tooltip personnalisée pour un widget."""
        # DÉSACTIVÉ TEMPORAIREMENT - Les tooltips pourraient créer des fenêtres blanches
        return
        
        # Récupérer l'application et le thème actuel
        app = QApplication.instance()
        if app is None:
            return
        
        if hasattr(self.parent(), 'config') and hasattr(self.parent().config, 'config'):
            theme = self.parent().config.config.get('app', {}).get('theme', 'light')
            
        if theme == 'dark':
            app.setStyleSheet("""
                QToolTip {
                    color: #ffffff;
                    background-color: #424242;
                    border: 1px solid #555555;
                    padding: 5px;
                    border-radius: 3px;
                    font-size: 12px;
                }
            """)
        else:
            app.setStyleSheet("""
                QToolTip {
                    color: #212529;
                    background-color: #f8f9fa;
                    border: 1px solid #dee2e6;
                    padding: 5px;
                    border-radius: 3px;
                    font-size: 12px;
                }
            """)
        
        # Afficher le tooltip
        QToolTip.showText(
            widget.mapToGlobal(widget.rect().bottomLeft()),
            text,
            widget,
            QRect(),
            3000
        )
    
    def load_current_values(self):
        """Charge les valeurs actuelles depuis la configuration."""
        telegram_config = self.config.get_section('telegram', {})
        self.api_id_edit.setText(telegram_config.get('api_id', ''))
        self.api_hash_edit.setText(telegram_config.get('api_hash', ''))
    
    def toggle_password_visibility(self, checked):
        """Bascule la visibilité du mot de passe."""
        # Supprimer l'icône actuelle
        for i in reversed(range(self.icon_layout.count())): 
            self.icon_layout.itemAt(i).widget().setParent(None)
            
        # Ajouter la nouvelle icône
        if checked:
            self.api_hash_edit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.icon_layout.addWidget(self.eye_icon)
        else:
            self.api_hash_edit.setEchoMode(QLineEdit.EchoMode.Password)
            self.icon_layout.addWidget(self.eye_slash_icon)
    
    def validate_fields(self):
        """Valide les champs du formulaire."""
        if not self.api_id_edit.text().strip():
            QMessageBox.warning(self, "Required field", "Please enter a valid API ID.")
            self.api_id_edit.setFocus()
            return False
            
        if not self.api_hash_edit.text().strip():
            QMessageBox.warning(self, "Required field", "Please enter a valid API Hash.")
            self.api_hash_edit.setFocus()
            return False
            
        return True
    
    def save_settings(self):
        """Sauvegarde les paramètres modifiés."""
        if not self.validate_fields():
            return
            
        try:
            settings = {
                'telegram': {
                    'api_id': self.api_id_edit.text().strip(),
                    'api_hash': self.api_hash_edit.text().strip()
                }
            }
            
            # Émettre le signal avec les nouveaux paramètres
            self.settings_saved.emit(settings)
            
            # Fermer la boîte de dialogue
            self.accept()
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"An error occurred while saving the settings :\n{str(e)}",
                QMessageBox.StandardButton.Ok
            )
