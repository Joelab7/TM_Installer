"""Boîte de dialogue de connexion à Telegram."""
import asyncio
import logging
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, Union

import qasync
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtWidgets import (
    QApplication, QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, 
    QHBoxLayout, QStackedWidget, QWidget, QMessageBox
)

from ..core.telegram_client import TelegramClientWrapper

logger = logging.getLogger(__name__)

class LoginDialog(QDialog):
    """Boîte de dialogue pour la connexion à un compte Telegram."""
    
    login_success = pyqtSignal(dict)  # Émis lorsque la connexion réussit
    login_failed = pyqtSignal(str)    # Émis en cas d'échec de connexion
    
    def __init__(self, telegram_client: TelegramClientWrapper, parent=None):
        """Initialise la boîte de dialogue de connexion.
        
        Args:
            telegram_client: Instance du client Telegram
            parent: Widget parent
        """
        super().__init__(parent)
        self.telegram_client = telegram_client
        self.verification_in_progress = False
        self.phone = None
        self.failed_attempts = 0  # Compteur de tentatives échouées
        self.max_attempts = 5  # Nombre maximum de tentatives avant blocage
        
        # Gestionnaire de tâches pour éviter les fuites mémoire
        self._active_tasks = set()
        self._cleanup_timer = QTimer()
        self._cleanup_timer.timeout.connect(self._cleanup_tasks)
        self._cleanup_timer.start(5000)  # Nettoyer toutes les 5 secondes
        
        self.setWindowTitle("Connect to Telegram")
        self.setMinimumSize(450, 350)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowContextHelpButtonHint)
        
        # Configurer l'interface utilisateur
        self.setup_ui()
        
        # Configurer les signaux
        self.setup_connections()
        
        # Désactiver le bouton de fermeture
        self.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
    
    def setup_ui(self):
        """Configure l'interface utilisateur de la boîte de dialogue."""
        # Layout principal
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(30, 25, 30, 25)
        self.main_layout.setSpacing(20)
        
        # Title
        title_label = QLabel("Connect to Telegram")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_font = title_label.font()
        title_font.setPointSize(20)
        title_font.setBold(True)
        title_font.setFamily('Segoe UI')
        title_label.setFont(title_font)
        title_label.setStyleSheet("""
            color: #4a90e2;
            margin-bottom: 5px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e5e7eb;
        """)
        
        # Widget empilé pour les différentes étapes de connexion
        self.stacked_widget = QStackedWidget()
        
        # Étape 1: Saisie du numéro de téléphone
        self.phone_widget = self.create_phone_widget()
        
        # Étape 2: Saisie du code de vérification
        self.code_widget = self.create_code_widget()
        
        # Étape 3: Saisie du mot de passe 2FA
        self.password_widget = self.create_password_widget()
        
        # Ajouter les widgets à la pile
        self.stacked_widget.addWidget(self.phone_widget)
        self.stacked_widget.addWidget(self.code_widget)
        self.stacked_widget.addWidget(self.password_widget)
        
        # Message d'état
        self.status_label = QLabel()
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("color: #e74c3c; min-height: 40px;")
        
        # Boutons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)
        
        # Bouton Retour
        self.back_button = QPushButton("Back")
        self.back_button.setMinimumWidth(100)
        self.back_button.setMinimumHeight(35)
        
        # Bouton Annuler
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.setMinimumWidth(100)
        self.cancel_button.setMinimumHeight(35)
        
        # Bouton Suivant/Connexion/Valider
        self.next_button = QPushButton("Next")
        self.next_button.setMinimumWidth(120)
        self.next_button.setMinimumHeight(35)
        
        # Style des boutons
        button_style = """
            QPushButton {
                padding: 8px 15px;
                border-radius: 4px;
                font-weight: 500;
                font-size: 14px;
                min-width: 100px;
            }
            QPushButton:enabled {
                background-color: #4a90e2;
                color: white;
                border: 1px solid #3a7bc8;
            }
            QPushButton:enabled:hover {
                background-color: #3a7bc8;
                border: 1px solid #2a6bb0;
            }
            QPushButton:enabled:pressed {
                background-color: #2a6bb0;
                padding: 9px 14px 7px 16px;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
                border: 1px solid #bbbbbb;
            }
        """
        
        # Style spécifique pour le bouton Annuler
        cancel_style = """
            QPushButton {
                background-color: #f0f0f0;
                color: #333333;
                border: 1px solid #cccccc;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
                border: 1px solid #bbbbbb;
            }
            QPushButton:pressed {
                background-color: #d0d0d0;
            }
        """
        
        # Appliquer les styles
        self.back_button.setStyleSheet(button_style)
        self.next_button.setStyleSheet(button_style)
        self.cancel_button.setStyleSheet(button_style + cancel_style)
        
        # Ajout des boutons au layout
        button_layout.addWidget(self.back_button)
        button_layout.addStretch()
        button_layout.addWidget(self.cancel_button)
        button_layout.addWidget(self.next_button)
        
        # Assembler l'interface
        self.main_layout.addWidget(title_label)
        self.main_layout.addSpacing(10)
        self.main_layout.addWidget(self.stacked_widget)
        self.main_layout.addWidget(self.status_label)
        self.main_layout.addLayout(button_layout)
        
        # Configurer les boutons par défaut
        self.back_button.hide()
        self.next_button.setDefault(True)
        self.next_button.setFocus()
        
        # Désactiver le bouton suivant tant qu'aucun numéro n'est saisi
        self.next_button.setEnabled(False)
    
    def create_phone_widget(self) -> QWidget:
        """Crée le widget pour la saisie du numéro de téléphone."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(15)
        
        # Texte d'information
        info_label = QLabel("Please enter your phone number with the country code.")
        info_label.setWordWrap(True)
        info_label.setStyleSheet("""
            color: #4b5563;
            font-size: 13px;
            line-height: 1.4;
            margin-bottom: 5px;
        """)
        
        # Champ de saisie du numéro
        self.phone_edit = QLineEdit()
        self.phone_edit.setPlaceholderText("Ex: +1234567890")
        self.phone_edit.setMaxLength(20)
        self.phone_edit.textChanged.connect(self.on_phone_changed)
        
        # Style du champ de saisie
        self.phone_edit.setStyleSheet("""
            QLineEdit {
                padding: 12px 15px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-size: 14px;
                background-color: #ffffff;
                color: #1f2937;
                selection-background-color: #3b82f6;
                selection-color: #ffffff;
            }
            QLineEdit:focus {
                border: 2px solid #4a90e2;
                padding: 11px 14px;
                background-color: #f8fafc;
            }
            QLineEdit:disabled {
                background-color: #f3f4f6;
                color: #9ca3af;
            }
        """)
        
        # Add widgets
        layout.addWidget(info_label)
        layout.addWidget(QLabel("Phone number:"))
        layout.addWidget(self.phone_edit)
        layout.addStretch()
        
        return widget
    
    def create_code_widget(self) -> QWidget:
        """Crée le widget pour la saisie du code de vérification."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(15)
        
        # Texte d'information
        info_label = QLabel("A verification code has been sent to your Telegram account.")
        info_label.setWordWrap(True)
        info_label.setStyleSheet("color: #7f8c8d;")
        
        # Champ de saisie du code
        self.code_edit = QLineEdit()
        self.code_edit.setPlaceholderText("5 digit code")
        self.code_edit.setMaxLength(5)
        self.code_edit.textChanged.connect(self.on_code_changed)
        
        # Style du champ de saisie du code
        self.code_edit.setStyleSheet("""
            QLineEdit {
                padding: 12px 15px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-size: 18px;
                letter-spacing: 8px;
                font-family: 'Courier New', monospace;
                text-align: center;
                background-color: #ffffff;
                color: #1f2937;
                selection-background-color: #3b82f6;
                selection-color: #ffffff;
            }
            QLineEdit:focus {
                border: 2px solid #4a90e2;
                padding: 11px 14px;
                background-color: #f8fafc;
            }
            QLineEdit:disabled {
                background-color: #f3f4f6;
                color: #9ca3af;
            }
        """)
        
        # Bouton pour renvoyer le code
        self.resend_button = QPushButton("Resend code")
        self.resend_button.setStyleSheet("""
            QPushButton {
                color: #4a90e2;
                border: none;
                background: none;
                text-decoration: none;
                padding: 6px 10px;
                border-radius: 4px;
                font-size: 13px;
                min-width: 120px;
            }
            QPushButton:hover {
                color: #3a7bc8;
                background-color: rgba(74, 144, 226, 0.1);
                text-decoration: none;
            }
            QPushButton:pressed {
                color: #2a6bb0;
                background-color: rgba(74, 144, 226, 0.2);
            }
            QPushButton:disabled {
                color: #bdc3c7;
                background: none;
            }
        """)
        self.resend_button.clicked.connect(self.on_resend_code_clicked)
        
        # Compteur pour le renvoi du code
        self.resend_timer = QTimer()
        self.resend_timer.timeout.connect(self.update_resend_timer)
        self.resend_counter = 30  # 30 secondes avant de pouvoir renvoyer
        
        # Ajout des widgets
        layout.addWidget(info_label)
        layout.addWidget(QLabel("Verification code:"))
        layout.addWidget(self.code_edit)
        
        # Layout pour le bouton de renvoi
        resend_layout = QHBoxLayout()
        resend_layout.addStretch()
        resend_layout.addWidget(self.resend_button)
        layout.addLayout(resend_layout)
        
        layout.addStretch()
        
        return widget
    
    def create_password_widget(self) -> QWidget:
        """Crée le widget pour la saisie du mot de passe 2FA."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(15)
        
        # Texte d'information
        info_label = QLabel("Your account is protected by two-factor authentication.")
        info_label.setWordWrap(True)
        info_label.setStyleSheet("color: #7f8c8d;")
        
        # Champ de saisie du mot de passe
        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("Enter your 2FA password")
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_edit.textChanged.connect(self.on_password_changed)
        
        # Style du champ de saisie du mot de passe
        self.password_edit.setStyleSheet("""
            QLineEdit {
                padding: 12px 15px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-size: 14px;
                background-color: #ffffff;
                color: #1f2937;
                selection-background-color: #3b82f6;
                selection-color: #ffffff;
            }
            QLineEdit:focus {
                border: 2px solid #4a90e2;
                padding: 11px 14px;
                background-color: #f8fafc;
            }
            QLineEdit:disabled {
                background-color: #f3f4f6;
                color: #9ca3af;
            }
        """)
        
        # Ajout des widgets
        layout.addWidget(info_label)
        layout.addWidget(QLabel("2FA password:"))
        layout.addWidget(self.password_edit)
        layout.addStretch()
        
        return widget
        
    def setup_connections(self):
        """Configure les connexions des signaux et des slots."""
        self.back_button.clicked.connect(self.on_back_clicked)
        self.next_button.clicked.connect(self.on_next_clicked)
        self.cancel_button.clicked.connect(self.reject)
        
        # Connexions pour la navigation au clavier
        self.phone_edit.returnPressed.connect(self.on_next_clicked)
        self.code_edit.returnPressed.connect(self.on_next_clicked)
        self.password_edit.returnPressed.connect(self.on_next_clicked)
    
    def is_valid_phone_number(self, phone):
        """Vérifie si le numéro de téléphone a un format valide.
        
        Args:
            phone (str): Le numéro de téléphone à valider
            
        Returns:
            tuple: (bool, str) - (True, '') si valide, (False, message_erreur) sinon
        """
        phone = phone.strip()
        
        # Vérifier si le numéro commence par un +
        if not phone.startswith('+'):
            return False, "The number must start with a '+' followed by the country code"
            
        # Vérifier que le reste ne contient que des chiffres
        if not phone[1:].isdigit():
            return False, "The number must contain only digits after the '+'. Ex: +1234567890"
            
        # Vérifier la longueur (entre 10 et 15 chiffres, sans compter le +)
        if len(phone) < 10 or len(phone) > 16:  # + suivi de 9 à 15 chiffres
            return False, "The number must contain between 9 and 15 digits (without counting the '+')"
            
        # Vérifier le code pays (les codes pays commencent par 1 à 9)
        if len(phone) > 1 and not phone[1].isdigit() or phone[1] == '0':
            return False, "The country code must start with a digit between 1 and 9"
            
        return True, ""
    
    def on_phone_changed(self, text):
        """Appelé lorsque le texte du champ téléphone change."""
        # Valider le format du numéro de téléphone
        is_valid, _ = self.is_valid_phone_number(text)
        self.next_button.setEnabled(is_valid)
        
        # Effacer les messages d'erreur précédents si le champ est vide
        if not text.strip():
            self.clear_status()
    
    def on_code_changed(self, text):
        """Appelé lorsque le texte du champ code change."""
        # Valider le format du code (5 chiffres)
        is_valid = len(text.strip()) == 5 and text.strip().isdigit()
        self.next_button.setEnabled(is_valid)
    
    def on_password_changed(self, text):
        """Appelé lorsque le texte du champ mot de passe change."""
        # Activer le bouton suivant si le mot de passe n'est pas vide
        self.next_button.setEnabled(bool(text.strip()))
    
    def on_back_clicked(self):
        """Appelé lorsque l'utilisateur clique sur le bouton Retour."""
        current_index = self.stacked_widget.currentIndex()
        if current_index > 0:
            self.stacked_widget.setCurrentIndex(current_index - 1)
            self.update_navigation_buttons()
    
    @qasync.asyncSlot()
    async def on_next_clicked(self):
        """Appelé lorsque l'utilisateur clique sur le bouton Suivant."""
        logger.debug("Next button clicked")
        current_index = self.stacked_widget.currentIndex()
        logger.debug(f"Current index of stacked widget: {current_index}")
        
        # Désactiver le bouton pour éviter les clics multiples
        self.next_button.setEnabled(False)
        
        try:
            if current_index == 0:  # Écran de numéro de téléphone
                logger.debug("Sending verification code...")
                success = await self.send_verification_code_async()
                if not success:
                    self.next_button.setEnabled(True)  # Réactiver le bouton en cas d'échec
            elif current_index == 1:  # Écran de code de vérification
                logger.debug("Verifying code...")
                await self.verify_code()
            elif current_index == 2:  # Écran de mot de passe 2FA
                logger.debug("Verifying 2FA...")
                await self.verify_2fa()
        except Exception as e:
            logger.exception("Error processing Next action")
            self.show_status(f"Error: {str(e)}", True)
            self.next_button.setEnabled(True)  # Réactiver le bouton en cas d'erreur
    
    @qasync.asyncSlot()
    async def on_resend_code_clicked(self):
        """Appelé lorsque l'utilisateur clique sur 'Renvoyer le code'."""
        logger.debug("Resend code button clicked")
        if not self.phone:
            logger.warning("No phone number available for code resend")
            return
            
        try:
            # Désactiver le bouton pendant l'envoi
            self.resend_button.setEnabled(False)
            self.resend_button.setText("Sending in progress...")
            
            # Appeler directement la méthode asynchrone
            await self.send_verification_code_async()
            
            # Réinitialiser le compteur après l'envoi réussi
            self.resend_counter = 30
            self.resend_button.setEnabled(False)  # Le minuteur le réactivera
            self.resend_timer.start(1000)
            logger.debug("Verification code resent successfully")
            
        except Exception as e:
            logger.exception("Error resending verification code")
            self.show_status(f"Error: Impossible to resend code: {str(e)}", True)
            # Réactiver le bouton en cas d'erreur
            self.resend_button.setEnabled(True)
            self.resend_button.setText("Resend code")
    
    def update_resend_timer(self):
        """Update the resend timer for the code resend button."""
        self.resend_counter -= 1
        if self.resend_counter <= 0:
            self.resend_timer.stop()
            self.resend_button.setEnabled(True)
            self.resend_button.setText("Resend code")
            self.resend_counter = 30  # Reset the counter
        else:
            self.resend_button.setText(f"Resend code ({self.resend_counter}s)")
    
    def _add_task(self, task: asyncio.Task) -> None:
        """Ajoute une tâche au suivi pour éviter les fuites mémoire."""
        self._active_tasks.add(task)
        task.add_done_callback(self._active_tasks.discard)

    def _cleanup_tasks(self) -> None:
        """Nettoie les tâches terminées pour éviter les fuites mémoire."""
        # Cette méthode est appelée périodiquement par le timer
        pass

    def _cancel_all_tasks(self) -> None:
        """Annule toutes les tâches actives."""
        for task in self._active_tasks.copy():
            if not task.done():
                task.cancel()
        self._active_tasks.clear()
    
    def show_status(self, message: str, is_error: bool = False):
        """Affiche un message d'état."""
        color = "#e74c3c" if is_error else "#27ae60"
        self.status_label.setStyleSheet(f"color: {color}; min-height: 40px;")
        self.status_label.setText(message)
    
    def clear_status(self):
        """Efface le message d'état."""
        self.status_label.clear()
    
    async def send_verification_code_async(self):
        """Envoie le code de vérification de manière asynchrone.
        
        Returns:
            bool: True si le code a été envoyé avec succès, False sinon
        """
        logger.debug("Start of send_verification_code_async")
        self.phone = self.phone_edit.text().strip()
        logger.debug(f"Phone number entered: {self.phone}")
        
        # Validate phone number format
        is_valid, error_msg = self.is_valid_phone_number(self.phone)
        if not is_valid:
            self.show_status(f"Invalid phone number format: {error_msg}", True)
            self.phone_edit.setFocus()
            self.phone_edit.selectAll()
            return False
        
        # Disable controls during verification
        self.set_controls_enabled(False)
        self.show_status("Verification of the session...", False)
        
        try:
            # Check if the user is already connected with this number
            if await self.telegram_client.is_user_authorized():
                logger.info("User is already connected, retrieving information...")
                await self._get_user_info_and_emit_success()
                return True
                
            # If we get here, the user is not connected, we send the code
            self.show_status("Sending verification code...", False)
            
            try:
                # Create a task with a timeout of 60 seconds
                send_code_task = asyncio.create_task(self.telegram_client.send_code(self.phone))
                self._add_task(send_code_task)  # Suivre la tâche
                
                # Wait for the task with a timeout
                try:
                    logger.debug("Calling telegram_client.send_code with timeout of 60 seconds...")
                    result = await asyncio.wait_for(send_code_task, timeout=60.0)
                    logger.debug(f"Result of send_code: {result}")
                    
                    # Check if the result is an error string
                    if isinstance(result, str) and any(keyword in result.lower() for keyword in ['phone number is invalid', 'phonenumberinvalid']):
                        error_msg = (
                            "The phone number is invalid according to Telegram. "
                            "Please verify the number and try again.\n"
                            "Make sure to include the country code (e.g., +1 for USA)."
                        )
                        self.show_status(error_msg, True)
                        self.set_controls_enabled(True)
                        self.phone_edit.setFocus()
                        self.phone_edit.selectAll()
                        return False
                        
                    # If the result is not True, it's an unhandled error
                    if result is not True:
                        raise ValueError(f"{result}")
                        
                except asyncio.TimeoutError:
                    logger.warning("Timeout while sending code - cancelling task")
                    if not send_code_task.done():
                        send_code_task.cancel()
                    self.show_status(
                        "The timeout for sending the code has been exceeded. "
                        "Please check your connection and try again.",
                        True
                    )
                    self.set_controls_enabled(True)
                    self.phone_edit.setFocus()
                    self.phone_edit.selectAll()
                    return False
                
                except asyncio.CancelledError:
                    logger.debug("Send code task was cancelled")
                    if not send_code_task.done():
                        send_code_task.cancel()
                    return False
                
                if result is True:
                    # Code envoyé avec succès, passer à l'écran de saisie du code
                    self.phone_code_hash = self.telegram_client.phone_code_hash
                    
                    # Activer les contrôles avant de changer d'écran
                    self.set_controls_enabled(True)
                    
                    # Changer d'écran
                    self.stacked_widget.setCurrentIndex(1)
                    
                    # Configurer l'interface pour la saisie du code
                    self.code_edit.setEnabled(True)
                    self.code_edit.setFocus()
                    self.clear_status()
                    
                    # Démarrer le minuteur pour le renvoi de code
                    self.resend_counter = 30
                    self.resend_button.setEnabled(False)
                    self.resend_timer.start(1000)
                    
                    logger.debug("Code sent successfully, moving to code screen")
                    return True
                    
                
            except Exception as e:
                error_msg = str(e)
                logger.error(f"Error sending code: {error_msg}")
                
                # Check error type
                if any(keyword in error_msg.lower() for keyword in ['flood', 'too many attempts']):
                    # Handle flood wait error
                    import re
                    wait_match = re.search(r'(\d+)', error_msg)
                    wait_seconds = int(wait_match.group(1)) if wait_match else 300  # Default to 5 minutes
                    
                    # Convertir en minutes pour l'affichage
                    wait_minutes = max(1, (wait_seconds + 59) // 60)  # Arrondir à la minute supérieure
                    
                    # Afficher un message d'erreur plus convivial
                    friendly_msg = (
                        f"Too many attempts to connect. Please wait {wait_minutes} "
                        f"minute(s) before trying again."
                    )
                    self.show_status(friendly_msg, True)
                    
                    # Réactiver les contrôles après le délai
                    async def reenable_after_delay():
                        try:
                            await asyncio.sleep(wait_seconds)
                            if self.phone_edit:  # Vérifier que le widget existe toujours
                                self.set_controls_enabled(True)
                                self.show_status("You can now try again.", False)
                                self.phone_edit.setFocus()
                        except Exception as e:
                            logger.error(f"Error reactivating controls: {e}")
                        
                    asyncio.create_task(reenable_after_delay())
                    
                # Gestion des erreurs de numéro invalide (au cas où l'erreur est levée comme une exception)
                elif any(keyword in error_msg.lower() for keyword in ['phone number is invalid', 'phonenumberinvalid']):
                    error_msg = (
                        "The phone number is invalid. "
                        "Please verify the number and try again.\n"
                        "Make sure to include the country code (e.g., +1 for USA)."
                    )
                    self.show_status(error_msg, True)
                    self.set_controls_enabled(True)
                    self.phone_edit.setFocus()
                    self.phone_edit.selectAll()
                    return False
                   
                # Gestion spécifique des erreurs de limite d'envoi de code Telegram
                elif any(keyword in error_msg.lower() for keyword in ['all available options', 'returned when all available options', 'no more options']):
                    user_friendly_msg = (
                        "Telegram has exhausted all available methods of sending verification codes for this number. "
                        "This can happen after several close attempts.\\n\\n"
                        "Recommended solutions:\\n"
                        "• Wait at least 1 hour before retrying\\n"
                        "• Use a temporary alternative phone number\\n"
                        "• Contact Telegram support if the problem persists"
                    )
                    self.show_status(user_friendly_msg, True)
                    self.set_controls_enabled(True)
                    self.phone_edit.setFocus()
                    self.phone_edit.selectAll()
                    return False

                # Other errors
                else:
                    user_friendly_msg = (
                        "Unable to send the verification code. "
                        f"Error: {error_msg}"
                    )
                    self.show_status(user_friendly_msg, True)
                    self.set_controls_enabled(True)
                    self.phone_edit.setFocus()
                    self.phone_edit.selectAll()
                
                return False
                
        except Exception as e:
            logger.exception("Unexpected error while sending verification code")
            self.show_status(f"Unexpected error: {str(e)}", True)
            return False
            
        finally:
            # Do not reactivate controls here as it could interfere with the flood wait delay
            pass
    
    @qasync.asyncSlot()
    async def send_verification_code(self):
        """Lance l'envoi du code de vérification de manière asynchrone."""
        logger.debug("Starting send_verification_code")
        code = self.code_edit.text().strip()
        if not code:
            self.show_status("Please enter a verification code", True)
            return
            self.set_controls_enabled(True)
            logger.debug("Vérification du code terminée")

    @qasync.asyncSlot()
    async def verify_code(self):
        """Launch code verification asynchronously."""
        logger.debug("Starting verify_code")
        try:
            success = await self.verify_code_async()
            # Vérifier si l'utilisateur est connecté avant de réactiver le bouton
            is_authorized = await self.telegram_client.is_user_authorized()
            if not success and not is_authorized:
                # Réactiver le bouton suivant uniquement si la vérification a échoué 
                # et que l'utilisateur n'est pas déjà connecté
                self.next_button.setEnabled(True)
            logger.debug("Code verification completed")
        except Exception as e:
            logger.exception("Error verifying code")
            # Vérifier si l'utilisateur est connecté avant d'afficher un message d'erreur
            is_authorized = await self.telegram_client.is_user_authorized()
            if not is_authorized:
                self.show_status(f"Error: {str(e)}", True)
                self.next_button.setEnabled(True)  # Réactiver le bouton en cas d'erreur
            else:
                logger.info("The user is already connected despite the error, continuing with the process...")

    async def verify_code_async(self):
        """
        Vérifie le code de manière asynchrone.
        
        Returns:
            bool: True if the verification is successful or if 2FA is required, False otherwise
        """
        code = self.code_edit.text().strip()
        logger.debug(f"Starting code verification: {code}")
        
        # Disable controls during verification
        self.set_controls_enabled(False)
        self.show_status("Verifying code...", False)
        
        try:
            # Vérifier d'abord si l'utilisateur est déjà connecté
            if await self.telegram_client.is_user_authorized():
                logger.info("The user is already connected, retrieving information...")
                await self._get_user_info_and_emit_success()
                return True
                
            # Try to connect with the code
            logger.debug("Trying to connect with the code...")
            
            try:
                # Utiliser asyncio.wait_for avec un timeout pour éviter de bloquer indéfiniment
                sign_in_task = asyncio.create_task(self.telegram_client.sign_in(code))
                self._add_task(sign_in_task)  # Suivre la tâche
                
                result = await asyncio.wait_for(sign_in_task, timeout=30)  # Timeout de 30 secondes
                
                # Donner le temps à l'interface de se mettre à jour
                await asyncio.sleep(0.1)
                
                if result is True:
                    # Connection successful without 2FA
                    logger.info("Connection successful without 2FA")
                    await self._get_user_info_and_emit_success()
                    return True
                    
                elif result == "2FA_NEEDED":
                    # 2FA required - use call_soon_threadsafe for UI updates
                    logger.info("2FA authentication required")
                    self.requires_2fa = True
                    
                    # Clear any previous error messages before transitioning to 2FA
                    self.clear_status()

                    
                    # Ne pas vérifier is_2fa_enabled ici car il peut y avoir un faux négatif
                    # à cause des limitations de l'API Telegram
                    
                    # Utiliser call_soon_threadsafe pour les mises à jour de l'interface
                    def update_ui():
                        try:
                            self.stacked_widget.setCurrentIndex(2)  # Aller à l'écran du mot de passe
                            self.password_edit.setEnabled(True)
                            self.password_edit.setFocus()
                            self.password_edit.selectAll()
                            
                            # Display an informative message about 2FA (not an error)
                            self.show_status("Please enter your 2FA password", False)
                        except Exception as e:
                            logger.error(f"Error updating 2FA interface: {e}")
                    
                    # Schedule interface update in GUI thread
                    QApplication.instance().processEvents()
                    asyncio.get_event_loop().call_soon_threadsafe(update_ui)
                    
                    # Donner le temps à l'interface de se mettre à jour
                    await asyncio.sleep(0.2)
                    
                    # Vérifier si l'utilisateur est finalement connecté
                    # (parfois la connexion peut réussir même avec 2FA si le code était un mot de passe à usage unique)
                    if await self.telegram_client.is_user_authorized():
                        logger.info("The user is now connected after 2FA")
                        await self._get_user_info_and_emit_success()
                        return True
                        
                    return True
                    
                else:
                    # Code incorrect or other error
                    error_msg = str(result) if result else ""
                    logger.warning(f"Code verification failed: {error_msg}")
                    
                    # Handle specific known errors
                    if "flood" in error_msg.lower():
                        # Try to extract the wait time
                        wait_match = re.search(r'(\d+)', error_msg)
                        wait_seconds = int(wait_match.group(1)) if wait_match else 30
                        
                        # Afficher un message d'attente avec un compte à rebours
                        await self.show_wait_message(wait_seconds)
                        return False
                    
                    # Vérifier d'abord si l'utilisateur est connecté malgré l'erreur
                    is_authorized = await self.telegram_client.is_user_authorized()
                    if is_authorized:
                        logger.info("The user is connected despite the error message, continuing the process...")
                        await self._get_user_info_and_emit_success()
                        return True
                        
                    # Messages d'erreur plus conviviaux
                    if "phone code invalid" in error_msg.lower() or "invalid code" in error_msg.lower():
                        user_msg = "The code you entered is incorrect. Please try again."
                    elif "phone code expired" in error_msg.lower():
                        user_msg = "The code has expired. Please request a new code."
                    elif "phone code empty" in error_msg.lower():
                        user_msg = "Please enter a verification code."
                    else:
                        # Journaliser l'erreur complète pour le débogage
                        logger.warning(f"invalid code: {error_msg}")
                        user_msg = "The code you entered is incorrect. Please try again."
                    
                    # Pour les autres erreurs, afficher le message d'erreur
                    def show_error():
                        # Vérifier une dernière fois si l'utilisateur est connecté
                        if not self.telegram_client.is_connected():
                            self.show_status(user_msg, True)
                            self.code_edit.selectAll()
                            self.code_edit.setFocus()
                            self.set_controls_enabled(True)
                        else:
                            # If the user is now connected, do not display an error message
                            logger.debug("The user is connected, no error message displayed")
                    
                    QApplication.instance().processEvents()
                    asyncio.get_event_loop().call_soon_threadsafe(show_error)
                    return False
                    
            except asyncio.TimeoutError:
                error_msg = "Connection timeout. Please check your connection and try again."
                logger.error(error_msg)
                
                def show_timeout_error():
                    self.show_status(error_msg, True)
                    self.set_controls_enabled(True)
                    self.code_edit.setFocus()
                
                QApplication.instance().processEvents()
                asyncio.get_event_loop().call_soon_threadsafe(show_timeout_error)
                return False
                
            except asyncio.CancelledError:
                logger.debug("Sign in task was cancelled")
                if not sign_in_task.done():
                    sign_in_task.cancel()
                    return False
                
        except Exception as e:
            logger.exception("Unexpected error in verify_code_async method")
            
            # Vérifier si l'utilisateur est déjà connecté avant d'afficher l'erreur
            is_authorized = await self.telegram_client.is_user_authorized()
            if not is_authorized:
                def show_unexpected_error():
                    self.show_status("An unexpected error occurred. Please try again.", True)
                    self.set_controls_enabled(True)
                
                QApplication.instance().processEvents()
                asyncio.get_event_loop().call_soon_threadsafe(show_unexpected_error)
            return False
            
        finally:
            # Toujours réactiver les contrôles à la fin
            def enable_controls():
                self.set_controls_enabled(True)
            
            loop = asyncio.get_event_loop()
            loop.call_soon_threadsafe(enable_controls)

    async def verify_password_async(self):
        """
        Vérifie le mot de passe 2FA de manière asynchrone avec gestion améliorée des erreurs.

        Returns:
            Union[bool, str]:
                - True si la vérification est réussie
                - str: Message d'erreur en cas d'échec ou 'flood_wait:seconds' si un délai est requis
        """
        password = self.password_edit.text().strip()
        if not password:
            await self.update_ui(
                status="Please enter your 2FA password",
                is_error=True,
                focus_field="password_edit"
            )
            return "Please enter your 2FA password"

        try:
            logger.info("Verifying 2FA password...")
            await self.update_ui(
                enable_controls=False,
                status="Verifying 2FA password...",
                is_error=False
            )

            # Vérifier d'abord si l'utilisateur est déjà connecté (au cas où)
            if await self.telegram_client.is_user_authorized():
                logger.info("The user is already connected, no need to verify the password")
                return True

            # Utiliser un timeout pour éviter de bloquer indéfiniment
            try:
                # Essayer de se connecter avec le mot de passe 2FA
                result = await asyncio.wait_for(
                    self.telegram_client.check_2fa_password(password),
                    timeout=30  # 30 secondes de timeout
                )
                
                if result:
                    logger.info("2FA password verified successfully")
                    # Vérifier une dernière fois que l'utilisateur est bien connecté
                    if await self.telegram_client.is_user_authorized():
                        return True
                    else:
                        logger.warning("2FA verification failed: incorrect password.")
                        error_msg = "Incorrect 2FA password."
                        await self.update_ui(
                            status=error_msg,
                            is_error=True,
                            enable_controls=True
                        )
                        return error_msg
                else:
                    logger.warning("2FA verification failed: incorrect password")
                    error_msg = "Incorrect 2FA password"
                    await self.update_ui(
                        status=error_msg,
                        is_error=True,
                        focus_field="password_edit"
                    )
                    return error_msg

            except asyncio.TimeoutError:
                error_msg = "Connection timeout. Please try again."
                logger.error("Connection timeout during 2FA verification")
                await self.update_ui(
                    status=error_msg,
                    is_error=True,
                    enable_controls=True
                )
                return error_msg

            except Exception as e:
                error_msg = str(e).lower()
                logger.exception("Unexpected error in verify_password_async method")
                
                # Gestion des erreurs spécifiques
                if "flood" in error_msg:
                    wait_match = re.search(r'(\d+)', error_msg)
                    wait_seconds = int(wait_match.group(1)) if wait_match else 30
                    logger.warning(f"Flood wait required: {wait_seconds} seconds")
                    
                    # Formater le message d'attente
                    if wait_seconds > 60:
                        minutes = wait_seconds // 60
                        wait_msg = f"Too many attempts. Please wait {minutes} minutes before trying again."
                    else:
                        wait_msg = f"Too many attempts. Please wait {wait_seconds} seconds before trying again."
                    
                    await self.update_ui(
                        status=wait_msg,
                        is_error=True,
                        enable_controls=True
                    )
                    return f"flood_wait:{wait_seconds}"
                    
                # Gestion des erreurs de mot de passe invalide
                if "password" in error_msg and "invalid" in error_msg:
                    user_msg = "The password you entered is incorrect. Please try again."
                    await self.update_ui(
                        status=user_msg,
                        is_error=True,
                        focus_field="password_edit"
                    )
                    return user_msg
                    
                # Gestion des trop nombreuses tentatives
                if "attempt" in error_msg and "too many" in error_msg:
                    user_msg = "Too many failed attempts. Please wait before trying again."
                    await self.update_ui(
                        status=user_msg,
                        is_error=True,
                        enable_controls=True
                    )
                    return user_msg
                    
                if "auth_key" in error_msg and "invalid" in error_msg:
                    error_msg = "Invalid session. Please restart the application."
                    await self.update_ui(
                        status=error_msg,
                        is_error=True,
                        enable_controls=True
                    )
                    return error_msg
                    
                if "network" in error_msg or "connection" in error_msg:
                    error_msg = "Connection error. Please check your Internet connection."
                    await self.update_ui(
                        status=error_msg,
                        is_error=True,
                        enable_controls=True
                    )
                    return error_msg
                    
                # For other types of errors, use a generic message
                error_msg = "An error occurred during verification. Please try again."
                await self.update_ui(
                    status=error_msg,
                    is_error=True,
                    enable_controls=True
                )
                return error_msg
                
        except asyncio.CancelledError:
            logger.debug("2FA verification cancelled")
            await self.update_ui(
                enable_controls=True,
                status="Verification cancelled",
                is_error=True
            )
            return "Verification cancelled"
            
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.exception("Unexpected error during 2FA verification")
            await self.update_ui(
                status=error_msg,
                is_error=True,
                enable_controls=True
            )
            return error_msg
            
        finally:
            # Vérifier si l'utilisateur est maintenant authentifié
            try:
                is_authorized = await self.telegram_client.is_user_authorized()
                if not is_authorized:
                    await self.update_ui(enable_controls=True)
                else:
                    # Désactiver le bouton Suivant si l'utilisateur est authentifié
                    def disable_next_button():
                        self.next_button.setEnabled(False)
                    loop = asyncio.get_event_loop()
                    loop.call_soon_threadsafe(disable_next_button)
            except Exception as e:
                logger.error(f"Error during authorization verification: {e}")
                await self.update_ui(enable_controls=True)
                return f"Error during authorization verification: {e}"

    @qasync.asyncSlot()
    async def _get_user_info_and_emit_success(self):
        """
        Retrieves user information and emits the success signal.
        
        Cette méthode est appelée après une authentification réussie pour récupérer
        les informations de l'utilisateur connecté et fermer la boîte de dialogue.
        """
        try:
            logger.debug("Retrieving user information...")
            
            # Récupérer les informations utilisateur directement via le client
            user = await self.telegram_client.client.get_me()
            if not user:
                error_msg = "No user information returned"
                logger.error(error_msg)
                self.login_failed.emit(error_msg)
                return
                
            # Build the user information dictionary
            user_info = {
                'id': str(getattr(user, 'id', '')),
                'first_name': getattr(user, 'first_name', ''),
                'last_name': getattr(user, 'last_name', ''),
                'username': getattr(user, 'username', ''),
                'phone': getattr(user, 'phone', self.phone or '')
            }
            
            # Utiliser le numéro de téléphone de l'instance si non fourni par l'API
            if not user_info['phone'] and self.phone:
                user_info['phone'] = self.phone
            
            # Vérifier que l'ID est présent (champ obligatoire)
            if not user_info['id']:
                error_msg = "Unable to retrieve user ID"
                logger.error(error_msg)
                self.login_failed.emit(error_msg)
                return
                
            # Journalisation des informations récupérées (sans affichage à l'utilisateur)
            logger.debug("User information retrieved successfully")
            
            # Émettre le signal de succès avec les informations utilisateur
            self.login_success.emit(user_info)
            
            # Fermer la boîte de dialogue
            self.accept()
            
        except Exception as e:
            error_msg = f"Error during user information retrieval: {str(e)}"
            logger.exception(error_msg)
            self.login_failed.emit("An error occurred during login. Please try again.")
    
    def format_wait_time(self, seconds: int) -> str:
        """Formate le temps d'attente en minutes et secondes."""
        if seconds < 60:
            return f"{seconds} seconds"
        minutes = seconds // 60
        remaining_seconds = seconds % 60
        return f"{minutes} minute{'s' if minutes > 1 else ''} and {remaining_seconds} second{'s' if remaining_seconds != 1 else ''}"

    def show_wait_message(self, seconds: int):
        """Affiche un message d'attente avec un compte à rebours."""
        self.wait_timer = QTimer()
        self.wait_timer.timeout.connect(lambda: self.update_wait_message(seconds))
        self.wait_timer.start(1000)  # Mise à jour toutes les secondes
        self.update_wait_message(seconds)

    def update_wait_message(self, remaining_seconds: int):
        """Met à jour le message d'attente avec le temps restant."""
        # Nettoyer l'ancien timer s'il existe
        if hasattr(self, 'wait_timer'):
            self.wait_timer.stop()
            self.wait_timer.deleteLater()
            delattr(self, 'wait_timer')
        
        if remaining_seconds <= 0:
            self.show_status("You can now try again.", False)
            self.set_controls_enabled(True)
            return
            
        # Afficher le temps restant
        wait_time = self.format_wait_time(remaining_seconds)
        self.show_status(f"Too many failed attempts. Please wait {wait_time}...", True)
        
        # Créer un nouveau timer pour la prochaine mise à jour
        self.wait_timer = QTimer()
        self.wait_timer.setSingleShot(True)
        self.wait_timer.timeout.connect(lambda: self.update_wait_message(remaining_seconds - 1))
        self.wait_timer.start(1000)

    @qasync.asyncSlot()
    async def verify_2fa(self):
        """
        Vérifie le mot de passe 2FA et gère le résultat de la vérification.
        Gère également les erreurs et les délais d'attente en cas de trop de tentatives.
        """
        # Vérifier si une vérification est déjà en cours
        if getattr(self, '_verification_in_progress', False):
            logger.debug("2FA verification already in progress, new attempt ignored")
            return
            
        # Initialiser les états
        self._verification_in_progress = True
        self._2fa_attempts = getattr(self, '_2fa_attempts', 0) + 1
        
        try:
            # Vérifier que le mot de passe n'est pas vide
            password = self.password_edit.text().strip()
            if not password:
                await self.update_ui(
                    status="Please enter your 2FA password",
                    is_error=True,
                    focus_field=self.password_edit,
                    enable_controls=True
                )
                return
                
            # Désactiver les contrôles pendant la vérification
            await self.update_ui(
                enable_controls=False,
                status="Verifying 2FA password...",
                is_error=False
            )
            
            # Donner un peu de temps à l'interface pour se mettre à jour
            await asyncio.sleep(0.1)
            
            # Lancer la vérification du mot de passe de manière asynchrone
            result = await self.verify_password_async()
            
            # Gérer le résultat de la vérification
            if result is True:
                # Connexion réussie - réinitialiser le compteur d'essais
                self._2fa_attempts = 0
                logger.info("2FA verification successful, retrieving user information...")
                await self._get_user_info_and_emit_success()
                return
                
            # Gérer le cas d'un délai d'attente (flood wait)
            if isinstance(result, str) and result.startswith("flood_wait:"):
                try:
                    # Extraire le temps d'attente en secondes
                    wait_seconds = int(result.split(":")[1])
                    logger.warning(f"Too many failed attempts. Waiting for {wait_seconds} seconds...")
                    await self.show_wait_message(wait_seconds)
                    return
                except (IndexError, ValueError) as e:
                    logger.error(f"Error parsing wait time: {e}")
                    error_msg = "Error waiting. Please try again."
                    
                    await self.update_ui(
                        status=error_msg,
                        is_error=True,
                        focus_field=self.password_edit,
                        select_text=True,
                        enable_controls=True
                    )
                    return
            else:
                # Afficher le message d'erreur avec le nombre d'essais
                error_msg = str(result) if result else "Invalid 2FA password"
                remaining = max(0, 3 - self._2fa_attempts)
                
                # Formater le message d'erreur de manière plus claire
                if remaining > 0:
                    error_msg = f"{error_msg} (Attempt {self._2fa_attempts}/3 - {remaining} attempt{'s' if remaining > 1 else ''} remaining)"
                else:
                    error_msg = f"{error_msg} (Attempt {self._2fa_attempts}/3)"
                
                # Si trop de tentatives, bloquer temporairement
                if self._2fa_attempts >= 3:
                    wait_seconds = 30  # 30 secondes de blocage
                    logger.warning(f"Too many failed attempts. Blocking for {wait_seconds} seconds")
                    await self.show_wait_message(wait_seconds)
                    self._2fa_attempts = 0  # Réinitialiser après le blocage
                else:
                    # Réactiver les contrôles et afficher l'erreur
                    await self.update_ui(
                        status=error_msg,
                        is_error=True,
                        focus_field=self.password_edit,
                        select_text=True,
                        enable_controls=True
                    )
                    
        except Exception as e:
            logger.exception("An unexpected error occurred in verify_2fa")
            
            # Message d'erreur plus convivial pour l'utilisateur
            error_msg = "An unexpected error occurred"
            if "password" in str(e).lower() or "password" in str(e).lower():
                error_msg = "Invalid 2FA password"
            elif "network" in str(e).lower() or "network" in str(e).lower():
                error_msg = "Network error. Please check your internet connection"
                
            await self.update_ui(
                status=f"{error_msg}. Please try again.",
                is_error=True,
                enable_controls=True,
                focus_field=self.password_edit,
                select_text=True
            )
            
        finally:
            # Toujours réactiver les contrôles et remettre le focus
            self._verification_in_progress = False
            
            # S'assurer que les contrôles sont réactivés et que le focus est sur le champ de mot de passe
            try:
                await self.update_ui(
                    enable_controls=True,
                    focus_field=self.password_edit,
                    select_text=True
                )
            except Exception as e:
                logger.error(f"Error while re-enabling controls: {e}")
                # Si update_ui échoue, essayer de réactiver les contrôles manuellement
                try:
                    self.set_controls_enabled(True)
                    self.password_edit.setFocus()
                    self.password_edit.selectAll()
                except Exception as e2:
                    logger.error(f"Error while manually re-enabling controls: {e2}")
                    
            # Nettoyer le mot de passe pour des raisons de sécurité
            self.password_edit.clear()

    @qasync.asyncSlot()
    async def _get_user_info_and_emit_success(self):
        """
        Récupère les informations utilisateur et émet le signal de succès.
        
        Cette méthode est appelée après une authentification réussie pour récupérer
        les informations de l'utilisateur connecté et fermer la boîte de dialogue.
        """
        try:
            logger.debug("Retrieving user information...")
            
            # Récupérer les informations utilisateur directement via le client
            user = await self.telegram_client.client.get_me()
            if not user:
                error_msg = "No user information returned"
                logger.error(error_msg)
                self.login_failed.emit(error_msg)
                return
                
            # Construire le dictionnaire des informations utilisateur
            user_info = {
                'id': str(getattr(user, 'id', '')),
                'first_name': getattr(user, 'first_name', ''),
                'last_name': getattr(user, 'last_name', ''),
                'username': getattr(user, 'username', ''),
                'phone': getattr(user, 'phone', self.phone or '')
            }
            
            # Utiliser le numéro de téléphone de l'instance si non fourni par l'API
            if not user_info['phone'] and self.phone:
                user_info['phone'] = self.phone
            
            # Vérifier que l'ID est présent (champ obligatoire)
            if not user_info['id']:
                error_msg = "Unable to retrieve user ID"
                logger.error(error_msg)
                self.login_failed.emit(error_msg)
                return
                
            # Journalisation des informations récupérées (sans affichage à l'utilisateur)
            logger.debug("User information retrieved successfully")
            
            # Émettre le signal de succès avec les informations utilisateur
            self.login_success.emit(user_info)
            
            # Fermer la boîte de dialogue
            self.accept()
            
        except Exception as e:
            error_msg = f"An error occurred while retrieving user information: {str(e)}"
            logger.exception(error_msg)
            self.login_failed.emit("An error occurred while logging in. Please try again.")
        finally:
            self._verification_in_progress = False
    
    def set_controls_enabled(self, enabled: bool):
        """Active ou désactive les contrôles de l'interface."""
        current_index = self.stacked_widget.currentIndex()
        
        # Toujours activer/désactiver les boutons de navigation
        self.next_button.setEnabled(enabled)
        self.back_button.setEnabled(enabled)
        self.cancel_button.setEnabled(enabled)
        
        # Gérer les champs de saisie en fonction de l'écran actuel
        if current_index == 0:  # Écran de téléphone
            self.phone_edit.setEnabled(enabled)
            self.next_button.setEnabled(enabled and bool(self.phone_edit.text().strip()))
        elif current_index == 1:  # Écran de code
            # Toujours activer le champ de code
            self.code_edit.setEnabled(True)
            # Activer le bouton suivant uniquement si le code est valide
            self.next_button.setEnabled(enabled and len(self.code_edit.text().strip()) == 5)
        elif current_index == 2:  # Écran de mot de passe
            self.password_edit.setEnabled(True)
            self.next_button.setEnabled(enabled and bool(self.password_edit.text().strip()))
        
        # Ne pas désactiver le bouton de renvoi s'il est déjà désactivé par le minuteur
        if self.resend_button.isEnabled() and not self.resend_timer.isActive():
            self.resend_button.setEnabled(enabled)
    
    async def update_ui(self, enable_controls=False, status=None, is_error=False, focus_field=None, select_text=False):
        """
        Met à jour l'interface utilisateur de manière asynchrone.
        
        Args:
            enable_controls: Si True, active les contrôles de l'interface
            status: Message de statut à afficher (optionnel)
            is_error: Si True, le message de statut est affiché comme une erreur
            focus_field: Champ sur lequel mettre le focus (optionnel)
            select_text: Si True, sélectionne tout le texte dans le champ de focus
        """
        try:
            # Mettre à jour les contrôles si demandé
            if enable_controls:
                def enable_ui():
                    self.set_controls_enabled(True)
                loop = asyncio.get_event_loop()
                loop.call_soon_threadsafe(enable_ui)
            
            # Mettre à jour le message de statut si fourni
            if status is not None:
                def update_status():
                    self.show_status(status, is_error)
                loop = asyncio.get_event_loop()
                loop.call_soon_threadsafe(update_status)
                
            # Gérer le focus et la sélection du texte si nécessaire
            if focus_field is not None:
                def set_focus():
                    field_name = str(focus_field)
                    if hasattr(self, field_name):
                        field = getattr(self, field_name)
                        field.setFocus()
                        if select_text and hasattr(field, 'selectAll'):
                            field.selectAll()
                loop = asyncio.get_event_loop()
                loop.call_soon_threadsafe(set_focus)
                
        except Exception as e:
            logger.error(f"An error occurred while updating the interface: {e}")
    
    def closeEvent(self, event):
        """Gère la fermeture de la fenêtre."""
        logger.debug("Login dialog is being closed, cleaning up tasks...")
        
        # Annuler toutes les tâches actives
        self._cancel_all_tasks()
        
        # Arrêter le minuteur de nettoyage
        if hasattr(self, '_cleanup_timer') and self._cleanup_timer.isActive():
            self._cleanup_timer.stop()
        
        # Arrêter le minuteur de renvoi de code
        if hasattr(self, 'resend_timer') and self.resend_timer.isActive():
            self.resend_timer.stop()
        
        # Arrêter le minuteur d'attente
        if hasattr(self, 'wait_timer') and self.wait_timer.isActive():
            self.wait_timer.stop()
        
        # Appeler la méthode parente
        super().closeEvent(event)
        logger.debug("Login dialog closed and cleaned up")
    
    def set_loading(self, loading: bool, message: str = ""):
        """Active ou désactive l'état de chargement.
        
        Args:
            loading: Si True, active l'état de chargement
            message: Message à afficher pendant le chargement
        """
        self.setEnabled(not loading)
        if message:
            self.status_label.setText(message)
    
    @qasync.asyncSlot()
    async def on_verify_2fa_clicked(self):
        """
        Gère le clic sur le bouton de vérification 2FA.
        
        Cette méthode est appelée lorsque l'utilisateur clique sur le bouton de vérification 2FA.
        Elle valide le mot de passe et lance la vérification.
        """
        # Vérifier si une vérification est déjà en cours
        if getattr(self, '_verification_in_progress', False):
            logger.debug("2FA verification already in progress")
            return
            
        password = self.password_edit.text().strip()
        
        # Validation du mot de passe
        if not password:
            logger.warning("Attempt of 2FA verification with an empty password")
            await self.update_ui(
                status="Please enter your 2FA password",
                is_error=True,
                focus_field="password_edit"
            )
            return
        
        # Vérifier le nombre maximal de tentatives
        max_attempts = 3
        current_attempts = getattr(self, '_2fa_attempts', 0)
        
        if current_attempts >= max_attempts:
            logger.warning(f"Too many attempts of 2FA verification (max {max_attempts})")
            await self.update_ui(
                status="Too many attempts. Please wait before retrying.",
                is_error=True,
                enable_controls=False
            )
            
            # Activer le bouton de réessai après un délai
            await asyncio.sleep(30)  # Attendre 30 secondes avant de permettre une nouvelle tentative
            self._2fa_attempts = 0
            await self.update_ui(
                enable_controls=True,
                focus_field="password_edit"
            )
            return
        
        # Incrémenter le compteur de tentatives
        self._2fa_attempts = current_attempts + 1
        
        try:
            # Désactiver les contrôles et afficher le statut
            await self.update_ui(
                enable_controls=False,
                status=f"2FA verification in progress (attempt {self._2fa_attempts}/{max_attempts})...",
                is_error=False
            )
            
            # Give the interface time to update
            await asyncio.sleep(0.1)
            
            # Launch password verification
            logger.info(f"Attempting 2FA verification (attempt {self._2fa_attempts}/{max_attempts})")
            result = await self.verify_password_async()
            
            # Handle verification result
            if result is True:
                # Reset counter on success
                self._2fa_attempts = 0
                logger.info("2FA verification successful, retrieving user information...")
                await self._get_user_info_and_emit_success()
                return
                
            # Handle flood wait
            if isinstance(result, str) and result.startswith("flood_wait:"):
                try:
                    wait_seconds = int(result.split(":")[1])
                    logger.warning(f"Waiting for {wait_seconds} seconds required")
                    await self.show_wait_message(wait_seconds)
                    return
                except (IndexError, ValueError) as e:
                    logger.error(f"Error parsing wait time: {e}")
                    error_msg = "Wait time error. Please try again."
            else:
                # Display error message with attempt count
                error_msg = str(result) if result else "Invalid 2FA password"
                remaining = max(0, max_attempts - self._2fa_attempts)
                
                # Format error message
                if remaining > 0:
                    error_msg = f"{error_msg} (Attempt {self._2fa_attempts}/{max_attempts} - {remaining} {'attempt' if remaining == 1 else 'attempts'} remaining)"
                else:
                    error_msg = f"{error_msg} (Attempt {self._2fa_attempts}/{max_attempts})"
            
            # Pour les erreurs, afficher le message et permettre une nouvelle tentative
            await self.update_ui(
                status=error_msg,
                is_error=True,
                enable_controls=True,
                focus_field="password_edit",
                select_text=True
            )
                
        except asyncio.CancelledError:
            logger.debug("2FA verification cancelled")
            await self.update_ui(
                status="2FA verification cancelled",
                is_error=True,
                enable_controls=True
            )
            raise
            
        except Exception as e:
            logger.exception("Unexpected error during 2FA verification")
            await self.update_ui(
                status=f"Unexpected error: {str(e)}",
                is_error=True,
                enable_controls=True,
                focus_field="password_edit"
            )
            
        finally:
            # S'assurer que le drapeau de vérification est réinitialisé
            self._verification_in_progress = False
            
            logger.debug("End of 2FA verification")
    
    def show_2fa_input(self):
        """Affiche le champ de saisie du mot de passe 2FA."""
        logger.debug("Displaying 2FA password input")
        
        # Masquer le groupe de code et afficher le groupe de mot de passe
        self.code_group.setVisible(False)
        self.password_group.setVisible(True)
        
        # Mettre à jour les boutons
        self.verify_code_btn.setVisible(False)
        self.verify_2fa_btn.setVisible(True)
        self.verify_2fa_btn.setEnabled(True)
        
        # Réinitialiser le compteur de tentatives
        self.failed_attempts = 0
        
        # Mettre à jour le message d'état
        status_text = "Please enter your 2FA password."
        if self.failed_attempts > 0:
            remaining = self.max_attempts - self.failed_attempts
            status_text = f"Invalid 2FA password. {remaining} attempt(s) remaining."
        
        self.status_label.setText(status_text)
        self.status_label.setStyleSheet("color: #e74c3c;" if self.failed_attempts > 0 else "")
        
        # Mettre le focus sur le champ de mot de passe
        self.password_edit.clear()
        self.password_edit.setFocus()
        
        # Activer les champs si nécessaire
        self.password_edit.setEnabled(True)
        self.verify_2fa_btn.setEnabled(True)
        
        # Ajuster la taille de la fenêtre
        self.adjustSize()
        
        # Forcer la mise à jour de l'interface utilisateur
        self.update()
        QApplication.processEvents()
    
    def closeEvent(self, event):
        """Gère la fermeture de la boîte de dialogue."""
        # Annuler la connexion en cours si nécessaire
        event.accept()
