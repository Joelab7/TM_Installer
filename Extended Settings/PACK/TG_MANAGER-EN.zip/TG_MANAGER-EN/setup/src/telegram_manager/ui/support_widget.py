"""Widget contextuel d'assistance pour l'application."""
import logging
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QSizePolicy, QSpacerItem, QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QSize, pyqtSignal, QUrl
from PyQt6.QtGui import QPixmap, QIcon, QDesktopServices, QColor


class SupportWidget(QWidget):
    """Widget contextuel affichant les informations de support et les liens."""

    def __init__(self, parent=None):
        """Initialise le widget de support.

        Args:
            parent: Widget parent
        """
        super().__init__(parent)
        # Utiliser une approche plus simple pour éviter les erreurs Windows
        self.setWindowFlags(Qt.WindowType.Popup)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)

        # Configuration des contacts et liens de support
        self.support_config = {
            'email': {
                'address': 'telegram-manager@outlook.com',
                'icon': '📩',
                'label': 'Support Email'
            },
            'telegram': {
                'username': 'TManagerSupport_bot',
                'icon': '💻',
                'label': 'Support Telegram'
            },
            'phone_connection': {
                'username': 'TManagerSoftware_bot',
                'icon': '📱',
                'label': 'Connect the account to Telegram',
                'start_param': '1'
            },
            'group': {
                'url': 'https://t.me/TManagerGroup',
                'icon': '🎭',
                'label': 'Official Group'
            },
            'channel': {
                'url': 'https://t.me/TManagerChannel',
                'icon': '📢',
                'label': 'Official Channel'
            }
        }

        self.setup_ui()
        self.apply_theme('light')  # Thème par défaut

    def mousePressEvent(self, event):
        """Gère les clics souris pour fermer le widget si on clique en dehors."""
        if not self.rect().contains(event.pos()):
            self.hide()
        super().mousePressEvent(event)

    def setup_ui(self):
        """Configure l'interface utilisateur du widget de support."""
        # Layout principal
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(10)

        # Titre
        title_label = QLabel("Help & Support")
        title_label.setObjectName("supportTitle")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title_label)

        # Séparateur
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        separator.setObjectName("separator")
        main_layout.addWidget(separator)

        # Section contacts
        contacts_label = QLabel("Support Contacts:")
        contacts_label.setObjectName("sectionTitle")
        main_layout.addWidget(contacts_label)

        # Boutons de contact
        self.email_btn = self._create_contact_button(
            self.support_config['email']['icon'],
            self.support_config['email']['label'],
            self.support_config['email']['address']
        )
        main_layout.addWidget(self.email_btn)

        self.telegram_btn = self._create_contact_button(
            self.support_config['telegram']['icon'],
            self.support_config['telegram']['label'],
            self.support_config['telegram']['username']
        )
        main_layout.addWidget(self.telegram_btn)

        # Bouton de connexion au bot
        self.bot_connection_btn = self._create_contact_button(
            self.support_config['phone_connection']['icon'],
            self.support_config['phone_connection']['label'],
            self.support_config['phone_connection']['username']
        )
        main_layout.addWidget(self.bot_connection_btn)

        # Séparateur
        separator2 = QFrame()
        separator2.setFrameShape(QFrame.Shape.HLine)
        separator2.setFrameShadow(QFrame.Shadow.Sunken)
        separator2.setObjectName("separator")
        main_layout.addWidget(separator2)

        # Section communauté
        community_label = QLabel("Social Media:")
        community_label.setObjectName("sectionTitle")
        main_layout.addWidget(community_label)

        # Boutons de communauté
        self.group_btn = self._create_link_button(
            self.support_config['group']['icon'],
            self.support_config['group']['label'],
            self.support_config['group']['url']
        )
        main_layout.addWidget(self.group_btn)

        self.channel_btn = self._create_link_button(
            self.support_config['channel']['icon'],
            self.support_config['channel']['label'],
            self.support_config['channel']['url']
        )
        main_layout.addWidget(self.channel_btn)

        # Bouton de fermeture
        close_btn = QPushButton("✕ Close")
        close_btn.setObjectName("closeButton")
        close_btn.clicked.connect(self.hide)
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        main_layout.addWidget(close_btn)

        # Espacement final
        main_layout.addItem(QSpacerItem(20, 10, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed))

        # Configuration de la taille
        self.setMinimumWidth(280)
        self.setMaximumWidth(400)

        # Supprimer l'ombre portée qui peut causer des problèmes sur Windows
        # shadow = QGraphicsDropShadowEffect()
        # shadow.setBlurRadius(10)
        # shadow.setColor(QColor(0, 0, 0, 50))
        # shadow.setOffset(0, 4)
        # self.setGraphicsEffect(shadow)

    def _create_contact_button(self, icon, label, contact_info):
        """Crée un bouton de contact.

        Args:
            icon: Icône à afficher
            label: Texte du bouton
            contact_info: Information de contact (email ou username)

        Returns:
            QPushButton: Le bouton créé
        """
        button = QPushButton(f"{icon} {label}")
        
        # Style spécial pour le bouton de connexion au bot
        if contact_info == 'TManagerSoftware_bot':
            button.setObjectName("botConnectionButton")
            # Stocker le paramètre start pour ce bot
            button.setProperty("start_param", self.support_config['phone_connection'].get('start_param', ''))
        else:
            button.setObjectName("contactButton")
            
        button.setCursor(Qt.CursorShape.PointingHandCursor)

        # Stocker l'information de contact
        button.setProperty("contact_info", contact_info)
        button.setProperty("contact_type", "email" if "@" in contact_info and "." in contact_info else "telegram")

        # Connecter le signal de clic
        button.clicked.connect(lambda: self._handle_contact_click(button))

        return button

    def _create_link_button(self, icon, label, url):
        """Crée un bouton de lien.

        Args:
            icon: Icône à afficher
            label: Texte du bouton
            url: URL à ouvrir

        Returns:
            QPushButton: Le bouton créé
        """
        button = QPushButton(f"{icon} {label}")
        button.setObjectName("linkButton")
        button.setCursor(Qt.CursorShape.PointingHandCursor)

        # Stocker l'URL
        button.setProperty("link_url", url)

        # Connecter le signal de clic
        button.clicked.connect(lambda: self._handle_link_click(button))

        return button

    def _handle_contact_click(self, button):
        """Gère le clic sur un bouton de contact."""
        contact_info = button.property("contact_info")
        contact_type = button.property("contact_type")
        start_param = button.property("start_param")

        try:
            if contact_type == "email":
                # Ouvrir le client email par défaut
                QDesktopServices.openUrl(QUrl(f"mailto:{contact_info}"))
            else:
                # Ouvrir Telegram avec l'username et le paramètre start si présent
                if start_param:
                    QDesktopServices.openUrl(QUrl(f"https://t.me/{contact_info}?start={start_param}"))
                else:
                    QDesktopServices.openUrl(QUrl(f"https://t.me/{contact_info}"))

            logging.info(f"Ouverture du contact {contact_type}: {contact_info}")
            self.hide()  # Masquer le widget après utilisation

        except Exception as e:
            logging.error(f"Erreur lors de l'ouverture du contact {contact_type}: {e}")
            # Essayer une approche alternative
            try:
                import subprocess
                import sys
                if contact_type == "email":
                    # Essayer d'ouvrir avec le navigateur par défaut
                    QDesktopServices.openUrl(QUrl(f"https://mail.google.com/mail/?view=cm&to={contact_info}"))
                else:
                    # Ouvrir directement l'URL Telegram avec paramètre start si présent
                    if start_param:
                        QDesktopServices.openUrl(QUrl(f"https://t.me/{contact_info}?start={start_param}"))
                    else:
                        QDesktopServices.openUrl(QUrl(f"https://t.me/{contact_info}"))
                self.hide()
            except Exception as e2:
                logging.warning(f"Contact {contact_info} non disponible - aucun programme de messagerie/installé")

    def _handle_link_click(self, button):
        """Gère le clic sur un bouton de lien."""
        url = button.property("link_url")

        try:
            QDesktopServices.openUrl(QUrl(url))
            logging.info(f"Ouverture du lien: {url}")
            self.hide()  # Masquer le widget après utilisation

        except Exception as e:
            logging.error(f"Erreur lors de l'ouverture du lien {url}: {e}")
            # Essayer avec subprocess comme fallback
            try:
                import subprocess
                import sys
                if sys.platform == "win32":
                    subprocess.run(["start", url], shell=True, check=True)
                elif sys.platform == "darwin":  # macOS
                    subprocess.run(["open", url], check=True)
                else:  # Linux
                    subprocess.run(["xdg-open", url], check=True)
                self.hide()
            except Exception as e2:
                logging.warning(f"Lien {url} non accessible - vérifiez votre connexion internet")

    def show_at_position(self, pos):
        """Affiche le widget à une position spécifique.

        Args:
            pos: Position (QPoint) où afficher le widget
        """
        # Ajuster la position pour que le widget soit visible à l'écran
        screen_geometry = self.screen().availableGeometry()
        widget_size = self.sizeHint()

        x = pos.x()
        y = pos.y()

        # S'assurer que le widget ne dépasse pas de l'écran
        if x + widget_size.width() > screen_geometry.right():
            x = screen_geometry.right() - widget_size.width()

        if y + widget_size.height() > screen_geometry.bottom():
            y = screen_geometry.bottom() - widget_size.height()

        self.move(x, y)
        self.show()
        self.raise_()

    def apply_theme(self, theme_name='light'):
        """Applique le thème spécifié au widget.

        Args:
            theme_name: Nom du thème ('light' ou 'dark')
        """
        try:
            is_dark = theme_name.lower() == 'dark'

            # Couleurs du thème
            theme_colors = {
                'light': {
                    'bg': '#ffffff',
                    'border': '#e0e0e0',
                    'title': '#2c3e50',
                    'section': '#34495e',
                    'text': '#555555',
                    'button_bg': '#f8f9fa',
                    'button_hover': '#e9ecef',
                    'button_text': '#333333',
                    'separator': '#dddddd'
                },
                'dark': {
                    'bg': '#2d2d2d',
                    'border': '#404040',
                    'title': '#ffffff',
                    'section': '#b0b0b0',
                    'text': '#cccccc',
                    'button_bg': '#3a3a3a',
                    'button_hover': '#454545',
                    'button_text': '#ffffff',
                    'separator': '#555555'
                }
            }

            colors = theme_colors[theme_name.lower()]

            # Style du widget principal
            self.setStyleSheet(f"""
                SupportWidget {{
                    background: {colors['bg']};
                    border: 1px solid {colors['border']};
                    border-radius: 12px;
                }}

                QLabel#supportTitle {{
                    color: {colors['title']};
                    font-size: 16px;
                    font-weight: 600;
                    padding: 5px 0;
                }}

                QLabel#sectionTitle {{
                    color: {colors['section']};
                    font-size: 13px;
                    font-weight: 500;
                    padding: 8px 0 5px 0;
                }}

                QPushButton#contactButton {{
                    background: {colors['button_bg']};
                    color: {colors['button_text']};
                    border: 1px solid {colors['border']};
                    border-radius: 8px;
                    padding: 10px 12px;
                    font-size: 12px;
                    text-align: left;
                    font-weight: 500;
                }}

                QPushButton#contactButton:hover {{
                    background: {colors['button_hover']};
                    border-color: #007bff;
                }}

                QPushButton#botConnectionButton {{
                    background: linear-gradient(135deg, #28a745, #20c997);
                    color: {'#ffffff' if is_dark else '#2c3e50'};
                    border: 1px solid #28a745;
                    border-radius: 8px;
                    padding: 12px 15px;
                    font-size: 13px;
                    text-align: left;
                    font-weight: 600;
                    min-width: 200px;
                }}

                QPushButton#botConnectionButton:hover {{
                    background: linear-gradient(135deg, #218838, #1ea085);
                    border-color: #1ea085;
                }}

                QPushButton#linkButton {{
                    background: {colors['button_bg']};
                    color: {colors['button_text']};
                    border: 1px solid {colors['border']};
                    border-radius: 8px;
                    padding: 10px 12px;
                    font-size: 12px;
                    text-align: left;
                    font-weight: 500;
                }}

                QPushButton#linkButton:hover {{
                    background: {colors['button_hover']};
                    border-color: #28a745;
                }}

                QPushButton#closeButton {{
                    background: transparent;
                    color: {colors['text']};
                    border: none;
                    padding: 8px 15px;
                    font-size: 12px;
                    font-weight: 500;
                }}

                QPushButton#closeButton:hover {{
                    color: #dc3545;
                }}

                QFrame#separator {{
                    color: {colors['separator']};
                    margin: 8px 0;
                }}
            """)

        except Exception as e:
            logging.error(f"Erreur lors de l'application du thème au support widget: {e}")

    def update_support_config(self, config):
        """Met à jour la configuration du support.

        Args:
            config: Dictionnaire contenant les nouvelles informations de support
        """
        if isinstance(config, dict):
            self.support_config.update(config)

            # Recréer l'interface si nécessaire
            self.setup_ui()
