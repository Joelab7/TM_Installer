"""Fenêtre principale de l'application."""
import asyncio
import configparser
import logging
import os
import sys
from pathlib import Path
from typing import Dict, Any
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QLineEdit, QMessageBox,
    QMenu, QToolBar, QFrame, QSizePolicy, QDialog, QDialogButtonBox, QApplication, QStackedWidget, QStatusBar,
    QToolButton, QBoxLayout, QFileDialog, QTabWidget, QDockWidget
)
from PyQt6.QtGui import QCursor, QIcon, QPixmap, QAction, QPalette, QColor
from PyQt6.QtCore import Qt, QTimer, QSize, pyqtSignal, QEvent

# Utilitaires
from .utils import set_window_icon

# Importer la boîte de dialogue des paramètres
from .dialogs import SettingsDialog

from ..core.telegram_client import TelegramClientWrapper
from ..core.config import Config
from ..core.app_state import app_state_manager
from ..notifications import NotificationManager

# Import du widget d'accueil personnalisé
from .home_widget import HomeWidget
from .members_manager_widget import MembersManagerWidget
from .save_credentials_widget import SaveCredentialsWidget

class MainWindow(QMainWindow):
    """Fenêtre principale de l'application."""
    
    # Définir un signal pour les changements de thème
    theme_changed = pyqtSignal(str)
    
    def __init__(self, config: Config, parent=None):
        """Initialise la fenêtre principale.
        
        Args:
            config: Instance de configuration de l'application
            parent: Widget parent
        """
        super().__init__(parent)
        self.config = config
        self._connection_lock = asyncio.Lock()  # Verrou pour éviter les conflits de connexion
        
        # Initialiser le client Telegram
        self.telegram_client = TelegramClientWrapper(config.config)
        
        # Mettre à jour l'état de l'application comme "en cours d'exécution"
        app_state_manager.update_app_status(True, "Telegram Manager")
        print("✅ [MainWindow] App status updated to running")
        logging.info("✅ [MainWindow] App status updated to running")
        
        # Initialiser le gestionnaire de notifications global pour le bot
        print("🔧 [MainWindow] Initializing global NotificationManager...")
        logging.info("🔧 [MainWindow] Initializing global NotificationManager...")
        
        try:
            self.notification_manager = NotificationManager(
                ui_callback=self.add_notification if hasattr(self, 'add_notification') else None,
                telegram_client_wrapper=self.telegram_client
            )
            print("✅ [MainWindow] Global NotificationManager created successfully")
            logging.info("✅ [MainWindow] Global NotificationManager created successfully")
            
            # Le démarrage du bot sera géré automatiquement après la connexion
            logging.info("ℹ️ Bot notifier startup will be handled after connection")
            
            # Planifier la mise à jour des informations de licence après que la boucle asyncio soit active
            QTimer.singleShot(2000, self._update_license_info_delayed)
            print("🔄 [MainWindow] License update scheduled with QTimer")
            logging.info("🔄 [MainWindow] License update scheduled with QTimer")
            
        except Exception as e:
            print(f"❌ [MainWindow] Error creating global NotificationManager: {e}")
            logging.error(f"❌ [MainWindow] Error creating global NotificationManager: {e}")
            self.notification_manager = None
        
        # Configuration de base de la fenêtre
        self.setWindowTitle("Telegram Manager")
        self.setMinimumSize(1024, 768)
        
        # Initialize state management attributes
        self._restart_warning_shown = False
        
        # Définir l'icône de la fenêtre
        set_window_icon(self, "app_icon")
        
        # Récupérer la configuration de l'interface
        ui_config = self.config.get_section('ui', {})
        
        # Widget central
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        # Layout principal
        self.main_layout = QVBoxLayout(self.central_widget)
        margins = ui_config.get('margins', 10)
        spacing = ui_config.get('spacing', 10)
        self.main_layout.setContentsMargins(margins, margins, margins, margins)
        self.main_layout.setSpacing(spacing)
        
        # Initialisation des composants de l'interface
        self.setup_toolbar()
        
        # Zone de contenu (empilée pour différentes vues)
        self.content_stack = QStackedWidget()
        self.main_layout.addWidget(self.content_stack)
        
        # Barre d'état
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
        
        # Configuration de l'interface utilisateur
        self.setup_ui()
        
        # On ne lance pas la connexion automatique ici, ce sera fait dans showEvent
    
    def setup_toolbar(self):
        """Configure la barre d'outils avec les actions principales."""
        # Créer la barre d'outils
        self.toolbar = self.addToolBar("Tools")
        self.toolbar.setMovable(True)  # Permettre le déplacement
        self.toolbar.setIconSize(QSize(16, 16))
        self.toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        
        # Login button
        self.login_btn = QAction("Login", self)
        self.login_btn.triggered.connect(self.show_login_dialog)
        self.toolbar.addAction(self.login_btn)
        
        # Refresh button
        refresh_action = QAction("Refresh", self)
        refresh_action.setIcon(QIcon(":/icons/refresh.png"))
        refresh_action.triggered.connect(self.refresh_data)
        self.toolbar.addAction(refresh_action)
        
        # Theme button
        self.theme_btn = QAction("Theme", self)
        self.theme_btn.setIcon(QIcon(":/icons/theme.png"))
        self.theme_btn.triggered.connect(self.show_theme_menu)
        self.toolbar.addAction(self.theme_btn)
        
        # Help button
        self.help_btn = QAction("Help", self)
        self.help_btn.setIcon(QIcon(":/icons/help.png"))
        self.help_btn.triggered.connect(self.show_help_dialog)
        self.toolbar.addAction(self.help_btn)
        
        # Settings button
        self.settings_btn = QAction("Settings", self)
        self.settings_btn.setIcon(QIcon(":/icons/settings.png"))
        self.settings_btn.triggered.connect(self.show_settings_dialog)
        self.toolbar.addAction(self.settings_btn)
        
        # Credentials button
        self.credentials_btn = QAction("Identifiers", self)
        self.credentials_btn.setIcon(QIcon(":/icons/save.png"))
        self.credentials_btn.triggered.connect(self.show_save_credentials_dialog)
        self.toolbar.addAction(self.credentials_btn)

        # Base style for the toolbar
        self.toolbar.setStyleSheet("""
            QToolBar {
                background: #f0f0f0;
                border: 1px solid #c0c0c0;
                border-radius: 4px;
                padding: 2px 4px;
                spacing: 4px;
            }
            QToolBar::separator {
                width: 1px;
                background: #c0c0c0;
                margin: 2px 4px;
            }
            QToolButton {
                padding: 4px 8px;
                border: 1px solid transparent;
                border-radius: 3px;
                background: transparent;
            }
            QToolButton:hover {
                background: rgba(0, 0, 0, 0.05);
                border: 1px solid #a0a0a0;
            }
            QToolButton:pressed {
                background: rgba(0, 0, 0, 0.1);
            }
            
            /* Style des tooltips */
            QToolTip {
                color: #000000;
                background-color: #ffffff;
                border: 1px solid #d0d0d0;
                padding: 6px 10px;
                border-radius: 4px;
                font-size: 12px;
            }
        """)
    
    def setup_ui(self):
        """Configure l'interface utilisateur."""
        # Créer le widget d'accueil
        self.home_widget = HomeWidget(self.telegram_client, self)
        self.content_stack.addWidget(self.home_widget)
        
        # Afficher le widget d'accueil par défaut
        self.content_stack.setCurrentWidget(self.home_widget)
        
        # Indicateurs d'état
        self._first_show = True
        self._initial_theme_applied = False
        
        # Configurer l'événement de changement d'onglet
        if hasattr(self, 'home_widget') and hasattr(self.home_widget, 'tab_widget'):
            self.home_widget.tab_widget.currentChanged.connect(self.on_tab_changed)
        
        # Connecter le signal de changement de thème au HomeWidget
        if hasattr(self, 'home_widget') and hasattr(self.home_widget, 'on_theme_changed'):
            self.theme_changed.connect(self.home_widget.on_theme_changed)
    
    def showEvent(self, event):
        """Surcharge de l'événement d'affichage de la fenêtre."""
        super().showEvent(event)
        
        # Ne lancer la connexion automatique qu'à la première ouverture
        if hasattr(self, '_first_show') and self._first_show:
            self._first_show = False
            
            # Appliquer le thème depuis la configuration au démarrage
            if hasattr(self, 'config') and hasattr(self.config, 'config'):
                theme = self.config.config.get('app', {}).get('theme', 'light')
                self._change_theme(theme)
            
            # Réactiver la connexion automatique avec une approche directe
            # Utiliser un appel direct dans la boucle d'événements au lieu de QTimer
            QApplication.instance().postEvent(self, QEvent(QEvent.Type.User))
            logging.debug("Connexion automatique réactivée avec postEvent")
    
    def event(self, event):
        """Gère les événements personnalisés."""
        if event.type() == QEvent.Type.User:
            # Déclencher la connexion automatique
            self.start_auto_connect()
            return True
        return super().event(event)
    
    def start_auto_connect(self):
        """Démarre la connexion automatique de manière asynchrone."""
        asyncio.create_task(self.auto_connect())
    
    async def auto_connect(self):
        """Tente de se connecter automatiquement si une session valide existe."""
        async with self._connection_lock:
            try:
                # Vérifier si une session existe déjà
                if await self.telegram_client.check_session():
                    self.status_bar.showMessage("Automatic connection in progress...")
                    connected = await self.telegram_client.connect()
                    if connected:
                        self.status_bar.showMessage("Connected successfully", 3000)
                        self.login_btn.setText("Logout")
                        # Mettre à jour l'interface utilisateur si nécessaire
                        if hasattr(self, 'on_login_success'):
                            await self.on_login_success()
                        return True
                    else:
                        self.status_bar.showMessage("Automatic connection failed", 3000)
                return False
            except Exception as e:
                self.status_bar.showMessage(f"Automatic connection error: {str(e)}", 5000)
                logging.error(f"Automatic connection error: {e}")
                return False
    
    async def _update_user_info_in_state(self):
        """Met à jour les informations utilisateur dans l'état global de l'application."""
        try:
            if self.telegram_client and self.telegram_client.is_connected():
                user_info = await self.telegram_client.get_me()
                if user_info:
                    user_data = {
                        "id": user_info.id,
                        "first_name": getattr(user_info, 'first_name', ''),
                        "last_name": getattr(user_info, 'last_name', ''),
                        "username": getattr(user_info, 'username', ''),
                        "phone": getattr(user_info, 'phone', ''),
                        "verified": getattr(user_info, 'verified', False),
                        "premium": getattr(user_info, 'premium', False)
                    }
                    app_state_manager.update_user_info(user_data)
                    logging.info(f"Informations utilisateur mises à jour: {user_data['first_name']} (@{user_data['username']})")
        except Exception as e:
            logging.error(f"Erreur lors de la mise à jour des informations utilisateur: {e}")
    
    async def _update_license_info_in_state(self):
        """Met à jour les informations de licence dans l'état global."""
        try:
            print("🔍 [MainWindow] Updating license info in state...")
            logging.info("🔍 [MainWindow] Updating license info in state...")
            
            # Importer le gestionnaire de licence depuis Program
            import sys
            from pathlib import Path
            
            # Ajouter le chemin vers Program
            program_path = Path(__file__).parent.parent.parent / "Program"
            print(f"📍 Fichier actuel: {Path(__file__).parent}")
            print(f"📍 Chemin Program installation: {program_path}")
            print(f"📍 Existe Program: {program_path.exists()}")
            
            # Si le chemin ne fonctionne pas, essayer le chemin d'installation
            if not program_path.exists():
                program_path = Path("C:/Program Files/Telegram Manager/Program")
                print(f"📍 Chemin Program alternatif: {program_path}")
                print(f"📍 Existe Program alternatif: {program_path.exists()}")
            
            if str(program_path) not in sys.path:
                sys.path.insert(0, str(program_path))
                print(f"✅ Chemin Program ajouté au sys.path: {program_path}")
            
            print(f"📋 sys.path contient maintenant: {sys.path[:3]}...")
            
            # Vérifier si le module security existe
            security_path = program_path / "security"
            print(f"📍 Chemin security: {security_path}")
            print(f"📍 Existe security: {security_path.exists()}")
            if security_path.exists():
                import os
                print(f"� Contenu de security: {os.listdir(security_path)}")
                license_manager_path = security_path / "license_manager.py"
                print(f"📍 license_manager.py existe: {license_manager_path.exists()}")
            
            from security.license_manager import LicenseManager
            
            print("✅ [MainWindow] LicenseManager imported successfully")
            logging.info("✅ [MainWindow] LicenseManager imported successfully")
            
            license_manager = LicenseManager()
            print("✅ [MainWindow] LicenseManager instance created")
            logging.info("✅ [MainWindow] LicenseManager instance created")
            
            result = license_manager.validate_license()
            print(f"📋 [MainWindow] License validation result: {result}")
            logging.info(f"📋 [MainWindow] License validation result: {result}")
            
            license_data = {
                "valid": result['valid'],
                "message": result['message'],
                "expiry_date": result['expiry_date'].isoformat() if result.get('expiry_date') else None,
                "days_remaining": result.get('days_remaining', 0)
            }
            
            print(f"💾 [MainWindow] Saving license data: {license_data}")
            logging.info(f"💾 [MainWindow] Saving license data: {license_data}")
            
            app_state_manager.update_license_info(license_data)
            print(f"✅ [MainWindow] License info updated in state: valid={result['valid']}, days_remaining={result.get('days_remaining', 0)}")
            logging.info(f"✅ [MainWindow] License info updated in state: valid={result['valid']}, days_remaining={result.get('days_remaining', 0)}")
            
        except Exception as e:
            print(f"❌ [MainWindow] Error updating license info: {e}")
            logging.error(f"❌ [MainWindow] Error updating license info: {e}")
            import traceback
            traceback.print_exc()
    
    async def _logout(self):
        """Gère la déconnexion de l'utilisateur et la suppression de la session."""
        try:
            success = await self.telegram_client.logout()
            
            if success:
                # Supprimer l'ancien widget de profil s'il existe
                if hasattr(self, 'profile_widget'):
                    self.profile_widget.deleteLater()
                    del self.profile_widget
                
                # Réinitialiser l'interface
                self.login_btn.setText("Login")
                self.content_stack.setCurrentIndex(0)  # Revenir à l'écran d'accueil
                
                # Réinitialiser le client
                telegram_config = self.config.get_section('telegram')
                self.telegram_client = TelegramClientWrapper(telegram_config)
                
                # Créer un nouveau widget de profil vide
                from .profile_widget import ProfileWidget
                self.profile_widget = ProfileWidget(None, self)
                self.profile_widget.logout_requested.connect(self.show_login_dialog)
                
                # Ajouter le widget au layout s'il existe
                if hasattr(self, 'profile_layout'):
                    self.profile_layout.addWidget(self.profile_widget)
                
                self.status_bar.showMessage("Logout successful. Restarting...", 3000)
                # Nettoyer les ressources avant le redémarrage
                self.cleanup_before_restart()
                # Redémarrer l'application
                QTimer.singleShot(500, self.restart_application)
            else:
                self.status_bar.showMessage("Logout failed. Restarting...", 5000)
                # Nettoyer et redémarrer quand même
                self.cleanup_before_restart()
                QTimer.singleShot(500, self.restart_application)
                
        except Exception as e:
            logging.error(f"Logout failed: {e}")
            self.status_bar.showMessage("Logout failed. Restarting...", 5000)
            # Nettoyer et tenter de redémarrer quand même en cas d'erreur
            self.cleanup_before_restart()
            QTimer.singleShot(500, self.restart_application)
        finally:
            # S'assurer que le widget est visible à nouveau
            if hasattr(self, 'profile_widget'):
                self.profile_widget.setVisible(True)
    
    def cleanup_before_restart(self):
        """Nettoie les ressources avant le redémarrage de l'application."""
        try:
            # Fermer proprement les connexions réseau
            if hasattr(self, 'telegram_client') and self.telegram_client:
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        # Si la boucle est en cours d'exécution, planifier la déconnexion
                        asyncio.create_task(self.telegram_client.disconnect(force=True))
                    else:
                        # Sinon, exécuter directement
                        loop.run_until_complete(self.telegram_client.disconnect(force=True))
                except Exception as e:
                    logging.error(f"Logout failed: {e}")
            
            # Effacer les informations de session dans l'état global
            app_state_manager.clear_session()
            
            # Nettoyer les autres ressources si nécessaire
            # ...
            
            # Forcer le garbage collection
            import gc
            gc.collect()
            
        except Exception as e:
            logging.error(f"Cleanup failed: {e}")
    
    async def _logout(self):
        """Gère la déconnexion de l'utilisateur et la suppression de la session."""
        try:
            # Afficher un message de statut
            self.status_bar.showMessage("Logout in progress...")
            # DÉSACTIVÉ TEMPORAIREMENT - QApplication.processEvents() peut créer des fenêtres blanches
            # QApplication.processEvents()
            
            # Cacher temporairement le widget de profil
            if hasattr(self, 'profile_widget'):
                self.profile_widget.setVisible(False)
            
            # Appeler la méthode de déconnexion
            success = await self.telegram_client.logout()
            
            if success:
                # Supprimer l'ancien widget de profil s'il existe
                if hasattr(self, 'profile_widget'):
                    self.profile_widget.deleteLater()
                    del self.profile_widget
                
                # Réinitialiser l'interface
                self.login_btn.setText("Login")
                self.content_stack.setCurrentIndex(0)  # Revenir à l'écran d'accueil
                
                # Réinitialiser le client
                telegram_config = self.config.get_section('telegram')
                self.telegram_client = TelegramClientWrapper(telegram_config)
                
                # Créer un nouveau widget de profil vide
                from .profile_widget import ProfileWidget
                self.profile_widget = ProfileWidget(None, self)
                self.profile_widget.logout_requested.connect(self.show_login_dialog)
                
                # Ajouter le widget au layout s'il existe
                if hasattr(self, 'profile_layout'):
                    self.profile_layout.addWidget(self.profile_widget)
                
                self.status_bar.showMessage("Logout successful. Restarting...", 3000)
                # Nettoyer les ressources avant le redémarrage
                self.cleanup_before_restart()
                # Redémarrer l'application
                QTimer.singleShot(500, self.restart_application)
            else:
                self.status_bar.showMessage("Logout failed. Restarting...", 5000)
                # Nettoyer et redémarrer quand même
                self.cleanup_before_restart()
                QTimer.singleShot(500, self.restart_application)
                
        except Exception as e:
            logging.error(f"Logout failed: {e}")
            self.status_bar.showMessage("Logout failed. Restarting...", 5000)
            # Nettoyer et tenter de redémarrer quand même en cas d'erreur
            self.cleanup_before_restart()
            QTimer.singleShot(500, self.restart_application)
        finally:
            # S'assurer que le widget est visible à nouveau
            if hasattr(self, 'profile_widget'):
                self.profile_widget.setVisible(True)
    
    def _start_bot_notifier_delayed(self):
        """Démarre le bot notifier après que la boucle asyncio soit active."""
        print("🚀 [MainWindow] Starting bot notifier delayed...")
        logging.info("🚀 [MainWindow] Starting bot notifier delayed...")
        
        try:
            if self.notification_manager and self.notification_manager.bot_notifier:
                # Utiliser asyncio pour démarrer le bot
                import asyncio
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    asyncio.create_task(self.notification_manager._start_bot_notifier())
                    print("✅ [MainWindow] Bot notifier startup task scheduled")
                    logging.info("✅ [MainWindow] Bot notifier startup task scheduled")
                else:
                    print("⚠️ [MainWindow] No running asyncio loop, trying direct execution")
                    logging.warning("⚠️ [MainWindow] No running asyncio loop, trying direct execution")
                    loop.run_until_complete(self.notification_manager._start_bot_notifier())
            else:
                print("❌ [MainWindow] No notification manager or bot notifier available")
                logging.warning("❌ [MainWindow] No notification manager or bot notifier available")
        except Exception as e:
            print(f"❌ [MainWindow] Error starting bot notifier delayed: {e}")
            logging.error(f"❌ [MainWindow] Error starting bot notifier delayed: {e}")
    
    def _update_license_info_delayed(self):
        """Met à jour les informations de licence après que la boucle asyncio soit active."""
        print("🔄 [MainWindow] Updating license info delayed...")
        logging.info("🔄 [MainWindow] Updating license info delayed...")
        
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.create_task(self._update_license_info_in_state())
                print("✅ [MainWindow] License update task scheduled successfully")
                logging.info("✅ [MainWindow] License update task scheduled successfully")
            else:
                print("⚠️ [MainWindow] Still no asyncio loop, trying direct execution")
                logging.warning("⚠️ [MainWindow] Still no asyncio loop, trying direct execution")
                loop.run_until_complete(self._update_license_info_in_state())
        except Exception as e:
            print(f"❌ [MainWindow] Error updating license info delayed: {e}")
            logging.error(f"❌ [MainWindow] Error updating license info delayed: {e}")
    
    def restart_application(self):
        """Redémarre l'application."""
        try:
            # Créer un nouveau processus pour redémarrer l'application
            python = sys.executable
            args = [python] + sys.argv
            
            # Si sous Windows
            if sys.platform == 'win32':
                # Utiliser Popen avec DETACHED_PROCESS pour éviter les problèmes de console
                import subprocess
                from subprocess import CREATE_NEW_PROCESS_GROUP, DETACHED_PROCESS
                
                # Fermer d'abord l'application actuelle
                QApplication.quit()
                
                # Lancer le nouveau processus
                subprocess.Popen(
                    args,
                    creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
                    close_fds=True
                )
            else:
                # Pour les autres systèmes d'exploitation
                os.execv(python, args)
                
        except Exception as e:
            logging.error(f"Restart failed: {e}")
            # Si le redémarrage échoue, afficher un message et fermer l'application
            QMessageBox.critical(
                self,
                "Error",
                f"An error occurred during restart.\nPlease restart the application manually.\n\nError: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
            QApplication.quit()
    
    def cleanup_before_restart(self):
        """Nettoie les ressources avant le redémarrage de l'application."""
        try:
            # Fermer proprement les connexions réseau
            if hasattr(self, 'telegram_client') and self.telegram_client:
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        # Si la boucle est en cours d'exécution, planifier la déconnexion
                        asyncio.create_task(self.telegram_client.disconnect(force=True))
                    else:
                        # Sinon, exécuter directement
                        loop.run_until_complete(self.telegram_client.disconnect(force=True))
                except Exception as e:
                    logging.error(f"Logout failed: {e}")
            
            # Nettoyer les autres ressources si nécessaire
            # ...
            
            # Forcer le garbage collection
            import gc
            gc.collect()
            
        except Exception as e:
            logging.error(f"Logout failed: {e}")
    
    def restart_application(self):
        """Redémarre l'application."""
        try:
            # Créer un nouveau processus pour redémarrer l'application
            python = sys.executable
            args = [python] + sys.argv
            
            # Si sous Windows
            if sys.platform == 'win32':
                # Utiliser Popen avec DETACHED_PROCESS pour éviter les problèmes de console
                import subprocess
                from subprocess import CREATE_NEW_PROCESS_GROUP, DETACHED_PROCESS
                
                # Fermer d'abord l'application actuelle
                QApplication.quit()
                
                # Lancer le nouveau processus
                subprocess.Popen(
                    args,
                    creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
                    close_fds=True
                )
            else:
                # Pour les autres systèmes d'exploitation
                os.execv(python, args)
                
        except Exception as e:
            logging.error(f"Restart failed: {e}")
            # Si le redémarrage échoue, afficher un message et fermer l'application
            QMessageBox.critical(
                self,
                "Error",
                f"An error occurred during restart.\nPlease restart the application manually.\n\nError: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
            QApplication.quit()
    
    def closeEvent(self, event):
        """Gère l'événement de fermeture de la fenêtre."""
        try:
            # Si le client Telegram est connecté, effectuer une déconnexion douce
            if hasattr(self, 'telegram_client') and self.telegram_client:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    asyncio.create_task(self.telegram_client.disconnect(force=False))
                else:
                    loop.run_until_complete(self.telegram_client.disconnect(force=False))
        except Exception as e:
            logging.error(f"Logout failed: {e}")
        finally:
            # Accepter l'événement de fermeture
            event.accept()
    
    def add_notification(self, message, is_error=False):
        """Ajoute une notification à afficher dans l'interface.
        
        Args:
            message (str): Le message de notification
            is_error (bool): Si True, affiche le message comme une erreur
        """
        try:
            # Journalisation pour le débogage
            log_level = 'ERROR' if is_error else 'INFO'
            log_message = f"[Notification] {message}"
            
            # Afficher dans la console et les logs
            print(f"{log_level}: {log_message}")
            logging.log(
                logging.ERROR if is_error else logging.INFO,
                log_message
            )
            
            # Afficher la notification dans la barre d'état
            if hasattr(self, 'status_bar') and self.status_bar is not None:
                self.status_bar.showMessage(message, 5000)  # Affiche pendant 5 secondes
            else:
                print("ATTENTION: Impossible d'afficher la notification - status_bar non disponible")
            
            # Si le widget de profil est disponible, lui envoyer la notification
            if hasattr(self, 'profile_widget') and self.profile_widget is not None:
                try:
                    self.profile_widget.add_notification(message, is_error)
                except Exception as e:
                    error_msg = f"Notification failed: {str(e)}"
                    print(error_msg)
                    logging.error(error_msg, exc_info=True)
            else:
                print("INFO: Aucun profile_widget disponible pour relayer la notification")
                
        except Exception as e:
            error_msg = f"Notification failed: {str(e)}"
            print(f"ERREUR: {error_msg}")
            logging.error(error_msg, exc_info=True)
    
    def show_members_manager(self):
        """Affiche la fenêtre de gestion des membres Telegram."""
        try:
            # Ne pas permettre l'ouverture pendant le chargement
            if hasattr(self, 'profile_widget') and hasattr(self.profile_widget, '_loading') and self.profile_widget._loading:
                # Prevent opening the member manager during loading
                logging.debug("Member manager opening blocked during loading")
                return
                
            if not self.telegram_client.is_connected():
                # Vérifier si l'utilisateur a déjà été averti et a refusé
                if self._restart_warning_shown:
                    logging.debug("Restart message already shown and rejected by user")
                    return
                
                reply = QMessageBox.warning(
                    self,
                    "Configuration changes made",
                    "The application must be restarted to accept the changes.\n\nClick on Ok to restart.",
                    QMessageBox.StandardButton.Ok
                )
                # L'utilisateur a cliqué sur Ok, réinitialiser le flag et redémarrer
                self._restart_warning_shown = True         #Empêche les répétitions d'ouvertures
                self.restart_application()
                return
                
            self.status_bar.showMessage("Opening Members Manager...", 2000)
            
            # Vérifier si le dock existe déjà
            if not hasattr(self, 'members_dock'):
                # Créer le dock widget
                self.members_dock = QDockWidget("Members Manager", self)
                self.members_dock.setObjectName("MembersManagerDock")
                
                # Créer et configurer le widget du gestionnaire de membres
                # Utiliser self comme parent pour les notifications
                self.members_manager = MembersManagerWidget(self.telegram_client, self)
                self.members_dock.setWidget(self.members_manager)
                
                # S'assurer que le widget est correctement configuré pour les notifications
                if hasattr(self.members_manager, 'setup_notification_connection'):
                    self.members_manager.setup_notification_connection()
                
                # Ajouter le dock à la fenêtre principale
                self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.members_dock)
                
                # Ajouter un bouton de fermeture
                close_action = self.members_dock.toggleViewAction()
                close_action.setText("Close Members Manager")
                close_action.triggered.connect(self.members_dock.close)
                
                # Ajouter l'action au menu Affichage
                if hasattr(self, 'view_menu'):
                    self.view_menu.addAction(close_action)
            
            # Afficher le dock s'il est caché
            if self.members_dock.isHidden():
                self.members_dock.show()
            
            # Mettre le focus sur le dock
            self.members_dock.raise_()
            self.members_dock.setFocus()
            
        except Exception as e:
            logging.error(f"Members Manager failed to open: {e}")
            QMessageBox.critical(
                self,
                "Error",
                f"An error occurred while opening Members Manager: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
    
    async def on_login_success(self):
        """Appelé après une connexion réussie."""
        try:
            from .profile_widget import ProfileWidget
            
            # Mettre à jour le bouton de connexion immédiatement
            self.login_btn.setText("Logout")
            
            # Mettre à jour les informations utilisateur dans l'état global
            await self._update_user_info_in_state()
            
            # Nettoyer le conteneur de profil existant
            if hasattr(self, 'profile_layout'):
                # Supprimer tous les widgets du layout de profil
                while self.profile_layout.count() > 0:
                    item = self.profile_layout.takeAt(0)
                    if item.widget():
                        item.widget().deleteLater()
            else:
                # Créer le layout de profil s'il n'existe pas
                self.profile_layout = QHBoxLayout()
                self.profile_layout.setContentsMargins(5, 0, 5, 0)
                self.profile_layout.setSpacing(5)
                
                # Créer un conteneur pour le profil
                profile_container = QWidget()
                profile_container.setLayout(self.profile_layout)
                
                # Ajouter le conteneur à la barre d'outils
                self.toolbar.addWidget(profile_container)
            
            # Créer et afficher le widget de profil dans la barre d'outils
            self.profile_widget = ProfileWidget(self.telegram_client, self)
            
            # Connecter le signal de déconnexion
            self.profile_widget.logout_requested.connect(self.show_login_dialog)
            
            # Ajouter le widget de profil au conteneur
            self.profile_layout.addWidget(self.profile_widget)
            
            # Ajouter le bouton TELEGRAM MEMBERS MANAGER
            self.members_manager_btn = QPushButton("TELEGRAM MEMBERS MANAGER")
            self.members_manager_btn.setFixedHeight(32)
            
            # Désactiver pendant le chargement
            if hasattr(self.profile_widget, '_loading') and self.profile_widget._loading:
                self.members_manager_btn.setEnabled(False)
                self.members_manager_btn.setText("TELEGRAM MEMBERS MANAGER (loading...)")
            else:
                self.members_manager_btn.clicked.connect(self.show_members_manager)
                
            self.members_manager_btn.setStyleSheet("""
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                              stop:0 #1e88e5, stop:1 #0d47a1);
                    color: white;
                    font-weight: bold;
                    border: none;
                    border-radius: 4px;
                    padding: 5px 15px;
                    margin-left: 10px;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                              stop:0 #42a5f5, stop:1 #1565c0);
                }
                QPushButton:pressed {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                              stop:0 #0d47a1, stop:1 #1e88e5);
                    padding: 6px 14px 4px 16px;
                }
            """)
            self.members_manager_btn.clicked.connect(self.show_members_manager)
            self.profile_layout.addWidget(self.members_manager_btn)
            
            # Forcer la mise à jour de l'interface
            # DÉSACTIVÉ TEMPORAIREMENT - QApplication.processEvents() peut créer des fenêtres blanches
            # QApplication.processEvents()
            
            # Charger le profil de manière asynchrone
            try:
                await self.profile_widget.load_profile()
                self.status_bar.showMessage("Connected successfully", 3000)
                
                # Recharger les données du widget d'accueil
                if hasattr(self, 'home_widget'):
                    self.home_widget.load_data()
                
                # Réactiver le bouton du gestionnaire de membres
                if hasattr(self, 'members_manager_btn'):
                    self.members_manager_btn.setEnabled(True)
                    self.members_manager_btn.setText("TELEGRAM MEMBERS MANAGER")
                    self.members_manager_btn.clicked.connect(self.show_members_manager)
                    
            except Exception as e:
                logging.error(f"Profile loading failed: {e}")
                self.status_bar.showMessage("Profile loading failed", 3000)
                
                # Réactiver même en cas d'erreur
                if hasattr(self, 'members_manager_btn'):
                    self.members_manager_btn.setEnabled(True)
                    self.members_manager_btn.setText("TELEGRAM MEMBERS MANAGER")
                    self.members_manager_btn.clicked.connect(self.show_members_manager)
            
            finally:
                # GARANTIE ABSOLUE: Toujours réactiver le bouton
                if hasattr(self, 'members_manager_btn'):
                    self.members_manager_btn.setEnabled(True)
                    self.members_manager_btn.setText("TELEGRAM MEMBERS MANAGER")
                    if not self.members_manager_btn.receivers(self.members_manager_btn.clicked) > 0:
                        self.members_manager_btn.clicked.connect(self.show_members_manager)
                    logging.debug("FINALLY: Bouton gestionnaire réactivé de manière garantie")
            
            # Démarrer le bot notifier après connexion réussie
            print("🚀 [MainWindow] Starting bot notifier after successful login...")
            logging.info("🚀 [MainWindow] Starting bot notifier after successful login...")
            
            try:
                if self.notification_manager and self.notification_manager.bot_notifier:
                    # Utiliser asyncio pour démarrer le bot
                    import asyncio
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        asyncio.create_task(self.notification_manager._start_bot_notifier())
                        print("✅ [MainWindow] Bot notifier startup task scheduled")
                        logging.info("✅ [MainWindow] Bot notifier startup task scheduled")
                    else:
                        print("⚠️ [MainWindow] No running asyncio loop, trying direct execution")
                        logging.warning("⚠️ [MainWindow] No running asyncio loop, trying direct execution")
                        loop.run_until_complete(self.notification_manager._start_bot_notifier())
                else:
                    print("❌ [MainWindow] No notification manager or bot notifier available")
                    logging.warning("❌ [MainWindow] No notification manager or bot notifier available")
            except Exception as e:
                print(f"❌ [MainWindow] Error starting bot notifier: {e}")
                logging.error(f"❌ [MainWindow] Error starting bot notifier: {e}")
            
            # Mettre à jour l'interface après un court délai pour s'assurer que tout est chargé
            # DÉSACTIVÉ TEMPORAIREMENT - QApplication.processEvents() peut créer des fenêtres blanches
            # QTimer.singleShot(500, lambda: QApplication.processEvents())
            
        except Exception as e:
            logging.error(f"Interface update failed after login: {e}")
            self.status_bar.showMessage("Interface update failed after login", 3000)
    
    def on_tab_changed(self, index):
        """Appelé lorsque l'onglet actif change."""
        # Vous pouvez ajouter ici une logique supplémentaire lors du changement d'onglet
        pass
    
    def on_login_success_wrapper(self):
        """Wrapper pour appeler on_login_success depuis un gestionnaire d'événements synchrone."""
        import asyncio
        asyncio.create_task(self.on_login_success())
        
        # Démarrer le bot notifier après la connexion réussie
        print("🚀 [MainWindow] Starting bot notifier after successful login...")
        logging.info("🚀 [MainWindow] Starting bot notifier after successful login...")
        
        try:
            if self.notification_manager and self.notification_manager.bot_notifier:
                # Utiliser asyncio pour démarrer le bot
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    asyncio.create_task(self.notification_manager._start_bot_notifier())
                    print("✅ [MainWindow] Bot notifier startup task scheduled")
                    logging.info("✅ [MainWindow] Bot notifier startup task scheduled")
                else:
                    print("⚠️ [MainWindow] No running asyncio loop, trying direct execution")
                    logging.warning("⚠️ [MainWindow] No running asyncio loop, trying direct execution")
                    loop.run_until_complete(self.notification_manager._start_bot_notifier())
            else:
                print("❌ [MainWindow] No notification manager or bot notifier available")
                logging.warning("❌ [MainWindow] No notification manager or bot notifier available")
        except Exception as e:
            print(f"❌ [MainWindow] Error starting bot notifier: {e}")
            logging.error(f"❌ [MainWindow] Error starting bot notifier: {e}")
    
    def show_login_dialog(self):
        """Affiche la boîte de dialogue de connexion ou déconnecte l'utilisateur."""
        # Si l'utilisateur est connecté, le déconnecter
        if self.telegram_client.is_connected():
            # Utiliser asyncio pour gérer la déconnexion asynchrone
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.create_task(self._logout())
            else:
                loop.run_until_complete(self._logout())
            return
            
        # Sinon, afficher la boîte de dialogue de connexion
        from .login_dialog import LoginDialog  # Importation locale pour éviter les imports circulaires
        
        dialog = LoginDialog(self.telegram_client, self)
        if dialog.exec():
            self.status_bar.showMessage("Connected successfully", 3000)
            self.login_btn.setText("Logout")
            # Mettre à jour l'interface après connexion
            self.on_login_success_wrapper()
    
    def refresh_data(self):
        """Rafraîchit les données affichées."""
        try:
            self.status_bar.showMessage("Refreshing data...", 2000)
            
            # Vérifier si le client est connecté
            if not self.telegram_client.is_connected():
                self.status_bar.showMessage("Please connect first", 3000)
                return
            
            # Recharger les données de manière asynchrone
            asyncio.create_task(self._refresh_data_async())
            
        except Exception as e:
            logging.error(f"Error during data refresh: {e}")
            self.status_bar.showMessage("Error during data refresh", 3000)
    
    async def _refresh_data_async(self):
        """Recharge les données de manière asynchrone."""
        try:
            # Recharger le profil
            if hasattr(self, 'profile_widget') and self.profile_widget is not None:
                await self.profile_widget.load_profile()
            
            # Recharger les données du widget d'accueil
            if hasattr(self, 'home_widget'):
                self.home_widget.load_data()
                
                # Mettre à jour les stats cards
                if hasattr(self.home_widget, '_update_stats_cards'):
                    self.home_widget._update_stats_cards()
            
            self.status_bar.showMessage("Refreshing in progress...", 3000)
            
        except Exception as e:
            logging.error(f"Error during asynchronous data reload: {e}")
            self.status_bar.showMessage("Error during data reload", 3000)
    
    def show_theme_menu(self):
        """Affiche le menu de sélection du thème."""
        menu = QMenu(self)
        
        # Options de thème
        light_action = QAction("Light", self)
        light_action.triggered.connect(lambda: self._change_theme("light"))
        menu.addAction(light_action)
        
        dark_action = QAction("Dark", self)
        dark_action.triggered.connect(lambda: self._change_theme("dark"))
        menu.addAction(dark_action)
        
        system_action = QAction("System", self)
        system_action.triggered.connect(lambda: self._change_theme("system"))
        menu.addAction(system_action)
        
        # Afficher le menu au curseur
        pos = QCursor.pos()
        menu.exec(pos)
    
    def update_styles_for_theme(self, theme):
        """Met à jour les styles des widgets en fonction du thème.
        
        Args:
            theme (str): Nom du thème ('light' ou 'dark')
        """
        try:
            # Mettre à jour le style de la barre d'outils
            self._update_toolbar_style(theme)
            
            # Mettre à jour le style du widget de profil s'il existe
            if hasattr(self, 'profile_widget'):
                # Forcer la mise à jour du style du widget de profil
                self.profile_widget.setProperty('theme', theme)
                self.profile_widget.style().unpolish(self.profile_widget)
                self.profile_widget.style().polish(self.profile_widget)
                
                # Mettre à jour les labels du profil
                if hasattr(self.profile_widget, 'name_label'):
                    self.profile_widget.name_label.setStyleSheet(f"""
                        QLabel#userNameLabel {{
                            color: {'#ffffff' if theme == 'dark' else '#333333'};
                        }}
                    """)
                
                if hasattr(self.profile_widget, 'details_label'):
                    self.profile_widget.details_label.setStyleSheet(f"""
                        QLabel#userDetailsLabel {{
                            color: {'#bbbbbb' if theme == 'dark' else '#666666'};
                        }}
                    """)
                
                # Forcer la mise à jour du style des enfants
                for child in self.profile_widget.findChildren(QLabel):
                    child.style().unpolish(child)
                    child.style().polish(child)
                    child.update()
            
            # Mettre à jour d'autres widgets si nécessaire
            
        except Exception as e:
            logging.error(f"Style update failed: {e}")
    
    def _update_toolbar_style(self, theme):
        """Met à jour le style de la barre d'outils en fonction du thème.
        
        Args:
            theme (str): Nom du thème ('light' ou 'dark')
        """
        try:
            if not hasattr(self, 'toolbar') or not self.toolbar:
                return
            
            if theme == 'dark':
                # Style pour le thème sombre
                style = """
                    QToolBar {
                        background-color: #2b2b2b;
                        border: none;
                        border-bottom: 1px solid #3d3d3d;
                    }
                    QToolButton, QLabel {
                        color: #ffffff;
                        background: transparent;
                        border: none;
                        padding: 4px 8px;
                    }
                    QToolButton:hover {
                        background-color: #3d3d3d;
                        border-radius: 4px;
                    }
                    QLabel#userInfo {
                        color: #ffffff;
                        font-weight: bold;
                        padding: 0 10px;
                    }
                    QToolTip {
                        color: #ffffff;
                        background-color: #2b2b2b;
                        border: 1px solid #4d4d4d;
                        padding: 6px 10px;
                        border-radius: 4px;
                        font-size: 12px;
                    }
                """
            else:
                # Style pour le thème clair
                style = """
                    QToolBar {
                        background-color: #f0f0f0;
                        border: none;
                        border-bottom: 1px solid #d0d0d0;
                    }
                    QToolButton, QLabel {
                        color: #000000;
                        background: transparent;
                        border: none;
                        padding: 4px 8px;
                    }
                    QToolButton:hover {
                        background-color: #e0e0e0;
                        border-radius: 4px;
                    }
                    QToolButton:pressed {
                        background-color: #d0d0d0;
                    }
                    QLabel#userInfo {
                        color: #000000;
                        font-weight: bold;
                        padding: 0 10px;
                    }
                    QToolTip {
                        color: #000000;
                        background-color: #ffffff;
                        border: 1px solid #d0d0d0;
                        padding: 6px 10px;
                        border-radius: 4px;
                        font-size: 12px;
                    }
                """
            
            self.toolbar.setStyleSheet(style)
            
            # Mettre à jour le style des éléments de la barre d'outils
            for child in self.toolbar.findChildren((QToolButton, QLabel)):
                if isinstance(child, QLabel) and 'user_name' in child.objectName():
                    child.setStyleSheet(f"color: {'#ffffff' if theme == 'dark' else '#000000'}; font-weight: bold;")
        except Exception as e:
            logging.error(f"Erreur lors de la mise à jour du style de la barre d'outils: {e}")
            # En cas d'erreur, réinitialiser le style
            try:
                self.toolbar.setStyleSheet("")
            except:
                pass
    
    def _show_theme_notification(self, theme):
        """Affiche une notification stylisée pour le changement de thème.
        
        Args:
            theme (str): Nom du thème ('light' ou 'dark')
        """
        theme_names = {'light': 'clair', 'dark': 'sombre'}
        
        # Créer une boîte de dialogue personnalisée
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Theme modified")
        msg_box.setText(f"The theme has been changed to {theme_names[theme]}.\n\nDo you want to restart the application now?")
        
        # Ajouter les boutons personnalisés
        restart_button = msg_box.addButton("Restart", QMessageBox.ButtonRole.AcceptRole)
        later_button = msg_box.addButton("Later", QMessageBox.ButtonRole.RejectRole)
        
        # Définir le bouton par défaut
        msg_box.setDefaultButton(restart_button)
        
        # Appliquer le style en fonction du thème
        if theme == 'dark':
            msg_box.setStyleSheet("""
                QMessageBox {
                    background-color: #2b2b2b;
                    color: #ffffff;
                }
                QLabel {
                    color: #ffffff;
                }
                QPushButton {
                    background-color: #4a90e2;
                    color: white;
                    border: 1px solid #3a7bc8;
                    padding: 5px 15px;
                    border-radius: 4px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #3a7bc8;
                }
                QPushButton:pressed {
                    background-color: #2a6bb0;
                }
                QPushButton:focus {
                    border: 2px solid #ffffff;
                }
            """)
        else:
            msg_box.setStyleSheet("""
                QMessageBox {
                    background-color: #ffffff;
                    color: #333333;
                }
                QLabel {
                    color: #333333;
                }
                QPushButton {
                    background-color: #4a90e2;
                    color: white;
                    border: 1px solid #3a7bc8;
                    padding: 5px 15px;
                    border-radius: 4px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #3a7bc8;
                }
                QPushButton:pressed {
                    background-color: #2a6bb0;
                }
                QPushButton:focus {
                    border: 2px solid #4a90e2;
                }
            """)
        
        # Afficher la boîte de dialogue et attendre la réponse
        msg_box.exec()
        
        # Vérifier si l'utilisateur a cliqué sur Redémarrer
        if msg_box.clickedButton() == restart_button:
            self.restart_application()
    
    def show_help_dialog(self):
        """Affiche la boîte de dialogue d'aide."""
        try:
            from .dialogs.help_dialog import HelpDialog
            
            # Créer et afficher la boîte de dialogue d'aide
            help_dialog = HelpDialog(self)
            
            # Appliquer le thème actuel à la boîte de dialogue
            if hasattr(self, 'config') and hasattr(self.config, 'config'):
                theme = self.config.config.get('app', {}).get('theme', 'light')
                if theme == 'dark':
                    help_dialog.setStyleSheet("""
                        QDialog {
                            background-color: #2b2b2b;
                            color: #ffffff;
                        }
                        QLabel {
                            color: #ffffff;
                        }
                        QTextBrowser {
                            background-color: #2b2b2b;
                            color: #ffffff;
                            border: 1px solid #3d3d3d;
                            border-radius: 4px;
                            padding: 10px;
                        }
                        QPushButton {
                            background-color: #4a90e2;
                            color: white;
                            border: 1px solid #3a7bc8;
                            padding: 6px 12px;
                            border-radius: 4px;
                            min-width: 90px;
                        }
                        QPushButton:hover {
                            background-color: #3a7bc8;
                        }
                        QPushButton:pressed {
                            background-color: #2a6bb0;
                        }
                        QPushButton:disabled {
                            background-color: #2d2d2d;
                            color: #666666;
                            border: 1px solid #3d3d3d;
                        }
                        QPushButton#closeButton {
                            background-color: #3d3d3d;
                            color: #ffffff;
                            border: 1px solid #555555;
                        }
                        QPushButton#closeButton:hover {
                            background-color: #4d4d4d;
                        }
                    """)
                else:
                    help_dialog.setStyleSheet("""
                        QDialog {
                            background-color: #f5f5f5;
                            color: #333333;
                        }
                        QLabel {
                            color: #333333;
                        }
                        QTextBrowser {
                            background-color: #ffffff;
                            color: #333333;
                            border: 1px solid #cccccc;
                            border-radius: 4px;
                            padding: 10px;
                        }
                        QPushButton {
                            background-color: #4a90e2;
                            color: white;
                            border: 1px solid #3a7bc8;
                            padding: 6px 12px;
                            border-radius: 4px;
                            min-width: 90px;
                        }
                        QPushButton:hover {
                            background-color: #3a7bc8;
                        }
                        QPushButton:pressed {
                            background-color: #2a6bb0;
                        }
                        QPushButton:disabled {
                            background-color: #f5f5f5;
                            color: #999999;
                            border: 1px solid #dddddd;
                        }
                        QPushButton#closeButton {
                            background-color: #e0e0e0;
                            color: #333333;
                            border: 1px solid #cccccc;
                        }
                        QPushButton#closeButton:hover {
                            background-color: #d0d0d0;
                        }
                    """)
            
            # Afficher la boîte de dialogue de manière modale
            help_dialog.exec()
            
        except Exception as e:
            logging.error(f"Error opening help: {e}")
            QMessageBox.critical(
                self,
                "Error",
                f"Unable to open help: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
    
    def _change_theme(self, theme_name):
        """Change le thème de l'application.
        
        Args:
            theme_name (str): Nom du thème à appliquer (peut être en français ou anglais)
        """
        try:
            # Normaliser le nom du thème
            theme_name = theme_name.lower()
            if theme_name in ['clair', 'light']:
                theme = 'light'
            elif theme_name in ['sombre', 'dark']:
                theme = 'dark'
            elif theme_name == 'system':
                # Utiliser le thème du système
                is_dark = QPalette().color(QPalette.ColorRole.Window).lightness() < 128
                theme = 'dark' if is_dark else 'light'
            else:
                theme = 'light'  # Par défaut
            
            # Appliquer le thème à l'application
            from .theme_manager import ThemeManager
            ThemeManager.apply_application_theme(theme)
            
            # Définir l'attribut de thème sur le widget parent
            self.setProperty('theme', theme)
            self.style().unpolish(self)
            self.style().polish(self)
            
            # Mettre à jour les styles des widgets enfants
            self.update_styles_for_theme(theme)
            
            # Mettre à jour la configuration
            if hasattr(self, 'config') and hasattr(self.config, 'config'):
                if 'app' not in self.config.config:
                    self.config.config['app'] = {}
                self.config.config['app']['theme'] = theme
                self.config.save()
            
            # Mettre à jour les styles de la barre d'outils
            if hasattr(self, 'toolbar'):
                self._update_toolbar_style(theme)
            
            # Mettre à jour le style des éléments de l'interface
            if hasattr(self, 'user_name'):
                self.user_name.setStyleSheet(f"color: {'#ffffff' if theme == 'dark' else '#000000'}; font-weight: bold;")
            
            # Mettre à jour le thème de la boîte de dialogue des paramètres si elle est ouverte
            from .dialogs.settings_dialog import SettingsDialog
            for widget in QApplication.topLevelWidgets():
                if isinstance(widget, SettingsDialog):
                    widget.apply_theme_style()
                    break
            
            # Mettre à jour le thème des cartes d'entité
            if hasattr(self, 'home_widget'):
                # Parcourir tous les widgets enfants pour trouver les cartes d'entité
                for widget in self.home_widget.findChildren(QFrame, "entityCard"):
                    if hasattr(widget, 'update_theme'):
                        widget.update_theme(theme)
            
            # Émettre le signal de changement de thème
            self.theme_changed.emit(theme)
            
            # Forcer la mise à jour de tous les widgets
            # DÉSACTIVÉ TEMPORAIREMENT - QApplication.processEvents() peut créer des fenêtres blanches
            # QApplication.processEvents()
            
            # Afficher un message à l'utilisateur uniquement si ce n'est pas le démarrage initial
            if hasattr(self, '_initial_theme_applied') and self._initial_theme_applied:
                self._show_theme_notification(theme)
            else:
                self._initial_theme_applied = True
            
        except Exception as e:
            logging.error(f"Error changing theme: {e}")
            QMessageBox.critical(
                self,
                "Error",
                f"An error occurred while changing the theme: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
            
    def show_settings_dialog(self):
        """Affiche la boîte de dialogue des paramètres."""
        # Créer et afficher la boîte de dialogue
        dialog = SettingsDialog(self.config, self)
        
        # Appliquer le thème actuel à la boîte de dialogue
        if hasattr(self, 'config') and hasattr(self.config, 'config'):
            theme = self.config.config.get('app', {}).get('theme', 'light')
            dialog.apply_theme_style()
        
        # Connecter le signal de sauvegarde
        dialog.settings_saved.connect(self.on_settings_saved)
        
        # Afficher la boîte de dialogue de manière modale
        dialog.exec()
    
    def on_settings_saved(self, settings):
        """Appelé lorsque les paramètres sont enregistrés dans la boîte de dialogue."""
        try:
            # Mettre à jour la configuration en mémoire
            for section, values in settings.items():
                if section not in self.config.config:
                    self.config.config[section] = {}
                self.config.config[section].update(values)
            
            # Sauvegarder la configuration sur le disque
            self.config.save()
            
            # Mettre à jour la configuration du client Telegram
            if 'telegram' in settings:
                self.telegram_client.update_config(settings['telegram'])
            
            # Afficher un message de confirmation
            QMessageBox.information(
                self,
                "Settings saved",
                "The settings have been successfully saved.",
                QMessageBox.StandardButton.Ok
            )
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"An error occurred while saving the settings: {str(e)}",
                QMessageBox.StandardButton.Ok
            )

    def save_settings(self, dialog):
        """Ancienne méthode de sauvegarde des paramètres (conservée pour compatibilité)."""
        try:
            # Récupérer le chemin du fichier de configuration
            config_path = Path(__file__).parent.parent.parent.parent / 'config.ini'
            
            # Lire la configuration existante
            config = configparser.ConfigParser()
            config.read(config_path, encoding='utf-8')
            
            # Mettre à jour les valeurs
            if 'telegram' not in config:
                config['telegram'] = {}
                
            config['telegram']['api_id'] = self.api_id_edit.text()
            config['telegram']['api_hash'] = self.api_hash_edit.text()
            
            # Sauvegarder les modifications
            with open(config_path, 'w', encoding='utf-8') as configfile:
                config.write(configfile)
            
            # Mettre à jour la configuration en mémoire
            self.config = Config(str(config_path))
            
            # Fermer la boîte de dialogue
            dialog.accept()
            
            # Afficher un message de confirmation
            QMessageBox.information(
                self,
                "Settings saved",
                "The settings have been successfully saved.",
                QMessageBox.StandardButton.Ok
            )
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"An error occurred while saving the settings : {str(e)}",
                QMessageBox.StandardButton.Ok
            )
    
    def show_save_credentials_dialog(self):
        """Affiche la boîte de dialogue pour sauvegarder les informations d'identification."""
        try:
            # Créer le widget de sauvegarde des credentials
            save_credentials_widget = SaveCredentialsWidget(self.config, self)
            
            # Créer une boîte de dialogue modale
            dialog = QDialog(self)
            dialog.setWindowTitle("Telegram Identifiers")
            dialog.setMinimumSize(650, 400)
            dialog.resize(750, 500)
            
            # Layout pour la boîte de dialogue
            layout = QVBoxLayout(dialog)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.setSpacing(0)
            
            # Ajouter le widget
            layout.addWidget(save_credentials_widget)
            
            # Connecter le signal de sauvegarde réussie
            save_credentials_widget.credentials_saved.connect(dialog.accept)
            
            # Surcharge de l'événement de fermeture pour vérifier les modifications non sauvegardées
            def has_unsaved_changes():
                """Vérifie s'il y a des modifications non sauvegardées."""
                for entry in save_credentials_widget.entries:
                    # Vérifier si l'entrée a du contenu mais n'est pas sauvegardée
                    if not entry.is_saved:
                        data = entry.get_data()
                        if data['phone'].strip() or data['api_id'].strip() or data['api_hash'].strip():
                            return True
                return False
            
            def closeEvent(event):
                """Gère l'événement de fermeture avec confirmation."""
                if has_unsaved_changes():
                    # Détecter le thème actuel de manière fiable
                    bg_color = dialog.palette().color(dialog.backgroundRole())
                    is_dark = bg_color.lightness() < 128
                    
                    # Créer le message box
                    msg_box = QMessageBox(dialog)
                    msg_box.setWindowTitle("Unsaved changes")
                    msg_box.setText("Do you want to save your changes before closing ?")
                    msg_box.setStandardButtons(QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Discard)
                    msg_box.setDefaultButton(QMessageBox.StandardButton.Save)
                    msg_box.button(QMessageBox.StandardButton.Save).setText("Save")
                    msg_box.button(QMessageBox.StandardButton.Cancel).setText("Cancel")
                    msg_box.button(QMessageBox.StandardButton.Discard).setText("Discard")
                    
                    # Appliquer le style en fonction du thème
                    if is_dark:
                        msg_box.setStyleSheet("""
                            QMessageBox {
                                background-color: #2d2d2d;
                                border: none;
                            }
                            QMessageBox QLabel {
                                color: #ffffff;
                                background-color: transparent;
                                border: none;
                            }
                            QMessageBox QPushButton {
                                background-color: #3d3d3d;
                                color: #ffffff;
                                border: 1px solid #4d4d4d;
                                padding: 4px 8px;
                                border-radius: 4px;
                                min-width: 70px;
                            }
                            QMessageBox QPushButton:hover {
                                background-color: #4d4d4d;
                            }
                            QMessageBox QPushButton:pressed {
                                background-color: #2a6ea5;
                            }
                        """)
                    
                    reply = msg_box.exec()
                    
                    if reply == QMessageBox.StandardButton.Save:
                        # Tenter de sauvegarder toutes les entrées avec du contenu
                        try:
                            saved_count = 0
                            for entry in save_credentials_widget.entries:
                                data = entry.get_data()
                                if (data['phone'].strip() or data['api_id'].strip() or data['api_hash'].strip()):
                                    if not entry.is_saved:
                                        save_credentials_widget.save_individual_entry(entry)
                                        saved_count += 1
                            if saved_count > 0:
                                # Détecter le thème actuel de manière fiable
                                bg_color = dialog.palette().color(dialog.backgroundRole())
                                is_dark = bg_color.lightness() < 128
                                
                                # Créer le message box avec style approprié
                                msg_box = QMessageBox(dialog)
                                msg_box.setWindowTitle("Success")
                                if saved_count == 1:
                                    msg_box.setText(f"{saved_count} saved entry.")
                                else:
                                    msg_box.setText(f"{saved_count} saved entries.")
                                msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
                                
                                # Appliquer le style en fonction du thème
                                if is_dark:
                                    msg_box.setStyleSheet("""
                                        QMessageBox {
                                            background-color: #2d2d2d;
                                            border: none;
                                        }
                                        QMessageBox QLabel {
                                            color: #ffffff;
                                            background-color: transparent;
                                            border: none;
                                        }
                                        QMessageBox QPushButton {
                                            background-color: #3d3d3d;
                                            color: #ffffff;
                                            border: 1px solid #4d4d4d;
                                            padding: 4px 8px;
                                            border-radius: 4px;
                                            min-width: 70px;
                                        }
                                        QMessageBox QPushButton:hover {
                                            background-color: #4d4d4d;
                                        }
                                        QMessageBox QPushButton:pressed {
                                            background-color: #2a6ea5;
                                        }
                                    """)
                                
                                msg_box.exec()
                            event.accept()
                        except Exception as e:
                            QMessageBox.warning(dialog, "Error", f"Saving error: {str(e)}")
                            event.ignore()
                    elif reply == QMessageBox.StandardButton.Discard:
                        event.accept()
                    else:  # Cancel
                        event.ignore()
                else:
                    event.accept()
            
            dialog.closeEvent = closeEvent
            
            # Appliquer le thème actuel
            if hasattr(self, 'config') and hasattr(self.config, 'config'):
                theme = self.config.config.get('app', {}).get('theme', 'light')
                if theme == 'dark':
                    dialog.setStyleSheet("""
                        QDialog {
                            background-color: #2b2b2b;
                            color: #ffffff;
                        }
                        QLabel {
                            color: #ffffff;
                        }
                        QLineEdit {
                            background-color: #3d3d3d;
                            color: #ffffff;
                            border: 1px solid #555555;
                            padding: 5px;
                            border-radius: 4px;
                        }
                        QPushButton {
                            background-color: #4a90e2;
                            color: white;
                            border: 1px solid #3a7bc8;
                            padding: 8px 16px;
                            border-radius: 4px;
                            font-weight: bold;
                        }
                        QPushButton:hover {
                            background-color: #3a7bc8;
                        }
                        QPushButton:pressed {
                            background-color: #2a6bb0;
                        }
                        QScrollArea {
                            background-color: #2b2b2b;
                            border: 1px solid #555555;
                        }
                        QFrame {
                            background-color: #3d3d3d;
                            color: #ffffff;
                            border: 1px solid #555555;
                        }
                    """)
            
            # Afficher la boîte de dialogue de manière modale
            if dialog.exec():
                logging.info("Save credentials dialog completed successfully")
            else:
                logging.info("Save credentials dialog cancelled")
            
        except Exception as e:
            logging.error(f"Error opening the save credentials dialog: {e}")
            QMessageBox.critical(
                self,
                "Error",
                f"An error occurred while opening the save credentials dialog: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
    
    def on_settings_updated(self, settings):
        """Appelé lorsque les paramètres sont mis à jour."""
        # Mettre à jour la configuration en mémoire
        if 'telegram' in settings:
            self.telegram_client.update_config(settings['telegram'])
            
        # Rafraîchir l'interface si nécessaire
        self.setup_ui()
