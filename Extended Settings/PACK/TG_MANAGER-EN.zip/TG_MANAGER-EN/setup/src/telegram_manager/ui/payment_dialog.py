"""
Boîte de dialogue pour le processus de paiement avec Coinbase Commerce.
"""
import logging
import webbrowser
from typing import Dict, Optional, Any

from PyQt6.QtCore import Qt, QTimer, QUrl, pyqtSignal, pyqtSlot
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout,
    QProgressBar, QMessageBox, QApplication
)

from ..payment.coinbase_commerce import CoinbaseCommerceClient

class PaymentDialog(QDialog):
    """Boîte de dialogue pour gérer le processus de paiement."""
    
    # Signaux
    payment_verified = pyqtSignal(dict)  # Émis lorsque le paiement est vérifié
    payment_failed = pyqtSignal(str)     # Émis en cas d'échec du paiement
    
    def __init__(self, payment_client: CoinbaseCommerceClient, amount: float,
                 currency: str = 'USD', parent=None):
        """
        Initialise la boîte de dialogue de paiement.
        
        Args:
            payment_client: Client CoinbaseCommerce
            amount: Montant à payer
            currency: Devise (par défaut: USD)
            parent: Widget parent
        """
        super().__init__(parent)
        self.payment_client = payment_client
        self.amount = amount
        self.currency = currency
        self.charge_data = None
        self.check_timer = QTimer(self)
        self.check_timer.timeout.connect(self.check_payment_status)
        self.check_count = 0  # Compteur de tentatives de vérification
        
        # Récupérer l'ID unique de l'appareil
        from telegram_manager.utils.device_id import get_or_create_device_id
        self.device_id = get_or_create_device_id()
        
        self.setWindowTitle("License Payment")
        self.setMinimumSize(400, 250)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        
        self.setup_ui()
        self.create_payment()
    
    def setup_ui(self):
        """Configure l'interface utilisateur de la boîte de dialogue."""
        layout = QVBoxLayout(self)
        
        # Titre
        title = QLabel("License Payment")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Montant
        amount_label = QLabel(f"Amount: {self.amount} {self.currency}")
        amount_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Instructions
        instructions = QLabel(
            "Please complete the payment to generate your monthly license (valid 30 days). "
            "The verification process may take a few moments after the payment."
        )
        instructions.setWordWrap(True)
        
        # Barre de progression
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)  # Commence à 0%
        self.progress_bar.setTextVisible(True)  # Afficher le pourcentage
        
        # Style minimal pour garantir la visibilité à 100% tout en gardant l'apparence d'origine
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #5DADE2;
            }
        """)
        
        # Boutons
        button_layout = QHBoxLayout()
        
        self.pay_button = QPushButton("Open Payment Page")
        self.pay_button.clicked.connect(self.open_payment_page)
        
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        self.cancel_button.setEnabled(True)  # S'assurer qu'il est activé au début
        
        button_layout.addWidget(self.pay_button)
        button_layout.addWidget(self.cancel_button)
        
        # Status
        self.status_label = QLabel("Ready to make the payment...")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Add widgets to layout
        layout.addWidget(title)
        layout.addWidget(amount_label)
        layout.addSpacing(10)
        layout.addWidget(instructions)
        layout.addSpacing(10)
        layout.addWidget(self.progress_bar)
        layout.addSpacing(10)
        layout.addWidget(self.status_label)
        layout.addLayout(button_layout)
    
    def create_payment(self):
        """Create a new payment charge."""
        self.status_label.setText("Creating transaction...")
        QApplication.processEvents()
        
        # Données utilisateur supplémentaires
        user_data = {
            'user_id': 'user_123',  # À remplacer par l'ID utilisateur réel
            'product': 'monthly_license',
            'validity_days': 30
        }
        
        # Create payment charge
        self.charge_data = self.payment_client.create_charge(
            amount=self.amount,
            currency=self.currency,
            name="License Software",
            description=f"License valid for 1 month - {self.amount} {self.currency}",
            user_data=user_data
        )
        
        if not self.charge_data:
            self.status_label.setText("Error creating payment")
            self.pay_button.setEnabled(False)
            return
        
        self.pay_button.setEnabled(True)
        self.status_label.setText("Ready to make the payment")
    
    def open_payment_page(self):
        """Open the payment page in the default browser."""
        if not self.charge_data:
            QMessageBox.critical(
                self,
                "Error",
                "Unable to open the payment page. Please try again.",
                QMessageBox.StandardButton.Ok
            )
            return
        
        payment_url = self.payment_client.get_payment_url(self.charge_data)
        if not payment_url:
            QMessageBox.critical(
                self,
                "Error",
                "Invalid payment URL. Please try again.",
                QMessageBox.StandardButton.Ok
            )
            return
        
        # Open the URL in the default browser
        webbrowser.open(payment_url)
        
        # Disable the payment button and start verification
        self.pay_button.setEnabled(False)
        self.status_label.setText("Waiting for payment confirmation...")
        
        # Mettre la barre de progression à 25% (paiement initié)
        self.progress_bar.setValue(25)
        
        self.check_timer.start(3000)  # Polling stable à 3 secondes
    
    def check_payment_status(self):
        """Vérifie le statut du paiement et valide l'identité de l'appareil."""
        if not self.charge_data or 'id' not in self.charge_data:
            self.payment_failed.emit("Payment data is invalid")
            self.reject()
            return
        
        self.check_count += 1
        charge_id = self.charge_data['id']
        logging.info(f"Checking payment status for charge: {charge_id} (attempt #{self.check_count})")
        
        # Vérifier le statut du paiement en incluant la vérification de l'appareil
        success, data = self.payment_client.verify_payment(
            charge_id=charge_id,
            expected_device_id=self.device_id
        )
        
        logging.info(f"Payment verification result: success={success}, data={data}")
        
        if success:
            self.handle_successful_payment(data)
        else:
            self.handle_payment_status(data)
        
        # Polling unique et stable : 3 secondes constantes
        # Évite les micro-bugs visuels des changements de fréquence
        interval = 3000  # 3 secondes fixes
        
        # Redémarrer le timer avec l'intervalle stable
        self.check_timer.stop()
        self.check_timer.start(interval)
    
    def handle_successful_payment(self, data: dict):
        """Traite un paiement réussi."""
        self.check_timer.stop()
        
        # Mettre la barre de progression à 100% (paiement réussi)
        self.progress_bar.setValue(100)
        
        self.status_label.setText("Payment confirmed!")
        
        # Extraire les informations de la transaction
        metadata = data.get('metadata', {})
        transaction_id = metadata.get('transaction_id', 'N/A')
        
        QMessageBox.information(
            self,
            "Payment successful",
            f"Your payment has been confirmed successfully.\n"
            f"Transaction ID: {transaction_id}\n\n"
            "Your license generation will begin now.",
            QMessageBox.StandardButton.Ok
        )
        
        # Émettre le signal avec les données complètes
        self.payment_verified.emit(data)
        self.accept()
    
    def handle_payment_status(self, data: dict):
        """Gère les différents statuts de paiement."""
        if not data:
            logging.warning("Empty payment status data received")
            return
        
        # Vérifier les erreurs spécifiques
        if data.get('error') == 'device_mismatch':
            logging.error("Device ID mismatch detected")
            self.check_timer.stop()
            QMessageBox.critical(
                self,
                "Security error",
                "The payment could not be verified on this device. "
                "Please use the same device that was used for the payment.",
                QMessageBox.StandardButton.Ok
            )
            self.payment_failed.emit("Device ID mismatch")
            self.reject()
            return
        
        # Gérer les statuts de paiement
        status = data.get('status', '').upper()
        logging.info(f"Processing payment status: {status}")
        
        # Statuts qui indiquent un succès immédiat
        success_statuses = ['CONFIRMED', 'COMPLETED', 'RESOLVED']
        if status in success_statuses:
            logging.info(f"Payment successful with status: {status}")
            self.handle_successful_payment(data)
            return
        
        status_messages = {
            'NEW': "Payment initiated, checking...",
            'PENDING': "Payment made, confirming...",
            'EXPIRED': "Payment expired",
            'UNRESOLVED': "Payment problem - please contact support",
            'CANCELED': "Payment canceled",
            'FAILED': "Payment failed - please try again"
        }
        
        # Mettre à jour le statut avec le compteur
        base_message = status_messages.get(status, f"Status: {status}")
        if status in ['NEW', 'PENDING']:
            status_text = f"{base_message} {self.check_count}"
            
            # Faire évoluer la barre de progression selon le statut
            if status == 'NEW':
                self.progress_bar.setValue(30)  # Début de vérification
            elif status == 'PENDING':
                self.progress_bar.setValue(60)  # Paiement reçu, en confirmation
                # Désactiver le bouton Cancel pendant la confirmation
                self.cancel_button.setEnabled(False)
            
            # Ajouter un message informatif pour PENDING (affiché en continu)
            if status == 'PENDING':
                # Message contextuel bien positionné sous le statut
                info_text = f"<br><span style='color: #28a745;'>Please wait. Confirmation may take up to 5 minutes.</span>"
                self.status_label.setText(status_text + info_text)
            else:
                self.status_label.setText(status_text)
        else:
            status_text = base_message
            self.status_label.setText(status_text)
            
            # Pour les statuts d'échec, mettre la barre à 0 et réactiver Cancel
            if status in ['EXPIRED', 'UNRESOLVED', 'CANCELED', 'FAILED']:
                self.progress_bar.setValue(0)
                self.cancel_button.setEnabled(True)  # Réactiver pour permettre la fermeture
        
        # Si le paiement a échoué ou a expiré
        if status in ['EXPIRED', 'UNRESOLVED', 'CANCELED', 'FAILED']:
            self.check_timer.stop()
            self.payment_failed.emit(f"Payment failed: {status}")
            
            # Afficher un message d'erreur détaillé
            error_msg = data.get('error', 'Unknown error')
            QMessageBox.warning(
                self,
                "Payment problem",
                f"The payment did not succeed.\n\n"
                f"Reason: {status_text}\n"
                f"Details: {error_msg}",
                QMessageBox.StandardButton.Ok
            )
            self.reject()
    
    def reject(self):
        """Annule le processus de paiement et la transaction web."""
        self.check_timer.stop()
        
        # Annuler la transaction sur Coinbase si elle existe
        if self.charge_data and 'id' in self.charge_data:
            try:
                charge_id = self.charge_data['id']
                logging.info(f"Cancelling Coinbase charge: {charge_id}")
                
                # Appeler l'API pour annuler/expire la charge
                cancel_result = self.payment_client.cancel_charge(charge_id)
                if cancel_result:
                    logging.info(f"Charge {charge_id} cancelled successfully")
                else:
                    logging.warning(f"Failed to cancel charge {charge_id}")
            except Exception as e:
                logging.error(f"Error cancelling charge: {str(e)}")
        
        super().reject()
    
    def closeEvent(self, event):
        """Gère la fermeture de la fenêtre et annule la transaction web."""
        self.check_timer.stop()
        
        # Annuler la transaction sur Coinbase si elle existe
        if self.charge_data and 'id' in self.charge_data:
            try:
                charge_id = self.charge_data['id']
                logging.info(f"Cancelling Coinbase charge on window close: {charge_id}")
                
                # Appeler l'API pour annuler/expire la charge
                cancel_result = self.payment_client.cancel_charge(charge_id)
                if cancel_result:
                    logging.info(f"Charge {charge_id} cancelled successfully on close")
                else:
                    logging.warning(f"Failed to cancel charge {charge_id} on close")
            except Exception as e:
                logging.error(f"Error cancelling charge on close: {str(e)}")
        
        super().closeEvent(event)
