"""Boîte de dialogue pour afficher les notifications du gestionnaire de membres."""
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QListWidget, QListWidgetItem, 
                           QPushButton, QHBoxLayout, QLabel, QSpacerItem, 
                           QSizePolicy, QFrame, QApplication)
from PyQt6.QtCore import Qt, QDateTime, QTimer
from PyQt6.QtGui import QColor

# Utilitaires
from ..utils import set_window_icon

class NotificationDialog(QDialog):
    """Boîte de dialogue affichant les notifications du gestionnaire de membres."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Members Manager Notifications")
        self.setMinimumSize(400, 300)
        
        # Définir l'icône de la fenêtre
        set_window_icon(self, "notification_icon")
        
        self.setup_ui()
        
    def is_dark_theme(self):
        """Détecte si le thème actuel est sombre."""
        # Vérifie la couleur de fond de la fenêtre parente
        bg_color = self.palette().color(self.backgroundRole())
        return bg_color.lightness() < 128
        
    def update_styles(self):
        """Met à jour les styles en fonction du thème."""
        if self.is_dark_theme():
            # Style pour thème sombre
            self.clear_btn.setStyleSheet("""
                QPushButton {
                    padding: 5px 12px;
                    border: 1px solid #4d4d4d;
                    border-radius: 4px;
                    background-color: #3d3d3d;
                    color: #ffffff;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #4d4d4d;
                    border-color: #5d5d5d;
                }
                QPushButton:pressed {
                    background-color: #3a6ea5;
                }
            """)
            self.notif_list.setStyleSheet("""
                QListWidget {
                    border: 1px solid #4d4d4d;
                    border-radius: 4px;
                    padding: 5px;
                    background-color: #2d2d2d;
                    color: #e0e0e0;
                    outline: none;
                    font-size: 13px;
                }
                QListWidget::item {
                    padding: 0;
                    border: none;
                    margin-bottom: 5px;
                    background: transparent;
                }
                QListWidget::item:selected {
                    background: transparent;
                }
                QScrollBar:vertical {
                    border: none;
                    background: #2d2d2d;
                    width: 10px;
                    border-radius: 5px;
                    margin: 0px;
                }
                QScrollBar::handle:vertical {
                    background: #4d4d4d;
                    min-height: 20px;
                    border-radius: 5px;
                }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                    height: 0px;
                }
            """)
        else:
            # Style pour thème clair
            self.clear_btn.setStyleSheet("""
                QPushButton {
                    padding: 5px 12px;
                    border: 1px solid #d0d0d0;
                    border-radius: 4px;
                    background-color: #f5f5f5;
                    color: #333333;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #e0e0e0;
                    border-color: #b0b0b0;
                }
                QPushButton:pressed {
                    background-color: #2196F3;
                    color: white;
                }
            """)
            self.notif_list.setStyleSheet("""
                QListWidget {
                    border: 1px solid #d0d0d0;
                    border-radius: 4px;
                    padding: 5px;
                    background-color: #ffffff;
                    color: #333333;
                    outline: none;
                    font-size: 13px;
                }
                QListWidget::item {
                    padding: 0;
                    border: none;
                    margin-bottom: 5px;
                    background: transparent;
                }
                QListWidget::item:selected {
                    background: transparent;
                }
                QScrollBar:vertical {
                    border: none;
                    background: #f5f5f5;
                    width: 10px;
                    border-radius: 5px;
                    margin: 0px;
                }
                QScrollBar::handle:vertical {
                    background: #c0c0c0;
                    min-height: 20px;
                    border-radius: 5px;
                }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                    height: 0px;
                }
            """)
    
    def setup_ui(self):
        """Configure l'interface utilisateur de la boîte de dialogue."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        
        # En-tête
        header = QHBoxLayout()
        title = QLabel("💬")
        title.setObjectName("notificationTitle")
        title.setStyleSheet("""
            QLabel#notificationTitle {
                font-family: 'Segoe UI Semibold', 'Arial Black', 'Arial', sans-serif;
                font-size: 20px;
                font-weight: 700;
                color: #2980b9;
                padding: 4px 0;
                letter-spacing: 0.5px;
                margin-bottom: 12px;
                border-bottom: 2px solid #3498db;
                padding-bottom: 6px;
            }
        """)
        
        self.clear_btn = QPushButton("Clear all")
        
        header.addWidget(title)
        header.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum))
        header.addWidget(self.clear_btn)
        
        # Liste des notifications
        self.notif_list = QListWidget()
        self.update_styles()
        
        layout.addLayout(header)
        layout.addWidget(self.notif_list)
        
        # Connexions
        self.clear_btn.clicked.connect(self.clear_notifications)
        
    def add_notification(self, message, is_error=False):
        """Ajoute une notification à la liste.
        
        Args:
            message (str): Le message de notification
            is_error (bool): Si True, affiche une icône d'erreur
        """
        time_str = QDateTime.currentDateTime().toString("HH:mm:ss")
        item = QListWidgetItem()
        
        # Créer un widget personnalisé pour la notification
        widget = QFrame()
        widget.setFrameShape(QFrame.Shape.StyledPanel)
        
        # Style selon le type de notification et le thème
        if self.is_dark_theme():
            if is_error:
                widget.setStyleSheet("""
                    QFrame {
                        background: #3d1e1e;
                        border: 1px solid #7f3f3f;
                        border-radius: 4px;
                        padding: 8px 12px;
                        color: #ffb3b3;
                    }
                """)
                icon = "❌"
            else:
                widget.setStyleSheet("""
                    QFrame {
                        background: #1e2a3d;
                        border: 1px solid #3f5f7f;
                        border-radius: 4px;
                        padding: 8px 12px;
                        color: #b3c9e5;
                    }
                """)
                icon = "ℹ️"
        else:
            if is_error:
                widget.setStyleSheet("""
                    QFrame {
                        background: #ffebee;
                        border: 1px solid #ef9a9a;
                        border-radius: 4px;
                        padding: 8px 12px;
                        color: #c62828;
                    }
                """)
                icon = "❌"
            else:
                widget.setStyleSheet("""
                    QFrame {
                        background: #e3f2fd;
                        border: 1px solid #90caf9;
                        border-radius: 4px;
                        padding: 8px;
                        color: #0d47a1;
                    }
                """)
                icon = "ℹ️"
            
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(2)
        
        # En-tête avec l'heure et l'icône
        header = QHBoxLayout()
        time_label = QLabel(f"<small>{time_str}</small>")
        time_label.setStyleSheet(f"color: {'#a0a0a0' if self.is_dark_theme() else '#666666'};")
        
        icon_label = QLabel(icon)
        
        header.addWidget(icon_label)
        header.addWidget(time_label)
        header.addSpacerItem(QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum))
        
        # Message
        message_label = QLabel(message)
        message_label.setWordWrap(True)
        message_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        
        layout.addLayout(header)
        layout.addWidget(message_label)
        
        # Définir la taille de l'élément
        item.setSizeHint(widget.sizeHint())
        
        # Ajouter l'élément à la liste
        self.notif_list.addItem(item)
        self.notif_list.setItemWidget(item, widget)
        
        # Faire défiler vers le bas pour voir le nouveau message
        self.notif_list.scrollToBottom()
    
    def clear_notifications(self):
        """Efface toutes les notifications."""
        self.notif_list.clear()
        
    def showEvent(self, event):
        """Surcharge de l'événement d'affichage pour positionner la fenêtre."""
        super().showEvent(event)
        
        # Mettre à jour les styles en fonction du thème
        self.update_styles()
        
        # Positionner la fenêtre en haut à droite de l'écran
        screen = QApplication.primaryScreen().availableGeometry()
        x = screen.width() - self.width() - 20
        self.move(x, 40)
        
        # Mettre la fenêtre au premier plan
        self.raise_()
        self.activateWindow()
