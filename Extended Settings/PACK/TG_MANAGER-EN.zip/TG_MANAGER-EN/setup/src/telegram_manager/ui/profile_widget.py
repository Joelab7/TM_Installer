"""
Widget pour afficher et gérer le profil utilisateur Telegram.
"""
import asyncio
import logging
from PyQt6.QtCore import Qt, QSize, pyqtSignal, QRectF, QTimer
from PyQt6.QtGui import QPixmap, QImage, QPainter, QPainterPath, QColor, QIcon, QFont
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFormLayout, QSizePolicy, 
    QStyle, QApplication, QPushButton, QMenu, QToolButton
)
from .dialogs.notification_dialog import NotificationDialog
import sys
import os

# Ajouter le chemin du dossier Program au sys.path
# Chercher dans le répertoire d'installation de l'application
current_dir = os.path.dirname(os.path.abspath(__file__))
print(f"📍 Fichier actuel: {current_dir}")

# Chemin vers le dossier Program de l'application installée
program_path = r'C:\Program Files\Telegram Manager\Program'
print(f"📍 Chemin Program installation: {program_path}")
print(f"📍 Existe Program: {os.path.exists(program_path)}")

# Alternative: depuis le répertoire d'exécution
exec_dir = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.getcwd()
alt_program_path = os.path.join(exec_dir, 'Program')
print(f"📍 Chemin Program depuis exécutable: {alt_program_path}")
print(f"📍 Existe Program alternatif: {os.path.exists(alt_program_path)}")

# Utiliser le chemin qui existe
final_program_path = None
if os.path.exists(program_path):
    final_program_path = program_path
elif os.path.exists(alt_program_path):
    final_program_path = alt_program_path

if final_program_path:
    # Vérifier si le dossier security existe
    security_path = os.path.join(final_program_path, 'security')
    print(f"📍 Chemin security: {security_path}")
    print(f"📍 Existe security: {os.path.exists(security_path)}")

    if os.path.exists(security_path):
        print(f"📂 Contenu de security: {os.listdir(security_path)}")
        
        # Vérifier si license_manager.py existe
        license_manager_path = os.path.join(security_path, 'license_manager.py')
        print(f"📍 license_manager.py existe: {os.path.exists(license_manager_path)}")

    # Ajouter le chemin Program au sys.path pour permettre l'import de security.license_manager
    if final_program_path not in sys.path:
        sys.path.insert(0, final_program_path)
        print(f"✅ Chemin Program ajouté au sys.path: {final_program_path}")
        print(f"📋 sys.path contient maintenant: {sys.path[:3]}...")  # Afficher les 3 premiers chemins
else:
    print(f"❌ Aucun chemin Program trouvé")

# Import du LicenseManager
try:
    from security.license_manager import LicenseManager
    print("✅ LicenseManager importé avec succès")
    
    # Test immédiat pour vérifier que le LicenseManager fonctionne
    test_manager = LicenseManager()
    print(f"✅ LicenseManager instance créée: {type(test_manager)}")
    
    # Test de validation pour voir si la logique fonctionne
    test_result = test_manager.validate_license()
    print(f"🧪 Test validation: {test_result}")
    
    if isinstance(test_result, dict) and 'valid' in test_result:
        print("✅ LicenseManager fonctionne correctement")
    else:
        print("❌ LicenseManager ne retourne pas le bon format")
        
except ImportError as import_error:
    print(f"❌ Erreur import LicenseManager: {import_error}")
    error_message = str(import_error)  # Sauvegarder le message d'erreur
    # Si l'import échoue, créer une classe de substitution
    class LicenseManager:
        def validate_license(self, license_key=None):
            return {'valid': False, 'message': f'License manager not available: {error_message}'}
        def __init__(self, *args, **kwargs):
            pass
except Exception as e:
    print(f"❌ Erreur lors du test du LicenseManager: {e}")
    error_message = str(e)
    class LicenseManager:
        def validate_license(self, license_key=None):
            return {'valid': False, 'message': f'License manager test failed: {error_message}'}
        def __init__(self, *args, **kwargs):
            pass

class ProfileWidget(QWidget):
    """Widget pour afficher le profil utilisateur."""
    
    logout_requested = pyqtSignal()
    
    def __init__(self, telegram_client, parent=None):
        super().__init__(parent)
        self.telegram_client = telegram_client
        self.notification_count = 0
        self.notification_dialog = None
        self.license_status = 'unknown'  # 'active', 'inactive', 'unknown'
        self.setup_ui()
        # Ne pas charger le profil ici, ce sera fait par le parent
        self._profile_loaded = False
        
        # Si aucun client n'est fourni, afficher un profil vide
        if telegram_client is None:
            self.show_empty_profile()
    
    def setup_ui(self):
        """Configure l'interface utilisateur."""
        # Layout principal avec marges et espacement réduits
        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 2, 4, 2)
        layout.setSpacing(4)
        
        # Photo de profil plus petite et bien cadrée
        self.photo_label = QLabel()
        photo_size = 32  # Augmenté pour s'adapter à la nouvelle hauteur
        self.photo_label.setFixedSize(photo_size, photo_size)
        self.photo_label.setStyleSheet(f"""
            QLabel {{
                border: 1px solid #0088cc;
                border-radius: {photo_size//2}px;
                background-color: #f0f0f0;
                min-width: {photo_size}px;
                max-width: {photo_size}px;
                min-height: {photo_size}px;
                max-height: {photo_size}px;
                qproperty-alignment: AlignCenter;
                padding: 0px;
                margin: 0px;
            }}
        """)
        
        # Layout pour les informations du profil (sans badge)
        info_layout = QVBoxLayout()
        info_layout.setContentsMargins(0, 0, 0, 0)
        info_layout.setSpacing(0)
        info_layout.setAlignment(Qt.AlignmentFlag.AlignVCenter)  # Centre le contenu verticalement
        
        # Layout horizontal pour nom et badge (maintenant seulement pour le badge potentiel)
        name_badge_layout = QHBoxLayout()
        name_badge_layout.setContentsMargins(0, 0, 0, 0)
        name_badge_layout.setSpacing(2)  # Espacement réduit
        name_badge_layout.setAlignment(Qt.AlignmentFlag.AlignVCenter)  # Centré verticalement
        
        # Nom complet en plus grand et en gras
        self.name_label = QLabel()
        self.name_label.setObjectName('userNameLabel')  # Ajout d'un nom d'objet pour le cibler dans les styles
        self.name_label.setStyleSheet("""
            QLabel#userNameLabel {
                font-weight: bold;
                font-size: 10px;
                color: #333333;
                margin: 0px;
                padding: 0px;
                line-height: 1.1;
            }
            
            /* Style pour le thème sombre */
            [theme="dark"] QLabel#userNameLabel {
                color: #ffffff;
            }
            
            /* Style pour le thème clair */
            [theme="light"] QLabel#userNameLabel {
                color: #333333;
            }
        """)
        
        # Ajouter le nom au layout horizontal
        name_badge_layout.addWidget(self.name_label, 1)  # Le nom prend l'expansion
        
        # Badge de licence moderne
        self.license_badge = QLabel()
        self.license_badge.setObjectName('licenseBadge')
        self.license_badge.setStyleSheet("""
            QLabel#licenseBadge {
                font-size: 9px;
                font-weight: 400;  /* Normal, pas gras */
                padding: 4px 8px;
                border-radius: 12px;
                qproperty-alignment: AlignCenter;
                min-width: 100px;
                max-width: 115px;
                min-height: 20px;
                max-height: 20px;
                border: 1px solid transparent;
                text-transform: none;  /* Pas de majuscules forcées */
                letter-spacing: 0.1px;
                margin-top: 0px;  /* Géré par le layout container */
            }
            QLabel#licenseBadge[status="active"] {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #e8f5e8, stop:1 #d4edda);
                color: #0d5f0d;  /* Vert plus foncé */
                border: 1px solid #c3e6cb;
            }
            QLabel#licenseBadge[status="inactive"] {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #fff3cd, stop:1 #ffeaa7);
                color: #664d03;  /* Marron plus foncé */
                border: 1px solid #ffeaa7;
            }
            QLabel#licenseBadge[status="unknown"] {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #f8d7da, stop:1 #f5c6cb);
                color: #491217;  /* Rouge plus foncé */
                border: 1px solid #f5c6cb;
            }
            /* Thème sombre - badge plus transparent avec texte plus clair */
            [theme="dark"] QLabel#licenseBadge[status="active"] {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 rgba(93, 184, 93, 0.5), stop:1 rgba(76, 174, 76, 0.5));
                color: #d4edda;  /* Vert clair pour le thème sombre */
                border: 1px solid rgba(76, 174, 76, 0.7);
            }
            [theme="dark"] QLabel#licenseBadge[status="inactive"] {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 rgba(240, 173, 78, 0.5), stop:1 rgba(238, 162, 54, 0.5));
                color: #ffeaa7;
                border: 1px solid rgba(238, 162, 54, 0.7);
            }
            [theme="dark"] QLabel#licenseBadge[status="unknown"] {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 rgba(217, 83, 79, 0.3), stop:1 rgba(212, 63, 58, 0.3));
                color: #f5c6cb;
                border: 1px solid rgba(212, 63, 58, 0.5);
            }
        """)
        self.license_badge.setText("...")
        self.license_badge.setProperty("status", "unknown")
        self.license_badge.hide()
        
        # Détails en plus petit et plus discret
        self.details_label = QLabel()
        self.details_label.setObjectName('userDetailsLabel')  # Ajout d'un nom d'objet pour le cibler dans les styles
        self.details_label.setStyleSheet("""
            QLabel#userDetailsLabel {
                font-size: 8px;
                color: #666666;
                margin: 0px;
                padding: 0px;
                margin-top: 0px;  /* Centré verticalement avec le reste */
                line-height: 1.1;
            }
            
            /* Style pour le thème sombre */
            [theme="dark"] QLabel#userDetailsLabel {
                color: #bbbbbb;
            }
            
            /* Style pour le thème clair */
            [theme="light"] QLabel#userDetailsLabel {
                color: #666666;
            }
        """)
        
        # Ajouter le layout nom au layout principal (sans badge)
        info_layout.addStretch(1)  # Spacer au-dessus
        info_layout.addWidget(self.name_label)  # Nom ajouté directement comme les détails
        info_layout.addWidget(self.details_label)
        info_layout.addStretch(1)  # Spacer en-dessous
        
        # Bouton de notification
        self.notif_button = QToolButton()
        self.notif_button.setIcon(QApplication.style().standardIcon(
            QStyle.StandardPixmap.SP_MessageBoxInformation
        ))
        self.notif_button.setIconSize(QSize(14, 14))  # Taille d'icône réduite
        self.notif_button.setFixedSize(24, 24)  # Taille fixe pour le bouton
        self.notif_button.setStyleSheet("""
            QToolButton {
                border: none;
                background: transparent;
                padding: 0px;
                margin: 0px;
                border-radius: 12px;
            }
            QToolButton:hover {
                background: #e0e0e0;
            }
            QToolButton::menu-indicator { 
                width: 0px;
                padding: 0px;
                margin: 0px;
            }
        """)
        
        # Menu déroulant pour les notifications
        self.notif_menu = QMenu()
        self.notif_menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                padding: 4px;
            }
            QMenu::item {
                padding: 6px 12px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: #e0e0e0;
            }
        """)
        
        # Badge de notification
        self.notif_badge = QLabel("0")
        self.notif_badge.setStyleSheet("""
            QLabel {
                background-color: #ff4444;
                color: white;
                border-radius: 7px;
                min-width: 14px;
                max-width: 14px;
                min-height: 14px;
                max-height: 14px;
                font-size: 8px;
                font-weight: bold;
                qproperty-alignment: AlignCenter;
                padding: 0px;
                margin: 0px;
                margin-top: -5px;
                margin-right: -5px;
                border: 1px solid white;
            }
        """)
        self.notif_badge.hide()
        
        # Bouton de notification
        self.notif_button = QToolButton()
        self.notif_button.setIcon(QApplication.style().standardIcon(
            QStyle.StandardPixmap.SP_MessageBoxInformation
        ))
        self.notif_button.setIconSize(QSize(14, 14))  # Taille d'icône réduite
        self.notif_button.setFixedSize(24, 24)  # Taille fixe pour le bouton
        self.notif_button.setStyleSheet("""
            QToolButton {
                border: none;
                background: transparent;
                padding: 0px;
                margin: 0px;
                border-radius: 12px;
            }
            QToolButton:hover {
                background: #e0e0e0;
            }
            QToolButton::menu-indicator { 
                width: 0px;
                padding: 0px;
                margin: 0px;
            }
        """)
        
        # Menu déroulant pour les notifications
        self.notif_menu = QMenu()
        self.notif_menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                padding: 4px;
            }
            QMenu::item {
                padding: 6px 12px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: #e0e0e0;
            }
        """)
        
        # Layout pour le bouton de notification avec badge
        self.notif_widget = QWidget()
        notif_layout = QVBoxLayout(self.notif_widget)
        notif_layout.setContentsMargins(0, 0, 0, 0)
        notif_layout.setSpacing(0)
        notif_layout.addWidget(self.notif_button, 0, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter)
        notif_layout.addWidget(self.notif_badge, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        self.notif_widget.setFixedHeight(24)  # Hauteur fixe pour aligner avec la photo de profil
        
        # Ajout des widgets au layout principal
        layout.addWidget(self.photo_label, 0, Qt.AlignmentFlag.AlignVCenter)
        
        # Container pour le badge avec décalage indépendant
        badge_container = QWidget()
        badge_layout = QVBoxLayout(badge_container)
        badge_layout.setContentsMargins(0, 6, 0, 0)  # Décalage pour aligner avec bouton
        badge_layout.setSpacing(0)
        badge_layout.addWidget(self.license_badge)
        # Pas de setFixedWidth pour permettre au badge de prendre sa taille naturelle
        
        layout.addLayout(info_layout, 1)  # Permettre l'expansion pour le centrage
        layout.addWidget(badge_container, 0, Qt.AlignmentFlag.AlignVCenter)  # Badge à gauche du bouton de notif
        layout.addWidget(self.notif_widget, 0, Qt.AlignmentFlag.AlignVCenter)
        layout.addStretch(0)  # Spacer pour l'équilibre
        
        # Ajustement de la taille minimale du widget
        self.setFixedHeight(44)  # Hauteur augmentée pour éviter la coupure du badge décalé
        
        # Connecter le clic sur le bouton de notification
        self.notif_button.clicked.connect(self.show_notifications)
        
        # DÉSACTIVÉ TEMPORAIRE - Les notifications simulées pourraient créer la fenêtre blanche
        # QTimer.singleShot(1000, self.simulate_notifications)
        logging.debug("Notifications simulées désactivées pour le débogage")
        
        # S'assurer que le widget prend toute la largeur disponible
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Preferred
        )
    
    def show_empty_profile(self):
        """Affiche un profil vide (déconnecté)."""
        self.name_label.setText("Not connected")
        self.details_label.setText("Connect to continue")
        self.photo_label.clear()
        self.photo_label.setStyleSheet(f"""
            QLabel {{
                border: 1px solid #cccccc;
                border-radius: {self.photo_label.width()//2}px;
                background-color: #f0f0f0;
                min-width: {self.photo_label.width()}px;
                max-width: {self.photo_label.width()}px;
                min-height: {self.photo_label.height()}px;
                max-height: {self.photo_label.height()}px;
                qproperty-alignment: AlignCenter;
                padding: 0px;
                margin: 0px;
            }}
        """)
        self._profile_loaded = False
        
        # Vérifier la licence même pour un profil vide
        asyncio.create_task(self._check_license_status())
    
    async def load_profile(self):
        """Charge les informations du profil utilisateur de manière asynchrone."""
        if self._profile_loaded or self.telegram_client is None:
            return
            
        try:
            # Récupérer les informations de l'utilisateur connecté
            if not self.telegram_client or not hasattr(self.telegram_client, 'client'):
                raise ValueError("Client Telegram non disponible")
                
            me = await self.telegram_client.client.get_me()
            if not me:
                raise ValueError("Impossible de récupérer les informations du profil")
                
            # Mettre à jour le nom complet
            full_name = f"{me.first_name or ''} {me.last_name or ''}".strip()
            self.name_label.setText(full_name or "User")
            
            # Mettre à jour les détails (nom d'utilisateur et téléphone)
            details = []
            if hasattr(me, 'username') and me.username:
                details.append(f"@{me.username}")
            if hasattr(me, 'phone') and me.phone:
                details.append(me.phone)
            self.details_label.setText(" • ".join(details) if details else "Utilisateur Telegram")
            
            # Charger la photo de profil si disponible
            if hasattr(me, 'photo') and me.photo:
                await self._load_profile_photo(me.photo)
            else:
                # Réinitialiser la photo de profil si aucune photo n'est disponible
                self.photo_label.clear()
                self.photo_label.setStyleSheet(f"""
                    QLabel {{
                        border: 1px solid #0088cc;
                        border-radius: {self.photo_label.width()//2}px;
                        background-color: #f0f0f0;
                        min-width: {self.photo_label.width()}px;
                        max-width: {self.photo_label.width()}px;
                        min-height: {self.photo_label.height()}px;
                        max-height: {self.photo_label.height()}px;
                        qproperty-alignment: AlignCenter;
                        padding: 0px;
                        margin: 0px;
                    }}
                """)
            
            # Vérifier le statut de la licence
            await self._check_license_status()
                
            self._profile_loaded = True
            
        except Exception as e:
            import logging
            logging.error(f"Error loading profile: {e}")
            self.name_label.setText("Error loading profile")
            self.details_label.setText("Unable to load profile")
            # Afficher le badge de licence même en cas d'erreur
            asyncio.create_task(self._check_license_status())
    
    async def _load_profile_photo(self, photo):
        """Charge la photo de profil à partir d'un objet photo Telegram."""
        try:
            # Télécharger la photo de profil
            photo_data = await self.telegram_client.client.download_profile_photo('me', file=bytes)
            
            if not photo_data:
                return
                
            # Créer une image à partir des données binaires
            image = QImage()
            image.loadFromData(photo_data)
            
            if image.isNull():
                return
            
            # Redimensionner et rogner l'image en cercle
            pixmap = QPixmap.fromImage(image).scaled(
                self.photo_label.width(),
                self.photo_label.height(),
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation
            )
            
            # Mettre à jour l'image de profil
            rounded_pixmap = self._create_rounded_pixmap(pixmap, self.photo_label.width())
            self.photo_label.setPixmap(rounded_pixmap)
            
        except Exception:
            pass
    
    def _create_rounded_pixmap(self, pixmap, size):
        """Crée une image ronde à partir d'une pixmap."""
        rounded = QPixmap(size, size)
        rounded.fill(Qt.GlobalColor.transparent)
        
        painter = QPainter(rounded)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        path = QPainterPath()
        path.addRoundedRect(0, 0, size, size, size//2, size//2)
        painter.setClipPath(path)
        
        # Centrer l'image
        target_rect = pixmap.rect()
        target_rect.moveCenter(rounded.rect().center())
        painter.drawPixmap(target_rect, pixmap)
        
        painter.end()
        return rounded
    
    def load_profile_async(self):
        """Démarre le chargement du profil."""
        asyncio.create_task(self.load_profile())
    
    def show_notifications(self):
        """Affiche la boîte de dialogue des notifications."""
        if self.notification_dialog is None:
            self.notification_dialog = NotificationDialog(self)
            self.notification_dialog.finished.connect(self.on_notification_dialog_closed)
        
        # Afficher la boîte de dialogue
        self.notification_dialog.show()
        self.notification_dialog.raise_()
        self.notification_dialog.activateWindow()
        
        # Réinitialiser le compteur de notifications
        self.notification_count = 0
        self.notif_badge.hide()
        
    def on_notification_dialog_closed(self):
        """Appelé lorsque la boîte de dialogue est fermée."""
        # Ne pas supprimer la boîte de dialogue pour conserver l'historique
        pass
        
    def add_notification(self, message, is_error=False):
        """Ajoute une notification à la boîte de dialogue.
        
        Args:
            message (str): Le message de notification
            is_error (bool): Si True, affiche une icône d'erreur
        """
        try:
            print(f"📨 Réception d'une notification dans ProfileWidget: {message} (erreur: {is_error})")
            
            # Créer la boîte de dialogue si elle n'existe pas
            if self.notification_dialog is None:
                print("  → Création d'une nouvelle boîte de dialogue de notification")
                self.notification_dialog = NotificationDialog(self)
                
            # Ajouter la notification à la boîte de dialogue
            print(f"  → Ajout de la notification à la boîte de dialogue")
            self.notification_dialog.add_notification(message, is_error)
            
            # Mettre à jour le badge
            self.notification_count += 1
            self.notif_badge.setText(str(self.notification_count))
            self.notif_badge.show()
            
            # Afficher la boîte de dialogue si elle n'est pas déjà visible
            if not self.notification_dialog.isVisible():
                print("  → Affichage de la boîte de dialogue de notification")
                self.notification_dialog.show()
                self.notification_dialog.activateWindow()
                self.notification_dialog.raise_()
            else:
                print("  → La boîte de dialogue est déjà visible")
            
            # Clignoter la barre des tâches sous Windows
            if hasattr(QApplication, 'alert'):
                QApplication.alert(self, 0)
                
            print("  → Notification traitée avec succès")
            
        except Exception as e:
            error_msg = f"Erreur dans ProfileWidget.add_notification: {str(e)}"
            print(f"❌ {error_msg}")
            logging.error(error_msg, exc_info=True)
    
    async def _check_license_status(self):
        """Vérifie le statut de la licence et met à jour le badge."""
        try:
            print("🔍 Début de la vérification de la licence...")
            
            # Créer une instance du LicenseManager
            license_manager = LicenseManager()
            print(f"✅ LicenseManager créé: {type(license_manager)}")
            
            # Vérifier si c'est la classe de substitution
            if 'profile_widget' in str(type(license_manager)):
                print("⚠️ Utilisation de la classe de substitution - LicenseManager non disponible")
                self.license_status = 'unknown'
                self.license_badge.setText('Indisponible')
                self.license_badge.setProperty('status', 'unknown')
            else:
                # Valider la licence avec le vrai LicenseManager
                result = license_manager.validate_license()
                print(f"📋 Résultat validation: {result}")
                
                if result.get('valid', False):
                    self.license_status = 'active'
                    days_remaining = result.get('days_remaining', 0)
                    
                    if days_remaining <= 7:
                        self.license_badge.setText(f'Days remaining: {days_remaining}')
                    else:
                        self.license_badge.setText('Active License')
                    self.license_badge.setProperty('status', 'active')
                    print(f"✅ Licence active - {days_remaining} jours restants")
                else:
                    self.license_status = 'inactive'
                    self.license_badge.setText('Inactive License')
                    self.license_badge.setProperty('status', 'inactive')
                    print(f"❌ Licence inactive - {result.get('message', 'Raison inconnue')}")
            
            # Afficher le badge et forcer la mise à jour du style
            self.license_badge.show()
            self.license_badge.style().unpolish(self.license_badge)
            self.license_badge.style().polish(self.license_badge)
            
        except Exception as e:
            import logging
            logging.error(f"Erreur lors de la vérification de la licence: {e}")
            print(f"❌ Exception lors de la vérification: {e}")
            
            self.license_status = 'error'
            self.license_badge.setText('Erreur')
            self.license_badge.setProperty('status', 'unknown')
            self.license_badge.show()
            self.license_badge.style().unpolish(self.license_badge)
            self.license_badge.style().polish(self.license_badge)
    
    def refresh_license_status(self):
        """Rafraîchit manuellement le statut de la licence."""
        asyncio.create_task(self._check_license_status())
    
    def get_license_status(self) -> str:
        """Retourne le statut actuel de la licence.
        
        Returns:
            str: 'active', 'inactive', ou 'unknown'
        """
        return self.license_status
    
    def simulate_notifications(self):
        """Simule la réception de notifications (à remplacer par une vraie implémentation)."""
        # Ajouter des exemples de notifications
        self.notif_menu.clear()
        self.notif_menu.addAction("Nouveau message reçu")
        self.notif_menu.addAction("Mise à jour disponible")
        self.notif_menu.addSeparator()
        self.notif_menu.addAction("Tout marquer comme lu")
        
        # Mettre à jour le badge
        self.notification_count = 2
        self.notif_badge.setText(str(self.notification_count))
        self.notif_badge.show()
    
    async def load_profile_photo(self):
        """Charge la photo de profil."""
        try:
            photo_data = await self.telegram_client.client.download_profile_photo('me', file=bytes)
            if photo_data:
                image = QImage()
                image.loadFromData(photo_data)
                
                # Créer une image ronde
                size = min(self.photo_label.width(), self.photo_label.height())
                
                # Redimensionner l'image en conservant les proportions
                scaled = image.scaled(
                    size, size,
                    Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                    Qt.TransformationMode.SmoothTransformation
                )
                
                # Créer un masque circulaire
                mask = QPixmap(size, size)
                mask.fill(Qt.GlobalColor.transparent)
                
                painter = QPainter(mask)
                painter.setRenderHint(QPainter.RenderHint.Antialiasing)
                
                # Créer un chemin circulaire pour le masque
                path = QPainterPath()
                path.addEllipse(QRectF(0, 0, size, size))
                painter.setClipPath(path)
                
                # Dessiner l'image centrée
                x = (scaled.width() - size) // 2
                y = (scaled.height() - size) // 2
                painter.drawImage(0, 0, scaled, x, y, size, size)
                
                painter.end()
                
                self.photo_label.setPixmap(mask)
                
        except Exception as e:
            print(f"Erreur photo: {e}")
            # Mettre une icône par défaut si la photo ne peut pas être chargée
            style = QApplication.style()
            if style:
                icon = style.standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)
                if icon and not icon.isNull():
                    self.photo_label.setPixmap(icon.pixmap(self.photo_label.size()))
