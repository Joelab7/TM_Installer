"""Widget d'onglets personnalisé avec style moderne."""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QFrame, QScrollArea, QLineEdit
)
from PyQt6.QtCore import Qt, pyqtSignal, QSize

class TabButton(QPushButton):
    """Bouton personnalisé pour les onglets."""
    
    def __init__(self, text, parent=None):
        """Initialise le bouton d'onglet."""
        super().__init__(text, parent)
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(40)
        self._theme = 'light'
        self.update_style()
    
    def set_theme(self, theme_name):
        """Définit le thème du bouton.
        
        Args:
            theme_name: Nom du thème ('light' ou 'dark')
        """
        self._theme = theme_name.lower()
        self.update_style()
    
    def update_style(self):
        """Met à jour le style en fonction du thème."""
        is_dark = self._theme == 'dark'
        
        style = f"""
            QPushButton {{
                border: none;
                background: transparent;
                color: {'#a0a0a0' if is_dark else '#666'};
                font-weight: 500;
                font-size: 13px;
                padding: 0 16px;
                border-bottom: 2px solid transparent;
            }}
            QPushButton:hover {{
                color: {'#ffffff' if is_dark else '#333'};
                background: {'#3a3a3a' if is_dark else '#f5f5f5'};
            }}
            QPushButton:checked {{
                color: {'#4CAF50' if is_dark else '#2e7d32'};
                border-bottom: 2px solid #4CAF50;
                font-weight: 600;
            }}
        """
        self.setStyleSheet(style)


class TabContent(QWidget):
    """Contenu d'un onglet avec défilement."""
    
    def __init__(self, parent=None):
        """Initialise le contenu de l'onglet."""
        super().__init__(parent)
        self._theme = 'light'
        self.setup_ui()
    
    def set_theme(self, theme_name):
        """Définit le thème du contenu de l'onglet.
        
        Args:
            theme_name: Nom du thème ('light' ou 'dark')
        """
        self._theme = theme_name.lower()
        self.update_styles()
    
    def update_styles(self):
        """Met à jour les styles en fonction du thème."""
        is_dark = self._theme == 'dark'
        
        # Style de la barre de recherche
        search_style = f"""
            QLineEdit {{
                background: {'#2d2d2d' if is_dark else '#ffffff'};
                color: {'#ffffff' if is_dark else '#2c3e50'};
                border: 1px solid {'#3a3a3a' if is_dark else '#e0e0e0'};
                border-radius: 8px;
                padding: 0 12px;
                font-size: 13px;
                selection-background-color: #4CAF50;
            }}
            QLineEdit:focus {{
                border-color: #4CAF50;
            }}
            QLineEdit::placeholder {{
                color: {'#7f8c8d' if is_dark else '#95a5a6'};
            }}
        """
        self.search_bar.setStyleSheet(search_style)
        
        # Style des boutons de navigation
        nav_style = f"""
            QPushButton {{
                border: 1px solid {'#4a4a4a' if is_dark else '#e0e0e0'};
                border-radius: 6px;
                padding: 6px 12px;
                background: {'#2d2d2d' if is_dark else '#ffffff'};
                color: {'#ffffff' if is_dark else '#2c3e50'};
                font-size: 13px;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background: {'#4a4a4a' if is_dark else '#f8f9fa'};
                border-color: #4CAF50;
            }}
            QPushButton:checked {{
                background: #4CAF50;
                color: white;
                border-color: #4CAF50;
            }}
        """
        
        # Appliquer le style à tous les boutons de navigation
        for button in self.nav_buttons.values():
            button.setStyleSheet(nav_style)
        
        # Style de la zone de défilement
        scroll_style = f"""
            QScrollArea {{
                border: none;
                background: transparent;
            }}
            QScrollBar:vertical {{
                border: none;
                background: {'#2d2d2d' if is_dark else '#f5f5f5'};
                width: 10px;
                margin: 0px 0px 0px 0px;
            }}
            QScrollBar::handle:vertical {{
                background: {'#4a4a4a' if is_dark else '#c4c4c4'};
                min-height: 20px;
                border-radius: 5px;
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
            }}
            QScrollBar:horizontal {{
                height: 0px;
            }}
        """
        self.scroll_area.setStyleSheet(scroll_style)
        
        # Style du contenu
        self.scroll_content.setStyleSheet(f"""
            QWidget {{
                background: transparent;
            }}
        """)
    
    def setup_ui(self):
        """Configure l'interface utilisateur du contenu."""
        # Layout principal avec espacement
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(8, 8, 8, 0) # Ajout de marges horizontales
        self.layout.setSpacing(12)

        # Barre de recherche
        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("Search...")
        self.search_bar.setFixedHeight(36)
        
        # Boutons de navigation pour les sections principales
        self.nav_layout = QHBoxLayout()
        self.nav_layout.setContentsMargins(0, 0, 0, 0)
        self.nav_layout.setSpacing(8)
        
        # Créer les boutons de navigation
        self.nav_buttons = {}
        nav_sections = ["All", "Groups", "Channels", "Bots", "Chats"]
        
        for section in nav_sections:
            button = QPushButton(section)
            button.setFixedHeight(32)
            button.setCheckable(True)
            button.setObjectName(f"nav_{section.lower()}")
            self.nav_buttons[section] = button
            self.nav_layout.addWidget(button)
        
        # Sélectionner "All" par défaut
        self.nav_buttons["All"].setChecked(True)
        
        # Ajouter un espace extensible pour pousser les boutons vers la gauche
        self.nav_layout.addStretch()
        
        # Zone de défilement
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        
        # Conteneur pour le contenu défilant
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setContentsMargins(0, 10, 0, 10)
        self.scroll_layout.setSpacing(10)
        self.scroll_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.scroll_area.setWidget(self.scroll_content)
        
        # Ajout des widgets au layout
        self.layout.addWidget(self.search_bar)
        self.layout.addLayout(self.nav_layout)  # Ajouter les boutons de navigation
        self.layout.addWidget(self.scroll_area)
        
        # Appliquer les styles initiaux
        self.update_styles()
    
    def add_widget(self, widget):
        """Ajoute un widget au contenu de l'onglet."""
        # Insère avant le stretch
        self.scroll_layout.insertWidget(self.scroll_layout.count() - 1, widget)
    
    def clear(self):
        """Vide le contenu de l'onglet."""
        while self.scroll_layout.count() > 1:  # Garde le stretch
            item = self.scroll_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()


class CustomTabWidget(QWidget):
    """Widget d'onglets personnalisé avec style moderne."""
    
    currentChanged = pyqtSignal(int)  # Émis lorsque l'onglet change
    
    def __init__(self, parent=None):
        """Initialise le widget d'onglets."""
        super().__init__(parent)
        self.tab_buttons = []
        self.tab_contents = []
        self.current_index = -1
        self._theme = 'light'
        self.setup_ui()
    
    def update_theme(self, theme_name):
        """Met à jour le thème de tous les onglets.
        
        Args:
            theme_name: Nom du thème ('light' ou 'dark')
        """
        self._theme = theme_name.lower()
        
        # Mettre à jour le style de la barre d'onglets
        is_dark = self._theme == 'dark'
        self.tab_bar.setStyleSheet(f"""
            QWidget#tabBar {{
                background: {'#2d2d2d' if is_dark else '#ffffff'};
                border-bottom: 1px solid {'#3a3a3a' if is_dark else '#e0e0e0'};
            }}
        """)
        
        # Mettre à jour tous les boutons d'onglets
        for button in self.tab_buttons:
            if hasattr(button, 'set_theme'):
                button.set_theme(theme_name)
        
        # Mettre à jour le style des onglets
        for content in self.tab_contents:
            if hasattr(content, 'set_theme'):
                content.set_theme(theme_name)
    
    # Alias pour la compatibilité avec le code existant
    set_theme = update_theme
    
    def setup_ui(self):
        """Configure l'interface utilisateur du widget d'onglets."""
        # Layout principal
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Barre d'onglets
        self.tab_bar = QWidget()
        self.tab_bar.setObjectName("tabBar")
        self.tab_bar.setFixedHeight(40)
        
        # Mettre à jour le style de la barre d'onglets
        is_dark = self._theme == 'dark'
        self.tab_bar.setStyleSheet(f"""
            QWidget#tabBar {{
                background: {'#2d2d2d' if is_dark else '#ffffff'};
                border-bottom: 1px solid {'#3a3a3a' if is_dark else '#e0e0e0'};
            }}
        """)
        
        # Layout horizontal pour les boutons d'onglets
        self.tab_layout = QHBoxLayout(self.tab_bar)
        self.tab_layout.setContentsMargins(8, 0, 8, 0)
        self.tab_layout.setSpacing(0)
        
        # Espacement à droite pour pousser les boutons vers la gauche
        self.tab_layout.addStretch()
        
        # Conteneur pour le contenu des onglets avec défilement
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        
        # Widget conteneur pour le contenu
        self.stack = QWidget()
        self.stacked_layout = QVBoxLayout(self.stack)
        self.stacked_layout.setContentsMargins(0, 0, 0, 0)
        self.stacked_layout.setSpacing(0)
        
        # Configurer la zone de défilement
        self.scroll_area.setWidget(self.stack)
        
        # Ajouter les widgets au layout principal
        layout.addWidget(self.tab_bar)
        layout.addWidget(self.scroll_area)
        
        # Appliquer le thème initial
        self.update_theme(self._theme)
    
    def add_tab(self, title):
        """Ajoute un nouvel onglet et retourne son widget de contenu."""
        # Créer le bouton d'onglet
        button = TabButton(title)
        button.set_theme(self._theme)  # Appliquer le thème actuel
        
        # Ajouter le bouton à la liste avant de connecter le signal
        index = len(self.tab_buttons)
        self.tab_buttons.append(button)
        self.tab_layout.insertWidget(index, button)
        
        # Connecter le signal avec l'index correct
        button.clicked.connect(lambda checked, idx=index: self.set_current_index(idx))
        
        # Créer le contenu de l'onglet
        content = TabContent()
        content.setObjectName(f"tabContent_{len(self.tab_contents)}")
        content.set_theme(self._theme)  # Appliquer le thème actuel
        self.tab_contents.append(content)
        self.stacked_layout.addWidget(content)
        
        # Masquer le contenu par défaut
        content.setVisible(False)
        
        # Si c'est le premier onglet, le sélectionner
        if len(self.tab_buttons) == 1:
            self.set_current_index(0)
            
        return content
    
    def set_current_index(self, index):
        """Défini l'onglet courant."""
        # Vérifier si l'index est valide
        if index < 0 or index >= len(self.tab_buttons):
            import traceback
            print(f"[CustomTabWidget] Index {index} invalide (0-{len(self.tab_buttons)-1})")
            print("Stack trace:")
            traceback.print_stack(limit=5)  # Affiche les 5 dernières frames de la pile d'appels
            return

        # Si l'index demandé est déjà l'index actuel, ne rien faire
        if index == self.current_index:
            return

        # Désélectionner l'onglet actuel s'il est valide
        if 0 <= self.current_index < len(self.tab_buttons):
            old_button = self.tab_buttons[self.current_index]
            if old_button:
                old_button.blockSignals(True)
                old_button.setChecked(False)
                old_button.blockSignals(False)

        # Mettre à jour l'index courant
        previous_index = self.current_index
        self.current_index = index

        # Sélectionner le nouvel onglet
        new_button = self.tab_buttons[index]
        if new_button:
            new_button.blockSignals(True)
            new_button.setChecked(True)
            new_button.blockSignals(False)

        # Afficher le contenu correspondant et masquer les autres
        for i, content in enumerate(self.tab_contents):
            if i < len(self.tab_buttons):  # S'assurer que l'index est valide
                content.setVisible(i == index)

        # Émettre le signal de changement d'onglet
        self.currentChanged.emit(index)
    
    def count(self):
        """Retourne le nombre d'onglets."""
        return len(self.tab_buttons)
    
    def get_content_widget(self, index):
        """Retourne le widget de contenu pour un onglet donné."""
        return self.widget(index)

    def get_scroll_area_for_content(self, content_widget):
        """Retourne la QScrollArea associée à un widget de contenu."""
        if content_widget in self.tab_contents:
            return content_widget.scroll_area
        return None
    
    def widget(self, index):
        """Retourne le widget à l'index spécifié."""
        if 0 <= index < len(self.tab_contents):
            return self.tab_contents[index]
        return None
