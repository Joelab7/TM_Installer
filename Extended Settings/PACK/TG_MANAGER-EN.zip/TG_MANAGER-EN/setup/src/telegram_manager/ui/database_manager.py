"""Gestionnaire de base de données pour les utilisateurs Telegram."""
import os
import sqlite3
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QPushButton, QHeaderView, QMessageBox, QFileDialog, QWidget,
    QListWidget, QListWidgetItem, QDialogButtonBox, QMenu, QApplication
)
from PyQt6.QtCore import Qt, QTimer
# Utilitaires
from .utils import set_window_icon

class DatabaseManager(QDialog):
    """Fenêtre de gestion de la base de données des utilisateurs."""
    
    def find_latest_database(self, directory):
        """Trouve le fichier de base de données le plus récent dans le répertoire spécifié."""
        try:
            if not os.path.exists(directory):
                print(f"[INFO] The data directory does not exist: {directory}")
                return None
                
            # Lister tous les fichiers de base de données
            db_files = [f for f in os.listdir(directory) 
                       if f.lower().endswith(('.db', '.sqlite', '.sqlite3'))]
            
            if not db_files:
                print("[INFO] No database file found in the directory")
                return None
                
            # Trier par date de modification (du plus récent au plus ancien)
            db_files.sort(key=lambda x: os.path.getmtime(
                os.path.join(directory, x)), 
                reverse=True
            )
            
            latest_db = os.path.join(directory, db_files[0])
            print(f"[INFO] Latest database file found: {latest_db}")
            return latest_db
            
        except Exception as e:
            print(f"[ERROR] Error searching for database file: {e}")
            return None
    
    def __init__(self, data_dir=None, parent=None):
        """Initialise la fenêtre de gestion de la base de données."""
        super().__init__(parent)
        
        # Définir l'icône de la fenêtre
        set_window_icon(self, "database_icon")
        
        # Chemin vers le dossier Program à la racine d'AppTG
        app_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
        default_data_dir = os.path.join(app_root, "Program", "data")
        
        # Utiliser le dossier de données fourni ou le dossier par défaut
        self.data_dir = data_dir if data_dir is not None else default_data_dir
        
        # S'assurer que le répertoire existe
        if not os.path.exists(self.data_dir):
            print(f"[INFO] Directory does not exist. Creating directory: {self.data_dir}")
            os.makedirs(self.data_dir, exist_ok=True)
        else:
            print(f"[INFO] Using existing directory: {self.data_dir}")
        
        # Essayer de trouver la base de données la plus récente
        self.db_path = self.find_latest_database(self.data_dir)
        
        # Si aucune base de données n'est trouvée, utiliser le nom par défaut
        if self.db_path is None:
            self.db_path = os.path.join(self.data_dir, "telegram_users.db")
            print(f"[INFO] Using default database file: {self.db_path}")
        
        self.setWindowTitle("Database Manager")
        self.setMinimumSize(800, 600)
        
        self.setup_ui()
        
        # Ne charger les données que si le fichier de base de données existe
        if os.path.exists(self.db_path):
            self.load_data()
        else:
            print("[INFO] No existing database file found.")
    
    def showEvent(self, event):
        """Surcharge de l'événement d'affichage."""
        super().showEvent(event)
        self.update_table_style()
        self.update_button_style()
    
    def setup_ui(self):
        """Configure l'interface utilisateur."""
        # Create main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)
        
        # Create toolbar
        toolbar = QWidget()
        toolbar_layout = QHBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create buttons
        self.export_btn = QPushButton("Export Data")
        self.export_btn.setToolTip("Export the current data")
        self.export_btn.clicked.connect(self.export_data)
        
        self.import_btn = QPushButton("Import Data")
        self.import_btn.setToolTip("Import data")
        self.import_btn.clicked.connect(self.import_data)
        
        self.delete_db_btn = QPushButton("Delete Databases")
        self.delete_db_btn.setToolTip("Delete Databases")
        self.delete_db_btn.setStyleSheet("""
            QPushButton {
                background-color: #ffcdd2;
                color: #d32f2f;
                border: 1px solid #d32f2f;
                padding: 5px 10px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #ffb3ba;
            }
            QPushButton:pressed {
                background-color: #ff8a80;
            }
        """)
        self.delete_db_btn.clicked.connect(self.delete_database)
        
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.setToolTip("Refresh the current Database")
        self.refresh_btn.clicked.connect(self.load_data)
        
        # Add buttons to toolbar
        toolbar_layout.addWidget(self.export_btn)
        toolbar_layout.addWidget(self.import_btn)
        toolbar_layout.addWidget(self.delete_db_btn)
        toolbar_layout.addWidget(self.refresh_btn)
        toolbar_layout.addStretch()
        
        # Add counter label
        self.counter_label = QLabel("Loading...")
        toolbar_layout.addWidget(self.counter_label)
        
        # Add toolbar to main layout
        main_layout.addWidget(toolbar)
        
        # Create table widget
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["ID", "Name", "Phone"])
        # Utiliser Fixed pour les premières colonnes et Stretch pour la dernière
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
        
        # Activer le menu contextuel
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        main_layout.addWidget(self.table, 1)  # The '1' makes the table take available space
        
        # Create button container
        button_container = QWidget()
        button_layout = QHBoxLayout(button_container)
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.addStretch()
        
        # Add close button
        self.close_btn = QPushButton("Close")
        self.close_btn.clicked.connect(self.accept)
        button_layout.addWidget(self.close_btn)
        
        # Add button container to main layout
        main_layout.addWidget(button_container)
        
        # Update button styles
        self.update_button_style()
    
    def is_dark_theme(self):
        """Détecte si le thème actuel est sombre."""
        # Vérifie la couleur de fond de la fenêtre parente
        bg_color = self.palette().color(self.backgroundRole())
        return bg_color.lightness() < 128
        
    def update_button_style(self):
        """Met à jour le style des boutons en fonction du thème."""
        button_style = """
            QPushButton {
                padding: 5px 15px;
                border-radius: 4px;
                min-width: 100px;
                margin: 2px;
            }
            QToolTip {
                background-color: #2b2b2b;
                color: #ffffff;
                border: 1px solid #4d4d4d;
                padding: 5px;
                border-radius: 4px;
                opacity: 240;
            }
        """
        
        if self.is_dark_theme():
            # Style pour le thème sombre
            self.setStyleSheet("""
                QPushButton {
                    background-color: #3d3d3d;
                    color: #ffffff;
                    border: 1px solid #4d4d4d;
                }
                QPushButton:hover {
                    background-color: #4d4d4d;
                    border-color: #5d5d5d;
                    color: #ffffff;
                }
                QPushButton:pressed {
                    background-color: #3a6ea5;
                    color: #ffffff;
                }
                QPushButton#deleteButton {
                    background-color: #5d1f1f;
                    color: #ffffff;
                }
                QPushButton#deleteButton:hover {
                    background-color: #7f2f2f;
                    color: #ffffff;
                }
                QPushButton#deleteButton:pressed {
                    background-color: #9f3f3f;
                }
            """ + button_style)
        else:
            # Style pour le thème clair
            self.setStyleSheet("""
                QPushButton {
                    background-color: #f5f5f5;
                    color: #333333;
                    border: 1px solid #d0d0d0;
                }
                QPushButton:hover {
                    background-color: #e0e0e0;
                    border-color: #b0b0b0;
                    color: #333333;
                }
                QPushButton:pressed {
                    background-color: #2196F3;
                    color: white;
                }
                QPushButton#deleteButton {
                    background-color: #ffebee;
                    color: #c62828;
                }
                QPushButton#deleteButton:hover {
                    background-color: #ffcdd2;
                    color: #c62828;
                }
                QPushButton#deleteButton:pressed {
                    background-color: #ef9a9a;
                    color: #c62828;
                }
                QToolTip {
                    background-color: #ffffff;
                    color: #333333;
                    border: 1px solid #d0d0d0;
                    padding: 5px;
                    border-radius: 4px;
                }
            """ + button_style.replace("QToolTip", ""))
        
        # Appliquer le style spécifique au bouton de suppression
        self.delete_db_btn.setObjectName("deleteButton")
        self.delete_db_btn.style().unpolish(self.delete_db_btn)
        self.delete_db_btn.style().polish(self.delete_db_btn)
    
    def update_table_style(self):
        """Met à jour le style du tableau en fonction du thème."""
        if self.is_dark_theme():
            self.table.setStyleSheet("""
                QTableWidget {
                    background-color: #2d2d2d;
                    alternate-background-color: #3d3d3d;
                    gridline-color: #4d4d4d;
                    color: #ffffff;
                    selection-background-color: #3a6ea5;
                    selection-color: #ffffff;
                    border: 1px solid #4d4d4d;
                    border-radius: 4px;
                }
                QTableWidget::item {
                    padding: 5px;
                    border: 1px solid #4d4d4d;
                }
                QTableWidget::item:selected {
                    background-color: #3a6ea5;
                }
                QHeaderView::section {
                    background-color: #3d3d3d;
                    color: #ffffff;
                    padding: 5px;
                    border: 1px solid #4d4d4d;
                }
                QHeaderView::section:checked {
                    background-color: #3a6ea5;
                }
                QTableCornerButton::section {
                    background-color: #3d3d3d;
                    border: 1px solid #4d4d4d;
                }
                QScrollBar:vertical {
                    border: none;
                    background: #2d2d2d;
                    width: 10px;
                    margin: 0px;
                }
                QScrollBar::handle:vertical {
                    background: #4d4d4d;
                    min-height: 20px;
                    border-radius: 5px;
                }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                    height: 0px;
                }
            """)
        else:
            self.table.setStyleSheet("""
                QTableWidget {
                    background-color: #ffffff;
                    alternate-background-color: #f5f5f5;
                    gridline-color: #e0e0e0;
                    color: #000000;
                    selection-background-color: #2196F3;
                    selection-color: #ffffff;
                    border: 1px solid #e0e0e0;
                    border-radius: 4px;
                }
                QTableWidget::item {
                    padding: 5px;
                    border: 1px solid #e0e0e0;
                }
                QTableWidget::item:selected {
                    background-color: #2196F3;
                }
                QHeaderView::section {
                    background-color: #f5f5f5;
                    color: #000000;
                    padding: 5px;
                    border: 1px solid #e0e0e0;
                }
                QHeaderView::section:checked {
                    background-color: #2196F3;
                    color: #ffffff;
                }
                QTableCornerButton::section {
                    background-color: #f5f5f5;
                    border: 1px solid #e0e0e0;
                }
                QScrollBar:vertical {
                    border: none;
                    background: #f5f5f5;
                    width: 10px;
                    margin: 0px;
                }
                QScrollBar::handle:vertical {
                    background: #c0c0c0;
                    min-height: 20px;
                    border-radius: 5px;
                }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                    height: 0px;
                }
            """)
    
    def delete_database(self):
        """Déplace la base de données actuelle vers la corbeille."""
        try:
            from send2trash import send2trash
            import glob
            
            # Vérifier si la base de données actuelle existe
            if not os.path.exists(self.db_path):
                QMessageBox.information(self, "Information", "No database file found to delete.")
                return
            
            # Trouver tous les fichiers .db dans le dossier de données
            db_files = glob.glob(os.path.join(self.data_dir, '*.db'))
            
            # Créer une boîte de dialogue de sélection
            dialog = QDialog(self)
            dialog.setWindowTitle("Select databases to delete")
            dialog.setMinimumWidth(400)
            
            layout = QVBoxLayout(dialog)
            
            # Ajouter une liste avec des cases à cocher
            list_widget = QListWidget()
            list_widget.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
            
            # Ajouter chaque fichier avec une case à cocher
            for db_file in db_files:
                item = QListWidgetItem(os.path.basename(db_file))
                item.setData(256, db_file)  # Stocker le chemin complet
                list_widget.addItem(item)
                # Sélectionner par défaut la base de données actuelle
                if db_file == self.db_path:
                    item.setSelected(True)
            
            layout.addWidget(list_widget)
            
            # Boutons OK/Annuler
            button_box = QDialogButtonBox(
                QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
            )
            button_box.accepted.connect(dialog.accept)
            button_box.rejected.connect(dialog.reject)
            
            layout.addWidget(button_box)
            
            # Afficher la boîte de dialogue
            if dialog.exec() == QDialog.DialogCode.Accepted:
                selected_items = list_widget.selectedItems()
                
                if not selected_items:
                    QMessageBox.information(
                        self,
                        "Information",
                        "No database selected."
                    )
                    return
                
                # Demander confirmation
                db_names = '\n'.join([item.text() for item in selected_items])
                reply = QMessageBox.warning(
                    self,
                    'Confirmation of deletion',
                    '⚠️ Warning !\n\n'
                    f'The following databases will be moved to the trash :\n\n{db_names}\n\n'
                    'Do you want to continue ?',
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                
                if reply == QMessageBox.StandardButton.Yes:
                    try:
                        # Fermer la connexion à la base de données si elle est ouverte
                        if hasattr(self, 'db_conn'):
                            self.db_conn.close()
                        
                        # Déplacer chaque fichier sélectionné vers la corbeille
                        for item in selected_items:
                            db_file = item.data(256)  # Récupérer le chemin complet
                            try:
                                print(f"[DEBUG] Moving to the trash: {db_file}")
                                send2trash(db_file)
                                print(f"[SUCCESS] {os.path.basename(db_file)} moved to the trash")
                            except Exception as e:
                                print(f"[ERROR] Impossible to move {db_file} : {str(e)}")
                        
                        # Réinitialiser l'interface
                        self.table.setRowCount(0)
                        self.table.setColumnCount(0)
                        self.counter_label.setText("Databases deleted")
                        
                        QMessageBox.information(
                            self,
                            "Operation successful",
                            f"{len(selected_items)} database(s) have been moved to the trash.\n"
                            "You can retrieve them if necessary."
                        )
                        
                        # Recharger les données si nécessaire
                        self.load_data()
                        
                    except Exception as e:
                        QMessageBox.critical(
                            self,
                            "Error",
                            f"An error occurred :\n{str(e)}"
                        )
        
        except ImportError:
            # Si send2trash n'est pas installé, proposer de l'installer
            reply = QMessageBox.question(
                self,
                'Missing module',
                'The send2trash module is required to move files to the trash.\n'
                'Do you want to install it now ?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes
            )
            
            if reply == QMessageBox.StandardButton.Yes:
                try:
                    import subprocess
                    import sys
                    
                    # Installer le module avec pip
                    subprocess.check_call([sys.executable, "-m", "pip", "install", "send2trash"])
                    
                    # Redémarrer la tentative de suppression
                    QMessageBox.information(
                        self,
                        "Installation successful",
                        "The module has been installed successfully.\n"
                        "Please restart the database deletion."
                    )
                except Exception as e:
                    QMessageBox.critical(
                        self,
                        "Installation error",
                        f"Unable to install the send2trash module :\n{str(e)}"
                    )
    
    def show_context_menu(self, position):
        """Affiche le menu contextuel pour la suppression des lignes sélectionnées."""
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return
            
        menu = QMenu(self)
        delete_action = menu.addAction("Delete selected entries")
        
        # Afficher le menu à la position du clic
        action = menu.exec(self.table.viewport().mapToGlobal(position))
        
        if action == delete_action:
            self.delete_selected_rows(selected_rows)
    
    def delete_selected_rows(self, selected_rows):
        """Supprime les lignes sélectionnées de la base de données."""
        if not selected_rows:
            return
            
        # Déterminer le message selon le nombre
        if len(selected_rows) == 1:
            message = f"Do you really want to delete {len(selected_rows)} selected entry?"
        else:
            message = f"Do you really want to delete {len(selected_rows)} selected entries?"
        
        reply = QMessageBox.question(
            self,
            "Confirmation of deletion",
            message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        
        if reply != QMessageBox.StandardButton.Yes:
            return
            
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Récupérer les IDs des lignes sélectionnées
            ids_to_delete = []
            for row in selected_rows:
                item = self.table.item(row.row(), 0)  # Première colonne contient l'ID
                if item is not None:
                    ids_to_delete.append(item.text())
            
            if not ids_to_delete:
                return
                
            # Construire et exécuter la requête de suppression
            placeholders = ','.join(['?'] * len(ids_to_delete))
            cursor.execute(f"DELETE FROM added_users WHERE id IN ({placeholders})", ids_to_delete)
            conn.commit()
            
            # Recharger les données
            self.load_data()
            
            # Déterminer le message selon le nombre
            if len(ids_to_delete) == 1:
                message = f"{len(ids_to_delete)} entry has been deleted successfully."
            else:
                message = f"{len(ids_to_delete)} entries have been deleted successfully."
            
            QMessageBox.information(
                self,
                "Deletion successful",
                message,
                QMessageBox.StandardButton.Ok
            )
            
        except sqlite3.Error as e:
            QMessageBox.critical(
                self,
                "Deletion error",
                f"An error occurred during deletion : {str(e)}",
                QMessageBox.StandardButton.Ok
            )
        finally:
            if 'conn' in locals():
                conn.close()
    
    def load_data(self):
        """Charge les données depuis la base de données."""
        try:
            if not os.path.exists(self.db_path):
                self.counter_label.setText("No database found")
                self.table.setRowCount(0)
                self.table.setColumnCount(0)
                return
                
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Récupérer les noms des tables
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            
            if not tables:
                self.counter_label.setText("No table found in the database")
                return
                
            # For simplicity, we take the first table
            table_name = tables[0][0]
            
            # Compter les enregistrements pour éviter les crashes
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
            total_records = cursor.fetchone()[0]
            
            # Protection contre les gros volumes de données
            max_safe_records = 50000
            if total_records > max_safe_records:
                reply = QMessageBox.question(
                    self,
                    "Large dataset",
                    f"The database contains {total_records:,} records.\n"
                    f"Loading all records may cause the application to freeze.\n"
                    f"Would you like to load only the most recent {max_safe_records:,} records?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes
                )
                
                if reply == QMessageBox.StandardButton.Yes:
                    cursor.execute(f"SELECT * FROM {table_name} ORDER BY rowid DESC LIMIT {max_safe_records}")
                else:
                    # L'utilisateur veut tout charger - essayer avec une limite plus grande
                    cursor.execute(f"SELECT * FROM {table_name} LIMIT {max_safe_records * 2}")
            else:
                cursor.execute(f"SELECT * FROM {table_name}")
            
            data = cursor.fetchall()
            
            # Récupérer les noms des colonnes
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [col[1] for col in cursor.fetchall()]
            
            # Mettre à jour le tableau
            self.table.setRowCount(len(data))
            self.table.setColumnCount(len(columns))
            self.table.setHorizontalHeaderLabels(columns)
            
            # Remplir le tableau par lots pour éviter les freezes
            batch_size = 100
            for batch_start in range(0, len(data), batch_size):
                batch_end = min(batch_start + batch_size, len(data))
                
                for row_idx in range(batch_start, batch_end):
                    row = data[row_idx]
                    for col_idx, value in enumerate(row):
                        item = QTableWidgetItem(str(value) if value is not None else "")
                        self.table.setItem(row_idx, col_idx, item)
                
                # Forcer la mise à jour de l'UI périodiquement
                if batch_start % (batch_size * 10) == 0:  # Toutes les 1000 lignes
                    QApplication.processEvents()
            
            # Utiliser un redimensionnement fixe pendant le chargement
            self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
            
            # Redimensionner manuellement les colonnes après le chargement (plus rapide)
            QTimer.singleShot(100, self.resize_columns)
            
            # Appel direct au redimensionnement comme fallback pour garantir l'exécution
            if self.table.rowCount() > 0 and self.table.columnCount() > 0:
                self.resize_columns()
            
            # Mettre à jour le compteur avec les informations de limitation si nécessaire
            if total_records > max_safe_records and len(data) < total_records:
                if len(data) == max_safe_records:
                    self.counter_label.setText(f"Showing {len(data):,} of {total_records:,} records (limited)")
                else:
                    self.counter_label.setText(f"Showing {len(data):,} of {total_records:,} records (partial)")
            else:
                if len(data) == 1:
                    self.counter_label.setText(f"{len(data):,} entry found")
                else:
                    self.counter_label.setText(f"{len(data):,} entries found")
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"Unable to load data : {str(e)}",
                QMessageBox.StandardButton.Ok
            )
        finally:
            if 'conn' in locals():
                conn.close()
    
    def resize_columns(self):
        """Redimensionne les colonnes de manière optimisée après le chargement."""
        try:
            # Vérifier si le tableau a des données avant de redimensionner
            if self.table.rowCount() == 0 or self.table.columnCount() == 0:
                return
                
            # Désactiver temporairement les mises à jour visuelles
            self.table.setUpdatesEnabled(False)
            
            # Redimensionner chaque colonne individuellement (plus rapide)
            total_fixed_width = 0
            for col in range(self.table.columnCount() - 1):
                self.table.resizeColumnToContents(col)
                current_width = self.table.columnWidth(col)
                max_width = 150
                min_width = 60
                if col == 0:
                    max_width = 120
                    min_width = 100
                elif col == 3:
                    max_width = 180
                    min_width = 70
                width = max(min(current_width, max_width), min_width)
                self.table.setColumnWidth(col, width)
                total_fixed_width += width

            last_col = self.table.columnCount() - 1
            if last_col >= 0:
                viewport_width = self.table.viewport().width()
                padding = 24
                remaining = viewport_width - total_fixed_width - padding
                final_width = max(min(remaining, 200), 80)
                self.table.setColumnWidth(last_col, final_width)
                self.table.horizontalHeader().setSectionResizeMode(last_col, QHeaderView.ResizeMode.Fixed)
            self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

            self.table.setUpdatesEnabled(True)
        except Exception as e:
            QMessageBox.warning(
                self,
                "Resize error",
                f"Unable to resize columns: {e}",
                QMessageBox.StandardButton.Ok
            )
    
    def export_data(self):
        """Export the data to a database file."""
        try:
            if not os.path.exists(self.db_path):
                QMessageBox.warning(
                    self,
                    "Warning",
                    "No database to export",
                    QMessageBox.StandardButton.Ok
                )
                return
                
            # Obtenir le nom de base du fichier actuel sans extension
            base_name = os.path.splitext(os.path.basename(self.db_path))[0]
            
            # Créer un horodatage
            import time
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            
            # Créer le nom de fichier avec le nom de la base actuelle + horodatage
            default_filename = f"{base_name}_{timestamp}.db"
            
            # Définir le répertoire de destination par défaut
            save_dir = self.data_dir if hasattr(self, 'data_dir') and os.path.exists(self.data_dir) else os.path.expanduser('~')
            
            # Demander où enregistrer le fichier
            file_path, _ = QFileDialog.getSaveFileName(
                self,
                "Export the database",
                os.path.join(save_dir, default_filename),
                "SQLite files (*.db);;All files (*)"
            )
            
            if not file_path:
                return
                
            # S'assurer que l'extension est .db
            if not file_path.lower().endswith('.db'):
                file_path = os.path.splitext(file_path)[0] + '.db'
                
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Récupérer les noms des tables
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            
            if not tables:
                QMessageBox.warning(
                    self,
                    "Warning",
                    "No table found in the database",
                    QMessageBox.StandardButton.Ok
                )
                return
                
            # Export the first table
            table_name = tables[0][0]
            cursor.execute(f"SELECT * FROM {table_name}")
            data = cursor.fetchall()
            
            # Récupérer les noms des colonnes
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [col[1] for col in cursor.fetchall()]
            
            # Copier le fichier de base de données
            import shutil
            shutil.copy2(self.db_path, file_path)
            
            QMessageBox.information(
                self,
                "Export successful",
                f"The database has been exported successfully to :\n{file_path}",
                QMessageBox.StandardButton.Ok
            )
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Export error",
                f"Unable to export data : {str(e)}",
                QMessageBox.StandardButton.Ok
            )
        finally:
            if 'conn' in locals():
                conn.close()
    
    def import_data(self):
        """Import data from a SQLite database file."""
        try:
            file_path, _ = QFileDialog.getOpenFileName(
                self,
                "Select a database file",
                self.data_dir,  # Default directory
                "SQLite files (*.db *.sqlite *.sqlite3);;All files (*)"
            )
            
            if not file_path:
                return
                
            # Vérifier si le fichier source est le même que la destination
            if os.path.abspath(file_path) == os.path.abspath(self.db_path):
                QMessageBox.information(
                    self,
                    "Information",
                    "You have selected the same file as the current database.",
                    QMessageBox.StandardButton.Ok
                )
                return
                
            # Vérifier si le fichier source est valide
            if not os.path.isfile(file_path):
                QMessageBox.warning(
                    self,
                    "Invalid file",
                    "The selected file does not exist or is not accessible.",
                    QMessageBox.StandardButton.Ok
                )
                return
                
            # Vérifier la taille du fichier
            if os.path.getsize(file_path) == 0:
                QMessageBox.warning(
                    self,
                    "Empty file",
                    "The selected file is empty.",
                    QMessageBox.StandardButton.Ok
                )
                return
                
            # Ask for confirmation
            reply = QMessageBox.question(
                self,
                "Confirmation",
                "Do you really want to replace the current database with the selected one?\n"
                "This action is irreversible and will erase all existing data.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            
            if reply == QMessageBox.StandardButton.No:
                return
                
                
            # Fermer la connexion actuelle si elle existe
            if hasattr(self, 'current_conn') and self.current_conn:
                self.current_conn.close()
            
            # Copier le fichier de base de données
            import shutil
            import time
            
            # Créer un nom de sauvegarde unique avec un timestamp
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            backup_dir = os.path.join(self.data_dir, "backups")
            os.makedirs(backup_dir, exist_ok=True)
            backup_path = os.path.join(backup_dir, f"backup_{timestamp}.db")
            
            try:
                # Sauvegarder l'ancienne base de données
                if os.path.exists(self.db_path):
                    shutil.copy2(self.db_path, backup_path)
                
                # Supprimer l'ancien fichier s'il existe
                if os.path.exists(self.db_path):
                    os.remove(self.db_path)
                
                # Copier le nouveau fichier
                shutil.copy2(file_path, self.db_path)
                
                QMessageBox.information(
                    self,
                    "Import successful",
                    f"The database has been imported successfully.\n"
                    f"A backup has been created : {backup_path}",
                    QMessageBox.StandardButton.Ok
                )
                
            except Exception as e:
                # En cas d'erreur, essayer de restaurer la sauvegarde
                error_msg = f"Error during importation : {str(e)}\n\n"
                if os.path.exists(backup_path):
                    try:
                        shutil.copy2(backup_path, self.db_path)
                        error_msg += "The database has been restored from the backup."
                    except Exception as restore_error:
                        error_msg += f"Failed to restore : {str(restore_error)}. "
                        error_msg += f"Please restore manually from : {backup_path}"
                
                QMessageBox.critical(
                    self,
                    "Import error",
                    error_msg,
                    QMessageBox.StandardButton.Ok
                )
                return                
            
            # Recharger les données
            self.load_data()
            
            # Forcer le redimensionnement des colonnes après importation
            QTimer.singleShot(200, self.resize_columns)
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Import error",
                f"An unexpected error occurred : {str(e)}",
                QMessageBox.StandardButton.Ok
            )
        finally:
            # Fermer la connexion si elle existe
            if 'conn' in locals():
                conn.close()

    def import_data(self):
        """Importe des données depuis un fichier de base de données SQLite dans le dossier data/."""
        try:
            # Vérifier si le répertoire data existe, sinon le créer
            if not hasattr(self, 'data_dir') or not self.data_dir:
                self.data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data')
            
            if not os.path.exists(self.data_dir):
                os.makedirs(self.data_dir)
            
            # Définir le dossier par défaut (data s'il existe, sinon le dossier personnel)
            default_dir = self.data_dir if hasattr(self, 'data_dir') and os.path.exists(self.data_dir) else os.path.expanduser('~')
            
            # Demander le fichier à importer
            file_path, _ = QFileDialog.getOpenFileName(
                self,
                "Select a database file",
                default_dir,
                "SQLite files (*.db *.sqlite *.sqlite3);;All files (*)"
            )
            
            if not file_path:
                return
                
            # Vérifier si le fichier source est valide
            if not os.path.isfile(file_path):
                QMessageBox.warning(
                    self,
                    "Invalid file",
                    "The selected file does not exist or is not accessible.",
                    QMessageBox.StandardButton.Ok
                )
                return
                
            # Vérifier la taille du fichier
            if os.path.getsize(file_path) == 0:
                QMessageBox.warning(
                    self,
                    "Empty file",
                    "The selected file is empty.",
                    QMessageBox.StandardButton.Ok
                )
                return
            
            # Vérifier si le fichier est une base de données SQLite valide
            try:
                import sqlite3
                conn = sqlite3.connect(file_path)
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                tables = cursor.fetchall()
                if not tables:
                    QMessageBox.warning(
                        self,
                        "Empty database",
                        "The selected database does not contain any tables.",
                        QMessageBox.StandardButton.Ok
                    )
                    return
                conn.close()
            except sqlite3.Error as e:
                QMessageBox.warning(
                    self,
                    "Invalid file",
                    f"The selected file is not a valid SQLite database : {str(e)}",
                    QMessageBox.StandardButton.Ok
                )
                return
                
            # Nettoyer le nom du fichier en supprimant les dates
            import re
            db_name = os.path.basename(file_path)
            # Supprimer les motifs de date comme _20231123, _2023-11-23, etc.
            db_name = re.sub(r'_\d{4}[-_]?\d{2}[-_]?\d{2}(?:_\d+)?', '', db_name)
            # Supprimer l'extension .db si elle est présente
            db_name = re.sub(r'\.db$', '', db_name, flags=re.IGNORECASE)
            # Ajouter l'extension .db si elle n'est pas présente
            if not db_name.lower().endswith('.db'):
                db_name += '.db'
            
            # Définir le chemin de destination dans le dossier data
            target_path = os.path.join(self.data_dir, db_name)
            
            # Si le fichier existe déjà, demander confirmation pour l'écraser
            if os.path.exists(target_path):
                reply = QMessageBox.question(
                    self,
                    "File already exists",
                    f"A file named '{db_name}' already exists in the data directory.\n"
                    "Do you want to overwrite it?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                if reply == QMessageBox.StandardButton.No:
                    return
            
            # Vérifier si on essaie de copier le fichier sur lui-même
            if os.path.abspath(file_path) == os.path.abspath(target_path):
                QMessageBox.information(
                    self,
                    "Information",
                    "You have selected the same file as the current database.",
                    QMessageBox.StandardButton.Ok
                )
                return
                
            # Copier le fichier dans le dossier data
            import shutil
            try:
                shutil.copy2(file_path, target_path)
                
                # Mettre à jour le chemin de la base de données
                self.db_path = target_path
                
                # Recharger les données
                self.load_data()
                
                # Forcer le redimensionnement des colonnes après importation
                QTimer.singleShot(200, self.resize_columns)
                
                QMessageBox.information(
                    self,
                    "Import successful",
                    "The database has been imported successfully.",
                    QMessageBox.StandardButton.Ok
                )
                
            except shutil.SameFileError:
                QMessageBox.information(
                    self,
                    "Information",
                    "You have selected the same file as the destination.",
                    QMessageBox.StandardButton.Ok
                )
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Import error",
                    f"Error during file copy : {str(e)}",
                    QMessageBox.StandardButton.Ok
                )
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Import error",
                f"An unexpected error occurred : {str(e)}",
                QMessageBox.StandardButton.Ok
            )
        finally:
            if 'conn' in locals():
                conn.close()
