"""Widget pour la gestion des membres Telegram avec terminal intégré."""
import os
import sys
import subprocess
import logging
import json
import webbrowser
import asyncio
from typing import Optional, Dict, Any

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit,
    QFileDialog, QMessageBox, QSizePolicy, QStyle, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QDockWidget, QApplication, QDialog, QComboBox
)
from PyQt6.QtCore import (
    QProcess, QTimer, Qt, QTextStream, QIODevice, 
    QProcessEnvironment, pyqtSignal, QObject, QUrl, QByteArray
)
from PyQt6.QtGui import (
    QTextCursor, QIcon, QPixmap, QAction, QKeyEvent, 
    QFont, QFontMetrics, QTextCharFormat, QColor
)

# Import des modules de paiement et de configuration
from ..payment.coinbase_commerce import CoinbaseCommerceClient
from ..config import COINBASE_COMMERCE_API_KEY, COINBASE_WEBHOOK_SECRET, LICENSE_PRICES
from .payment_dialog import PaymentDialog

# Import du système de notifications par bot
from ..notifications import NotificationManager, BotNotifier

# Utilitaires
from .utils import set_window_icon
from .database_manager import DatabaseManager
from .trial_manager import TrialManager
from datetime import datetime, timedelta

class MembersManagerWidget(QWidget):
    """Widget pour gérer les membres Telegram avec un terminal intégré."""
    
    # Signal pour les notifications
    notification_signal = pyqtSignal(str, bool)  # message, is_error

    def show_trial_dialog(self):
        """Affiche la boîte de dialogue d'essai gratuit et gère la logique."""
        # Vérifier si un essai est déjà actif
        if self.trial_manager.is_trial_active():
            trial_info = self.trial_manager.get_trial_info()
            end_date = datetime.fromisoformat(trial_info['end_date']).strftime('%m/%d/%Y')
            QMessageBox.information(
                self,
                "Trial already active",
                f"You have already activated your free trial.\n"
                f"Expiration date : {end_date}",
                QMessageBox.StandardButton.Ok
            )
            return

        # Vérifier si un essai existe mais est expiré
        trial_info = self.trial_manager.get_trial_info()
        if trial_info is not None:
            # Un fichier d'essai existe mais n'est plus actif = essai expiré
            start_date = datetime.fromisoformat(trial_info['start_date']).strftime('%m/%d/%Y')
            end_date = datetime.fromisoformat(trial_info['end_date']).strftime('%m/%d/%Y')
            QMessageBox.information(
                self,
                "Trial expired",
                f"Your free trial of {trial_info['days']} days has ended.\n\n"
                f"Trial period : {start_date} → {end_date}\n\n"
                f"💡 To continue using the application, you must purchase a license.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Afficher la boîte de dialogue de confirmation pour un nouvel essai
        reply = QMessageBox.question(
            self,
            "Free trial",
            "Do you want to activate a free trial of 7 days?\n\n"
            "Features included :\n"
            "• Complete members management\n"
            "• Access to all features",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes
        )

        if reply == QMessageBox.StandardButton.Yes:
            # Désactiver le bouton pendant la génération
            if hasattr(self, 'trial_btn'):
                self.trial_btn.setEnabled(False)
        
            try:
                # Démarrer l'essai
                trial_info = self.trial_manager.start_trial(7)
                # Générer la licence
                self.generate_trial_license()
            except Exception as e:
                logging.error(f"Error starting trial : {e}")
                QMessageBox.critical(
                    self,
                    "Error",
                    f"Unable to start trial : {str(e)}",
                    QMessageBox.StandardButton.Ok
                )
                if hasattr(self, 'trial_btn'):
                    self.trial_btn.setEnabled(True)
    
    def __init__(self, telegram_client, parent=None):
        """Initialise le widget du gestionnaire de membres.
        
        Args:
            telegram_client: Instance du client Telegram
            parent: Widget parent (optionnel)
        """
        print("🏗️ [MembersManagerWidget] Constructor called...")
        logging.info("🏗️ [MembersManagerWidget] Constructor called...")
        
        super().__init__(parent)
        self.telegram_client = telegram_client
        self.process = None
        self.trial_manager = TrialManager("TelegramManager")
        
        print(f"📞 [MembersManagerWidget] Telegram client in constructor: {telegram_client is not None}")
        logging.info(f"📞 [MembersManagerWidget] Telegram client in constructor: {telegram_client is not None}")
        
        # Initialiser le gestionnaire de notifications
        self.notification_manager = None
        self._setup_notification_manager(parent)
        
        # Récupérer le thème initial depuis la configuration du parent
        self._current_theme = self.get_initial_theme(parent)
        
        # Définir l'icône du widget
        set_window_icon(self, "members_manager_icon")
        
        print("✅ [MembersManagerWidget] Constructor completed")
        logging.info("✅ [MembersManagerWidget] Constructor completed")
        
        self.setup_ui()
        
        # Si c'est une fenêtre indépendante, définir le titre et la taille
        if self.isWindow():
            self.setWindowTitle("Members Manager")
            self.setMinimumSize(1000, 700)
            # Masquer les boutons de la fenêtre système
            self.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
            self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, False)
            self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, False)
        
        # Configurer la connexion de notification
        self.setup_notification_connection()
        
        # Connecter au signal de changement de thème du parent
        if parent and hasattr(parent, 'theme_changed'):
            parent.theme_changed.connect(self.on_theme_changed)
    
    def _setup_notification_manager(self, parent):
        """Configure le gestionnaire de notifications avec support bot."""
        print("🔧 [MembersManagerWidget] Setting up notification manager...")
        logging.info("🔧 [MembersManagerWidget] Setting up notification manager...")
        
        try:
            # Utiliser le NotificationManager global du MainWindow si disponible
            if parent and hasattr(parent, 'notification_manager'):
                self.notification_manager = parent.notification_manager
                print("✅ [MembersManagerWidget] Using global NotificationManager from MainWindow")
                logging.info("✅ [MembersManagerWidget] Using global NotificationManager from MainWindow")
            else:
                # Récupérer le callback UI du parent
                ui_callback = parent.add_notification if parent and hasattr(parent, 'add_notification') else None
                
                print(f"📞 [MembersManagerWidget] Telegram client available: {self.telegram_client is not None}")
                print(f"🎨 [MembersManagerWidget] UI callback available: {ui_callback is not None}")
                logging.info(f"📞 [MembersManagerWidget] Telegram client available: {self.telegram_client is not None}")
                logging.info(f"🎨 [MembersManagerWidget] UI callback available: {ui_callback is not None}")
                
                # Créer le gestionnaire de notifications avec le client Telegram principal
                print("🤖 [MembersManagerWidget] Creating NotificationManager...")
                logging.info("🤖 [MembersManagerWidget] Creating NotificationManager...")
                
                self.notification_manager = NotificationManager(
                    ui_callback=ui_callback,
                    telegram_client_wrapper=self.telegram_client
                )
                
                print("✅ [MembersManagerWidget] NotificationManager created successfully")
                logging.info("✅ [MembersManagerWidget] NotificationManager created successfully")
            
        except Exception as e:
            print(f"❌ [MembersManagerWidget] Error setting up notification manager: {e}")
            logging.error(f"❌ [MembersManagerWidget] Error setting up notification manager: {e}")
            logging.error(f"❌ [MembersManagerWidget] Error type: {type(e).__name__}")
            # Fallback: utiliser le système de notification simple
            self.notification_manager = None
        
    def get_initial_theme(self, parent):
        """Récupère le thème initial depuis la configuration.
        
        Args:
            parent: Widget parent pour accéder à la configuration
            
        Returns:
            str: Nom du thème ('light' ou 'dark')
        """
        try:
            # Essayer de récupérer depuis la configuration du parent
            if parent and hasattr(parent, 'config'):
                return parent.config.config.get('app', {}).get('theme', 'light')
            # Fallback: essayer depuis le home_widget
            elif parent and hasattr(parent, 'home_widget') and hasattr(parent.home_widget, '_current_theme'):
                return parent.home_widget._current_theme
            # Fallback: essayer directement depuis le parent
            elif parent and hasattr(parent, '_current_theme'):
                return parent._current_theme
            else:
                # Dernier fallback: light par défaut
                return 'light'
        except Exception:
            # En cas d'erreur, retourner le thème par défaut
            return 'light'
    
    def setup_notification_connection(self):
        """Configure la connexion des notifications avec le parent."""
        parent = self.parent()
        if parent is not None and hasattr(parent, 'add_notification'):
            try:
                # Se déconnecter d'abord pour éviter les doublons
                self.notification_signal.disconnect()
            except (TypeError, RuntimeError) as e:
                # Ignorer si pas encore connecté
                pass
            
            # Se reconnecter au parent
            self.notification_signal.connect(parent.add_notification)
        else:
            pass
    
    async def send_notification(self, message: str, is_error: bool = False, bot_only: bool = False):
        """
        Envoie une notification via le gestionnaire de notifications.
        
        Args:
            message: Message de notification
            is_error: Si True, formate comme une erreur
            bot_only: Si True, n'envoie que via le bot
        """
        if self.notification_manager:
            await self.notification_manager.send_notification(message, is_error, bot_only)
        else:
            # Fallback: utiliser l'ancien système
            self.notification_signal.emit(message, is_error)
    
    def showEvent(self, event):
        """Gère l'événement d'affichage du widget."""
        super().showEvent(event)
        # S'assurer que la connexion de notification est établie
        self.setup_notification_connection()
    
    def setup_ui(self):
        """Configure l'interface utilisateur du widget."""
        # Configuration de la fenêtre - uniquement si c'est une fenêtre indépendante
        if self.isWindow():
            # Configurer la fenêtre avec les drapeaux de base
            self.setWindowFlags(Qt.WindowType.Window | 
                              Qt.WindowType.WindowTitleHint |
                              Qt.WindowType.CustomizeWindowHint)
            
            # Désactiver la barre de titre native
        else:
            # Si c'est un widget intégré, ne pas définir de drapeaux de fenêtre
            pass
        
        # Layout principal
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(5, 30, 5, 5)
        main_layout.setSpacing(5)
        
        # Ne pas démarrer automatiquement le programme
        # L'utilisateur devra cliquer sur le bouton Démarrer
        
        # Barre de titre personnalisée
        self.title_bar = QFrame()
        self.title_bar.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                          stop:0 #1e88e5, stop:1 #0d47a1);
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                padding: 5px;
            }
            QPushButton {
                background: transparent;
                border: none;
                color: white;
                padding: 2px 8px;
                font-size: 14px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 4px;
            }
        """)
        title_layout = QHBoxLayout(self.title_bar)
        title_layout.setContentsMargins(5, 0, 5, 0)
        title_layout.setSpacing(10)
        
        # Titre de la fenêtre
        self.title_label = QLabel("Members Manager")
        self.title_label.setStyleSheet("color: white; font-weight: bold;")
        title_layout.addWidget(self.title_label)
        
        # Boutons de contrôle de la fenêtre - afficher même en mode intégré pour le bouton d'essai
        if self.isWindow():
            self.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
            self.trial_btn = QPushButton("Free Trial")
            self.trial_btn.setStyleSheet("""
                QPushButton {
                background: #4CAF50;
                color: white;
                border: none;
                padding: 2px 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #45a049;
            }
        """)
            self.trial_btn.clicked.connect(self.show_trial_dialog)
            title_layout.addWidget(self.trial_btn)

            title_layout.addStretch()
            
            # Bouton Réduire
            self.minimize_btn = QPushButton("−")
            self.minimize_btn.setFixedSize(20, 20)
            self.minimize_btn.clicked.connect(self.showMinimized)
            title_layout.addWidget(self.minimize_btn)
            
            # Bouton Agrandir/Restaurer
            self.maximize_btn = QPushButton("□")
            self.maximize_btn.setFixedSize(20, 20)
            self.maximize_btn.clicked.connect(self.toggle_maximize)
            title_layout.addWidget(self.maximize_btn)
            
            # Bouton Fermer
            self.close_btn = QPushButton("×")
            self.close_btn.setFixedSize(20, 20)
            self.close_btn.clicked.connect(self.close)
            title_layout.addWidget(self.close_btn)
        else:
            # En mode intégré, afficher seulement le bouton d'essai à droite
            title_layout.addStretch()
            self.trial_btn = QPushButton("Free Trial")
            self.trial_btn.setStyleSheet("""
                QPushButton {
                background: #4CAF50;
                color: white;
                border: none;
                padding: 2px 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #45a049;
            }
        """)
            self.trial_btn.clicked.connect(self.show_trial_dialog)
            title_layout.addWidget(self.trial_btn)
        
        # Ajout de la barre de titre
        main_layout.addWidget(self.title_bar, 0, Qt.AlignmentFlag.AlignTop)
        
        # Zone de boutons
        button_layout = QHBoxLayout()
        
        # Bouton Start
        self.start_btn = QPushButton("Start")
        self.start_btn.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))
        self.start_btn.clicked.connect(self.start_process)
        button_layout.addWidget(self.start_btn)
        
        # Bouton Stop
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaStop))
        self.stop_btn.clicked.connect(self.stop_process)
        self.stop_btn.setEnabled(False)
        button_layout.addWidget(self.stop_btn)
        
        # Bouton pour gérer les données
        self.db_btn = QPushButton("Manage data")
        self.db_btn.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_FileDialogDetailedView))
        self.db_btn.clicked.connect(self.manage_database)
        button_layout.addWidget(self.db_btn)
        
        # Bouton Generate License
        self.license_btn = QPushButton("Generate license")
        self.license_btn.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon))
        self.license_btn.clicked.connect(self.generate_license)
        button_layout.addWidget(self.license_btn)
        
        # Espacement
        button_layout.addStretch()
        
        # Ajout de la barre de boutons au layout principal
        main_layout.addLayout(button_layout)
        
        # Zone de terminal (lecture seule)
        self.terminal = QTextEdit()
        self.terminal.setReadOnly(True)  # Désactiver l'édition directe
        self.update_terminal_style()  # Appliquer le style initial
        
        # Configurer le comportement du terminal
        self.terminal.setAcceptRichText(False)
        self.terminal.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        main_layout.addWidget(self.terminal)
        
        # Zone de saisie utilisateur
        self.input_frame = QFrame()
        
        input_layout = QHBoxLayout(self.input_frame)
        input_layout.setContentsMargins(0, 0, 0, 0)
        
        # Modern paste button
        self.paste_button = QPushButton(">>")
        self.paste_button.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                          stop:0 #87CEEB, stop:1 #4682B4);
                color: white;
                border: none;
                border-radius: 6px;
                padding: 4px 8px;
                font-size: 12px;
                font-weight: bold;
                min-width: 30px;
                max-width: 30px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                          stop:0 #6BB6D6, stop:1 #5F9EA0);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                          stop:0 #4682B4, stop:1 #4169E1);
            }
        """)
        self.paste_button.setToolTip("Paste from clipboard")
        self.paste_button.clicked.connect(self.paste_from_clipboard)
        input_layout.addWidget(self.paste_button)
        
        self.input_field = QLineEdit()
        self.input_field.returnPressed.connect(self.on_input_entered)
        input_layout.addWidget(self.input_field)
        
        # Modern Enter button
        self.enter_button = QPushButton("Enter")
        self.enter_button.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                          stop:0 #87CEEB, stop:1 #4682B4);
                color: white;
                border: none;
                border-radius: 6px;
                padding: 6px 12px;
                font-size: 12px;
                font-weight: bold;
                min-width: 50px;
                max-width: 50px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                          stop:0 #6BB6D6, stop:1 #5F9EA0);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                          stop:0 #4682B4, stop:1 #4169E1);
            }
        """)
        self.enter_button.setToolTip("Execute command")
        self.enter_button.clicked.connect(self.on_input_entered)
        input_layout.addWidget(self.enter_button)
        
        # Appliquer le style après la création de tous les éléments
        self.update_input_frame_style()  # Appliquer le style initial
        
        main_layout.addWidget(self.input_frame)
        
        # Historique des commandes
        self.command_history = []
        self.history_index = 0
        
        # Initialisation du processus (sera configuré dans start_process)
        self.process = None
        
        # Activer le focus sur le champ de saisie
        self.input_field.setFocus()
        
    def manage_database(self):
        """Ouvre le gestionnaire de base de données."""
        try:
            # Chemin vers le dossier Program à la racine d'AppTG
            app_root = os.path.abspath(os.path.join(
                os.path.dirname(__file__), 
                "..", "..", "..", ".."  # Remonter jusqu'à la racine d'AppTG
            ))
            data_dir = os.path.join(app_root, "Program", "data")
            
            # Créer le dossier data s'il n'existe pas
            if not os.path.exists(data_dir):
                print(f"[INFO] Creating the data directory: {data_dir}")
                os.makedirs(data_dir, exist_ok=True)
            
            # Ouvrir la fenêtre de gestion de la base de données
            print(f"[INFO] Using the data directory: {data_dir}")
            dialog = DatabaseManager(data_dir, self)
            dialog.exec()
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"Unable to open the database manager: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
    
    def clear_terminal(self):
        """Clear the terminal content."""
        self.terminal.clear()
        
    def start_process(self):
        """Démarre le processus du gestionnaire de membres."""
        try:
            # Arrêter le processus s'il est déjà en cours d'exécution
            if self.process and self.process.state() == QProcess.ProcessState.Running:
                self.stop_process()
                
            # Nettoyer le terminal
            self.clear_terminal()
            
            # Mettre à jour l'interface avant de démarrer
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            
            # Notifier le démarrage
            self.notification_signal.emit("🚀 Starting the Members Manager...", False)
            print("🔔 Notification: Starting the Members Manager...")
            
            # Envoyer aussi via le bot si disponible
            if self.notification_manager:
                try:
                    # Vérifier si une boucle asyncio est active
                    loop = asyncio.get_running_loop()
                    asyncio.create_task(self.send_notification("🚀 Starting the Members Manager...", False))
                except RuntimeError:
                    # Pas de boucle asyncio active (application en train de fermer)
                    pass
            
            # Construction du chemin vers le dossier Program
            current_dir = os.path.dirname(os.path.abspath(__file__))  # Dossier ui
            src_dir = os.path.dirname(current_dir)  # Dossier telegram_manager
            telegram_dir = os.path.dirname(src_dir)  # Dossier src
            setup_dir = os.path.dirname(telegram_dir)  # Dossier setup
            app_root = os.path.dirname(setup_dir)  # Dossier AppTG
            program_path = os.path.join(app_root, "Program")
            
            # Afficher la structure des dossiers pour le débogage
            print("\n[DEBUG] Directory structure:")
            print(f"- {app_root} (root)")
            print(f"  - {os.path.basename(setup_dir)}/ (setup directory)")
            print(f"  - Program/ (program directory)")
            
            # Vérifier l'existence du dossier Program
            if not os.path.exists(program_path):
                print("\n[ERROR] Program folder not found:")
                for item in os.listdir(app_root):
                    item_path = os.path.join(app_root, item)
                    print(f"- {item} {'(directory)' if os.path.isdir(item_path) else ''}")
                
                error_msg = (
                    f"\n[ERROR] The Program folder is not found at:\n"
                    f"{program_path}\n"
                    "Please ensure that the 'Program' folder exists at:\n"
                    f"{app_root}"
                )
                print(error_msg)
                raise FileNotFoundError(error_msg)
            
            print(f"\n[SUCCESS] Program folder found: {program_path}")
            
            # Vérifier l'existence du fichier main.py
            main_script = os.path.join(program_path, "main.py")
            if not os.path.exists(main_script):
                error_msg = (
                    f"\n[ERROR] The main.py file is not found in:\n"
                    f"{program_path}\n"
                    f"Content of the Program folder:\n"
                )
                try:
                    for item in os.listdir(program_path):
                        item_path = os.path.join(program_path, item)
                        error_msg += f"- {item} {'(directory)' if os.path.isdir(item_path) else ''}\n"
                except Exception as e:
                    error_msg += f"Unable to list the content of the folder: {str(e)}\n"
                
                print(error_msg)
                raise FileNotFoundError(f"The main.py file is not found in: {program_path}")
            
            print(f"[SUCCESS] main.py file found: {main_script}")
            
            # Arrêter le processus s'il est déjà en cours d'exécution
            if self.process and self.process.state() == QProcess.ProcessState.Running:
                self.process.kill()
                self.process.waitForFinished()
            
            # Créer un nouveau processus
            self.process = QProcess()
            self.process.readyReadStandardOutput.connect(self.read_stdout)
            self.process.readyReadStandardError.connect(self.read_stderr)
            self.process.finished.connect(self.process_finished)
            
            # Configurer l'environnement pour le processus
            env = QProcessEnvironment.systemEnvironment()
            env.insert("PYTHONIOENCODING", "utf-8")
            env.insert("PYTHONUTF8", "1")
            env.insert("FORCE_HTML_COLORS", "1")  # Forcer les couleurs HTML pour progress.py
            env.insert("PROGRESS_HTML_MODE", "1")  # Alternative pour forcer le mode HTML
            
            # Configurer le processus
            self.process.setWorkingDirectory(program_path)
            self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
            self.process.setProcessEnvironment(env)
            
            # Démarrer le processus avec les paramètres UTF-8
            python_executable = sys.executable
            script_path = os.path.join(program_path, "main.py")
            
            if not os.path.exists(script_path):
                QMessageBox.critical(
                    self,
                    "Error",
                    f"The main.py file is not found in : {program_path}",
                    QMessageBox.StandardButton.Ok
                )
                return
            
            # Configurer l'environnement pour le processus
            env = QProcessEnvironment.systemEnvironment()
            env.insert("PYTHONIOENCODING", "utf-8")
            env.insert("PYTHONLEGACYWINDOWSSTDIO", "utf-8")
            
            # Démarrer le processus
            print(f"Starting process: {python_executable} -X utf8 -u {script_path}")
            self.process.start(python_executable, ["-X", "utf8", "-u", script_path])
            
            if not self.process.waitForStarted(5000):  # Attendre 5 secondes max
                error_msg = "❌ Process start failed: timeout"
                print(error_msg)
                self.notification_signal.emit(error_msg, True)
                # Envoyer aussi via le bot si disponible
                if self.notification_manager:
                    try:
                        # Vérifier si une boucle asyncio est active
                        loop = asyncio.get_running_loop()
                        asyncio.create_task(self.send_notification(error_msg, True))
                    except RuntimeError:
                        # Pas de boucle asyncio active (application en train de fermer)
                        pass
                raise Exception(error_msg)
                
            print("✅ Members Manager started successfully")
            self.append_output("=== Members Manager started successfully ===\n")
            self.append_output(f"Directory: {program_path}\n")
            self.append_output(f"Command: {python_executable} -X utf8 -u main.py\n\n")
            self.notification_signal.emit("✅ Members Manager started successfully", False)
            
            # Envoyer aussi via le bot si disponible
            if self.notification_manager:
                try:
                    # Vérifier si une boucle asyncio est active
                    loop = asyncio.get_running_loop()
                    asyncio.create_task(self.send_notification("✅ Members Manager started successfully", False))
                except RuntimeError:
                    # Pas de boucle asyncio active (application en train de fermer)
                    pass
            
        except Exception as e:
            self.append_output(f"Error starting the process: {str(e)}\n")
            logging.error(f"Error starting the process: {e}")
    
    def stop_process(self, silent=False):
        """Arrête le processus en cours d'exécution.
        
        Args:
            silent (bool): Si True, n'affiche pas de notification
        """
        if self.process and self.process.state() == QProcess.ProcessState.Running:
            if not silent:
                #self.append_output("\n=== Members manager stopped successfully ===\n")
                print("🛑 Members Manager stopped successfully...")
                self.notification_signal.emit("🛑 Members Manager stopped successfully...", False)
                
                # Envoyer aussi via le bot si disponible
                #if self.notification_manager:
                #    asyncio.create_task(self.send_notification("🛑 Members manager stopped successfully...", False))
            
            # Désactiver les boutons pendant l'arrêt
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(False)
            
            # Arrêt du processus
            self.process.terminate()
            
            # Attendre la fin du processus avec un timeout
            if not self.process.waitForFinished(3000):  # 3 secondes
                # Si le processus ne répond pas, le forcer à s'arrêter
                self.process.kill()
                self.process.waitForFinished(1000)
            
            self.append_output("=== Members Manager stopped successfully ===\n")
            self.notification_signal.emit("Members Manager stopped successfully", False)
            
            # Envoyer aussi via le bot si disponible
            if self.notification_manager:
                asyncio.create_task(self.send_notification("Members Manager stopped successfully", False))
        
        # Réactiver le bouton de démarrage et désactiver le bouton d'arrêt
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
    
    def read_stdout(self):
        """Lit la sortie standard du processus avec gestion d'encodage."""
        if self.process:
            raw_data = self.process.readAllStandardOutput().data()
            try:
                # Essayer d'abord avec UTF-8
                data = raw_data.decode('utf-8')
            except UnicodeDecodeError:
                # Si échec, essayer avec la locale système (cp1252 sous Windows)
                try:
                    import locale
                    data = raw_data.decode(locale.getpreferredencoding())
                except:
                    # En dernier recours, utiliser replace pour les caractères invalides
                    data = raw_data.decode('utf-8', errors='replace')
            
            if data:
                self.append_output(data)
    
    def read_stderr(self):
        """Lit la sortie d'erreur du processus avec gestion d'encodage."""
        if self.process:
            raw_data = self.process.readAllStandardError().data()
            try:
                # Essayer d'abord avec UTF-8
                data = raw_data.decode('utf-8')
            except UnicodeDecodeError:
                # Si échec, essayer avec la locale système (cp1252 sous Windows)
                try:
                    import locale
                    data = raw_data.decode(locale.getpreferredencoding())
                except:
                    # En dernier recours, utiliser replace pour les caractères invalides
                    data = raw_data.decode('utf-8', errors='replace')
            
            if data:
                self.append_output(f"<span style='color: #ff6b6b'>{data}</span>")
    
    def process_finished(self, exit_code, exit_status):
        """Appelé lorsque le processus est terminé."""
        # Mettre à jour l'interface
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        
        # Déterminer le message en fonction du code de sortie
        if exit_code == 0 or exit_code == 15:  # 15 est le code de sortie pour SIGTERM
            message = "Process finished / Members Manager stopped"
            is_error = False
        else:
            message = "⛔ Members Manager stopped by user"
            is_error = True
        
        # Afficher le message dans la console et envoyer une notification
        print(message)
        self.append_output(f"\n=== {message} ===\n")
        self.notification_signal.emit(message, is_error)
        
        # Envoyer aussi via le bot si disponible
        if self.notification_manager:
            try:
                # Vérifier si une boucle asyncio est active
                loop = asyncio.get_running_loop()
                asyncio.create_task(self.send_notification(message, is_error))
            except RuntimeError:
                # Pas de boucle asyncio active (application en train de fermer)
                pass
        
        # Nettoyer le processus
        try:
            if self.process:
                self.process.deleteLater()
                self.process = None
        except RuntimeError:
            # L'objet a déjà été supprimé (application en train de fermer)
            self.process = None
    
    def on_process_error(self, error):
        """Gère les erreurs du processus."""
        error_msg = f"❌ Process error: {error}"
        self.append_output(f"\n{error_msg}\n")
        self.stop_btn.setEnabled(False)
        self.start_btn.setEnabled(True)
        logging.error(error_msg)
        self.notification_signal.emit(error_msg, True)
        
        # Envoyer aussi via le bot si disponible
        if self.notification_manager:
            try:
                # Vérifier si une boucle asyncio est active
                loop = asyncio.get_running_loop()
                asyncio.create_task(self.send_notification(error_msg, True))
            except RuntimeError:
                # Pas de boucle asyncio active (application en train de fermer)
                pass
    
    def paste_from_clipboard(self):
        """Paste clipboard content to the input field."""
        try:
            from PyQt6.QtWidgets import QApplication
            clipboard = QApplication.clipboard()
            text = clipboard.text()
            if text:
                # Insert text at current cursor position
                cursor = self.input_field.cursorPosition()
                current_text = self.input_field.text()
                new_text = current_text[:cursor] + text + current_text[cursor:]
                self.input_field.setText(new_text)
                # Position cursor after pasted text
                self.input_field.setCursorPosition(cursor + len(text))
                self.input_field.setFocus()
        except Exception as e:
            logging.error(f"Error pasting from clipboard: {e}")
    
    def on_input_entered(self):
        """Appelé lorsque l'utilisateur appuie sur Entrée dans le champ de saisie."""
        command = self.input_field.text().strip()
        if command:
            # Afficher la commande dans le terminal
            self.append_output(f">> {command}\n")
            
            # Exécuter la commande
            self.execute_command(command)
            
            # Ajouter à l'historique
            self.command_history.append(command)
            self.history_index = len(self.command_history)
            
            # Effacer le champ de saisie
            self.input_field.clear()
    
    def keyPressEvent(self, event):
        """Gestion des raccourcis clavier globaux."""
        # Navigation dans l'historique avec les flèches haut/bas
        if event.key() == Qt.Key.Key_Up and self.command_history:
            if self.history_index > 0:
                self.history_index -= 1
                self.input_field.setText(self.command_history[self.history_index])
        elif event.key() == Qt.Key.Key_Down and self.command_history:
            if self.history_index < len(self.command_history) - 1:
                self.history_index += 1
                self.input_field.setText(self.command_history[self.history_index])
            else:
                self.history_index = len(self.command_history)
                self.input_field.clear()
        else:
            super().keyPressEvent(event)
    
    def execute_command(self, command):
        """Exécute une commande dans le processus."""
        if not self.process or self.process.state() != QProcess.ProcessState.Running:
            self.append_output("Error: No running process.\n")
            return
            
        # Ajouter un retour à la ligne à la commande si nécessaire
        if not command.endswith('\n'):
            command += '\n'
            
        # Écrire la commande dans l'entrée standard du processus
        try:
            self.process.write(command.encode('utf-8'))
        except Exception as e:
            self.append_output(f"Error while sending the command: {str(e)}\n")
    
    def append_output(self, text):
        """Ajoute du texte à la sortie du terminal avec conversion des couleurs."""
        cursor = self.terminal.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        
        # DÉSACTIVÉ - La gestion des retours chariot cause des blocages
        # Priorité: Stabilité > Apparence
        # Les couleurs bleues fonctionnent déjà parfaitement
        # TODO: Réimplémenter avec une approche différente si nécessaire
        # 
        # if '\r' in text:
        #     # Séparer le texte par les retours chariot
        #     lines = text.split('\r')
        #     if len(lines) > 1:
        #         # Garder seulement la dernière ligne (la mise à jour actuelle)
        #         text = lines[-1]
        #         # Vérifier si c'est une barre de progression tqdm
        #         if '📅 Today:' in text and '%' in text and '|' in text:
        #             # Supprimer uniquement la dernière ligne si c'est une barre de progression
        #             try:
        #                 cursor.movePosition(QTextCursor.MoveOperation.StartOfLine, QTextCursor.MoveMode.KeepAnchor)
        #                 selected_text = cursor.selectedText()
        #                 # Vérifier que la ligne à supprimer est bien une barre de progression
        #                 if '📅 Today:' in selected_text and '%' in selected_text:
        #                     cursor.removeSelectedText()
        #             except:
        #                 # En cas d'erreur, continuer sans suppression pour éviter les blocages
        #                 pass
        
        # Vérifier si le texte contient déjà des balises HTML
        if '<span style=' in text:
            # Utiliser insertHtml pour les couleurs HTML existantes
            cursor.insertHtml(text)
        else:
            # Convertir les codes ANSI en HTML si présents
            html_text = self.convert_ansi_to_html(text)
            if html_text != text:
                # Du texte a été converti, utiliser insertHtml
                cursor.insertHtml(html_text)
            else:
                # Pas de conversion, utiliser insertText
                cursor.insertText(text)
        
        self.terminal.setTextCursor(cursor)
        self.ensure_cursor_visible()
    
    def convert_ansi_to_html(self, text):
        """Convertit les codes couleur ANSI en HTML."""
        import re
        
        # Codes ANSI à remplacer par des couleurs HTML (COMPLET - tout en bleu pour cohérence)
        ansi_to_html = {
            # Reset
            '\033[0m': '</span>',                              # Reset
            
            # Codes de base - TOUS en bleu pour cohérence du thème
            '\033[30m': '<span style="color: #3498db;">',      # Noir → Bleu
            '\033[31m': '<span style="color: #3498db;">',      # Rouge → Bleu
            '\033[32m': '<span style="color: #3498db;">',      # Vert → Bleu
            '\033[33m': '<span style="color: #3498db;">',      # Jaune → Bleu
            '\033[34m': '<span style="color: #3498db;">',      # Bleu → Bleu
            '\033[35m': '<span style="color: #3498db;">',      # Magenta → Bleu
            '\033[36m': '<span style="color: #3498db;">',      # Cyan → Bleu
            '\033[37m': '<span style="color: #3498db;">',      # Blanc → Bleu
            
            # Codes clairs - TOUS en bleu clair
            '\033[90m': '<span style="color: #3498db;">',      # Gris foncé → Bleu
            '\033[91m': '<span style="color: #3498db;">',      # Rouge clair → Bleu
            '\033[92m': '<span style="color: #3498db;">',      # Vert clair → Bleu
            '\033[93m': '<span style="color: #3498db;">',      # Jaune clair → Bleu
            '\033[94m': '<span style="color: #3498db;">',      # Bleu clair → Bleu
            '\033[95m': '<span style="color: #3498db;">',      # Magenta clair → Bleu
            '\033[96m': '<span style="color: #3498db;">',      # Cyan clair → Bleu
            '\033[97m': '<span style="color: #3498db;">',      # Blanc clair → Bleu
            
            # Codes avec gras (bold) - TOUS en bleu gras
            '\033[1m': '<span style="color: #2980b9; font-weight: bold;">',     # Gras → Bleu gras
            '\033[1;30m': '<span style="color: #2980b9; font-weight: bold;">',  # Noir gras → Bleu gras
            '\033[1;31m': '<span style="color: #2980b9; font-weight: bold;">',  # Rouge gras → Bleu gras
            '\033[1;32m': '<span style="color: #2980b9; font-weight: bold;">',  # Vert gras → Bleu gras
            '\033[1;33m': '<span style="color: #2980b9; font-weight: bold;">',  # Jaune gras → Bleu gras
            '\033[1;34m': '<span style="color: #2980b9; font-weight: bold;">',  # Bleu gras → Bleu gras
            '\033[1;35m': '<span style="color: #2980b9; font-weight: bold;">',  # Magenta gras → Bleu gras
            '\033[1;36m': '<span style="color: #2980b9; font-weight: bold;">',  # Cyan gras → Bleu gras
            '\033[1;37m': '<span style="color: #2980b9; font-weight: bold;">',  # Blanc gras → Bleu gras
            '\033[1;90m': '<span style="color: #2980b9; font-weight: bold;">',  # Gris gras → Bleu gras
            '\033[1;91m': '<span style="color: #2980b9; font-weight: bold;">',  # Rouge clair gras → Bleu gras
            '\033[1;92m': '<span style="color: #2980b9; font-weight: bold;">',  # Vert clair gras → Bleu gras
            '\033[1;93m': '<span style="color: #2980b9; font-weight: bold;">',  # Jaune clair gras → Bleu gras
            '\033[1;94m': '<span style="color: #2980b9; font-weight: bold;">',  # Bleu clair gras → Bleu gras
            '\033[1;95m': '<span style="color: #2980b9; font-weight: bold;">',  # Magenta clair gras → Bleu gras
            '\033[1;96m': '<span style="color: #2980b9; font-weight: bold;">',  # Cyan clair gras → Bleu gras
            '\033[1;97m': '<span style="color: #2980b9; font-weight: bold;">',  # Blanc clair gras → Bleu gras
            
            # Codes alternatifs (sans point-virgule)
            '\033[32m': '<span style="color: #3498db;">',      # Vert → Bleu
            '\033[92m': '<span style="color: #3498db;">',      # Vert clair → Bleu
            '\033[1;32m': '<span style="color: #2980b9; font-weight: bold;">',  # Vert gras → Bleu gras
            '\033[1;92m': '<span style="color: #2980b9; font-weight: bold;">',  # Vert clair gras → Bleu gras
            
            # Codes de fond (background) - aussi en bleu
            '\033[40m': '<span style="color: #3498db;">',      # Fond noir → Bleu
            '\033[41m': '<span style="color: #3498db;">',      # Fond rouge → Bleu
            '\033[42m': '<span style="color: #3498db;">',      # Fond vert → Bleu
            '\033[43m': '<span style="color: #3498db;">',      # Fond jaune → Bleu
            '\033[44m': '<span style="color: #3498db;">',      # Fond bleu → Bleu
            '\033[45m': '<span style="color: #3498db;">',      # Fond magenta → Bleu
            '\033[46m': '<span style="color: #3498db;">',      # Fond cyan → Bleu
            '\033[47m': '<span style="color: #3498db;">',      # Fond blanc → Bleu
            
            # Codes spéciaux tqdm et autres librairies
            '\033[35m': '<span style="color: #3498db;">',      # Magenta → Bleu
            '\033[36m': '<span style="color: #3498db;">',      # Cyan → Bleu
            '\033[A': '',                                       # Curseur vers le haut (ignorer)
            '\033[B': '',                                       # Curseur vers le bas (ignorer)
            '\033[C': '',                                       # Curseur vers la droite (ignorer)
            '\033[D': '',                                       # Curseur vers la gauche (ignorer)
            '\033[K': '',                                       # Effacer fin de ligne (ignorer)
            '\033[J': '',                                       # Effacer écran (ignorer)
            '\033[H': '',                                       # Position curseur (ignorer)
            '\033[2K': '',                                      # Effacer ligne entière (ignorer)
        }
        
        # Remplacer tous les codes ANSI
        html_text = text
        for ansi_code, html_tag in ansi_to_html.items():
            html_text = html_text.replace(ansi_code, html_tag)
        
        # Colorisation automatique des temps et nombres dans les barres de progression
        if '📅 Today:' in html_text and '%' in html_text:
            import re
            
            # Colorier les temps au format [MM:SS ou [HH:MM:SS
            # Correction: gérer les temps suivis directement par des nombres comme [03:29671
            html_text = re.sub(r'\[(\d{1,2}:\d{2}(?::\d{2})?)(?=\d{3,}|\D|$)', r'[<span style="color: #3498db;">\1</span> ', html_text)
            
            # Colorier les nombres dans les barres de progression (ex: 6/40, 15%)
            html_text = re.sub(r'(\d+)/(\d+)', r'<span style="color: #3498db;">\1</span>/<span style="color: #3498db;">\2</span>', html_text)
            html_text = re.sub(r'(\d+)%', r'<span style="color: #3498db;">\1</span>%', html_text)
            
            # Colorier les caractères de barre de progression qui ne sont pas déjà colorés
            # Chercher les caractères de barre après | et avant |
            html_text = re.sub(r'\|([^|]*)\|', lambda m: '|' + re.sub(r'([█▌░▏▎▓▐])', r'<span style="color: #3498db;">\1</span>', m.group(1)) + '|', html_text)
        
        return html_text
    
    def ensure_cursor_visible(self):
        """Assure que le curseur est visible dans la zone de défilement."""
        self.terminal.ensureCursorVisible()
        vsb = self.terminal.verticalScrollBar()
        vsb.setValue(vsb.maximum())
    
    def show_logs(self):
        """Affiche les journaux du gestionnaire de membres."""
        # Implémentez la logique pour afficher les journaux
        self.append_output("\n=== Showing logs ===\n")
        # TODO: Implémenter la lecture des fichiers de logs
    
    def generate_license(self):
        """
        Affiche la boîte de dialogue de paiement et lance la génération de la licence 
        après confirmation du paiement.
        """
        try:
            # Désactiver le bouton pendant le processus
            self.license_btn.setEnabled(False)
            self.license_btn.setText("Payment processing...")
            QApplication.processEvents()
            
            # Vérifier que les clés API sont configurées
            if not COINBASE_COMMERCE_API_KEY or COINBASE_COMMERCE_API_KEY == 'your_api_key_here':
                raise ValueError("The Coinbase Commerce API key is not configured correctly.")
            
            # Créer le client de paiement
            payment_client = CoinbaseCommerceClient(
                api_key=COINBASE_COMMERCE_API_KEY,
                webhook_secret=COINBASE_WEBHOOK_SECRET,
                parent=self
            )
            
            # Afficher la boîte de dialogue de paiement
            payment_dialog = PaymentDialog(
                payment_client=payment_client,
                amount=LICENSE_PRICES['1_month'],  # Utilisation du prix depuis la configuration
                currency='USD',
                parent=self
            )
            
            # Connecter les signaux
            payment_dialog.payment_verified.connect(self.on_payment_verified)
            payment_dialog.payment_failed.connect(self.on_payment_failed)
            
            # Afficher la boîte de dialogue
            payment_dialog.exec()
            
            # Réactiver le bouton si l'utilisateur annule
            if not payment_dialog.result():
                self.license_btn.setEnabled(True)
                self.license_btn.setText("Generate license")
        
        except Exception as e:
            error_msg = f"Error preparing the payment: {str(e)}"
            logging.error(error_msg, exc_info=True)
            QMessageBox.critical(
                self,
                "Error",
                f"Unable to start the payment process:\n{str(e)}\n\n"
                f"Please check your Internet connection and try again.",
                QMessageBox.StandardButton.Ok
            )
            self.license_btn.setEnabled(True)
            self.license_btn.setText("Generate license")
    
    def on_payment_verified(self, payment_data):
        """
        Appelé lorsque le paiement est vérifié avec succès.
        Démarre la génération de la licence.
        """
        try:
            self.append_output("\n=== Payment confirmed ===\n")
            self.append_output(f"Transaction ID: {payment_data.get('id', 'N/A')}\n")
            
            # Update the interface
            self.license_btn.setText("License generation...")
            
            # Construction du chemin vers le script de génération de licence
            current_dir = os.path.dirname(os.path.abspath(__file__))  # Dossier ui
            src_dir = os.path.dirname(current_dir)  # Dossier telegram_manager
            telegram_dir = os.path.dirname(src_dir)  # Dossier src
            setup_dir = os.path.dirname(telegram_dir)  # Dossier setup
            app_root = os.path.dirname(setup_dir)  # Dossier AppTG
            program_path = os.path.join(app_root, "Program")
            license_script = os.path.join(program_path, "manage_license.py")
            
            # Vérifier que le script de licence existe
            if not os.path.exists(license_script):
                error_msg = f"[ERROR] The license script is not found: {license_script}"
                self.append_output(f"\n{error_msg}")
                self.license_btn.setEnabled(True)
                self.license_btn.setText("Generate license")
                return
            
            # Créer et configurer le processus
            self.license_process = QProcess()
            self.license_process.setWorkingDirectory(program_path)
            
            # Configurer la sortie standard et d'erreur
            self.license_process.readyReadStandardOutput.connect(self.handle_license_output)
            self.license_process.readyReadStandardError.connect(self.handle_license_error)
            self.license_process.finished.connect(self.on_license_generated)
            
            # Start the process
            self.append_output("=== License generation in progress ===\n")
            self.license_process.start("python", ["manage_license.py", "generate", "--days", "30"])
            
        except Exception as e:
            error_msg = f"Error starting license generation: {str(e)}"
            logging.error(error_msg, exc_info=True)
            self.append_output(f"\n{error_msg}")
            self.license_btn.setEnabled(True)
            self.license_btn.setText("Generate license")
    
    def on_payment_failed(self, error_message):
        """
        Appelé en cas d'échec du paiement.
        
        Args:
            error_message: Message d'erreur décrivant la raison de l'échec
        """
        error_msg = f"Payment failed: {error_message}"
        logging.error(error_msg)
        self.append_output(f"\n❌ {error_msg}\n")
        
        # Afficher un message d'erreur à l'utilisateur
        QMessageBox.critical(
            self,
            "Payment failed",
            f"The payment could not be processed:\n{error_message}\n\nPlease try again or contact support.",
            QMessageBox.StandardButton.Ok
        )
        
        # Réactiver le bouton
        self.license_btn.setEnabled(True)
        self.license_btn.setText("Generate license")
    
    def handle_license_output(self):
        """Affiche la sortie standard du processus de génération de licence."""
        if hasattr(self, 'license_process'):
            output = self.license_process.readAllStandardOutput().data().decode('utf-8', errors='replace')
            if output:
                self.append_output(output)
    
    def handle_license_error(self):
        """Affiche les erreurs du processus de génération de licence."""
        if hasattr(self, 'license_process'):
            error = self.license_process.readAllStandardError().data().decode('utf-8', errors='replace')
            if error:
                self.append_output(f"\nError: {error}")
    
    def on_license_generated(self, exit_code, exit_status):
        """Appelé lorsque la génération de la licence est terminée."""
        try:
            # Lire toute la sortie restante
            self.handle_license_output()
            self.handle_license_error()
            
            # Réactiver le bouton
            self.license_btn.setEnabled(True)
            self.license_btn.setText("Generate a license")
            
            if exit_code == 0 and exit_status == QProcess.ExitStatus.NormalExit:
                success_msg = "\n✅ License generation completed successfully!"
                self.append_output(success_msg)
                
                # Émettre une notification
                if hasattr(self, 'notification_signal'):
                    self.notification_signal.emit("✅ License payment completed successfully", False)
                
                # Envoyer aussi via le bot si disponible
                if self.notification_manager:
                    try:
                        # Vérifier si une boucle asyncio est active
                        loop = asyncio.get_running_loop()
                        asyncio.create_task(self.send_notification("✅ License payment completed successfully 🎉", False))
                    except RuntimeError:
                        # Pas de boucle asyncio active (application en train de fermer)
                        pass
            else:
                error_msg = f"\n❌ License generation failed (code: {exit_code})"
                self.append_output(error_msg)
                
        except Exception as e:
            error_msg = f"Error processing the end of license generation: {str(e)}"
            self.append_output(f"\n{error_msg}")
            logging.error(error_msg, exc_info=True)
        finally:
            # Nettoyer
            try:
                if hasattr(self, 'license_process') and self.license_process:
                    self.license_process.deleteLater()
                    delattr(self, 'license_process')
            except RuntimeError:
                # L'objet a déjà été supprimé (application en train de fermer)
                if hasattr(self, 'license_process'):
                    delattr(self, 'license_process')

    def check_license_write_permissions(self):
        """Vérifie les permissions d'écriture pour le dossier de licence."""
        try:
            # Vérifier les permissions en essayant de créer un fichier temporaire
            test_file = os.path.join(
                os.path.expanduser("~"),
                "TelegramManager",
                "trial_license",
                ".write_test"
            )
            os.makedirs(os.path.dirname(test_file), exist_ok=True)
            with open(test_file, 'w') as f:
                f.write("test")
            os.remove(test_file)
            return True
        except Exception as e:
            error_msg = f"Permission error: Cannot write to license directory\n{str(e)}"
            logging.error(error_msg)
            QMessageBox.critical(self, "Permission Error", error_msg)
            return False

    def get_program_path(self):
        """Retourne le chemin vers le dossier Program."""
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))  # Dossier ui
            src_dir = os.path.dirname(current_dir)  # Dossier telegram_manager
            telegram_dir = os.path.dirname(src_dir)  # Dossier src
            setup_dir = os.path.dirname(telegram_dir)  # Dossier setup
            app_root = os.path.dirname(setup_dir)  # Dossier racine
            return os.path.join(app_root, "Program")
        except Exception as e:
            error_msg = f"Error locating program directory: {str(e)}"
            logging.error(error_msg)
            QMessageBox.critical(self, "Error", error_msg)
            return None

    def cleanup_existing_processes(self):
        """Nettoie les processus existants."""
        if hasattr(self, 'license_process'):
            try:
                if self.license_process and self.license_process.state() != QProcess.ProcessState.NotRunning:
                    self.license_process.terminate()
                    self.license_process.waitForFinished(2000)
                if self.license_process:
                    self.license_process.deleteLater()
            except (RuntimeError, AttributeError):
                # L'objet a déjà été supprimé (application en train de fermer)
                pass
            except Exception as e:
                logging.warning(f"Error cleaning up existing process: {e}")
            finally:
                delattr(self, 'license_process')

    def setup_license_process_signals(self):
        """Configure les signaux du processus de licence."""
        self.license_process.readyReadStandardOutput.connect(self.handle_license_output)
        self.license_process.readyReadStandardError.connect(self.handle_license_error)
        self.license_process.finished.connect(self.on_trial_license_generated)

    def generate_trial_license(self):
        """Génère une licence d'essai de 7 jours."""
        try:
            # Vérifier d'abord si on peut écrire dans le dossier de destination
            if not self.check_license_write_permissions():
                return False

            # Désactiver le bouton pour éviter les clics multiples
            if hasattr(self, 'trial_btn'):
                self.trial_btn.setEnabled(False)
                self.trial_btn.setText("Processing...")
            
            # Afficher un indicateur de chargement
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            
            # Construction du chemin vers le script de licence
            program_path = self.get_program_path()
            if not program_path:
                return False

            license_script = os.path.join(program_path, "manage_license.py")
            
            # Vérifier que le script de licence existe
            if not os.path.exists(license_script):
                error_msg = "[ERROR] The license script was not found"
                self.append_output(f"\n{error_msg}")
                QMessageBox.critical(self, "Error", error_msg)
                return False
        
            # Nettoyer les processus existants
            self.cleanup_existing_processes()
        
            # Créer et configurer le processus
            self.license_process = QProcess()
            self.license_process.setWorkingDirectory(program_path)
        
            # Configurer les signaux
            self.setup_license_process_signals()
        
            # Démarrer le processus pour 7 jours
            self.append_output("=== Trial license generation in progress (7 days) ===\n")
            
            # Utiliser le bon interpréteur Python
            python_exe = sys.executable or "python"
            self.license_process.start(
                python_exe, 
                [license_script, "generate", "--days", "7"]
            )
            
            # Configurer un timeout pour le processus
            QTimer.singleShot(30000, self.check_license_process_timeout)
            
            return True
        
        except Exception as e:
            error_msg = f"Error generating trial license: {str(e)}"
            logging.error(error_msg, exc_info=True)
            self.append_output(f"\n{error_msg}")
            QMessageBox.critical(self, "Error", error_msg)
            
            # Réactiver le bouton en cas d'erreur
            if hasattr(self, 'trial_btn'):
                self.trial_btn.setEnabled(True)
                self.trial_btn.setText("Start Free Trial")
                
            QApplication.restoreOverrideCursor()
            return False
            
    def check_license_process_timeout(self):
        """Vérifie si le processus de génération de licence a dépassé le temps imparti."""
        if hasattr(self, 'license_process') and self.license_process.state() == QProcess.ProcessState.Running:
            logging.warning("License generation process is taking too long, terminating...")
            self.append_output("\n⚠️ Process is taking too long, please wait or try again...")
            self.license_process.terminate()

    def on_trial_license_generated(self, exit_code, exit_status):
        """Appelé lorsque la génération de la licence d'essai est terminée."""
        try:
            # Restaurer le curseur
            QApplication.restoreOverrideCursor()
            
            # Lire les sorties
            self.handle_license_output()
            self.handle_license_error()
            
            # Vérifier si le processus s'est terminé correctement
            process_success = (exit_code == 0 and 
                             exit_status == QProcess.ExitStatus.NormalExit)
            
            if process_success:
                success_msg = "\n✅ Trial license generated successfully!"
                self.append_output(success_msg)
                
                # Envoyer la notification UI
                self.notification_signal.emit("✅ Trial license activated successfully", False)
                
                # Envoyer aussi via le bot si disponible
                if self.notification_manager:
                    try:
                        # Vérifier si une boucle asyncio est active
                        loop = asyncio.get_running_loop()
                        asyncio.create_task(self.send_notification("✅ Trial license activated successfully 🎁", False))
                    except RuntimeError:
                        # Pas de boucle asyncio active (application en train de fermer)
                        pass
                
                # Mettre à jour l'interface utilisateur
                if hasattr(self, 'trial_btn'):
                    self.trial_btn.setText("Trial Activated")
                    self.trial_btn.setStyleSheet("background-color: #4CAF50; color: white;")
                    
                # Afficher un message de succès avec l'icône de l'application
                msg_box = QMessageBox()
                
                # Définir l'icône de la fenêtre
                from .utils import set_window_icon
                set_window_icon(msg_box, "app_icon")
                
                # Configurer le message
                msg_box.setIcon(QMessageBox.Icon.Information)
                msg_box.setWindowTitle("Success")
                msg_box.setText("Your 7-day trial has been activated!")
                msg_box.setInformativeText(
                    "You can now enjoy all premium features for 7 days.\n\n"
                    "After the trial period, you'll need to purchase a full license to continue."
                )
                msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
                
                # Pour Windows, forcer l'icône dans la barre des tâches
                if hasattr(self, 'window') and hasattr(self.window(), 'windowIcon'):
                    msg_box.setWindowIcon(self.window().windowIcon())
                elif hasattr(QApplication.instance(), 'windowIcon'):
                    msg_box.setWindowIcon(QApplication.instance().windowIcon())
                msg_box.exec()
                
                # Émettre un signal de mise à jour de l'interface si nécessaire
                if hasattr(self, 'update_ui_after_license'):
                    self.update_ui_after_license()
                    
            else:
                error_msg = f"\n❌ Trial license generation failed (exit code: {exit_code})"
                self.append_output(error_msg)
                
                # Envoyer la notification UI d'erreur
                self.notification_signal.emit("❌ Trial license generation failed", True)
                
                # Envoyer aussi via le bot si disponible
                if self.notification_manager:
                    try:
                        # Vérifier si une boucle asyncio est active
                        loop = asyncio.get_running_loop()
                        asyncio.create_task(self.send_notification("❌ Trial license generation failed", True))
                    except RuntimeError:
                        # Pas de boucle asyncio active (application en train de fermer)
                        pass
                
                # Afficher un message d'erreur détaillé
                error_box = QMessageBox()
                error_box.setIcon(QMessageBox.Icon.Critical)
                error_box.setWindowTitle("Error")
                error_box.setText("Failed to generate trial license")
                error_box.setInformativeText(
                    "An error occurred while generating your trial license.\n"
                    "Please check the logs for more details and try again."
                )
                error_box.setStandardButtons(QMessageBox.StandardButton.Ok)
                error_box.exec()
                
                # Réactiver le bouton d'essai
                if hasattr(self, 'trial_btn'):
                    self.trial_btn.setEnabled(True)
                    self.trial_btn.setText("Start Free Trial")
        
        except Exception as e:
            logging.error(f"Error in on_trial_license_generated: {str(e)}", exc_info=True)
            
        finally:
            # Nettoyer les ressources
            self.cleanup_existing_processes()
            QApplication.restoreOverrideCursor()
    
    def toggle_maximize(self):
        """Bascule entre l'état agrandi et normal de la fenêtre."""
        if self.isMaximized():
            self.showNormal()
            self.maximize_btn.setText("□")
        else:
            self.showMaximized()
            self.maximize_btn.setText("❐")
    
    def closeEvent(self, event):
        """Gère la fermeture du widget."""
        # Arrêter le processus s'il est en cours d'exécution
        if self.process and self.process.state() == QProcess.ProcessState.Running:
            self.process.terminate()
            if not self.process.waitForFinished(1000):
                self.process.kill()
        event.accept()
    
    def update_terminal_style(self):
        """Met à jour le style du terminal selon le thème actuel."""
        if self._current_theme == 'dark':
            # Thème sombre : fond sombre, texte blanc par défaut
            self.terminal.setStyleSheet("""
                QTextEdit {
                    background-color: #2b2b2b;
                    color: #ffffff;  /* Texte blanc par défaut pour le thème sombre */
                    font-family: 'Consolas', 'Courier New', monospace;
                    font-size: 10pt;
                    border: 1px solid #444;
                    border-top-left-radius: 4px;
                    border-top-right-radius: 4px;
                    border-bottom: none;
                    padding: 5px;
                }
                QTextEdit span {
                    color: inherit;  /* Permet aux couleurs HTML de s'appliquer */
                }
            """)
        else:
            # Thème clair : fond clair, texte noir par défaut
            self.terminal.setStyleSheet("""
                QTextEdit {
                    background-color: #f5f5f5;
                    color: #000000;  /* Texte noir par défaut pour le thème clair */
                    font-family: 'Consolas', 'Courier New', monospace;
                    font-size: 10pt;
                    border: 1px solid #ccc;
                    border-top-left-radius: 4px;
                    border-top-right-radius: 4px;
                    border-bottom: none;
                    padding: 5px;
                }
                QTextEdit span {
                    color: inherit;  /* Permet aux couleurs HTML de s'appliquer */
                }
            """)
    
    def on_theme_changed(self, theme_name):
        """Gère le changement de thème.
        
        Args:
            theme_name: Nom du thème ('light' ou 'dark')
        """
        self._current_theme = theme_name
        self.update_terminal_style()
        
        # Mettre à jour aussi le style de la zone de saisie
        self.update_input_frame_style()
    
    def update_input_frame_style(self):
        """Update input frame style according to theme."""
        if self._current_theme == 'dark':
            self.input_frame.setStyleSheet("""
                QFrame {
                    background-color: #2b2b2b;
                    border: 1px solid #444;
                    border-top: none;
                    border-bottom-left-radius: 4px;
                    border-bottom-right-radius: 4px;
                    padding: 5px;
                }
                QLineEdit {
                    background-color: #353535;
                    color: #ffffff;  /* White */
                    border: 1px solid #444;
                    border-radius: 3px;
                    padding: 5px;
                    font-family: 'Consolas', 'Courier New', monospace;
                }
            """)
            # Style for buttons in dark mode
            button_style_dark = """
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                              stop:0 #87CEEB, stop:1 #4682B4);
                    color: white;
                    border: none;
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                              stop:0 #6BB6D6, stop:1 #5F9EA0);
                }
                QPushButton:pressed {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                              stop:0 #4682B4, stop:1 #4169E1);
                }
            """
            if hasattr(self, 'paste_button'):
                self.paste_button.setStyleSheet(button_style_dark + """
                    QPushButton {
                        min-width: 30px;
                        max-width: 30px;
                        padding: 4px 8px;
                    }
                """)
            if hasattr(self, 'enter_button'):
                self.enter_button.setStyleSheet(button_style_dark + """
                    QPushButton {
                        min-width: 50px;
                        max-width: 50px;
                        padding: 6px 12px;
                    }
                """)
        else:
            self.input_frame.setStyleSheet("""
                QFrame {
                    background-color: #f5f5f5;
                    border: 1px solid #ccc;
                    border-top: none;
                    border-bottom-left-radius: 4px;
                    border-bottom-right-radius: 4px;
                    padding: 5px;
                }
                QLineEdit {
                    background-color: #ffffff;
                    color: #000000;  /* Black */
                    border: 1px solid #ccc;
                    border-radius: 3px;
                    padding: 5px;
                    font-family: 'Consolas', 'Courier New', monospace;
                }
            """)
            # Style for buttons in light mode
            button_style_light = """
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                              stop:0 #87CEEB, stop:1 #4682B4);
                    color: white;
                    border: none;
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                              stop:0 #6BB6D6, stop:1 #5F9EA0);
                }
                QPushButton:pressed {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                              stop:0 #4682B4, stop:1 #4169E1);
                }
            """
            if hasattr(self, 'paste_button'):
                self.paste_button.setStyleSheet(button_style_light + """
                    QPushButton {
                        min-width: 30px;
                        max-width: 30px;
                        padding: 4px 8px;
                    }
                """)
            if hasattr(self, 'enter_button'):
                self.enter_button.setStyleSheet(button_style_light + """
                    QPushButton {
                        min-width: 50px;
                        max-width: 50px;
                        padding: 6px 12px;
                    }
                """)
