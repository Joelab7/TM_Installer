"""Package utilitaire pour l'interface utilisateur."""
from .icon_manager import get_icon, set_window_icon, get_icon_path
