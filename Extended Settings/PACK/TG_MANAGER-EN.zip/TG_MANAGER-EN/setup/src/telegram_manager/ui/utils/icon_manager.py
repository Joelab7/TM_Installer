"""Gestionnaire d'icônes pour l'application."""
from pathlib import Path
from PyQt6.QtGui import QIcon, QPixmap
from PyQt6.QtWidgets import QApplication
import os
import sys

def get_icon_path(icon_name):
    """Retourne le chemin complet vers une icône.
    
    Args:
        icon_name (str): Nom du fichier d'icône (sans extension)
        
    Returns:
        str: Chemin complet vers l'icône ou None si non trouvée
    """
    # Essayer différents formats d'icônes
    icon_formats = ['.png', '.ico', '.svg']
    
    # Chemins de base à vérifier
    base_paths = []
    
    # 1. Si l'application est packagée (pyinstaller)
    if getattr(sys, 'frozen', False):
        base_paths.append(Path(sys._MEIPASS))
    
    # 2. Chemin relatif au module (pour le développement)
    base_paths.append(Path(__file__).parent.parent.parent.parent / 'resources' / 'icons')
    
    # 3. Chemin absolu pour l'installation (pour les packages installés)
    try:
        import pkg_resources
        base_paths.append(Path(pkg_resources.resource_filename('telegram_manager', 'resources/icons')))
    except (ImportError, pkg_resources.DistributionNotFound):
        pass
    
    # 4. Chemin du répertoire de travail
    base_paths.append(Path.cwd() / 'resources' / 'icons')
    
    # Parcourir tous les chemins de base et formats pour trouver l'icône
    for base_path in base_paths:
        if not base_path.exists():
            continue
            
        # Vérifier directement le fichier avec le nom complet
        for ext in icon_formats:
            icon_path = base_path / f"{icon_name}{ext}"
            if icon_path.exists():
                return str(icon_path)
        
        # Vérifier dans les sous-dossiers
        for ext in icon_formats:
            for icon_file in base_path.rglob(f"*{icon_name}*{ext}"):
                if icon_file.exists():
                    return str(icon_file)
    
    # Aucune icône trouvée
    print(f"[WARNING] Icône non trouvée: {icon_name}")
    return None

def get_icon(icon_name):
    """Récupère une icône par son nom.
    
    Args:
        icon_name (str): Nom du fichier d'icône (sans extension)
        
    Returns:
        QIcon: L'icône chargée ou une icône vide si non trouvée
    """
    if not icon_name:
        print("[WARNING] Aucun nom d'icône fourni")
        return QIcon()
    
    icon_path = get_icon_path(icon_name)
    if icon_path:
        try:
            icon = QIcon(icon_path)
            if icon.isNull():
                print(f"[WARNING] Impossible de charger l'icône: {icon_path}")
                return QIcon()
            return icon
        except Exception as e:
            print(f"[ERROR] Erreur lors du chargement de l'icône {icon_name} depuis {icon_path}: {e}")
            return QIcon()
    
    print(f"[WARNING] Aucune icône trouvée pour: {icon_name}")
    return QIcon()

def set_window_icon(window, icon_name):
    """Définit l'icône d'une fenêtre ou d'un widget, y compris dans la barre des tâches.
    
    Args:
        window: Le widget ou la fenêtre Qt à laquelle définir l'icône
        icon_name (str): Nom du fichier d'icône (sans extension)
    """
    if not icon_name:
        print("[WARNING] Aucun nom d'icône fourni pour set_window_icon")
        return
    
    try:
        # Obtenir la fenêtre principale
        main_window = window
        if hasattr(window, 'window') and window.window():
            main_window = window.window()
        
        # Ne définir l'icône que si c'est une fenêtre
        if hasattr(main_window, 'isWindow') and main_window.isWindow():
            icon = get_icon(icon_name)
            
            if not icon.isNull():
                # Définir l'icône de la fenêtre
                main_window.setWindowIcon(icon)
                
                # Définir l'icône de la barre des tâches (Windows spécifique)
                if sys.platform == 'win32':
                    try:
                        import ctypes
                        import os
                        
                        # Obtenir le chemin complet de l'icône
                        icon_path = get_icon_path(icon_name)
                        if icon_path and os.path.exists(icon_path):
                            # Convertir le chemin en format natif Windows
                            icon_path = os.path.abspath(icon_path)
                            # Définir l'icône de la barre des tâches
                            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(icon_path)
                    except Exception as e:
                        print(f"[ERROR] Impossible de définir l'icône de la barre des tâches: {e}")
            else:
                # Si l'icône n'est pas trouvée, essayer avec le nom de la fenêtre
                if hasattr(main_window, 'windowTitle'):
                    fallback_name = main_window.windowTitle().lower().replace(' ', '_')
                    if fallback_name != icon_name:  # Éviter une boucle infinie
                        print(f"[INFO] Essai avec le nom de la fenêtre: {fallback_name}")
                        set_window_icon(main_window, fallback_name)
        
        # Pour les widgets intégrés, définir l'icône de la fenêtre parente
        elif hasattr(window, 'parentWidget') and window.parentWidget():
            parent_window = window.parentWidget().window()
            if parent_window and parent_window != window:
                print(f"[INFO] Définition de l'icône pour la fenêtre parente: {icon_name}")
                set_window_icon(parent_window, icon_name)
    except Exception as e:
        print(f"[ERROR] Erreur lors de la définition de l'icône {icon_name}: {e}")
