"""Gestionnaire de thèmes pour l'application."""
from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtGui import QPalette, QColor
import logging

class ThemeManager:
    """Gère l'application des thèmes dans l'application."""
    
    @staticmethod
    def apply_toolbar_theme(toolbar, theme_name):
        """Applique le thème à la barre d'outils."""
        if not toolbar:
            return
            
        if theme_name.lower() == 'dark':
            toolbar.setStyleSheet("""
                QToolBar {
                    background-color: #2b2b2b;
                    border: none;
                    padding: 2px;
                }
                QToolButton {
                    background-color: transparent;
                    border: 1px solid transparent;
                    padding: 4px;
                    border-radius: 4px;
                    color: #ffffff;
                }
                QToolButton:hover {
                    background-color: #3a3a3a;
                    border: 1px solid #4a4a4a;
                }
                QToolButton:pressed {
                    background-color: #1e1e1e;
                }
                QToolButton:disabled {
                    color: #666666;
                }
            """)
        else:
            toolbar.setStyleSheet("""
                QToolBar {
                    background-color: #f0f0f0;
                    border: none;
                    padding: 2px;
                }
                QToolButton {
                    background-color: transparent;
                    border: 1px solid transparent;
                    padding: 4px;
                    border-radius: 4px;
                    color: #000000;
                }
                QToolButton:hover {
                    background-color: #e0e0e0;
                    border: 1px solid #d0d0d0;
                }
                QToolButton:pressed {
                    background-color: #d0d0d0;
                }
                QToolButton:disabled {
                    color: #999999;
                }
            """)
    
    @staticmethod
    def apply_application_theme(theme_name):
        """Applique le thème à l'ensemble de l'application."""
        app = QApplication.instance()
        
        if theme_name.lower() == 'dark':
            # Style pour le thème sombre
            dark_palette = QPalette()
            dark_palette.setColor(QPalette.ColorRole.Window, QColor(53, 53, 53))
            dark_palette.setColor(QPalette.ColorRole.WindowText, QColor(255, 255, 255))
            dark_palette.setColor(QPalette.ColorRole.Base, QColor(35, 35, 35))
            dark_palette.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
            dark_palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(255, 255, 255))
            dark_palette.setColor(QPalette.ColorRole.ToolTipText, QColor(255, 255, 255))
            dark_palette.setColor(QPalette.ColorRole.Text, QColor(255, 255, 255))
            dark_palette.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
            dark_palette.setColor(QPalette.ColorRole.ButtonText, QColor(255, 255, 255))
            dark_palette.setColor(QPalette.ColorRole.BrightText, QColor(255, 0, 0))
            dark_palette.setColor(QPalette.ColorRole.Link, QColor(42, 130, 218))
            dark_palette.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
            dark_palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
            app.setPalette(dark_palette)
            
            # Style supplémentaire pour les menus déroulants
            app.setStyleSheet("""
                QMenu {
                    background-color: #2b2b2b;
                    color: white;
                    border: 1px solid #3a3a3a;
                }
                QMenu::item:selected {
                    background-color: #3a3a3a;
                }
                QMenu::item:disabled {
                    color: #666666;
                }
                QMenuBar {
                    background-color: #2b2b2b;
                    color: white;
                }
                QMenuBar::item:selected {
                    background-color: #3a3a3a;
                }
                QMenuBar::item:disabled {
                    color: #666666;
                }
            """)
        else:
            # Réinitialiser au style par défaut pour le thème clair
            app.setPalette(QPalette())
            app.setStyleSheet("""
                QMenu::item:disabled {
                    color: #999999;
                }
                QMenuBar::item:disabled {
                    color: #999999;
                }
            """)
