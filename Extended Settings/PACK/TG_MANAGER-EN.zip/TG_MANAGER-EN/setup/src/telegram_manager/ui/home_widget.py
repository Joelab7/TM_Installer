"""Widget pour la page d'accueil de l'application (version nettoyée)."""
import asyncio
import logging
import unicodedata
from datetime import datetime
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QFrame, QLabel, 
    QPushButton, QScrollArea, QTabWidget, QLineEdit, QTextEdit, QSizePolicy,
    QStackedWidget, QToolBar, QToolButton, QMenu, QMenuBar, QStatusBar,
    QDialog, QMessageBox, QProgressBar, QApplication, QSplitter,
    QGraphicsDropShadowEffect, QButtonGroup, QGroupBox, QCheckBox,
    QComboBox, QSpinBox, QSlider, QFileDialog, QInputDialog, QListView
)
from PyQt6.QtCore import Qt, QSize, QTimer, pyqtSignal, QObject, QUrl, QThread, pyqtSlot, QEvent
from PyQt6.QtGui import QPixmap, QIcon, QPainter, QColor, QLinearGradient, QGradient
# Les imports de PyQt6 sont maintenant tous au même endroit

# Import des composants personnalisés
from .components.custom_tab_widget import CustomTabWidget
from .support_widget import SupportWidget
from telegram_manager.core.entity_loader_wrapper import FastEntityLoader
from telegram_manager.core.entity_model import EntityModel
from telegram_manager.core.entity_delegate import EntityDelegate

class StatsCard(QFrame):
    """Widget pour afficher une statistique avec compteur d'administrateurs."""
    
    def __init__(self, title: str, value: str = "0", admin_count: str = "0", icon: str = "👥", parent=None):
        """Initialise la carte de statistique.
        
        Args:
            title: Titre de la statistique (ex: "Groupes", "Canaux")
            value: Nombre total d'entités
            admin_count: Nombre d'entités administrées
            icon: Icône à afficher (par défaut: 👥)
            parent: Widget parent
        """
        super().__init__(parent)
        self.setObjectName("statsCard")
        self.setMinimumHeight(100)
        # Utilisation de QGraphicsEffect pour le shadow au lieu de box-shadow CSS
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(8)
        shadow.setColor(QColor(0, 0, 0, 25))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)
        
        # Style de base avec propriétés compatibles Qt
        self.setStyleSheet("""
            QFrame#statsCard {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                         stop:0 #ffffff, stop:1 #f8f9fa);
                border-radius: 12px;
                border: 1px solid #e0e0e0;
                padding: 16px;
            }
            QFrame#statsCard[hovered="true"] {
                margin-top: -2px;
                margin-bottom: 2px;
            }
            QLabel#statsTitle {
                color: #6c757d;
                font-size: 14px;
                font-weight: 500;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            QLabel#statsValue {
                color: #2c3e50;
                font-size: 28px;
                font-weight: 700;
                margin: 4px 0;
            }
            QLabel#statsAdmin {
                color: #3498db;
                font-size: 13px;
                font-weight: 500;
                margin-top: 2px;
            }
            QLabel#statsIcon {
                font-size: 32px;
                min-width: 50px;
                text-align: center;
                padding: 8px;
                background: rgba(52, 152, 219, 0.1);
                border-radius: 10px;
                color: #3498db;
            }
        """)
        
        # Effet de survol
        self.setProperty("hovered", False)
        self.installEventFilter(self)
        
        # Layout principal
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(15)
        
        # Icône à gauche
        self.icon_label = QLabel(icon)
        self.icon_label.setObjectName("statsIcon")
        layout.addWidget(self.icon_label, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        
        # Conteneur pour le texte à droite
        text_widget = QWidget()
        text_layout = QVBoxLayout(text_widget)
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(2)
        
        # Titre
        self.title_label = QLabel(title.upper())
        self.title_label.setObjectName("statsTitle")
        
        # Valeur principale (nombre total)
        self.value_label = QLabel(value)
        self.value_label.setObjectName("statsValue")
        
        # Compteur d'administrateurs
        self.admin_label = QLabel(f"{admin_count} administered")
        self.admin_label.setObjectName("statsAdmin")
        self.admin_label.setVisible(int(admin_count) > 0)
        
        # Ajout des widgets au layout
        text_layout.addWidget(self.title_label)
        text_layout.addWidget(self.value_label)
        text_layout.addWidget(self.admin_label)
        text_layout.addStretch()
        
        layout.addWidget(text_widget, 1)
    
    def set_value(self, value: str, admin_count: str = None):
        """Définit les valeurs affichées.
        
        Args:
            value: Nombre total d'entités
            admin_count: Nombre d'entités administrées (optionnel)
        """
        self.value_label.setText(str(value))
        if admin_count is not None:
            self.admin_label.setText(f"{admin_count} administered")
            self.admin_label.setVisible(int(admin_count) > 0)
    
    def eventFilter(self, obj, event):
        """Gère les événements de survol pour les effets visuels."""
        if obj is self:
            if event.type() == QEvent.Type.Enter:
                self.setProperty("hovered", "true")
                self.style().unpolish(self)
                self.style().polish(self)
                # Mise à jour du shadow sur survol
                shadow = QGraphicsDropShadowEffect()
                shadow.setBlurRadius(12)
                shadow.setColor(QColor(0, 0, 0, 40))
                shadow.setOffset(0, 4)
                self.setGraphicsEffect(shadow)
                return True
            elif event.type() == QEvent.Type.Leave:
                self.setProperty("hovered", "false")
                self.style().unpolish(self)
                self.style().polish(self)
                # Réinitialisation du shadow
                shadow = QGraphicsDropShadowEffect()
                shadow.setBlurRadius(8)
                shadow.setColor(QColor(0, 0, 0, 25))
                shadow.setOffset(0, 2)
                self.setGraphicsEffect(shadow)
                return True
        return super().eventFilter(obj, event)


class HomeWidget(QWidget):
    """Widget principal de la page d'accueil."""
    
    def __init__(self, telegram_client, parent=None):
        """Initialise le widget de la page d'accueil.
        
        Args:
            telegram_client: Instance du client Telegram
            parent: Widget parent
        """
        super().__init__(parent)
        self.telegram_client = telegram_client
        
        # Loader C++ ultra-rapide
        self.entity_loader = FastEntityLoader()
        
        self.entities = {
            'groups': {'admin': [], 'member': []},
            'channels': {'admin': [], 'member': []},
            'chats': {'admin': [], 'member': []},
            'bots': {'admin': [], 'member': []}
        }
        self._load_task = None
        self._reload_timer = None
        self._load_lock = asyncio.Lock()  # Verrou pour éviter les accès concurrentiels
        self._selected_cards = {}  # Dictionnaire pour suivre la carte sélectionnée par onglet
        self._current_theme = 'light'  # Thème par défaut
        
        # Initialiser avec le thème du parent si disponible
        if parent and hasattr(parent, 'current_theme'):
            self._current_theme = parent.current_theme
            
        self.setup_ui()
        
        # S'abonner aux événements de changement de compte
        if hasattr(self.telegram_client, 'account_changed'):
            self.telegram_client.account_changed.connect(self.on_account_changed)
            
        # S'abonner aux changements de thème si le parent a un gestionnaire de thème
        if parent and hasattr(parent, 'theme_changed'):
            parent.theme_changed.connect(self.on_theme_changed)
        
        # Charger les données après un court délai
        # Utiliser une approche directe sans QTimer pour éviter la fenêtre parasite
        QApplication.instance().postEvent(self, QEvent(QEvent.Type.User))
        logging.debug("Automatic reloading reactivated with postEvent")

        self._setup_search_connections()
        
        # Initialiser le widget de support
        self.support_widget = SupportWidget(self)
        
        # Connecter le bouton d'assistance au widget de support
        self.help_button.clicked.connect(self._toggle_support_widget)
    
    def _create_next_card_for_tab(self, entity_type):
        """Crée la prochaine carte pour un onglet spécifique de manière différée."""
        if not hasattr(self, '_pending_tabs') or entity_type not in self._pending_tabs:
            return
        
        tab_info = self._pending_tabs[entity_type]
        cards_to_create = tab_info['cards_to_create']
        
        if not cards_to_create:
            # Fin de la création des cartes pour cet onglet
            cards_added = tab_info['cards_added_count']
            if cards_added > 0:
                logging.info(f"[UPDATE_TAB] {cards_added} cards added successfully to the {entity_type} tab")
            else:
                logging.warning(f"[UPDATE_TAB] No valid card could be created for {entity_type}")
                self._show_empty_message(tab_info['tab_content'], tab_info['empty_message'])
            
            # Nettoyer cet onglet
            del self._pending_tabs[entity_type]
            return
        
        i, entity_data = cards_to_create.pop(0)
        entity_title = entity_data.get('title', 'sans titre')
        
        try:
            logging.debug(f"[UPDATE_TAB] Deferred creation of card {i+1}/{len(cards_to_create)+1} for {entity_title} (tab: {entity_type})")
            
            # Vérifier les données de l'entité
            if not entity_data.get('id'):
                logging.warning(f"[UPDATE_TAB] Entity {entity_title} has no valid ID, it will be ignored")
                # Continue with the next card
                QTimer.singleShot(10, lambda: self._create_next_card_for_tab(entity_type))
                return
            
            card = self._create_entity_card(entity_data)
            if card:
                try:
                    tab_info['layout'].addWidget(card)
                    tab_info['cards_added_count'] += 1
                    logging.debug(f"[UPDATE_TAB] Card added successfully for {entity_title} (tab: {entity_type})")
                except Exception as add_error:
                    logging.error(f"[UPDATE_TAB] Error adding card for {entity_title}: {add_error}", exc_info=True)
            else:
                logging.error(f"[UPDATE_TAB] Failed to create card for {entity_title}")
            
            # Continuer avec la carte suivante après un très court délai
            QTimer.singleShot(10, lambda: self._create_next_card_for_tab(entity_type))
            
        except Exception as card_error:
            logging.error(f"[UPDATE_TAB] Error creating card for {entity_title}: {card_error}", exc_info=True)
            # Continuer même en cas d'erreur
            QTimer.singleShot(10, lambda: self._create_next_card_for_tab(entity_type))
    
    def _create_next_card(self):
        """Crée la prochaine carte de manière différée pour éviter la fenêtre parasite."""
        if not hasattr(self, '_cards_to_create') or not self._cards_to_create:
            # Fin de la création des cartes
            if hasattr(self, '_cards_added_count') and self._cards_added_count > 0:
                logging.info(f"[UPDATE_TAB] {self._cards_added_count} cartes ajoutées avec succès à l'onglet {self._current_entity_type}")
            else:
                logging.warning(f"[UPDATE_TAB] Aucune carte valide n'a pu être créée pour {self._current_entity_type}")
                if hasattr(self, '_current_tab_content') and hasattr(self, '_empty_message'):
                    self._show_empty_message(self._current_tab_content, self._empty_message)
            return
        
        i, entity_data = self._cards_to_create.pop(0)
        entity_title = entity_data.get('title', 'sans titre')
        
        try:
            logging.debug(f"[UPDATE_TAB] Création différée de la carte {i+1}/{len(self._cards_to_create)+1} pour {entity_title}")
            
            # Vérifier les données de l'entité
            if not entity_data.get('id'):
                logging.warning(f"[UPDATE_TAB] L'entité {entity_title} n'a pas d'ID valide, elle sera ignorée")
                # Continuer avec la carte suivante
                QTimer.singleShot(5, self._create_next_card)
                return
            
            card = self._create_entity_card(entity_data)
            if card:
                try:
                    self._current_layout.addWidget(card)
                    self._cards_added_count += 1
                    logging.debug(f"[UPDATE_TAB] Carte ajoutée avec succès pour {entity_title}")
                except Exception as add_error:
                    logging.error(f"[UPDATE_TAB] Erreur lors de l'ajout de la carte pour {entity_title}: {add_error}", exc_info=True)
            else:
                logging.error(f"[UPDATE_TAB] Échec de la création de la carte pour {entity_title}")
            
            # Continuer avec la carte suivante après un très court délai
            QTimer.singleShot(5, self._create_next_card)
            
        except Exception as card_error:
            logging.error(f"[UPDATE_TAB] Erreur lors de la création de la carte pour {entity_title}: {card_error}", exc_info=True)
            # Continuer même en cas d'erreur
            QTimer.singleShot(5, self._create_next_card)
    
    def on_account_changed(self):
        """Appelé lors d'un changement de compte."""
        logging.info("Changement de compte détecté, préparation du rechargement...")
        # Vider les cartes existantes et réinitialiser la sélection
        self._deselect_all_cards()

        # Réinitialiser les barres de recherche
        for content_widget in [self.groups_content, self.channels_content, self.bots_content, self.chats_content]:
            content_widget.search_bar.clear()

        # Réinitialiser l'interface immédiatement
        self._init_entities_structure()
        
        # Planifier le rechargement avec un délai pour laisser le temps au client de se reconnecter
        self.schedule_reload(5000)  # 5 secondes de délai pour une reconnexion complète
    
    def _init_entities_structure(self):
        """Initialise la structure des entités."""
        self.entities = {
            'groups': {'admin': [], 'member': []},
            'channels': {'admin': [], 'member': []},
            'chats': {'admin': [], 'member': []},
            'bots': {'admin': [], 'member': []}
        }
        logging.debug("Structure des entités initialisée")
        self.update_ui()
    
    async def _cancel_pending_operations(self):
        """Annule les opérations en cours de manière asynchrone."""
        # Annuler la tâche de chargement en cours si elle existe
        if hasattr(self, '_load_task') and self._load_task and not self._load_task.done():
            try:
                self._load_task.cancel()
                await asyncio.wait_for(self._load_task, timeout=1.0)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
            except Exception as e:
                logging.warning(f"Erreur lors de l'annulation de la tâche: {e}")
        
        # Arrêter le minuteur de rechargement s'il est actif
        if hasattr(self, '_reload_timer') and self._reload_timer and self._reload_timer.isActive():
            self._reload_timer.stop()
    
    def schedule_reload(self, delay_ms=5000):
        """Planifie un rechargement des entités après un délai."""
        # Annuler le minuteur existant s'il y en a un
        if hasattr(self, '_reload_timer') and self._reload_timer:
            self._reload_timer.stop()
        
        # Créer un nouveau QTimer
        self._reload_timer = QTimer(self)
        self._reload_timer.setSingleShot(True)
        
        # Connecter le signal timeout à la méthode reload_data
        self._reload_timer.timeout.connect(self.reload_data)
        
        # Démarrer le timer
        self._reload_timer.start(delay_ms)
    
    async def _reload_data_async(self):
        """Recharge les données de manière asynchrone."""
        # Verrou supplémentaire pour éviter les conflits avec auto_connect
        if not hasattr(self, '_global_lock'):
            self._global_lock = asyncio.Lock()
        
        async with self._global_lock:
            try:
                # Vérifier si le client est connecté avant de continuer
                if not self.telegram_client or not self.telegram_client.is_connected():
                    logging.warning("Client Telegram non connecté, report du chargement des données")
                    return False
                
                # Attendre un court instant pour éviter les conflits avec Telethon
                await asyncio.sleep(0.2)
                
                # Vider les données existantes
                self.entities = {
                    'groups': {'admin': [], 'member': []},
                    'channels': {'admin': [], 'member': []},
                    'chats': {'admin': [], 'member': []},
                    'bots': {'admin': [], 'member': []}
                }
                
                # Mettre à jour l'interface immédiatement
                self.update_ui()
                
                # Attendre un court instant pour laisser l'interface se mettre à jour
                await asyncio.sleep(0.1)
                
                # Charger les nouvelles données
                await self.load_entities()
                
            except Exception as e:
                logging.error(f"Erreur lors du rechargement des données: {e}")
                # Réessayer après un délai en cas d'échec
                self.schedule_reload(5000)
    
    def reload_data(self):
        """Lance le rechargement des données."""
        # Vérifier si le client est en cours de connexion pour éviter les conflits
        if (self.telegram_client and hasattr(self.telegram_client, '_connecting') and 
            self.telegram_client._connecting):
            logging.debug("Connexion en cours, report du rechargement des données")
            return
        
        # Annuler toute tâche de chargement en cours
        if hasattr(self, '_load_task') and self._load_task and not self._load_task.done():
            self._load_task.cancel()
        
        # Créer une tâche asynchrone pour le rechargement
        loop = asyncio.get_event_loop()
        self._load_task = loop.create_task(self._reload_data_async())
        
        # Gérer les erreurs potentielles
        self._load_task.add_done_callback(self._on_load_complete)
    
    def setup_ui(self):
        """Configure l'interface utilisateur du widget."""
        # Layout principal
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)

        # Layout horizontal pour l'en-tête avec titre et bouton d'assistance
        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(10)

        # En-tête avec titre
        self.header = QLabel("Dashboard")
        self.header.setObjectName("dashboardHeader")
        # Retirer les contraintes de taille qui causent des problèmes
        header_layout.addWidget(self.header, 1)  # Stretch factor 1 pour que le titre prenne l'espace disponible

        # Bouton d'assistance
        self.help_button = QToolButton()
        self.help_button.setObjectName("helpButton")
        self.help_button.setText("💻")
        self.help_button.setToolTip("Help and Support")
        self.help_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.help_button.setFixedSize(32, 32)  # Remettre la taille fixe pour le bouton
        # Ajouter l'alignement vertical pour un meilleur positionnement
        header_layout.addWidget(self.help_button, 0, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight)

        # Ajouter un espace extensible pour pousser les éléments vers la gauche
        header_layout.addStretch()

        main_layout.addLayout(header_layout)

        # Appliquer le thème initial
        self.apply_theme()
        
        # Cartes de statistiques
        stats_container = QWidget()
        stats_layout = QHBoxLayout(stats_container)
        stats_layout.setContentsMargins(0, 0, 0, 0)
        stats_layout.setSpacing(15)
        
        # Créer les cartes avec des icônes et des compteurs d'administrateurs
        self.groups_card = StatsCard(
            title="Groups", 
            value="0", 
            admin_count="0", 
            icon="🎭"  # Icône pour les groupes
        )
        
        self.channels_card = StatsCard(
            title="Channels", 
            value="0", 
            admin_count="0", 
            icon="📢"  # Icône pour les canaux
        )
        
        self.bots_card = StatsCard(
            title="Bots", 
            value="0", 
            admin_count="0", 
            icon="🤖"  # Icône pour les bots
        )
        
        self.chats_card = StatsCard(
            title="Chats", 
            value="0", 
            admin_count="0", 
            icon="🙈"  # Icône pour les chats
        )
        
        # Ajouter les cartes au layout
        stats_layout.addWidget(self.groups_card)
        stats_layout.addWidget(self.channels_card)
        stats_layout.addWidget(self.bots_card)
        stats_layout.addWidget(self.chats_card)
        
        # Ajuster la politique de taille pour que les cartes aient la même largeur
        for i in range(stats_layout.count()):
            stats_layout.setStretch(i, 1)
        
        main_layout.addWidget(stats_container)
        
        # Créer le widget d'onglets personnalisé
        self.tab_widget = CustomTabWidget()
        
        # Cacher la barre d'onglets bleue pour éliminer le bloc vide
        if hasattr(self.tab_widget, 'tab_bar'):
            self.tab_widget.tab_bar.hide()
        
        # Créer les onglets et stocker les références aux contenus
        self.groups_content = self.tab_widget.add_tab("Groups")
        self.groups_content.setObjectName("groups_content")
        self.channels_content = self.tab_widget.add_tab("Channels")
        self.channels_content.setObjectName("channels_content")
        self.bots_content = self.tab_widget.add_tab("Bots")
        self.bots_content.setObjectName("bots_content")
        self.chats_content = self.tab_widget.add_tab("Chats")
        self.chats_content.setObjectName("chats_content")
        
        # Initialiser les contenus vides
        for content in [self.groups_content, self.channels_content, self.bots_content, self.chats_content]:
            content.clear()
            label = QLabel("Waiting for connection...")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            # Appliquer un style au message de chargement
            label.setStyleSheet("""
                QLabel {
                    color: #3498db;
                    font-size: 14px;
                    font-weight: 500;
                    padding: 20px;
                }
            """)
            content.add_widget(label)
        
        main_layout.addWidget(self.tab_widget, 1)


    def apply_theme(self, theme_name='light'):
        """Applique le thème spécifié au widget et à ses composants enfants.
        
        Args:
            theme_name: Nom du thème à appliquer ('light' ou 'dark')
        """
        try:
            self._current_theme = theme_name.lower()
            is_dark = self._current_theme == 'dark'
            
            # Styles pour l'en-tête
            header_style = """
                QLabel#dashboardHeader {
                    font-size: 26px;
                    font-weight: 700;
                    color: %s;
                    padding: 8px 0;
                    border-bottom: 2px solid %s;
                    letter-spacing: 0.5px;
                }
            """ % ('#5dade2' if is_dark else '#3498db', '#5dade255' if is_dark else '#3498db55')
            
            # Appliquer le style à l'en-tête s'il existe
            if hasattr(self, 'header') and self.header is not None:
                self.header.setStyleSheet(header_style)
            
            # Appliquer le style au bouton d'assistance s'il existe
            if hasattr(self, 'help_button') and self.help_button is not None:
                help_button_style = """
                    QToolButton#helpButton {
                        background: %s;
                        border: 1px solid %s;
                        border-radius: 16px;
                        font-size: 16px;
                        padding: 0;
                        margin: 0;
                        width: 32px;
                        height: 32px;
                        max-width: 32px;
                        max-height: 32px;
                        min-width: 32px;
                        min-height: 32px;
                    }
                    QToolButton#helpButton:hover {
                        background: %s;
                        border-color: %s;
                    }
                    QToolButton#helpButton:pressed {
                        background: %s;
                    }
                    QToolTip {
                        background: %s;
                        color: %s;
                        border: 1px solid %s;
                        border-radius: 6px;
                        padding: 5px 8px;
                        font-size: 12px;
                    }
                """ % (
                    'rgba(93, 173, 226, 0.15)' if is_dark else 'rgba(52, 152, 219, 0.1)',
                    '#5dade2' if is_dark else '#3498db',
                    'rgba(93, 173, 226, 0.25)' if is_dark else 'rgba(52, 152, 219, 0.2)',
                    '#3498db' if is_dark else '#2980b9',
                    'rgba(93, 173, 226, 0.35)' if is_dark else 'rgba(52, 152, 219, 0.3)',
                    '#2d2d2d' if is_dark else '#ffffff',  # background tooltip
                    '#ffffff' if is_dark else '#2c3e50',  # color tooltip (texte)
                    '#404040' if is_dark else '#e0e0e0'   # border tooltip
                )
                self.help_button.setStyleSheet(help_button_style)
            
            # Définir les couleurs en fonction du thème
            theme_colors = {
                'light': {
                    'bg1': '#ffffff',
                    'bg2': '#f8f9fa',
                    'hover_bg1': '#f0f2f5',
                    'hover_bg2': '#e9ecef',
                    'border': '#e0e0e0',
                    'title_color': '#6c757d',
                    'value_color': '#2c3e50',
                    'admin_color': '#3498db',
                    'icon_bg': 'rgba(52, 152, 219, 0.1)',
                    'icon_color': '#3498db'
                },
                'dark': {
                    'bg1': '#3a3a3a',
                    'bg2': '#2d2d2d',
                    'hover_bg1': '#454545',
                    'hover_bg2': '#3a3a3a',
                    'border': '#444',
                    'title_color': '#b0b0b0',
                    'value_color': '#ffffff',
                    'admin_color': '#5dade2',
                    'icon_bg': 'rgba(93, 173, 226, 0.2)',
                    'icon_color': '#5dade2'
                }
            }
            
            # Appliquer le style aux cartes de statistiques si elles existent
            for card_name in ['groups_card', 'channels_card', 'bots_card', 'chats_card']:
                if hasattr(self, card_name):
                    card = getattr(self, card_name, None)
                    if isinstance(card, StatsCard):
                        card_style = """
                            QFrame#statsCard {
                                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                         stop:0 %(bg1)s, stop:1 %(bg2)s);
                                border-radius: 12px;
                                border: 1px solid %(border)s;
                                padding: 16px;
                            }
                            QFrame#statsCard[hovered="true"] {
                                margin-top: -2px;
                                margin-bottom: 2px;
                                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                         stop:0 %(hover_bg1)s, stop:1 %(hover_bg2)s);
                            }
                            QLabel#statsTitle {
                                color: %(title_color)s;
                                font-size: 14px;
                                font-weight: 500;
                                text-transform: uppercase;
                                letter-spacing: 0.5px;
                            }
                            QLabel#statsValue {
                                color: %(value_color)s;
                                font-size: 28px;
                                font-weight: 700;
                                margin: 4px 0;
                            }
                            QLabel#statsAdmin {
                                color: %(admin_color)s;
                                font-size: 13px;
                                font-weight: 500;
                                margin-top: 2px;
                            }
                            QLabel#statsIcon {
                                font-size: 32px;
                                min-width: 50px;
                                text-align: center;
                                padding: 8px;
                                background: %(icon_bg)s;
                                border-radius: 10px;
                                color: %(icon_color)s;
                            }
                        """ % theme_colors[self._current_theme]
                        card.setStyleSheet(card_style)
            
            # Mettre à jour le thème du widget d'onglets s'il existe
            if hasattr(self, 'tab_widget'):
                if hasattr(self.tab_widget, 'set_theme'):
                    self.tab_widget.set_theme(theme_name)
                elif hasattr(self.tab_widget, 'update_theme'):
                    self.tab_widget.update_theme(theme_name)
                
            # Mettre à jour le style des barres de défilement
            scroll_style = """
                QScrollArea {
                    border: none;
                    background: transparent;
                }
                QScrollBar:vertical {
                    border: none;
                    background: %(bg2)s;
                    width: 10px;
                    margin: 0px;
                }
                QScrollBar::handle:vertical {
                    background: %(icon_color)s;
                    min-height: 20px;
                    border-radius: 5px;
                }
                QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                    height: 0px;
                }
            """ % theme_colors[self._current_theme]
            
            # Appliquer le style aux zones de défilement
            for widget_name in ['groups_content', 'channels_content', 'bots_content', 'chats_content']:
                if hasattr(self, widget_name):
                    widget = getattr(self, widget_name)
                    if hasattr(widget, 'setStyleSheet'):
                        widget.setStyleSheet(scroll_style)
                        
        except Exception as e:
            logging.error(f"Erreur lors de l'application du thème: {str(e)}")
    
    def _toggle_support_widget(self):
        """Bascule l'affichage du widget de support contextuel."""
        if self.support_widget.isVisible():
            self.support_widget.hide()
        else:
            # Positionner le widget à côté du bouton d'assistance
            button_pos = self.help_button.mapToGlobal(self.help_button.rect().bottomRight())
            self.support_widget.show_at_position(button_pos)

    def on_theme_changed(self, theme_name):
        """Appelé lorsque le thème de l'application change.
        
        Args:
            theme_name: Nom du thème ('light' ou 'dark')
        """
        self._current_theme = theme_name
        self.apply_theme(theme_name)
        
        # Mettre à jour les tooltips pour le nouveau thème
        try:
            from ...main import apply_tooltip_style
            app = QApplication.instance()
            if app and hasattr(self, 'parent') and self.parent():
                apply_tooltip_style(app, self.parent())
        except ImportError:
            # Fallback si l'import ne fonctionne pas
            pass
        
        # Mettre à jour les onglets
        if hasattr(self, 'tab_widget'):
            if hasattr(self.tab_widget, 'update_theme'):
                self.tab_widget.update_theme(theme_name)
            elif hasattr(self.tab_widget, 'set_theme'):
                self.tab_widget.set_theme(theme_name)
                
        # Mettre à jour le thème du widget de support
        if hasattr(self, 'support_widget'):
            self.support_widget.apply_theme(theme_name)
                
        # NOTE: Plus de EntityCard à mettre à jour - utilisation de QListView
        # Les thèmes sont gérés par QListView et EntityDelegate
        logging.debug(f"[THEME] Thème {theme_name} appliqué - les QListView utilisent déjà le thème approprié")
        
        # Mettre à jour le thème des delegates dans chaque QListView
        for tab_name in ['groups', 'channels', 'chats', 'bots']:
            tab_attr = f'{tab_name}_content'
            if hasattr(self, tab_attr):
                tab_content = getattr(self, tab_attr)
                # Chercher la QListView dans cet onglet
                list_views = tab_content.findChildren(QListView)
                for list_view in list_views:
                    delegate = list_view.itemDelegate()
                    if delegate and hasattr(delegate, 'set_theme'):
                        is_dark = (theme_name == 'dark')
                        delegate.set_theme(is_dark)
                        # Forcer le rechargement des items
                        if list_view.model():
                            list_view.model().dataChanged.emit(
                                list_view.model().index(0, 0),
                                list_view.model().index(
                                    list_view.model().rowCount() - 1, 0
                                )
                            )
                        logging.debug(f"[THEME] Delegate mis à jour pour {tab_name}")
        
        # NOTE: Plus de cartes sélectionnées à mettre à jour
        # Les QListView gèrent automatiquement les sélections et les thèmes
        logging.debug(f"[THEME] Thème appliqué à tous les composants")
    
    def _update_stats_cards(self):
        """Met à jour les StatsCard avec les données des entités chargées."""
        try:
            if not hasattr(self, 'entities') or not self.entities:
                logging.warning("[STATS] Aucune entité à afficher")
                return
            
            # Calculer les statistiques pour chaque type
            stats = {
                'groups': {'total': 0, 'admin': 0},
                'channels': {'total': 0, 'admin': 0},
                'bots': {'total': 0, 'admin': 0},
                'chats': {'total': 0, 'admin': 0}
            }
            
            for entity_type in ['groups', 'channels', 'bots', 'chats']:
                if entity_type in self.entities:
                    admin_count = len(self.entities[entity_type].get('admin', []))
                    member_count = len(self.entities[entity_type].get('member', []))
                    stats[entity_type]['total'] = admin_count + member_count
                    stats[entity_type]['admin'] = admin_count
            
            # Mettre à jour chaque StatsCard
            if hasattr(self, 'groups_card'):
                self.groups_card.set_value(str(stats['groups']['total']), str(stats['groups']['admin']))
                logging.debug(f"[STATS] Groupes: {stats['groups']['total']} total, {stats['groups']['admin']} admin")
            
            if hasattr(self, 'channels_card'):
                self.channels_card.set_value(str(stats['channels']['total']), str(stats['channels']['admin']))
                logging.debug(f"[STATS] Canaux: {stats['channels']['total']} total, {stats['channels']['admin']} admin")
            
            if hasattr(self, 'bots_card'):
                self.bots_card.set_value(str(stats['bots']['total']), str(stats['bots']['admin']))
                logging.debug(f"[STATS] Bots: {stats['bots']['total']} total, {stats['bots']['admin']} admin")
            
            if hasattr(self, 'chats_card'):
                self.chats_card.set_value(str(stats['chats']['total']), str(stats['chats']['admin']))
                logging.debug(f"[STATS] Chats: {stats['chats']['total']} total, {stats['chats']['admin']} admin")
                
            logging.info(f"[STATS] Statistiques mises à jour avec succès")
            
        except Exception as e:
            logging.error(f"[STATS] Erreur lors de la mise à jour des statistiques: {e}", exc_info=True)
    
    def _deselect_all_cards(self):
        """NOTE: Plus de cartes à désélectionner - utilisation de QListView."""
        # Les QListView gèrent automatiquement les sélections
        # Plus besoin de désélectionner manuellement les cartes
        logging.debug("[DESELECT] Plus de cartes à désélectionner - QListView gère les sélections")
        return
    
    def _on_entity_card_clicked(self, card, entity_id):
        """NOTE: Plus de cartes à gérer - utilisation de QListView."""
        # Les clics sont gérés par EntityDelegate et QListView
        # Plus besoin de gérer manuellement les clics sur les cartes
        logging.debug(f"[CLICK] Clic géré par QListView - ID: {entity_id}")
        return
    
    def _copy_to_clipboard(self, text: str):
        """Copie le texte donné dans le presse-papiers."""
        if not text:
            logging.warning("Tentative de copier un texte vide dans le presse-papiers.")
            return
        try:
            clipboard = QApplication.instance().clipboard()
            if clipboard:
                clipboard.setText(text)
                logging.info(f"'{text}' a été copié dans le presse-papiers.")
            else:
                logging.error("Impossible d'accéder au presse-papiers.")
        except Exception as e:
            logging.error(f"Erreur lors de la copie dans le presse-papiers: {e}")

    def _setup_search_connections(self):
        """Connecte les barres de recherche aux fonctions de filtrage."""
        self.groups_content.search_bar.textChanged.connect(
            lambda text: self._filter_entities(self.groups_content, text)
        )
        self.channels_content.search_bar.textChanged.connect(
            lambda text: self._filter_entities(self.channels_content, text)
        )
        self.bots_content.search_bar.textChanged.connect(
            lambda text: self._filter_entities(self.bots_content, text)
        )
        self.chats_content.search_bar.textChanged.connect(
            lambda text: self._filter_entities(self.chats_content, text)
        )
        
        # Connecter les signaux des boutons de navigation
        for section, button in self.groups_content.nav_buttons.items():
            button.clicked.connect(lambda checked, s=section: self._navigate_to_section(self.groups_content, s))
        
        for section, button in self.channels_content.nav_buttons.items():
            button.clicked.connect(lambda checked, s=section: self._navigate_to_section(self.channels_content, s))
        
        for section, button in self.bots_content.nav_buttons.items():
            button.clicked.connect(lambda checked, s=section: self._navigate_to_section(self.bots_content, s))
        
        for section, button in self.chats_content.nav_buttons.items():
            button.clicked.connect(lambda checked, s=section: self._navigate_to_section(self.chats_content, s))

    def _close_loading_dialog(self):
        """Ferme la boîte de dialogue de chargement si elle est ouverte."""
        try:
            if hasattr(self, 'loading_dialog') and self.loading_dialog is not None:
                if hasattr(self.loading_dialog, 'isVisible') and callable(self.loading_dialog.isVisible) and self.loading_dialog.isVisible():
                    # Utiliser hide() au lieu de accept() pour éviter les fenêtres blanches
                    self.loading_dialog.hide()
                # Nettoyer proprement le dialogue
                self.loading_dialog.deleteLater()
                self.loading_dialog = None
                logging.debug("LoadingDialog fermé et nettoyé avec succès")
        except Exception as e:
            logging.error(f"Erreur lors de la fermeture de la boîte de dialogue de chargement: {e}", exc_info=True)
    
    def _navigate_to_section(self, content_widget, section_name):
        """Navigue vers la section spécifiée dans la QListView."""
        try:
            # Récupérer la QListView dans le scroll_layout
            list_view = None
            if hasattr(content_widget, 'scroll_layout'):
                for i in range(content_widget.scroll_layout.count()):
                    widget = content_widget.scroll_layout.itemAt(i).widget()
                    if isinstance(widget, QListView):
                        list_view = widget
                        break
            
            if not list_view or not hasattr(list_view, 'model_ref'):
                logging.warning("Aucune QListView trouvée pour la navigation")
                return
            
            model = list_view.model_ref
            if not model:
                return
            
            # Mettre à jour l'état des boutons de navigation
            for button_name, button in content_widget.nav_buttons.items():
                button.setChecked(button_name == section_name)
            
            # Si "All" est sélectionné, afficher toutes les entités
            if section_name == "All":
                model.set_entity_type_filter(None)
                logging.info("Navigation to : All entities")
                return
            
            # Pour les autres sections, filtrer par type d'entité
            entity_type_map = {
                "Groups": "groups",
                "Channels": "channels", 
                "Bots": "bots",
                "Chats": "chats"
            }
            
            entity_type = entity_type_map.get(section_name)
            if entity_type:
                # Filtrer pour n'afficher que ce type d'entité
                model.set_entity_type_filter(entity_type)
                logging.info(f"Navigation vers la section: {section_name} ({entity_type}) - {len([e for e in model.entities if e.get('entity_type') == entity_type])} entités trouvées")
                
                # Scroller en haut de la liste
                list_view.scrollToTop()
            
        except Exception as e:
            logging.error(f"Erreur lors de la navigation vers la section {section_name}: {e}", exc_info=True)
    
    def _filter_entities(self, content_widget, text):
        """Filtre les entités avec QListView et le modèle."""
        try:
            # Récupérer la QListView dans le scroll_layout
            list_view = None
            if hasattr(content_widget, 'scroll_layout'):
                for i in range(content_widget.scroll_layout.count()):
                    widget = content_widget.scroll_layout.itemAt(i).widget()
                    if isinstance(widget, QListView):
                        list_view = widget
                        break
            
            if not list_view or not hasattr(list_view, 'model_ref'):
                logging.warning("Aucune QListView trouvée pour le filtrage")
                return
            
            model = list_view.model_ref
            if not model:
                return
            
            # Appliquer le filtre de recherche au modèle
            model.set_search_filter(text)
            logging.info(f"Filtrage par recherche: '{text}'")
            
        except Exception as e:
            logging.error(f"Erreur lors du filtrage: {e}", exc_info=True)
    
    def _handle_entity_action(self, action, data):
        """Gère les actions des entités depuis le delegate."""
        try:
            if action == "copy_id":
                entity_id = str(data.get('id', data) if isinstance(data, dict) else data)
                self._copy_to_clipboard(entity_id)
                QMessageBox.information(self, "Successful copy", f"ID {entity_id} copied to clipboard")
                logging.info(f"[ENTITY_ACTION] ID copied: {entity_id}")
                
            elif action == "copy_link":
                link = data.get('invite_link') if isinstance(data, dict) else None
                if link and link != 'None':
                    self._copy_to_clipboard(link)
                    QMessageBox.information(self, "Successful copy", "Link copied to clipboard")
                    logging.info(f"[ENTITY_ACTION] Link copied: {link}")
                else:
                    logging.warning("[ENTITY_ACTION] No link available for this entity")
                    
            elif action == "entity_click":
                entity_id = str(data.get('id', data) if isinstance(data, dict) else data)
                logging.info(f"[ENTITY_ACTION] Entity clicked: {entity_id}")
                # TODO: Implement an action for entity click
                
        except Exception as e:
            logging.error(f"[ENTITY_ACTION] Error processing action {action}: {e}", exc_info=True)

    
    async def load_entities(self):
        """Charge les entités (groupes, canaux, bots) de manière asynchrone."""
        if not hasattr(self, '_load_lock'):
            self._load_lock = asyncio.Lock()
        
        async with self._load_lock:
            try:
                logging.info("Début du chargement des entités...")
                logging.debug(f"Structure initiale de self.entities: {self.entities}")
                
                if not self.telegram_client or not self.telegram_client.client or not self.telegram_client.client.is_connected():
                    error_msg = "Client Telegram non connecté ou non initialisé"
                    logging.error(error_msg)
                    return False
                
                # Récupérer les dialogues
                try:
                    dialogs = await self.telegram_client.client.get_dialogs(limit=None)
                    logging.info(f"Nombre de dialogues récupérés : {len(dialogs)}")
                    
                    # Afficher des informations sur les types de dialogues
                    dialog_types = {}
                    for dialog in dialogs:
                        if not hasattr(dialog, 'entity'):
                            dialog_type = 'sans_entite'
                        else:
                            entity = dialog.entity
                            if hasattr(entity, 'user') and entity.user:
                                if getattr(entity, 'bot', False):
                                    dialog_type = 'bot'
                                else:
                                    dialog_type = 'user'
                            elif hasattr(entity, 'broadcast') and entity.broadcast:
                                dialog_type = 'channel'
                            elif hasattr(entity, 'megagroup') and entity.megagroup:
                                dialog_type = 'supergroup'
                            elif hasattr(entity, 'gigagroup') and entity.gigagroup:
                                dialog_type = 'gigagroup'
                            elif hasattr(entity, 'gigagroup'):
                                dialog_type = 'group'
                            else:
                                dialog_type = 'unknown'
                        
                        dialog_types[dialog_type] = dialog_types.get(dialog_type, 0) + 1
                    
                    logging.info(f"Répartition des types de dialogues: {dialog_types}")
                    
                except Exception as e:
                    logging.error(f"Erreur lors de la récupération des dialogues : {e}", exc_info=True)
                    return False
                
                me = await self.telegram_client.client.get_me()
                
                # Afficher des informations sur les premiers dialogues
                for i, dialog in enumerate(dialogs[:10]):  # Limité aux 10 premiers pour éviter trop de logs
                    entity = getattr(dialog, 'entity', None)
                    if not entity:
                        logging.warning(f"Dialogue {i}: Pas d'entité - {dialog}")
                        continue
                        
                    logging.info(f"Dialogue {i}: Type={type(entity).__name__}, ID={getattr(entity, 'id', 'N/A')}")
                    logging.info(f"  - Attributs: {[a for a in dir(entity) if not a.startswith('_')]}")
                    
                    # Vérifier les attributs spécifiques pour les utilisateurs
                    if hasattr(entity, 'user') and entity.user:
                        logging.info(f"  - C'est un utilisateur! Bot: {getattr(entity, 'bot', 'N/A')}, Self: {getattr(entity, 'self', 'N/A')}")
                        logging.info(f"  - Détails: {getattr(entity, 'first_name', 'N/A')} {getattr(entity, 'last_name', 'N/A')} (@{getattr(entity, 'username', 'N/A')})")
                
                # Traiter les dialogues en parallèle
                tasks = [self._process_entity(dialog, me) for dialog in dialogs]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                
                # Vérifier les résultats
                for i, result in enumerate(results):
                    if isinstance(result, Exception):
                        logging.error(f"Erreur lors du traitement du dialogue {i}: {result}", exc_info=result)
                
                # Vérifier les erreurs dans les tâches
                for i, result in enumerate(results):
                    if isinstance(result, Exception):
                        logging.warning(f"Erreur lors du traitement du dialogue {i}: {result}")
                
                # Charger les bots
                await self._load_bots(dialogs)
                
                # Mettre à jour l'interface utilisateur dans le thread principal
                def update_ui_safe():
                    try:
                        self.update_ui()
                        
                        # Mettre à jour les StatsCard avec les nouvelles données
                        self._update_stats_cards()
                        
                        # Log le nombre d'entités chargées
                        for entity_type in self.entities:
                            count = len(self.entities[entity_type]['admin'] + self.entities[entity_type]['member'])
                            logging.info(f"{entity_type.capitalize()} chargés : {count}")
                    except Exception as e:
                        logging.error(f"Erreur lors de la mise à jour de l'interface : {e}")
                
                # S'assurer que la mise à jour se fait dans le thread principal
                if hasattr(self, 'window') and hasattr(self.window(), 'call_in_main_thread'):
                    self.window().call_in_main_thread(update_ui_safe)
                else:
                    update_ui_safe()
                
                return True
                
            except Exception as e:
                logging.error(f"Erreur lors du chargement des entités: {e}", exc_info=True)
                return False
    
    async def _process_entity(self, dialog, me):
        """Traite une entité (groupe/canal) de manière asynchrone."""
        if not dialog:
            logging.warning("Dialogue invalide (None)")
            return
            
        if not hasattr(dialog, 'entity'):
            logging.warning(f"Dialogue sans attribut 'entity': {dialog}")
            return
            
        entity = dialog.entity
        entity_type = type(entity).__name__
        entity_id = getattr(entity, 'id', 'N/A')
        
        # Log des attributs de l'entité pour le débogage
        entity_attrs = [a for a in dir(entity) if not a.startswith('_')]
        logging.debug(f"Entité ID {entity_id} (Type: {entity_type}) - Attributs: {entity_attrs}")
        
        # Vérifier les attributs spécifiques
        if hasattr(entity, 'user'):
            logging.debug(f"  - C'est un utilisateur: {entity.user}")
            if hasattr(entity, 'bot'):
                logging.debug(f"  - Est un bot: {entity.bot}")
            if hasattr(entity, 'self'):
                logging.debug(f"  - Est l'utilisateur courant: {entity.self}")
            if hasattr(entity, 'first_name'):
                logging.debug(f"  - Prénom: {entity.first_name}")
            if hasattr(entity, 'last_name'):
                logging.debug(f"  - Nom: {entity.last_name}")
            if hasattr(entity, 'username'):
                logging.debug(f"  - Username: @{entity.username}")
        
        # Vérifier si c'est un utilisateur (chat privé)
        is_user = hasattr(entity, 'user') and entity.user
        is_bot = getattr(entity, 'bot', False)
        is_self = getattr(entity, 'self', False)
        is_me = entity.id == me.id if hasattr(entity, 'id') else False
        
        # Vérifier si c'est un dialogue privé (discussion 1:1)
        is_private_chat = False
        
        # Détection plus précise des chats privés
        if hasattr(dialog, 'is_user') and dialog.is_user:
            # Déjà marqué comme utilisateur par Telegram
            is_private_chat = True
            logging.debug(f"[CHAT_DETECTION] Chat détecté comme privé via dialog.is_user (ID: {entity_id})")
        elif is_user and not is_bot and not is_self and not is_me:
            # Utilisateur non-bot qui n'est pas soi-même
            is_private_chat = True
            logging.debug(f"[CHAT_DETECTION] Chat détecté comme privé via is_user (ID: {entity_id})")
        elif hasattr(entity, 'mutual_contact') and entity.mutual_contact:
            # Contact mutuel (discussion 1:1)
            is_private_chat = True
            logging.debug(f"[CHAT_DETECTION] Chat détecté comme privé via mutual_contact (ID: {entity_id})")
        
        # Log détaillé pour le débogage
        logging.debug(f"[CHAT_DETECTION] Détails de détection - is_user: {is_user}, is_bot: {is_bot}, is_self: {is_self}, is_me: {is_me}, is_private_chat: {is_private_chat}")
        logging.debug(f"[CHAT_DETECTION] Attributs de l'entité: {[a for a in dir(entity) if not a.startswith('_')]}")
        
        # Si c'est un bot, forcer la catégorisation comme bot
        if is_bot:
            logging.debug(f"[CHAT_DETECTION] Bot détecté: {getattr(entity, 'first_name', 'N/A')} {getattr(entity, 'last_name', 'N/A')} (ID: {entity_id})")
        
        # Vérifier si c'est un canal
        is_channel = hasattr(entity, 'broadcast') and entity.broadcast
        
        # Vérifier si c'est un supergroupe (megagroup ou gigagroup)
        is_supergroup = hasattr(entity, 'megagroup') and entity.megagroup
        is_gigagroup = hasattr(entity, 'gigagroup') and entity.gigagroup
        
        # Vérifier si c'est un groupe classique (pas supergroupe)
        is_classic_group = (hasattr(entity, 'participants_count') and entity.participants_count > 0) and not is_supergroup and not is_gigagroup
        
        # Log pour le débogage
        logging.debug(f"[PROCESS_ENTITY] Type détecté - Privé: {is_private_chat}, Canal: {is_channel}, Supergroupe: {is_supergroup}, Gigagroupe: {is_gigagroup}, Groupe classique: {is_classic_group}, Bot: {is_bot}")
        
        
        # Récupérer le lien d'invitation
        invite_link = ""
        if hasattr(entity, 'username') and entity.username:
            # Pour les entités avec un nom d'utilisateur public
            username = entity.username
            if username.startswith(('https://t.me/', 't.me/')):
                username = username.split('t.me/')[-1].split('/')[-1].split('?')[0]
            invite_link = f"https://t.me/{username}"
        elif is_private_chat and hasattr(entity, 'id'):
            # Pour les chats privés
            invite_link = f"tg://user?id={entity.id}"
        elif hasattr(self.telegram_client, 'get_invite_link') and (is_supergroup or is_gigagroup or is_channel or is_classic_group):
            # Pour les groupes et canaux privés, essayer de récupérer un lien d'invitation
            try:
                invite_link = await self.telegram_client.get_invite_link(entity)
                if not invite_link:
                    # Si aucun lien n'est disponible, utiliser un format par défaut
                    invite_link = f"https://t.me/joinchat/{entity.id}"
            except Exception as e:
                logging.error(f"Erreur lors de la récupération du lien d'invitation pour {entity.id}: {e}")
                invite_link = f"https://t.me/joinchat/{entity.id}"  # Format par défaut en cas d'erreur
            
        # Récupérer le nombre de participants si disponible
        members_count = 0  # Par défaut à 0 (pas d'affichage pour les chats privés)
        if not is_private_chat:
            # Pour les groupes et canaux uniquement, récupérer le nombre de participants
            try:
                if hasattr(entity, 'participants_count'):
                    members_count = entity.participants_count
                elif hasattr(dialog, 'participants') and hasattr(dialog.participants, 'participants'):
                    members_count = len(dialog.participants.participants)
            except Exception as e:
                logging.error(f"Erreur lors de la récupération du nombre de membres pour {entity.id}: {e}")
                members_count = 0  # En cas d'erreur, ne pas afficher de nombre
        
        # Vérifier si l'utilisateur est administrateur
        is_admin = False
        if hasattr(entity, 'admin_rights') and entity.admin_rights:
            is_admin = True
        elif hasattr(dialog, 'participants') and hasattr(dialog.participants, 'participants'):
            # Vérifier si l'utilisateur est administrateur dans les participants
            for participant in dialog.participants.participants:
                if hasattr(participant, 'is_admin') and participant.is_admin:
                    is_admin = True
                    break
        
        # Déterminer le format de l'ID en fonction du type d'entité
        entity_id = entity.id
        if is_channel or is_supergroup or is_gigagroup:
            # Pour les canaux, supergroupes et gigagroupes, ajouter -100 devant l'ID réel
            entity_id = int(f"-100{abs(entity_id)}")
        elif is_classic_group:
            # Pour les groupes classiques, ajouter simplement - devant l'ID
            entity_id = -abs(entity_id)
        
        # Détecter si l'utilisateur est banni/supprimé (pas de nom, pas de username)
        is_banned_or_deleted = (
            hasattr(entity, 'first_name') and not entity.first_name and
            hasattr(entity, 'last_name') and not entity.last_name and
            hasattr(entity, 'username') and not entity.username
        )
        
        if is_banned_or_deleted:
            entity_title = "Deleted Account 👻"
        else:
            entity_title = getattr(entity, 'title', 
                                 f"{getattr(entity, 'first_name', '') or ''} {getattr(entity, 'last_name', '') or ''}".strip() or 
                                 f"@{getattr(entity, 'username', '') or ''}" or 
                                 f"chat_{getattr(entity, 'id', 'unknown')}")
        
        # Nettoyer le titre pour enlever les "None" résiduels
        if entity_title and 'None' in entity_title:
            entity_title = entity_title.replace('None', '').strip()
            # Nettoyer les espaces multiples
            entity_title = ' '.join(entity_title.split())
        
        entity_data = {
            'id': entity_id,
            'title': entity_title,
            'username': getattr(entity, 'username', ''),
            'invite_link': invite_link,
            'is_admin': is_admin,
            'members_count': members_count,
            'is_group': not (hasattr(entity, 'broadcast') and entity.broadcast),
            'is_private_chat': is_private_chat
        }
        
        
        # Déterminer la catégorie de l'entité en fonction des indicateurs de type
        if is_bot:
            # Pour les bots
            category = 'bots'
            role = 'member'  # Pas de statut admin pour les bots
            entity_data['is_bot'] = True  # Ajouter un indicateur explicite
            logging.debug(f"[CATEGORIZATION] Bot détecté: {entity_data.get('title')} (ID: {entity_data.get('id')})")
        elif is_private_chat and not is_bot:
            # Pour les chats privés (1:1) qui ne sont pas des bots
            category = 'chats'
            role = 'member'
            entity_data['is_private_chat'] = True  # Ajouter un indicateur explicite
            logging.debug(f"[CATEGORIZATION] Chat privé détecté: {entity_data.get('title')} (ID: {entity_data.get('id')})")
        elif is_channel:
            # Pour les canaux (broadcast)
            category = 'channels'
            role = 'admin' if is_admin else 'member'
            entity_data['is_channel'] = True  # Ajouter un indicateur explicite
            logging.debug(f"[CATEGORIZATION] Canal détecté: {entity_data.get('title')} (ID: {entity_data.get('id')})")
        elif is_supergroup or is_gigagroup:
            # Pour les supergroupes et gigagroupes
            category = 'groups'
            role = 'admin' if is_admin else 'member'
            entity_data['is_group'] = True  # Ajouter un indicateur explicite
            entity_data['is_supergroup'] = is_supergroup  # Ajouter un indicateur explicite
            entity_data['is_gigagroup'] = is_gigagroup  # Ajouter un indicateur explicite
            logging.debug(f"[CATEGORIZATION] {'Supergroupe' if is_supergroup else 'Gigagroupe'} détecté: {entity_data.get('title')} (ID: {entity_data.get('id')})")
        elif is_classic_group:
            # Pour les groupes classiques
            category = 'groups'
            role = 'admin' if is_admin else 'member'
            entity_data['is_group'] = True  # Ajouter un indicateur explicite
            entity_data['is_classic_group'] = True  # Ajouter un indicateur explicite
            logging.debug(f"[CATEGORIZATION] Groupe classique détecté: {entity_data.get('title')} (ID: {entity_data.get('id')})")
        else:
            # Type non reconnu, essayer de le déterminer par d'autres moyens
            logging.warning(f"Type d'entité non reconnu pour l'entité {entity_data.get('title', 'inconnu')} (ID: {entity_data.get('id', 'inconnu')})")
            
            # Essayer de deviner le type en fonction des attributs disponibles
            if hasattr(entity, 'broadcast'):
                category = 'channels'
                role = 'admin' if is_admin else 'member'
                entity_data['is_channel'] = True
                logging.warning(f"  -> Détecté comme canal (fallback)")
            elif hasattr(entity, 'megagroup') or hasattr(entity, 'gigagroup'):
                category = 'groups'
                role = 'admin' if is_admin else 'member'
                entity_data['is_group'] = True
                if hasattr(entity, 'megagroup'):
                    entity_data['is_supergroup'] = True
                if hasattr(entity, 'gigagroup'):
                    entity_data['is_gigagroup'] = True
                logging.warning(f"  -> Détecté comme supergroupe/gigagroupe (fallback)")
            elif hasattr(entity, 'user') and entity.user and not is_bot:
                category = 'chats'
                role = 'member'
                entity_data['is_private_chat'] = True
                logging.warning(f"  -> Détecté comme chat privé (fallback)")
            else:
                # Par défaut, considérer comme un groupe classique
                category = 'groups'
                role = 'member'
                entity_data['is_group'] = True
                entity_data['is_classic_group'] = True
                logging.warning(f"  -> Par défaut, considéré comme groupe classique")
        
        # Vérifier si l'entité existe déjà pour éviter les doublons
        existing_index = next((i for i, e in enumerate(self.entities[category][role]) 
                             if e.get('id') == entity_data['id']), None)
            
        # Mettre à jour l'entité existante ou en ajouter une nouvelle
        if existing_index is not None:
            # Mettre à jour l'entité existante avec les nouvelles données
            self.entities[category][role][existing_index].update(entity_data)
            logging.debug(f"Entité mise à jour: {entity_data['title']} (ID: {entity_data['id']})")
        else:
            # Ajouter la nouvelle entité à la liste appropriée
            self.entities[category][role].append(entity_data)
            logging.debug(f"Nouvelle entité ajoutée: {entity_data['title']} (ID: {entity_data['id']})")
            
        # Log détaillé des données de l'entité
        debug_info = [
            f"[PROCESS_ENTITY] Données de l'entité {entity_title} (ID: {entity.id}):",
            f"[PROCESS_ENTITY] - Titre: {entity_title}",
            f"[PROCESS_ENTITY] - Username: {entity_data['username']}",
            f"[PROCESS_ENTITY] - Lien d'invitation: {invite_link}",
            f"[PROCESS_ENTITY] - Est admin: {is_admin}",
            f"[PROCESS_ENTITY] - Nombre de membres: {members_count}",
            f"[PROCESS_ENTITY] - Est un groupe: {entity_data['is_group']}"
        ]
        
        for line in debug_info:
            logging.debug(line)
            
        logging.info(f"Entité {entity_data.get('title', 'sans titre')} (ID: {entity_data.get('id', 'inconnu')}) traitée avec succès")
        
        return entity_data
    
    async def _is_bot_admin(self, bot_entity):
        """Vérifie si l'utilisateur actuel est administrateur/propriétaire du bot.
        
        Args:
            bot_entity: L'entité du bot à vérifier
            
        Returns:
            bool: Toujours False car on ne gère plus les badges admin pour les bots
        """
        return False
    
    async def _load_bots(self, dialogs):
        """Charge les informations supplémentaires pour les bots.
        
        Note: Les bots sont maintenant principalement chargés via _process_entity.
        Cette méthode est conservée pour la compatibilité et pour charger les bots manquants.
        """
        try:
            # S'assurer que la catégorie bots existe
            if 'bots' not in self.entities:
                self.entities['bots'] = {'admin': [], 'member': []}
            
            # Récupérer les bots depuis les contacts (en plus de ceux déjà chargés via _process_entity)
            try:
                from telethon.tl.functions.contacts import GetContactsRequest
                result = await self.telegram_client.client(GetContactsRequest(hash=0))
                
                for user in result.users:
                    if user.bot:
                        # Vérifier si le bot existe déjà
                        bot_exists = any(bot['id'] == user.id for bot in self.entities['bots']['member'])
                        
                        if not bot_exists:
                            bot_data = {
                                'id': user.id,
                                'title': f"{user.first_name or ''} {user.last_name or ''}".strip() or f"@{user.username}" if user.username else f"user_{user.id}",
                                'username': user.username or '',
                                'invite_link': f"https://t.me/{user.username}" if user.username else "",
                                'is_admin': False,  # Pas de statut admin pour les bots
                                'is_bot': True,
                                'is_private_chat': True  # Les bots sont considérés comme des chats privés
                            }
                            self.entities['bots']['member'].append(bot_data)
                            logging.debug(f"Bot ajouté depuis les contacts: {bot_data.get('title')} (ID: {user.id})")
                            
            except Exception as e:
                logging.error(f"Erreur lors du chargement des contacts: {e}")
                
        except Exception as e:
            logging.error(f"Erreur lors du chargement des bots: {e}", exc_info=True)
    
    def _on_load_complete(self, task):
        """Gère le résultat du chargement des données."""
        try:
            # Vérifier s'il y a eu une exception
            success = task.result()
            if success:
                logging.info("Chargement des données terminé avec succès")
                # Mettre à jour l'interface
                if hasattr(self, 'window') and hasattr(self.window(), 'call_in_main_thread'):
                    self.window().call_in_main_thread(self.update_ui)
                else:
                    self.update_ui()
        except asyncio.CancelledError:
            # La tâche a été annulée, c'est normal
            logging.info("Chargement des données annulé")
            pass
        except Exception as e:
            logging.error(f"Erreur lors du chargement des données: {e}", exc_info=True)
            # Réessayer après un délai
            self.schedule_reload(5000)
    
    def load_data(self):
        """Méthode de compatibilité pour main_window.py.
        
        Cette méthode est appelée depuis main_window.py après une connexion réussie.
        Elle déclenche un rechargement des données.
        """
        self.reload_data()
    
    def update_ui(self, **kwargs):
        """Met à jour l'interface utilisateur avec les données chargées."""
        self._ui_update_start = datetime.now()
        
        # Solution radicale : ne charger que les statistiques, pas les cartes
        main_window = self.parent()
        window_hidden = False
        if main_window and hasattr(main_window, 'setVisible'):
            main_window.setVisible(False)
            window_hidden = True
            logging.info("[UPDATE_UI] Fenêtre principale masquée pour éviter la fenêtre parasite")
        
        try:
            logging.info("Mise à jour de l'interface utilisateur...")
            logging.debug(f"Contenu complet de self.entities: {self.entities}")
            
            # Calculer les totaux et administrateurs pour chaque type d'entité
            entity_stats = {}
            for entity_type in ['groups', 'channels', 'bots', 'chats']:
                if entity_type in self.entities:
                    admin_count = len(self.entities[entity_type].get('admin', []))
                    member_count = len(self.entities[entity_type].get('member', []))
                    total_count = admin_count + member_count
                    entity_stats[entity_type] = {
                        'total': total_count,
                        'admin': admin_count,
                        'member': member_count
                    }
                else:
                    entity_stats[entity_type] = {'total': 0, 'admin': 0, 'member': 0}
            
            logging.info(f"Statistiques calculées: {entity_stats}")
            
            # Mettre à jour uniquement les cartes statistiques
            try:
                if hasattr(self, 'groups_stat_card'):
                    self.groups_stat_card.update_stats(
                        entity_stats['groups']['total'],
                        entity_stats['groups']['admin']
                    )
                if hasattr(self, 'channels_stat_card'):
                    self.channels_stat_card.update_stats(
                        entity_stats['channels']['total'],
                        entity_stats['channels']['admin']
                    )
                if hasattr(self, 'bots_stat_card'):
                    self.bots_stat_card.update_stats(
                        entity_stats['bots']['total'],
                        entity_stats['bots']['admin']
                    )
                if hasattr(self, 'chats_stat_card'):
                    self.chats_stat_card.update_stats(
                        entity_stats['chats']['total'],
                        entity_stats['chats']['admin']
                    )
                logging.info("Cartes statistiques mises à jour avec succès")
            except Exception as stats_error:
                logging.error(f"Erreur lors de la mise à jour des cartes statistiques: {stats_error}", exc_info=True)
            
            # NE PAS CHARGER LES CARTES - Attendre la demande de l'utilisateur
            logging.info("Chargement des cartes reporté à la demande de l'utilisateur")
            
            # Charger automatiquement les entités avec HTML pour éviter la fenêtre parasite
            logging.info("Chargement automatique des entités avec HTML")
            
            for tab_name, tab_content in [('groups', self.groups_content), 
                                         ('channels', self.channels_content), 
                                         ('bots', self.bots_content), 
                                         ('chats', self.chats_content)]:
                try:
                    self.load_entities_with_webview(tab_name)
                    logging.debug(f"Entités chargées automatiquement pour l'onglet {tab_name}")
                except Exception as tab_error:
                    logging.error(f"Erreur lors du chargement de l'onglet {tab_name}: {tab_error}", exc_info=True)
            
            logging.info("Mise à jour de l'interface utilisateur terminée avec chargement HTML")
            
        except Exception as e:
            logging.error(f"Erreur lors de la mise à jour de l'interface: {e}", exc_info=True)
            # Afficher un message d'erreur dans l'interface
            error_widget = QLabel(f"Erreur lors du chargement des données: {str(e)}")
            error_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
            error_widget.setStyleSheet("color: red;")
            self.groups_content.clear()
            self.groups_content.add_widget(error_widget)
            
            # Fermer la boîte de dialogue de chargement en cas d'erreur
            # DÉSACTIVÉ TEMPORAIRE - LoadingDialog désactivé pour le débogage
            # self._close_loading_dialog()
            logging.debug("close_loading_dialog désactivé dans except - LoadingDialog non utilisé")
        finally:
            # Réafficher la fenêtre principale à la fin
            if window_hidden and main_window and hasattr(main_window, 'setVisible'):
                main_window.setVisible(True)
                logging.info("[UPDATE_UI] Fenêtre principale réaffichée")

    def update_tab(self, entity_type, tab_content, empty_message):
        """Met à jour le contenu d'un onglet avec les entités.
        
        Args:
            entity_type: Type d'entité ('groups', 'channels', 'bots' ou 'chats')
            tab_content: Instance de TabContent du CustomTabWidget
            empty_message: Message à afficher si aucune entité n'est disponible
        """
        try:
            logging.info(f"[UPDATE_TAB] Début de la mise à jour de l'onglet {entity_type}")
            logging.debug(f"[UPDATE_TAB] Type d'onglet: {type(tab_content).__name__}")
            logging.debug(f"[UPDATE_TAB] Contenu avant nettoyage: {tab_content.findChildren(type(tab_content))}")
            
            # Vérifier si le contenu de l'onglet est valide
            if not hasattr(tab_content, 'clear') or not hasattr(tab_content, 'scroll_layout'):
                error_msg = f"[UPDATE_TAB] Le contenu de l'onglet {entity_type} n'a pas les méthodes attendues"
                logging.error(error_msg)
                self._show_error_in_tab(tab_content, error_msg)
                return
                
            try:
                tab_content.clear()  # Vider le contenu précédent
            except Exception as clear_error:
                error_msg = f"[UPDATE_TAB] Erreur lors du nettoyage de l'onglet {entity_type}: {str(clear_error)}"
                logging.error(error_msg, exc_info=True)
                self._show_error_in_tab(tab_content, error_msg)
                return
            
            # Récupérer le layout du contenu scrollable
            layout = tab_content.scroll_layout
            if not layout:
                error_msg = f"[UPDATE_TAB] Impossible de récupérer le layout pour l'onglet {entity_type}"
                logging.error(error_msg)
                self._show_error_in_tab(tab_content, error_msg)
                return

            # Récupérer les entités pour ce type
            try:
                if entity_type not in self.entities:
                    logging.warning(f"[UPDATE_TAB] Aucune entité trouvée pour le type: {entity_type}")
                    admin_entities = []
                    member_entities = []
                    all_entities_sorted = []
                else:
                    admin_entities = self.entities[entity_type].get('admin', [])
                    member_entities = self.entities[entity_type].get('member', [])
                    
                    # Trier chaque groupe séparément par titre
                    try:
                        admin_entities_sorted = sorted(admin_entities, key=lambda x: str(x.get('title', '')).lower())
                        member_entities_sorted = sorted(member_entities, key=lambda x: str(x.get('title', '')).lower())
                    except Exception as sort_error:
                        logging.warning(f"[UPDATE_TAB] Erreur lors du tri des entités: {sort_error}")
                        admin_entities_sorted = admin_entities
                        member_entities_sorted = member_entities
                    
                    # Combiner les listes triées (admin d'abord, puis membres)
                    all_entities_sorted = admin_entities_sorted + member_entities_sorted
                
                    logging.info(f"[UPDATE_TAB] Entités trouvées pour {entity_type}: {len(all_entities_sorted)} (admin: {len(admin_entities)}, membres: {len(member_entities)})")
                    
                    # Journalisation détaillée des entités pour le débogage
                    for i, ent in enumerate(all_entities_sorted[:10]):  # Augmenté à 10 entités pour plus de visibilité
                        logging.debug(f"[UPDATE_TAB] Entité {i+1}/{len(all_entities_sorted)}: ID={ent.get('id', 'N/A')}, "
                                    f"Titre='{ent.get('title', 'N/A')}', "
                                    f"Admin={ent.get('is_admin', False)}, "
                                    f"Type={type(ent).__name__}, "
                                    f"Clés={list(ent.keys())}")

                    if all_entities_sorted:
                        # Solution Lazy Loading : charger les cartes progressivement
                        cards_added = 0
                        batch_size = 10  # Nombre de cartes à charger par batch
                        
                        # Stocker les entités restantes pour le chargement progressif
                        if not hasattr(self, '_pending_entities'):
                            self._pending_entities = {}
                        self._pending_entities[entity_type] = all_entities_sorted
                        
                        # Charger le premier batch immédiatement
                        first_batch = all_entities_sorted[:batch_size]
                        remaining_entities = all_entities_sorted[batch_size:]
                        
                        logging.info(f"[UPDATE_TAB] Lazy Loading : {len(first_batch)} cartes immédiatement, {len(remaining_entities)} en attente")
                        
                        # Créer et ajouter le premier batch
                        for i, entity_data in enumerate(first_batch):
                            try:
                                entity_title = entity_data.get('title', 'sans titre')
                                logging.debug(f"[UPDATE_TAB] Création de la carte {i+1}/{len(first_batch)} (batch 1) pour {entity_title}")
                                
                                # Vérifier les données de l'entité
                                if not entity_data.get('id'):
                                    logging.warning(f"[UPDATE_TAB] L'entité {entity_title} n'a pas d'ID valide, elle sera ignorée")
                                    continue
                                
                                # NOTE: Plus de création de cartes - utilisation de QListView
                                # Les entités sont affichées via EntityModel + EntityDelegate
                                logging.debug(f"[UPDATE_TAB] Entité {entity_title} gérée via QListView")
                            
                            except Exception as card_error:
                                logging.error(f"[UPDATE_TAB] Erreur lors de la création de la carte pour {entity_title}: {card_error}", exc_info=True)
                        
                        # Stocker les entités restantes et planifier le chargement différé
                        if remaining_entities:
                            self._pending_entities[entity_type] = remaining_entities
                            # Utiliser un QTimer très court pour charger le reste sans bloquer l'UI
                            QTimer.singleShot(100, lambda: self._load_remaining_entities(entity_type, tab_content, layout))
                            logging.info(f"[UPDATE_TAB] {len(remaining_entities)} cartes planifiées pour chargement différé")
                        
                        if cards_added > 0:
                            logging.info(f"[UPDATE_TAB] {cards_added} cartes ajoutées immédiatement à l'onglet {entity_type}")
                        else:
                            logging.warning(f"[UPDATE_TAB] Aucune carte valide n'a pu être créée pour {entity_type}")
                            self._show_empty_message(tab_content, empty_message)
                    else:
                        # Afficher un message si aucune entité n'est trouvée
                        logging.warning(f"[UPDATE_TAB] Aucune entité trouvée pour {entity_type}")
                        self._show_empty_message(tab_content, empty_message)

                # Ajouter un espace extensible pour pousser les cartes vers le haut
                try:
                    layout.addStretch()
                except Exception as stretch_error:
                    logging.warning(f"[UPDATE_TAB] Erreur lors de l'ajout du stretch: {stretch_error}")
                
                logging.info(f"[UPDATE_TAB] Mise à jour de l'onglet {entity_type} terminée avec succès")
                
            except Exception as process_error:
                error_msg = f"Erreur lors du traitement des entités pour {entity_type}: {str(process_error)}"
                logging.error(error_msg, exc_info=True)
                self._show_error_in_tab(tab_content, error_msg)

        except Exception as e:
            error_msg = f"Erreur inattendue lors de la mise à jour de l'onglet {entity_type}: {str(e)}"
            logging.error(error_msg, exc_info=True)
            self._show_error_in_tab(tab_content, error_msg)
    
    
    def _handle_entity_action(self, action, data):
        """Gère les actions des entités depuis le delegate."""
        try:
            if action == "copy_id":
                entity_id = str(data.get('id', data) if isinstance(data, dict) else data)
                self._copy_to_clipboard(entity_id)
                QMessageBox.information(self, "Copy successful", f"ID {entity_id} copied to clipboard")
                logging.info(f"[ENTITY_ACTION] ID copied: {entity_id}")
                
            elif action == "copy_link":
                link = str(data.get('invite_link', data) if isinstance(data, dict) else data)
                if link and link != 'None':
                    self._copy_to_clipboard(link)
                    QMessageBox.information(self, "Copy successful", "Link copied to clipboard")
                    logging.info(f"[ENTITY_ACTION] Link copied: {link}")
                else:
                    logging.warning("[ENTITY_ACTION] No link available for this entity")
                    
            elif action == "entity_click":
                entity_id = str(data.get('id', data) if isinstance(data, dict) else data)
                logging.info(f"[ENTITY_ACTION] Entity clicked: {entity_id}")
                # TODO: Implement an action for entity click
                
        except Exception as e:
            logging.error(f"[ENTITY_ACTION] Error processing action {action}: {e}", exc_info=True)
    
    def _clear_tab_content(self, tab_content):
        """Nettoie complètement le contenu d'un onglet."""
        try:
            logging.debug(f"[CLEAR_TAB] Nettoyage de l'onglet")
            
            # Méthode 1 : Si c'est un scroll area avec layout
            if hasattr(tab_content, 'scroll_layout'):
                while tab_content.scroll_layout.count():
                    item = tab_content.scroll_layout.takeAt(0)
                    if item.widget():
                        item.widget().deleteLater()
            # Méthode 2 : Nettoyage direct du layout
            else:
                layout = getattr(tab_content, 'layout', None)
                if layout:
                    while layout.count():
                        item = layout.takeAt(0)
                        if item.widget():
                            item.widget().deleteLater()
                else:
                    # Méthode 3 : Nettoyage radical pour les widgets récalcitrants
                    if hasattr(tab_content, 'clear'):
                        tab_content.clear()
                    
                    # Supprimer tous les widgets enfants
                    for child in tab_content.children():
                        if hasattr(child, 'deleteLater'):
                            child.deleteLater()
                    
                    # Recréer un layout propre
                    new_layout = QVBoxLayout(tab_content)
                    new_layout.setContentsMargins(0, 0, 0, 0)
                    tab_content.setLayout(new_layout)
                    
            logging.debug(f"[CLEAR_TAB] Onglet nettoyé avec succès")
        except Exception as e:
            logging.error(f"[CLEAR_TAB] Erreur lors du nettoyage: {e}", exc_info=True)
    
    def load_entities_with_webview(self, entity_type):
        """Charge les entités en utilisant QListView (pas de widgets massifs)."""
        try:
            logging.info(f"[LIST_VIEW] Début du chargement des entités pour {entity_type}")
            
            # Récupérer le contenu de l'onglet approprié
            tab_content = None
            
            if entity_type == 'groups':
                tab_content = self.groups_content
            elif entity_type == 'channels':
                tab_content = self.channels_content
            elif entity_type == 'bots':
                tab_content = self.bots_content
            elif entity_type == 'chats':
                tab_content = self.chats_content
            
            if not tab_content:
                logging.error(f"[LIST_VIEW] Onglet non trouvé pour {entity_type}")
                return
            
            # Nettoyer le contenu existant
            self._clear_tab_content(tab_content)
            
            # Charger les entités avec le loader Python
            if hasattr(self, 'entity_loader'):
                entities_data = self.entity_loader.load_entities(self.entities)
                logging.info(f"[LOADER] Données traitées avec le loader Python")
            
            # Créer le modèle personnalisé (pas de widgets !)
            # Charger toutes les entités pour permettre la navigation entre sections
            model = EntityModel(entity_loader=self.entity_loader)
            model.set_entities(self.entities, None)  # None = tous les types
            
            # Créer le délégué pour le rendu personnalisé
            delegate = EntityDelegate()
            
            # Appliquer le thème actuel au délégué
            is_dark = getattr(self, '_current_theme', 'light') == 'dark'
            delegate.set_theme(is_dark)
            
            # Connecter les signaux du délégué
            delegate.copy_id_clicked.connect(lambda entity: self._handle_entity_action("copy_id", entity))
            delegate.copy_link_clicked.connect(lambda entity: self._handle_entity_action("copy_link", entity))
            delegate.entity_clicked.connect(lambda entity: self._handle_entity_action("entity_click", entity))
            
            # Créer la QListView (UN SEUL WIDGET !)
            list_view = QListView()
            list_view.setModel(model)
            list_view.setItemDelegate(delegate)
            
            # Configuration du style
            list_view.setAlternatingRowColors(True)
            list_view.setSelectionMode(QListView.SelectionMode.SingleSelection)
            list_view.setSpacing(2)
            
            # Appliquer le thème
            is_dark = getattr(self, '_current_theme', 'light') == 'dark'
            if is_dark:
                list_view.setStyleSheet("""
                    QListView {
                        background: #2c3e50;
                        alternate-background-color: #34495e;
                        color: #ecf0f1;
                        border: none;
                        outline: none;
                    }
                    QListView::item:selected {
                        background: #9b59b6;
                        color: white;
                    }
                    QListView::item:hover {
                        background: #34495e;
                    }
                """)
            else:
                list_view.setStyleSheet("""
                    QListView {
                        background: #f8f9fa;
                        alternate-background-color: #ffffff;
                        color: #2c3e50;
                        border: none;
                        outline: none;
                    }
                    QListView::item:selected {
                        background: #3498db;
                        color: white;
                    }
                    QListView::item:hover {
                        background: #e9ecef;
                    }
                """)
            
            # Stocker les références pour les actions
            list_view.entity_type = entity_type
            list_view.model_ref = model
            list_view.delegate_ref = delegate
            
            # Ajouter la QListView à l'onglet (UN SEUL WIDGET !)
            # Ajouter dans le scroll_content pour éviter le bloc bleu vide
            if hasattr(tab_content, 'scroll_layout'):
                tab_content.scroll_layout.addWidget(list_view)
            else:
                # Fallback : layout principal
                layout = getattr(tab_content, 'layout', None)
                if not layout:
                    layout = QVBoxLayout(tab_content)
                    tab_content.setLayout(layout)
                layout.addWidget(list_view)
            
            logging.info(f"[LIST_VIEW] QListView créée pour {entity_type} - ZERO FENÊTRE PARASITE !")
            
        except Exception as e:
            logging.error(f"[LIST_VIEW] Erreur lors du chargement: {e}", exc_info=True)
            if tab_content:
                self._show_error_in_tab(tab_content, f"Erreur: {str(e)}")
    
    def _load_remaining_entities(self, entity_type, tab_content, layout):
        """Charge les entités restantes par petits lots pour éviter la fenêtre parasite."""
        try:
            if not hasattr(self, '_pending_entities') or entity_type not in self._pending_entities:
                logging.debug(f"[LOAD_REMAINING] Aucune entité en attente pour {entity_type}")
                return
            
            remaining_entities = self._pending_entities[entity_type]
            if not remaining_entities:
                logging.debug(f"[LOAD_REMAINING] Toutes les entités déjà chargées pour {entity_type}")
                return
            
            batch_size = 5  # Plus petit batch pour le chargement différé
            current_batch = remaining_entities[:batch_size]
            new_remaining = remaining_entities[batch_size:]
            
            logging.info(f"[LOAD_REMAINING] Chargement de {len(current_batch)} cartes pour {entity_type}, {len(new_remaining)} restantes")
            
            cards_added = 0
            for entity_data in current_batch:
                try:
                    entity_title = entity_data.get('title', 'sans titre')
                    logging.debug(f"[LOAD_REMAINING] Création de la carte pour {entity_title}")
                    
                    # Vérifier les données de l'entité
                    if not entity_data.get('id'):
                        logging.warning(f"[LOAD_REMAINING] L'entité {entity_title} n'a pas d'ID valide, elle sera ignorée")
                        continue
                    
                    # NOTE: Plus de création de cartes - utilisation de QListView
                    # Les entités sont affichées via EntityModel + EntityDelegate
                    logging.debug(f"[LOAD_REMAINING] Entité {entity_title} gérée via QListView")
                
                except Exception as card_error:
                    logging.error(f"[LOAD_REMAINING] Erreur lors de la création de la carte: {card_error}", exc_info=True)
            
            # Mettre à jour les entités restantes
            self._pending_entities[entity_type] = new_remaining
            
            logging.info(f"[LOAD_REMAINING] {cards_added} cartes ajoutées, {len(new_remaining)} restantes pour {entity_type}")
            
            # Continuer le chargement s'il reste des entités
            if new_remaining:
                QTimer.singleShot(200, lambda: self._load_remaining_entities(entity_type, tab_content, layout))
            else:
                logging.info(f"[LOAD_REMAINING] Chargement terminé pour {entity_type}")
                # Forcer le rafraîchissement du layout
                tab_content.update()
                layout.update()
        
        except Exception as e:
            logging.error(f"[LOAD_REMAINING] Erreur lors du chargement progressif: {e}", exc_info=True)
    
    def _show_empty_message(self, tab_content, message):
        try:
            empty_label = QLabel(message)
            empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            empty_label.setStyleSheet("""
                color: #666;
                font-style: italic;
                padding: 20px;
                font-size: 14px;
            """)
            if hasattr(tab_content, 'scroll_layout'):
                tab_content.scroll_layout.addWidget(empty_label)
            else:
                tab_content.add_widget(empty_label)
        except Exception as e:
            logging.error(f"Erreur lors de l'affichage du message vide: {e}", exc_info=True)
    
    def _show_error_in_tab(self, tab_content, error_message):
        """Affiche un message d'erreur dans l'onglet spécifié."""
        try:
            tab_content.clear()
            error_label = QLabel(error_message)
            error_label.setWordWrap(True)
            error_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            error_label.setStyleSheet("""
                color: #e74c3c;
                font-weight: bold;
                padding: 20px;
                background-color: #fde8e8;
                border-radius: 5px;
                margin: 10px;
                font-size: 13px;
            """)
            if hasattr(tab_content, 'scroll_layout'):
                tab_content.scroll_layout.addWidget(error_label)
            else:
                tab_content.add_widget(error_label)
        except Exception as e:
            logging.error(f"Erreur critique lors de l'affichage du message d'erreur: {e}", exc_info=True)

    def _on_entity_card_clicked(self, card, entity_id):
        """Gère le clic sur une carte d'entité.
        
        Args:
            card: La carte qui a été cliquée
            entity_id: L'ID de l'entité associée à la carte
        """
        try:
            logging.debug(f"Clic sur la carte d'entité {entity_id}")
            
            # Vérifier si la carte est déjà sélectionnée
            if card.property("selected") == True:
                # Si la carte est déjà sélectionnée, on la désélectionne
                card.set_selected(False)
                # Supprimer la carte des sélections
                for tab_name, selected_card in list(self._selected_cards.items()):
                    if selected_card == card:
                        del self._selected_cards[tab_name]
                return
                
            # Désélectionner toutes les cartes d'abord
            self._deselect_all_cards()
            
            # Déterminer l'onglet actif en fonction de l'index
            current_index = self.tab_widget.current_index
            tab_names = ['groups', 'channels', 'bots', 'chats']
            
            if 0 <= current_index < len(tab_names):
                current_tab = tab_names[current_index]
                
                # Vérifier si une carte est déjà sélectionnée dans cet onglet
                if current_tab in self._selected_cards and self._selected_cards[current_tab] is not None:
                    try:
                        self._selected_cards[current_tab].set_selected(False)
                    except Exception as e:
                        logging.error(f"Erreur lors de la désélection de la carte précédente: {e}")
                
                # Sélectionner la nouvelle carte
                self._selected_cards[current_tab] = card
                card.set_selected(True)
                logging.debug(f"Carte sélectionnée dans l'onglet {current_tab}: {entity_id}")
            else:
                logging.warning(f"Index d'onglet invalide: {current_index}")
            
            # Copier l'ID dans le presse-papiers
            self._copy_to_clipboard(str(entity_id))
            
        except Exception as e:
            logging.error(f"Erreur lors de la gestion du clic sur la carte: {e}", exc_info=True)
    
    def update_recent_activities(self, activities):
        """Met à jour la liste des activités récentes."""
        if not hasattr(self, 'recent_activities'):
            return
            
        if not activities:
            self.recent_activities.setText("Aucune activité récente")
            return
            
        activities_text = "\n".join(f"• {activity}" for activity in activities)
        self.recent_activities.setText(activities_text)
