"""Boîte de dialogue d'aide pour l'application."""
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QPushButton, QTextBrowser, QHBoxLayout
)
from PyQt6.QtCore import Qt, QUrl
from PyQt6.QtGui import QDesktopServices
from pathlib import Path

class HelpDialog(QDialog):
    """Boîte de dialogue affichant l'aide de l'application."""
    
    def __init__(self, parent=None):
        """Initialise la boîte de dialogue d'aide."""
        super().__init__(parent)
        self.setWindowTitle("Help - How to use the application")
        self.setMinimumSize(700, 600)
        self.setup_ui()
    
    def setup_ui(self):
        """Configure l'interface utilisateur de la boîte de dialogue."""
        layout = QVBoxLayout(self)
        
        # Zone de texte pour le contenu d'aide
        self.text_browser = QTextBrowser()
        self.text_browser.setOpenExternalLinks(True)
        self.text_browser.setOpenLinks(False)
        self.text_browser.anchorClicked.connect(self.on_link_clicked)
        
        # Style pour le texte d'aide
        help_text = """
        <h1>How to use the application</h1>
        
        <h2>Initial configuration</h2>
        <p>Before starting to use the application, you must configure your Telegram API identifiers :</p>
        <ol>
            <li>Go to <a href="https://my.telegram.org/">my.telegram.org</a> and log in with your Telegram account.</li>
            <li>Click on "API development tools".</li>
            <li>Fill in the form with the following information :
                <ul>
                    <li><strong>App title</strong> : The name of your application (for example "My Telegram Manager")</li>
                    <li><strong>Short name</strong> : A short name entirely in lowercase and without spaces (for example, "tmanager")</li>
                    <li><strong>Platform</strong> : Web</li>
                    <li><strong>Description</strong> : A short description of your application</li>
                </ul>
            </li>
            <li>After submission, you will receive an <strong>api_id</strong> and an <strong>api_hash</strong>.</li>
        </ol>
        
        <h2>Application configuration</h2>
        <p>Once your API identifiers are obtained :</p>
        <ol>
            <li>Click on the <strong>Settings</strong> button (gear icon).</li>
            <li>Fill in the fields with your API identifiers :
                <ul>
                    <li><strong>API ID</strong> : Your API identifier</li>
                    <li><strong>API Hash</strong> : Your API secret key</li>
                </ul>
            </li>
            <li>Click on <strong>Save</strong> to save the parameters.</li>
        </ol>
        
        <h2>Connect to your account</h2>
        <p>After configuring the parameters :</p>
        <ol>
            <li>Click on the <strong>Login</strong> button.</li>
            <li>Enter your phone number (in international format, e.g., +1234567890).</li>
            <li>Enter the confirmation code you will receive by Telegram.</li>
            <li>If you have enabled two-factor authentication, enter your password.</li>
        </ol>
        
        <h2>Useful links</h2>
        <ul>
            <li><a href="https://core.telegram.org/api/obtaining_api_id">Telegram API documentation</a></li>
            <li><a href="https://core.telegram.org/api">Telegram API documentation</a></li>
            <li><a href="https://my.telegram.org/apps">Manage your API applications</a></li>
        </ul>
        
        <p><strong>Note :</strong> Your API identifiers are stored locally on your computer and are not shared with third parties.</p>
        """
        
        self.text_browser.setHtml(help_text)
        
        # Bouton de fermeture
        button_box = QHBoxLayout()
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        button_box.addStretch()
        button_box.addWidget(close_button)
        
        # Ajout des widgets au layout
        layout.addWidget(self.text_browser)
        layout.addLayout(button_box)
    
    def on_link_clicked(self, url):
        """Ouvre les liens dans le navigateur par défaut."""
        QDesktopServices.openUrl(url)
