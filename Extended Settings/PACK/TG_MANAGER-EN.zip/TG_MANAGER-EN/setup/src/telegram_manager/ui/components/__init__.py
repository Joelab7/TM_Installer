"""
Composants d'interface utilisateur personnalisés pour l'application Telegram Manager.
"""

# Import des composants
try:
    from telegram_manager.ui.components.custom_tab_widget import CustomTabWidget
    
    __all__ = ['CustomTabWidget']
    
except ImportError as e:
    # En cas d'erreur d'importation, on essaie avec des chemins relatifs
    try:
        from .custom_tab_widget import CustomTabWidget
        
        __all__ = ['CustomTabWidget']
        
    except ImportError as ie:
        # Si les imports échouent, on définit les classes comme None
        CustomTabWidget = None
        
        import logging
        logging.error(f"Erreur lors du chargement des composants: {ie}")
        __all__ = []
