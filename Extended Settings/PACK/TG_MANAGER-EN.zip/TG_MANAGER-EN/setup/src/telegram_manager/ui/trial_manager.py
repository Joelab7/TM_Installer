"""Gestion de la période d'essai gratuite."""
import os
import json
import logging
from datetime import datetime, timedelta

class TrialManager:
    """Gestionnaire de la période d'essai gratuite."""
    
    def __init__(self, app_name="TelegramManager"):
        """Initialise le gestionnaire d'essai.
        
        Args:
            app_name: Nom de l'application pour le dossier de données
        """
        self.app_name = app_name
        self.app_data = os.getenv('APPDATA', os.path.expanduser('~'))
        
        # Créer le dossier principal de l'application s'il n'existe pas
        self.app_dir = os.path.join(self.app_data, self.app_name)
        os.makedirs(self.app_dir, exist_ok=True, mode=0o700)
        
        # Créer le sous-dossier des licences
        self.license_dir = os.path.join(self.app_dir, 'trial_license')
        os.makedirs(self.license_dir, exist_ok=True, mode=0o700)
        
        self.license_file = os.path.join(self.license_dir, 'trial_license.json')
    
    def is_trial_active(self):
        """Vérifie si un essai est actif.
        
        Returns:
            bool: True si un essai est actif, False sinon
        """
        if not os.path.exists(self.license_file):
            return False
            
        try:
            with open(self.license_file, 'r', encoding='utf-8') as f:
                license_data = json.load(f)
                end_date = datetime.fromisoformat(license_data['end_date'])
                return datetime.now() < end_date
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logging.debug(f"Erreur de lecture du fichier de licence: {e}")
            return False
    
    def get_trial_info(self):
        """Récupère les informations de l'essai.
        
        Returns:
            dict: Les informations de l'essai ou None si non trouvé
        """
        if not os.path.exists(self.license_file):
            return None
            
        try:
            with open(self.license_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError) as e:
            logging.debug(f"Erreur de lecture des informations d'essai: {e}")
            return None
    
    def start_trial(self, days=7):
        """Démarre une période d'essai.
        
        Args:
            days: Nombre de jours pour l'essai
            
        Returns:
            dict: Les informations de la licence d'essai
            
        Raises:
            IOError: Si l'écriture du fichier échoue
            Exception: Pour les autres erreurs inattendues
        """
        try:
            # Créer les dossiers avec les permissions appropriées
            os.makedirs(self.app_dir, exist_ok=True, mode=0o700)
            os.makedirs(self.license_dir, exist_ok=True, mode=0o700)
            
            # Vérifier les permissions d'écriture
            if not os.access(self.license_dir, os.W_OK):
                raise IOError(f"Permission refusée pour écrire dans {self.license_dir}")
            
            # Préparer les données de la licence
            start_date = datetime.now()
            license_data = {
                'trial_used': True,
                'start_date': start_date.isoformat(),
                'end_date': (start_date + timedelta(days=days)).isoformat(),
                'type': 'trial',
                'days': days
            }
            
            # Écrire de manière atomique
            temp_license_file = f"{self.license_file}.tmp"
            
            try:
                # Écrire d'abord dans un fichier temporaire
                with open(temp_license_file, 'w', encoding='utf-8') as f:
                    json.dump(license_data, f, indent=4, ensure_ascii=False)
                
                # Remplacer le fichier de manière atomique
                if os.path.exists(self.license_file):
                    os.replace(temp_license_file, self.license_file)
                else:
                    os.rename(temp_license_file, self.license_file)
                
                return license_data
                
            finally:
                # Nettoyer le fichier temporaire s'il existe encore
                if os.path.exists(temp_license_file):
                    try:
                        os.remove(temp_license_file)
                    except OSError:
                        pass  # Ignorer les erreurs de suppression du fichier temporaire
                        
        except Exception as e:
            logging.error("Erreur lors de la création de la licence d'essai", exc_info=True)
            raise