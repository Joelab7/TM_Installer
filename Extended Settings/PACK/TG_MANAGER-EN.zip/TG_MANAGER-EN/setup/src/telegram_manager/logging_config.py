"""
Configuration de la journalisation pour l'application Telegram Manager.
"""
import os
import logging
from pathlib import Path

def setup_logging():
    """Configure la journalisation pour l'application."""
    # Créer le répertoire de logs s'il n'existe pas
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    # Chemin du fichier de log
    log_file = log_dir / "telegram_manager.log"
    
    # Configuration de base
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(log_file, encoding='utf-8')
        ]
    )
    
    # Niveaux de log spécifiques pour certains modules
    logging.getLogger('telethon').setLevel(logging.WARNING)
    logging.getLogger('asyncio').setLevel(logging.WARNING)
    logging.getLogger('PIL').setLevel(logging.WARNING)
    
    # Activer le mode debug si la variable d'environnement est définie
    if os.environ.get('TELEGRAM_MANAGER_DEBUG'):
        logging.getLogger().setLevel(logging.DEBUG)
        logging.info("Mode debug activé")

# Appeler la configuration au chargement du module
setup_logging()

# Exporter le logger principal
logger = logging.getLogger("telegram_manager")
