"""Package principal de l'application Telegram Manager."""

__version__ = "0.1.0"
