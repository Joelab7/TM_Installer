"""
Gestion de l'identifiant unique de l'appareil.
"""
import os
import json
import uuid
from pathlib import Path
import datetime
from typing import Optional

def get_app_data_dir() -> Path:
    """Retourne le répertoire de données de l'application."""
    if os.name == 'nt':  # Windows
        app_data = os.getenv('APPDATA')
        if app_data:
            path = Path(app_data) / 'TelegramManager'
        else:
            path = Path.home() / '.telegram_manager'
    else:  # Linux/Mac
        path = Path.home() / '.config' / 'telegram_manager'
    
    path.mkdir(parents=True, exist_ok=True)
    return path

def get_or_create_device_id() -> str:
    """
    Récupère l'ID de l'appareil ou en crée un nouveau s'il n'existe pas.
    
    Returns:
        str: L'identifiant unique de l'appareil
    """
    config_dir = get_app_data_dir()
    config_file = config_dir / 'device.json'
    
    # Si le fichier existe, on lit l'ID
    if config_file.exists():
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                device_id = data.get('device_id')
                if device_id and isinstance(device_id, str):
                    return device_id
        except (json.JSONDecodeError, IOError):
            pass
    
    # Si on arrive ici, soit le fichier n'existe pas, soit il est invalide
    # On génère un nouvel ID
    device_id = str(uuid.uuid4())
    
    # On sauvegarde l'ID
    try:
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump({
                'device_id': device_id,
                'created_at': str(datetime.datetime.now().isoformat())
            }, f, indent=2)
    except IOError as e:
        # En cas d'erreur d'écriture, on utilise quand même l'ID généré
        # mais il ne sera pas persistant
        pass
    
    return device_id

def get_device_fingerprint() -> dict:
    """
    Crée une empreinte numérique de l'appareil.
    
    Returns:
        dict: Dictionnaire contenant des informations sur l'appareil
    """
    import platform
    import hashlib
    
    # Informations système de base
    system_info = {
        'system': platform.system(),
        'node': platform.node(),  # nom d'hôte
        'release': platform.release(),
        'version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor(),
    }
    
    # Création d'un hash des informations
    hash_obj = hashlib.sha256()
    for key, value in sorted(system_info.items()):
        hash_obj.update(f"{key}={value}".encode('utf-8'))
    
    return {
        'fingerprint': hash_obj.hexdigest(),
        'info': system_info
    }
