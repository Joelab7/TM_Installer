"""Configuration de l'application."""
import os
from pathlib import Path

# Dossier de base de l'application
BASE_DIR = Path(__file__).parent.parent

# Dossier pour les sessions Telegram
SESSION_DIR = BASE_DIR / 'sessions'
os.makedirs(SESSION_DIR, exist_ok=True)

# Configuration de la base de données
DATABASE_URL = 'sqlite:///telegram_manager.db'

# Configuration de l'API Telegram
TELEGRAM_API = {
    'api_id': '24198944',
    'api_hash': '170437ad9e983cbc4eba63af8ca03e4e',
}

# Configuration de l'application
APP_CONFIG = {
    'language': 'fr',
    'theme': 'light',
    'style': 'Fusion',
}

# Configuration des logs
LOG_CONFIG = {
    'level': 'INFO',
    'file': 'app.log',
    'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
}

# Classe de configuration principale
class Config:
    """Classe de configuration principale."""
    
    def __init__(self):
        self.BASE_DIR = BASE_DIR
        self.SESSION_DIR = SESSION_DIR
        self.DATABASE_URL = DATABASE_URL
        self.TELEGRAM_API = TELEGRAM_API
        self.APP_CONFIG = APP_CONFIG
        self.LOG_CONFIG = LOG_CONFIG
    
    def get(self, section: str, key: str, default=None):
        """Récupère une valeur de configuration."""
        section_upper = section.upper()
        if hasattr(self, section_upper):
            section_obj = getattr(self, section_upper, {})
            if isinstance(section_obj, dict):
                return section_obj.get(key, default)
        return default
