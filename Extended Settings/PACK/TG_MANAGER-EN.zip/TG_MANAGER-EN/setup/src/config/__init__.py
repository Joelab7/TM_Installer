"""Package de configuration de l'application."""

# Ce fichier rend le répertoire config un package Python
